(() => {
const RESOURCE_KEYS=["wood","wine","marble","crystal","sulfur"];
const clean=value=>String(value??"").replace(/\s+/g," ").trim();
// A negative value can come with a typographic minus or, in right-to-left text, with its minus at
// the end ("12-"); read as negative in the Firefox edition (satisfaction guard, 2026-10-20).
const firefoxEdition=()=>{try {return !/\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name??'');} catch {return true;}};
function numeric(value,{decimal=false}={}) {
  let text=clean(value).replace(/[\s\u00a0\u200e\u200f]/g,"");
  if(firefoxEdition()) {text=text.replace(/[\u2212\u2013]/g,"-");if(/^[\d.,]+-$/.test(text)) text="-"+text.slice(0,-1);}
  if(!text || !/^[+-]?[\d.,]+$/.test(text)) return null;
  let normalized=text;
  if(decimal) {
    const separator=text.includes(".")?".":text.includes(",")?",":null;
    if(separator && (text.includes(".") && text.includes(",") || /^[+-]?\d{1,3}([.,]\d{3})+$/.test(text))) normalized=text.replace(/[.,]/g,"");
    else normalized=text.replace(",",".");
  } else normalized=text.replace(/[.,]/g,"");
  return Number.isFinite(Number(normalized))?Number(normalized):null;
}
function viewHtml(source) {
  const text=String(source);
  const match=text.match(/ajax.Responder, (\[\[[\S\s]*?\]\])\);/);
  let response;
  try {response=JSON.parse(text.trim().startsWith("[")?text:match?.[1]??"null");} catch {return text;}
  if(!Array.isArray(response)) return text;
  const fragments=[];let nodes=0;
  const visit=(value,depth)=>{
    if(++nodes>10000 || depth>8) return;
    if(typeof value==="string" && /<(?:table|div|ul|span|li|section|p|h[1-6]|select|form|input|script)\b/i.test(value)) fragments.push(value);
    else if(Array.isArray(value)) value.forEach(child=>visit(child,depth+1));
    // Deliberately do not render arbitrary JS params or credentials.
  };
  response.filter(command=>["changeView","updateTemplateData","updateBackgroundData"].includes(command?.[0])).forEach(command=>visit(command[1],0));
  return fragments.join("\n");
}

function templateFields(source) {
 const text=String(source),match=text.match(/ajax.Responder, (\[\[[\S\s]*?\]\])\);/);
 let commands;try{commands=JSON.parse(text.trim().startsWith('[')?text:match?.[1]??'null');}catch{return {};}
 const fields={};for(const command of Array.isArray(commands)?commands:[])if(command?.[0]==='updateTemplateData'&&command[1]&&typeof command[1]==='object'&&!Array.isArray(command[1]))Object.assign(fields,command[1]);
 return fields;
}

function parseCityView(source) {
  const document=new DOMParser().parseFromString(viewHtml(source),"text/html");
  document.querySelectorAll("script,style,iframe,button,textarea,select,[type=password],[type=hidden]").forEach(node=>node.remove());
  const metrics=[];
  const field=(id,label,decimal=false)=>{
    const node=document.querySelector("#"+id),updated=templateFields(source)[id];
    const value=numeric(updated?.text??(typeof updated==='string'?updated:node?.textContent),{decimal});if(value!==null) metrics.push({key:id,label,value});
  };
  for(const [id,label,decimal] of [
    ["js_TownHallHappinessLargeValue","שביעות רצון",true],["js_TownHallPopulationGrowthValue","צמיחת אוכלוסייה לשעה",true],
    ["js_TownHallOccupiedSpace","אוכלוסייה כוללת",false],["js_TownHallMaxInhabitants","קיבולת אוכלוסייה",false],
    ["js_TownHallPopulationGraphScientistCount","מדענים",false],["js_TownHallPopulationGraphPriestCount","כוהנים",false],
    ["js_TownHallSatisfactionOverviewCultureBoniTreatyBonusValue","בונוס שביעות רצון מהסכמי תרבות",false],
    ["js_academy_research_tooltip_basic_production","ייצור מחקר בסיסי לשעה",true],
  ]) field(id,label,decimal);
  for(const [selector,key,label] of [["#inputWood","workersWood","עובדים במנסרה"],["#inputLuxury","workersLuxury","עובדים במשאב יוקרה"]]) {
    const input=document.querySelector(selector);if(!input) continue;
    const value=numeric(input.getAttribute("value"));if(value!==null) metrics.push({key,label,value});
    const max=numeric(input.getAttribute("max"));if(max!==null) metrics.push({key:key+"Max",label:"קיבולת "+label,value:max});
  }
  const tables=[];
  for(const table of Array.from(document.querySelectorAll("table")).slice(0,40)) {
    const rows=[];let columns=[];
    for(const row of Array.from(table.querySelectorAll("tr")).slice(0,200)) {
      const cells=Array.from(row.children).filter(node=>["TD","TH"].includes(node.tagName));
      const values=cells.map(cell=>{
        const copy=cell.cloneNode(true);copy.querySelectorAll("input,form").forEach(node=>node.remove());
        copy.querySelectorAll("img[alt]").forEach(image=>image.replaceWith(document.createTextNode(" "+image.getAttribute("alt")+" ")));
        return clean(copy.textContent);
      });
      if(!values.some(Boolean)) continue;
      if(!columns.length && cells.some(cell=>cell.tagName==="TH")) columns=values;
      else rows.push(values);
    }
    if(rows.length) {
      const width=Math.max(columns.length,...rows.map(row=>row.length));
      if(!columns.length) columns=Array.from({length:width},(_,index)=>index===0?"פרט":"ערך "+index);
      while(columns.length<width) columns.push("פרט נוסף");
      tables.push({columns,rows});
    }
  }
  const costs={};
  for(const item of document.querySelectorAll("#buildingUpgrade ul.resources li")) {
    const css=String(item.getAttribute("class")??"").split(/\s+/);
    const resource=RESOURCE_KEYS.find(key=>css.includes(key) || key==="crystal" && css.includes("glass"));
    if(!resource) continue;
    const title=String(item.getAttribute("title")??"").match(/\d[\d.,\s]*/)?.[0];
    const value=numeric(title??item.textContent);if(value!==null) costs[resource]=value;
  }
  // Preserve relevant server text (e.g. espionage status) without scripts,
  // links, form controls, hidden values or English-only assumptions.
  const notes=Array.from(document.querySelectorAll(".contentBox01h li, .contentBox01h p, .content .goods, .government_pic img"))
    .map(node=>node.tagName==="IMG"?clean(node.getAttribute("alt")??node.getAttribute("title")):clean(node.textContent))
    .filter(text=>text && text.length<=500).slice(0,50);
  // The upgrade's build time, as the game shows it next to the costs (unknown stays null).
  const time=document.querySelector("#buildingUpgrade ul.resources li.time, #buildingUpgrade .time");
  const durationMs=parseDuration(time?.getAttribute("title")?.match(/\d.*$/)?.[0]??time?.textContent);
  return {metrics,tables,costs,notes,durationMs};
}
// "1ש' 23ד'", "2h 5m 10s", "1d 3h" or "01:02:03" → milliseconds; anything else → null.
function parseDuration(value) {
  const text=clean(value);if(!text) return null;
  const clock=text.match(/^(\d+):(\d{2}):(\d{2})$/);
  if(clock) return ((Number(clock[1])*60+Number(clock[2]))*60+Number(clock[3]))*1000;
  let seconds=0,found=false;
  const rest=text.replace(/(\d+)\s*(days?|d|ימים|יום|י['׳]?|hours?|hrs?|h|שעות|שעה|שע['׳]?|ש['׳]?|minutes?|mins?|m|דקות|דקה|דק['׳]?|ד['׳]?|seconds?|secs?|s|שניות|שנייה|שנ['׳]?)(?=[\s\d.,]|$)/gi,(_,amount,unit)=>{
    const u=unit.replace(/['׳]$/,'').toLowerCase();
    seconds+=Number(amount)*(/^(days?|d|ימים|יום|י)$/.test(u)?86400:/^(hours?|hrs?|h|שעות|שעה|שע|ש)$/.test(u)?3600:/^(minutes?|mins?|m|דקות|דקה|דק|ד)$/.test(u)?60:1);found=true;return '';
  }).replace(/[\s,]+/g,'');
  return found&&!rest?seconds*1000:null;
}
function parseResourceCapacities(html) {
  const match=String(html).match(/maxResources:\s*JSON\.parse\('([^']+)'\)/);
  if(!match) return null;
  try {
    const raw=JSON.parse(match[1].replace(/\\"/g,'"'));
    const fields=[raw.resource,raw["1"],raw["2"],raw["3"],raw["4"]];
    if(fields.some(value=>value==null || value==="" || typeof value==="boolean")) return null;
    const values=fields.map(Number);
    if(values.some(value=>!Number.isSafeInteger(value) || value<0)) return null;
    return Object.fromEntries(RESOURCE_KEYS.map((key,index)=>[key,values[index]]));
  } catch {return null;}
}
function parseRecruitment(source) {
  const text=String(source),match=text.match(/ajax.Responder, (\[\[[\S\s]*?\]\])\);/);
  let response;
  try {response=JSON.parse(text.trim().startsWith("[")?text:match?.[1]??"null");} catch {return [];}
  if(!Array.isArray(response)) return [];
  const units={};
  for(const command of response??[]) {
    if(command?.[0]!=="updateTemplateData" || !command[1] || typeof command[1]!=="object") continue;
    for(const [key,value] of Object.entries(command[1])) {
      const match=key.match(/^js_barracks([A-Za-z]+?)(\d+)$/);if(!match) continue;
      units[match[2]]??={};units[match[2]][match[1]]=value;
    }
  }
  return Object.values(units).flatMap(unit=>{
    const unitClass=String(unit.UnitClass?.class??"").split(/\s+/).find(name=>/^(unit_|ship_)/.test(name));
    if(!unitClass) return [];
    const parsed=parseCityView(`<div id="buildingUpgrade"><ul class="resources">${unit.Costs?.text??""}</ul></div>`);
    const citizensDocument=new DOMParser().parseFromString(String(unit.Costs?.text??""),"text/html");
    const citizens=numeric(citizensDocument.querySelector("li.citizens")?.textContent);
    const locked=/\binvisible\b/.test(unit.BuyTextfieldContainer?.class??"") || !!clean(unit.ProblemTextfield?.text) ||
      !!unit.NoSliderLine?.class && !/\binvisible\b/.test(unit.NoSliderLine.class);
    const label=clean(unit.UnitName?.text??unit.UnitHelp?.title??unitClass);
    return [{label,unitClass,costs:parsed.costs,citizens,available:numeric(unit.UnitUnitsAvailable?.text),locked,
      reason:clean(unit.ProblemTextfield?.text),offense:clean(unit.OffUpgrade?.title),defense:clean(unit.DefUpgrade?.title)}];
  });
}

function parseDailyBonuses(source,now=Date.now()) {
 const document=new DOMParser().parseFromString(viewHtml(source),'text/html');
 const container=document.querySelector('#VideoRewards');
 const features=container?Array.from(container.querySelectorAll('li')).filter(node=>node.querySelector('form')||/js_nextPossible/.test(node.innerHTML)):[];
 return ['Resource','Tradegood','Favour','Ambrosia'].map((key,index)=>{
  const timer=document.querySelector('#js_nextPossible'+key),feature=features[index];
  const text=clean(timer?.textContent),clock=text.match(/^(?:(\d+)\s*(?:d|days?|יום|ימים)\s*)?(\d+):(\d{2}):(\d{2})$/i);
  let seconds=clock&&Number(clock[3])<60&&Number(clock[4])<60?Number(clock[1]??0)*86400+Number(clock[2])*3600+Number(clock[3])*60+Number(clock[4]):null;
  if(seconds===null&&/^(?:\d+\s*[dhms]\s*)+$/i.test(text)) seconds=Array.from(text.matchAll(/(\d+)\s*([dhms])/gi)).reduce((sum,match)=>sum+Number(match[1])*({d:86400,h:3600,m:60,s:1}[match[2].toLowerCase()]),0);
  // Hebrew servers: "11ש 54ד" (י = days, ש = hours, ד = minutes, שנ = seconds).
  if(seconds===null&&/^(?:\d+\s*(?:שנ|[ישד])['׳]?\s*)+$/.test(text)) seconds=Array.from(text.matchAll(/(\d+)\s*(שנ|[ישד])/g)).reduce((sum,match)=>sum+Number(match[1])*({'י':86400,'ש':3600,'ד':60,'שנ':1}[match[2]]),0);
  const available=!!feature?.querySelector('form input[name="videoId"]');
  return {id:51+index,key,label:['ייצור עץ','ייצור משאב יוקרה','נקודות חסד','אמברוסיה'][index],status:available?'available':timer?'cooldown':'unknown',nextAvailableAt:seconds===null?null:now+seconds*1000,remainingText:text||null};
 });
}
function parseProductionBonuses(source) {
 const document=new DOMParser().parseFromString(viewHtml(source),'text/html');
 const candidates=Array.from(document.querySelectorAll('tr,li,.bonus,.premiumFeature'));
 return candidates.flatMap(node=>{
  const text=clean(node.textContent);
  if(!/production|ייצור|תפוקה|wood bonus|wine bonus|marble bonus|crystal bonus|sulphur bonus|בונוס.*(?:עץ|יין|שיש|קריסטל|גופרית)/i.test(text))return [];
  const percentage=text.match(/([\d]+(?:[.,]\d+)?)\s*%/);
  const inactive=/inactive|not active|לא פעיל|אינו פעיל|לא מופעל/i.test(text+' '+node.className);
  const active=!inactive&&/\bactive\b|activated|מופעל|פעיל/i.test(text+' '+node.className);
  return [{label:text.slice(0,250),active:inactive?false:active?true:null,percent:percentage?Number(percentage[1].replace(',','.')):null}];
 }).filter((item,index,items)=>items.findIndex(other=>other.label===item.label)===index);
}


function parseResearchView(source) {
 let response;try{response=typeof source==='string'?JSON.parse(source):source;}catch{throw new Error('תגובת המחקר לא פוענחה');}
 const fields={};
 for(const command of Array.isArray(response)?response:[])if(['updateResearch','updateTemplateData'].includes(command?.[0])&&command[1]&&typeof command[1]==='object'&&!Array.isArray(command[1]))Object.assign(fields,command[1]);
 const text=value=>{
  if(value&&typeof value==='object')value=value.text??value.html??value.value;
  if(typeof value!=='string'&&typeof value!=='number')return 'לא עבר פענוח';
  return clean(new DOMParser().parseFromString('<div>'+String(value)+'</div>','text/html').querySelector('div')?.textContent)||'לא זמין';
 };
 const rows=Object.keys(fields).filter(key=>/^js_researchAdvisorChangeResearchTypeTxt\d+$/.test(key)).map(key=>{
  const index=key.match(/\d+$/)[0];return [text(fields[key]),text(fields['js_researchAdvisorNextResearchName'+index]),text(fields['js_researchAdvisorProgressTxt'+index])];
 });
 if(!rows.length)throw new Error('שדות המחקר אינם תואמים');
 return {rows};
}
function parseAcademyProduction(source) {
 const document=new DOMParser().parseFromString(viewHtml(source),'text/html');
 const fields=templateFields(source),basic=fields.js_academy_research_tooltip_basic_production;
 const base=numeric(basic?.text??(typeof basic==='string'?basic:document.querySelector('#js_academy_research_tooltip_basic_production')?.textContent),{decimal:true});
 const totals=Array.from(document.querySelectorAll('[id]')).filter(node=>/^js_academy_/i.test(node.id)&&/research/i.test(node.id)&&/production/i.test(node.id)&&/total|complete/i.test(node.id));
 const values=totals.map(node=>numeric(node.textContent,{decimal:true})).filter(value=>value!==null);
 for(const [key,value] of Object.entries(fields))if(/^js_academy_/i.test(key)&&/research/i.test(key)&&/production/i.test(key)&&/total|complete/i.test(key)){const parsed=numeric(value?.text??(typeof value==='string'?value:null),{decimal:true});if(parsed!==null)values.push(parsed);}
 const unique=[...new Set(values)];
 return {basePerHour:base,perHour:unique.length===1?unique[0]:null};
}

globalThis.IkariamReadInsights={parseDuration,parseResearchView,parseAcademyProduction,parseDailyBonuses,parseProductionBonuses,numeric,viewHtml,parseCityView,parseResourceCapacities,parseRecruitment};
})();

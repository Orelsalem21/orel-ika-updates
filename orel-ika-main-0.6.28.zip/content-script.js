// Isolated wrapper allows repair injection into an already-open game tab.
(() => {
if(globalThis.__ikariamAgentReaderVersion === "2026-10-05-read-jobs-v3") return;
globalThis.__ikariamAgentReaderVersion = "2026-10-05-read-jobs-v3";
// Read-only browser-session transport. Structured parsers follow the pinned Ikabot sources.
const LOG_PREFIX = "[ikariam-agent:content-script]";
console.log(LOG_PREFIX, "loaded on", location.href);

function decodeUnicodeEscape(input) {
  if (typeof input !== "string") return input;
  return input.replace(/u([0-9a-fA-F]{4})/g, (_match, hex) => String.fromCharCode(parseInt(hex, 16)));
}

// Ported from resources.py::getAvailableResources(html, num=True). Field
// mapping verified against the function's own return-order comment:
// Ikariam's internal keys are "resource"=wood, "1"=wine, "2"=marble,
// "3"=crystal, "4"=sulfur — NOT the numbers 1-4 in that order.
function parseAvailableResources(html) {
  const match = html.match(
    /\\"resource\\":(\d+),\\"2\\":(\d+),\\"1\\":(\d+),\\"4\\":(\d+),\\"3\\":(\d+)}/,
  );
  if (!match) return null;
  const [, wood, marble, wine, sulfur, crystal] = match;
  return {
    wood: Number(wood),
    wine: Number(wine),
    marble: Number(marble),
    crystal: Number(crystal),
    sulfur: Number(sulfur),
  };
}

// Ported from resources.py::getWarehouseCapacity(html).
function parseWarehouseCapacity(html) {
  const match = html.match(/maxResources:\s*JSON\.parse\('\{\\"resource\\":(\d+),/);
  return match ? Number(match[1]) : null;
}

// Ported from resources.py::getWineConsumptionPerHour(html).
function parseWineConsumptionPerHour(html) {
  const match = html.match(/wineSpendings:\s(\d+)/);
  return match ? Number(match[1]) : 0;
}

// Ported from getJson.py::getFreeCitizens(html) — not yet surfaced in the
// UI (population current/max aren't available from this page), kept here
// because it's a useful, already-verified signal for a future pass.
function parseFreeCitizens(html) {
  const match = html.match(/js_GlobalMenu_citizens">(.*?)<\/span>/);
  if (!match) return null;
  const digitsOnly = match[1].replace(/\D/g, "");
  return digitsOnly ? Number(digitsOnly) : null;
}

// Ported from getJson.py::getCity()'s position[] transform loop, verbatim
// logic (including the un-explained magic "-17" slice from the original
// Python — reproduced faithfully, not re-derived).
function transformPositions(rawPositions) {
  if (!Array.isArray(rawPositions)) return [];
  return rawPositions.map((raw, index) => {
    const position = { ...raw, position: index };
    if ("level" in position) position.level = parseInt(position.level, 10);
    position.isBusy = raw.isBusy===true || raw.isBusy===1 || raw.isBusy==="1";
    if (typeof position.building === "string" && position.building.includes("constructionSite")) {
      position.isBusy = true;
      position.building = position.building.slice(0, -17);
    } else if (typeof position.building === "string" && position.building.includes("buildingGround ")) {
      position.name = "empty";
      position.type = position.building.split(" ").pop();
      position.building = "empty";
    }
    return position;
  });
}

function parseCurrentPage(html = document.documentElement.outerHTML) {
  const match = html.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/);

  if (!match) {
    console.warn(
      LOG_PREFIX,
      'parse failed: "updateBackgroundData" block not found in the current page HTML',
      `(page length: ${html.length} chars)`,
    );
    return { found: false, reason: "parse_error" };
  }

  try {
    const city = JSON.parse(match[1]);
    const hostMatch = location.hostname.match(/^s(\d+)-(\w+)\.ikariam\.gameforge\.com$/);

    const resources = parseAvailableResources(html);
    const storageCapacity = parseWarehouseCapacity(html);
    const wineConsumptionPerHour = parseWineConsumptionPerHour(html);
    const freeCitizens = parseFreeCitizens(html);
    const buildings = transformPositions(city.position);

    const result = {
      found: true,
      ownerName: decodeUnicodeEscape(city.ownerName),
      cityId: city.id != null ? String(city.id) : null,
      cityName: decodeUnicodeEscape(city.name),
      x: city.islandXCoord != null ? Number(city.islandXCoord) : null,
      y: city.islandYCoord != null ? Number(city.islandYCoord) : null,
      mundo: hostMatch ? hostMatch[1] : null,
      servidor: hostMatch ? hostMatch[2] : null,
      resources,
      storageCapacity,
      wineConsumptionPerHour,
      freeCitizens,
      buildings,
    };
    console.log(LOG_PREFIX, "parsed successfully:", result);
    return result;
  } catch (error) {
    console.error(LOG_PREFIX, "JSON.parse of the matched block failed:", error, match[1]?.slice(0, 300));
    return { found: false, reason: "parse_error", error: String(error) };
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "IKARIAM_AGENT_PARSE_PAGE") {
    console.log(LOG_PREFIX, "received IKARIAM_AGENT_PARSE_PAGE request from background");
    const current=parseCurrentPage();
    if(current.found) {lastIdentity={page:current,at:Date.now()};sendResponse(current); return false;}
    // Another view on screen: the identity read in the last ten minutes answers at once instead of a
    // game request that may wait behind the tab's queue (user report, 2026-10-27).
    if(lastIdentity&&Date.now()-lastIdentity.at<600000) {sendResponse(lastIdentity.page); return false;}
    // Ikabot session.get() reads index.php when the current DOM is not a city view.
    (globalThis.IkariamPageFetch??fetch)("/index.php?view=city",{credentials:"same-origin",redirect:"error",signal:AbortSignal.timeout(10000)})
      .then(response=>{if(!response.ok) throw new Error("read failed");return response.text();})
      .then(html=>sendResponse(parseCurrentPage(html)),()=>sendResponse({found:false,reason:"parse_error"}));
    return true;
  }
  // No async work here, so no "return true" needed — sendResponse already
  // fired synchronously above.
});
async function resolveCurrentPage() {
  const current=parseCurrentPage();
  if(current.found) return current;
  const response=await (globalThis.IkariamPageFetch??fetch)("/index.php?view=city",{credentials:"same-origin",redirect:"error",signal:AbortSignal.timeout(10000)});
  if(!response.ok) throw new Error("לא ניתן לקרוא את מצב החיבור");
  return parseCurrentPage(await response.text());
}
// Account-wide, sequential read-only scan. Source: getStatus.collectData and
// pedirInfo.getIdsOfCities. Only view requests are sent; no action/function.
let snapshotFlight = null;
// The 48,000 policy and the panel both need the same full account scan (~200 requests).
// While one runs the other joins it, and a finished scan is kept per account (also across
// tab reloads) so the panel and the policy reuse it instead of queueing a second scan.
let enrichedFlight = null, lastEnriched = null;
async function cachedSnapshot(accountKey, maxAge, after = 0) {
  let entry = lastEnriched?.accountKey === accountKey ? lastEnriched : null;
  if (!entry) { try { entry = (await chrome.storage.local.get("account-snapshot-" + accountKey))["account-snapshot-" + accountKey] ?? null; } catch { entry = null; } }
  if (!entry?.snapshot || Date.now() - entry.at > maxAge || entry.at <= after) return null;
  return JSON.parse(JSON.stringify(entry.snapshot));
}
function sharedEnrichedSnapshot(onCityRead) {
  if (enrichedFlight) { if (onCityRead) enrichedFlight.listeners.add(onCityRead); return enrichedFlight.promise; }
  const listeners = new Set(onCityRead ? [onCityRead] : []);
  const promise = collectAccountSnapshot(true, (cities, total) => Promise.all([...listeners].map(listener => Promise.resolve(listener(cities, total)).catch(() => {}))))
    .then(async snapshot => {
      const page = parseCurrentPage(), accountKey = [snapshot.ownerName, page.mundo, page.servidor].join("|");
      lastEnriched = {at: Date.now(), accountKey, snapshot: JSON.parse(JSON.stringify(snapshot))};
      try { await chrome.storage.local.set({["account-snapshot-" + accountKey]: lastEnriched}); } catch { /* Cache only. */ }
      return snapshot;
    })
    .finally(() => { enrichedFlight = null; });
  enrichedFlight = {promise, listeners};
  return promise;
}
async function readAccountSnapshot() {
  if (snapshotFlight) return snapshotFlight;
  snapshotFlight = scheduleRead(()=>collectAccountSnapshot(true),'קריאת ערים',{priority:true,yieldable:true}).finally(() => { snapshotFlight = null; });
  return snapshotFlight;
}
async function collectAccountSnapshot(enrich=false,onCityRead=null) {
  const initial = await resolveCurrentPage();
  if (!initial.found || !initial.cityId) throw new Error("לא זוהתה עיר מחוברת");
  let token = document.documentElement.outerHTML.match(/actionRequest"?:\s*"([^"]+)"/)?.[1];
  let requests = 0;
  async function read(params) {
    if (++requests > (enrich?200:150)) throw new Error("חריגה ממגבלת בקשות הסריקה");
    await new Promise(resolve => setTimeout(resolve, 550));
    const response = await (globalThis.IkariamPageFetch??fetch)("/index.php?" + new URLSearchParams(params), {
      credentials: "same-origin", redirect: "error", signal: AbortSignal.timeout(15000),
    });
    if (!response.ok) throw new Error("קריאת המשחק נכשלה (" + response.status + ")");
    const html = await response.text();
    const nextToken = html.match(/actionRequest"?:\s*"([^"]+)"/)?.[1];
    if (nextToken) token = nextToken;
    if (/TXT_ERROR_WRONG_REQUEST_ID|logoutAvatar|Gameforge Login/.test(html) && !html.includes("updateBackgroundData"))
      throw new Error("החיבור למשחק פג או שהתגובה אינה תקינה");
    return html;
  }
  const home = await read({view: "city", cityId: initial.cityId});
  const m = home.match(/relatedCityData:\s*JSON\.parse\('(.+?),\\"additionalInfo/);
  if (!m) throw new Error("לא ניתן לפענח את רשימת הערים; לא תוצג רשימה חלקית");
  const related = JSON.parse((m[1] + "}").replace(/\\/g, "").replace(/city_/g, ""));
  const ids = Object.keys(related).filter(id => related[id].relationship === "ownCity");
  if (!ids.length || ids.length > 60) throw new Error("רשימת הערים אינה תקינה");
  const cities = [];
  let header = null;
  try {
    for (const id of ids) {
      const html = id === initial.cityId ? home : await read({view: "city", cityId: id});
      const match = html.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/);
      if (!match) throw new Error("לא ניתן לפענח עיר " + id);
      const raw = JSON.parse(match[1]);
      if (String(raw.id) !== id || decodeUnicodeEscape(raw.ownerName) !== initial.ownerName) {
        const detail = "ביקשנו עיר " + id + " של " + initial.ownerName + ", התקבלה עיר " + raw.id + " של " + decodeUnicodeEscape(raw.ownerName ?? "לא ידוע");
        console.warn(LOG_PREFIX, "account/city mismatch", {detail, pageFetch: typeof globalThis.cloneInto === "function" && typeof globalThis.content?.fetch === "function"});
        // Same own city, different owner name: the player was renamed after the tab loaded.
        if (String(raw.id) === id && ids.includes(id)) {
          const error = new Error("שם השחקן השתנה מ־" + initial.ownerName + " ל־" + decodeUnicodeEscape(raw.ownerName ?? "") + ", והלשונית עדיין מציגה את השם הקודם. יש לרענן את לשונית החשבון.");
          error.code = "renamed";throw error;
        }
        throw new Error("זוהתה אי התאמה בין החשבון לעיר (" + detail + ")");
      }
      const number = value => value === undefined || value === null || value === "" ? null :
        Number.isFinite(Number(value)) ? Number(value) : null;
      async function readHeader() {
        const global = JSON.parse(await read({view: "updateGlobalData", ajax: "1"}));
        const header = global?.[0]?.[1]?.headerData;
        if (!header || Number(header.relatedCity?.owncity) !== 1 || !header.currentResources)
          throw new Error("לא ניתן לאמת את נתוני העיר " + id);
        if (header.relatedCity.id != null && String(header.relatedCity.id) !== id)
          throw new Error("נתוני הכותרת שייכים לעיר אחרת");
        const c = header.currentResources;
        const stock = {wood:number(c.resource), wine:number(c["1"]), marble:number(c["2"]), crystal:number(c["3"]), sulfur:number(c["4"])};
        if (Object.values(stock).some(v => v === null)) throw new Error("משאבים חסרים בעיר " + id);
        return {header, stock};
      }
      // The stock embedded in the city page is authoritative (Ikabot getCity /
      // getAvailableResources). The header may still describe the previously
      // selected city when the game omits relatedCity.id: re-select once, and if it
      // still disagrees, header-only values for this city stay undecoded.
      const page = parseAvailableResources(html);
      const agrees = stock => !page || Object.keys(page).every(key => Math.abs(stock[key] - page[key]) <= Math.max(100, page[key] * 0.01));
      let {header: h, stock: headerStock} = await readHeader();
      let staleHeader = false;
      if (!agrees(headerStock)) {
        await read({view: "city", cityId: id});
        ({header: h, stock: headerStock} = await readHeader());
        staleHeader = !agrees(headerStock);
      }
      const r = h.currentResources;
      const resources = page ?? headerStock;
      const resourceCheck = {pageReadable: !!page, staleHeader,
        mismatches: staleHeader ? Object.keys(page).filter(key => Math.abs(headerStock[key] - page[key]) > Math.max(100, page[key] * 0.01)).map(key => ({resource:key, header:headerStock[key], page:page[key]})) : []};
      const production = {wood:null, wine:null, marble:null, crystal:null, sulfur:null};
      production.wood = staleHeader || number(h.resourceProduction) === null ? null : number(h.resourceProduction) * 3600;
      const good = ["wood", "wine", "marble", "crystal", "sulfur"][Number(h.producedTradegood)];
      if (good) {
        for(const key of ["wine","marble","crystal","sulfur"]) production[key]=0;
        production[good] = staleHeader || number(h.tradegoodProduction) === null ? null : number(h.tradegoodProduction) * 3600;
      }
      let civic=null,civicWarning=null;
      if(enrich && globalThis.IkariamReadInsights && token) {
        try {
          const parsed=globalThis.IkariamReadInsights.parseCityView(await read({view:"townHall",cityId:id,position:0,backgroundView:"city",currentCityId:id,actionRequest:token,ajax:1}));
          civic=Object.fromEntries(parsed.metrics.map(item=>[item.key,item.value]));
          if(!Object.keys(civic).length) civicWarning="פרטי האוכלוסייה והעובדים לא פוענחו";
        } catch {civicWarning="קריאת בית העירייה לא הושלמה";}
      }
      let researchProduction=null;
      const academy=transformPositions(raw.position).find(building=>building.building==="academy");
      if(enrich&&academy&&globalThis.IkariamReadInsights)try {
        researchProduction=globalThis.IkariamReadInsights.parseAcademyProduction(await read({view:"academy",cityId:id,position:academy.position,currentCityId:id,backgroundView:"city",ajax:1}));
      }catch { /* A missing academy rate must stay unknown. */ }
      cities.push({
        id, name:decodeUnicodeEscape(raw.name), coordinates:related[id].coords,
        islandId:raw.islandId!=null?String(raw.islandId):null,isCapital:raw.isCapital===true || raw.isCapital===1 || raw.isCapital==="1",
        resources, storageCapacity:parseWarehouseCapacity(html),
        resourceCapacities:globalThis.IkariamReadInsights?.parseResourceCapacities(html)??null,
        population:{current:civic?.js_TownHallOccupiedSpace??null,max:civic?.js_TownHallMaxInhabitants??null,satisfaction:civic?.js_TownHallHappinessLargeValue??null},
        freeCitizens:number(r.citizens),populationGrowthPerHour:civic?.js_TownHallPopulationGrowthValue??null,
        scientists:civic?.js_TownHallPopulationGraphScientistCount??null,priests:civic?.js_TownHallPopulationGraphPriestCount??null,
        workers:{wood:civic?.workersWood??null,luxury:civic?.workersLuxury??null,maxWood:civic?.workersWoodMax??null,maxLuxury:civic?.workersLuxuryMax??null},
        civicWarning,
        researchProduction,productionPerHour:production, tradegood:good ?? null,
        wineConsumptionPerHour:staleHeader?null:number(h.wineSpendings),
        buildings:transformPositions(raw.position),
        tradeShips:{available:number(h.freeTransporters), total:number(h.maxTransporters)},
        resourceCheck,
        freighters:{available:number(html.match(/GlobalMenu_freeFreighters">(\d+)</)?.[1]),total:number(html.match(/maxFreighters">(\d+)</)?.[1])},
      });
      header = h;
      if(onCityRead) await onCityRead(cities,ids.length);
      // A complete city is a safe boundary: the next read selects its city again and
      // obtains a fresh token. Never yield between a city selection and its header.
      await yieldToPirates();
    }
  } finally {
    // Reading a city view changes the server's selected-city context. Restore it.
    await read({view:"city", cityId:initial.cityId});
  }
  const n = value => value == null || value === "" ? null : Number.isFinite(Number(value)) ? Number(value) : null;
  const incomeParts = ["income", "godGoldResult", "badTaxAccountant", "upkeep", "scientistsUpkeep"].map(key => n(header[key]));
  return {ownerName:initial.ownerName, cities, gold:n(header.gold),
    goldProductionPerHour:incomeParts.every(v => v !== null) ? incomeParts.reduce((a,b)=>a+b,0) : null,
    scannedAt:new Date().toISOString()};
}
const activeAccountJobs=new Set();
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if(message?.type==='IKARIAM_AGENT_READ_ACCOUNT_JOB') {
    const id=message.requestId;
    if(typeof id!=='string'||!/^[a-zA-Z0-9-]{1,80}$/.test(id)||typeof message.accountKey!=='string') {sendResponse({ok:false,reason:'מזהה קריאה אינו תקין'});return false;}
    const key='account-read-'+id;
    if(activeAccountJobs.has(id)) {sendResponse({ok:true,accepted:true});return false;}
    activeAccountJobs.add(id);
    chrome.storage.local.get(key).then(async stored=>{
      const all=await chrome.storage.local.get(null);
      const stale=Object.keys(all).filter(name=>name.startsWith('account-read-')&&name!==key&&!activeAccountJobs.has(name.slice('account-read-'.length))&&Date.now()-(all[name]?.updatedAt??0)>600000);
      if(stale.length) await chrome.storage.local.remove(stale);
      const saved=stored[key];
      if(saved?.accountKey && saved.accountKey!==message.accountKey) throw new Error('הקריאה שייכת לחשבון אחר');
      if(saved?.status==='complete') {activeAccountJobs.delete(id);sendResponse({ok:true,accepted:true});return;}
      await chrome.storage.local.set({[key]:{status:'pending',accountKey:message.accountKey,updatedAt:Date.now(),progress:{stage:'ממתין לתור הקריאות בלשונית',done:0,total:null,startedAt:Date.now()}}});
      sendResponse({ok:true,accepted:true});
      const progress=(cities,total)=>chrome.storage.local.set({[key]:{status:'pending',accountKey:message.accountKey,updatedAt:Date.now(),
          progress:{stage:'נקראה העיר '+cities.at(-1).name,done:cities.length,total,startedAt:Date.now()}}}).catch(()=>{});
      const recent=message.force?null:await cachedSnapshot(message.accountKey,mainEdition()?600000:300000);
      const reuse=async()=>{
        const page=await resolveCurrentPage();
        if([page.ownerName,page.mundo,page.servidor].join('|')!==message.accountKey) throw new Error('החשבון במשחק השתנה; יש להתחבר מחדש');
        const snapshot=recent??await sharedEnrichedSnapshot(progress);
        if(snapshot.ownerName!==page.ownerName) throw new Error('החשבון השתנה במהלך הסריקה');
        return snapshot;
      };
      let started=false;
      const waiting=()=>setTimeout(async()=>{if(started)return;
        const current=(await chrome.storage.local.get(key).catch(()=>({})))[key];if(started||current?.status!=='pending')return;
        chrome.storage.local.set({[key]:{status:'pending',accountKey:message.accountKey,updatedAt:Date.now(),progress:{stage:readQueueStatus(),done:0,total:null,startedAt:Date.now()}}}).catch(()=>{});waiting();},5000);
      if(!recent&&!enrichedFlight)waiting();
      void (recent||enrichedFlight?reuse():scheduleRead(async()=>{
        started=true;
        const page=await resolveCurrentPage();
        if([page.ownerName,page.mundo,page.servidor].join('|')!==message.accountKey) throw new Error('החשבון במשחק השתנה; יש להתחבר מחדש');
        const startedAt=Date.now();
        // Publish per-city progress so the panel can show how long the read will take.
        const snapshot=await sharedEnrichedSnapshot((cities,total)=>chrome.storage.local.set({[key]:{status:'pending',accountKey:message.accountKey,updatedAt:Date.now(),
          progress:{stage:'נקראה העיר '+cities.at(-1).name,done:cities.length,total,startedAt}}}).catch(()=>{}));
        const after=await resolveCurrentPage();
        if([after.ownerName,after.mundo,after.servidor].join('|')!==message.accountKey||snapshot.ownerName!==page.ownerName) throw new Error('החשבון השתנה במהלך הסריקה');
        return snapshot;
      },"קריאת החשבון למסך",{priority:true,yieldable:true})).then(snapshot=>chrome.storage.local.set({[key]:{status:'complete',ok:true,snapshot,accountKey:message.accountKey,updatedAt:Date.now()}}),
        error=>chrome.storage.local.set({[key]:{status:'complete',ok:false,reason:error.message,retryable:/Failed to fetch|fetch failed|network|timeout|timed out|abort|\(50[234]\)/i.test(error.name+' '+error.message),accountKey:message.accountKey,updatedAt:Date.now()}}))
        .catch(()=>console.warn(LOG_PREFIX,'read result could not be stored; the page may have refreshed'))
        .finally(()=>activeAccountJobs.delete(id));
    }).catch(error=>{activeAccountJobs.delete(id);sendResponse({ok:false,reason:error.message});});return true;
  }
  if (message?.type !== "IKARIAM_AGENT_READ_ACCOUNT") return false;
  readAccountSnapshot().then(snapshot => sendResponse({ok:true,snapshot}),
    () => sendResponse({ok:false,reason:"קריאת החשבון נכשלה. החיבור או מבנה תגובת המשחק אינם תואמים; לא יוצגו נתוני דמו."}));
  return true;
});

async function collectCityReadView(cityId,kind,position) {
  if(typeof cityId!=="string" || !/^\d+$/.test(cityId) || !["civic","building","island","military"].includes(kind)) throw new Error("בקשת פרטי עיר אינה תקינה");
  const initial=await resolveCurrentPage();
  if(!initial.found) throw new Error("יש להתחבר לחשבון במשחק");
  let token,count=0;
  async function read(params) {
    if(++count>35) throw new Error("סריקת העיר הגיעה למגבלת בקשות");
    await new Promise(resolve=>setTimeout(resolve,550));
    const response=await (globalThis.IkariamPageFetch??fetch)("/index.php?"+new URLSearchParams(params),{credentials:"same-origin",redirect:"error",signal:AbortSignal.timeout(15000)});
    if(!response.ok) throw new Error("קריאת פרטי העיר נכשלה");
    const text=await response.text();token=text.match(/actionRequest"?:\s*"([^"]+)"/)?.[1]??token;return text;
  }
  try {
    const html=await read({view:"city",cityId});
    const match=html.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/);
    if(!match) throw new Error("נתוני העיר אינם תואמים");
    const city=JSON.parse(match[1]);
    if(String(city.id)!==cityId || decodeUnicodeEscape(city.ownerName)!==initial.ownerName) throw new Error("ניתן לקרוא פרטי ערים של החשבון המחובר בלבד");
    const groups=[],base={cityId,currentCityId:cityId,backgroundView:"city",ajax:1};
    if(kind==="island") {
      if(!/^\d+$/.test(String(city.islandId))) throw new Error("מזהה האי חסר");
      const source=await read({view:"island",islandId:city.islandId,ajax:1,...(token?{actionRequest:token}:{})});
      const data=source.match(/ajax.Responder, (\[\[[\S\s]*?\]\])\);/);
      const response=JSON.parse(data?.[1]??source),island=response?.[1]?.[1];
      if(!island || String(island.id)!==String(city.islandId) || !Array.isArray(island.cities)) throw new Error("פרטי האי אינם תואמים");
      const rows=[];
      for(const place of island.cities.filter(place=>place.type==="city").slice(0,30)) {
        let score="לא זמין";
        try {
          const parsed=globalThis.IkariamReadInsights.viewHtml(await read({view:"cityDetails",destinationCityId:place.id,ajax:1}));
          const document=new DOMParser().parseFromString(parsed,"text/html");
          const value=globalThis.IkariamReadInsights.numeric(document.querySelector("#js_selectedCityScore")?.textContent);
          if(value!==null) score=String(value);
        } catch { /* Other public fields remain useful if the score read fails. */ }
        rows.push([textOnly(decodeUnicodeEscape(place.name)),textOnly(decodeUnicodeEscape(place.ownerName??place.Name)),String(place.level??"לא זמין"),textOnly(place.ownerAllyTag??place.AllyTag??""),textOnly(place.state??""),score]);
      }
      groups.push({id:"island",title:"ערים באי",columns:["עיר","שחקן","רמת עיר","ברית","מצב","ניקוד"],rows,note:"מידע ציבורי שמוחזר על ידי המשחק; ניקוד שלא נקרא מסומן כלא זמין."});
      groups.push({id:"island-info",title:"פרטי האי",columns:["פרט","ערך"],rows:[["שם",textOnly(decodeUnicodeEscape(island.name))],["מיקום",`[${island.xCoord}:${island.yCoord}]`],
        ["רמת מנסרה",String(island.woodLv??"לא זמין")],["רמת מכרה יוקרה",String(island.goodLv??"לא זמין")],["רמת פלא",String(island.wonderLv??"לא זמין")]],note:"רמות מוצגות רק כששדות הרמה מופיעים בתשובה."});
    } else {
      let view="townHall",index=0;
      if(kind==="military") view="cityMilitary";
      if(kind==="building") {
        if(!Number.isSafeInteger(position) || position<0 || position>60) throw new Error("מיקום המבנה אינו תקין");
        const building=transformPositions(city.position).find(item=>item.position===position);
        if(!building || building.building==="empty" || !/^[a-zA-Z][a-zA-Z0-9]*$/.test(building.building)) throw new Error("המבנה אינו קיים בעיר");
        view=building.building==="hideout"?"safehouse":building.building;index=position;
      }
      if(!token) throw new Error("לא נמצא טוקן לקריאת פרטי המבנה");
      const source=await read({...base,view,position:index,actionRequest:token});
      const parsed=globalThis.IkariamReadInsights.parseCityView(source);
      if(parsed.metrics.length) groups.push({id:"metrics",title:"נתוני עיר ומבנה",columns:["פרט","ערך"],rows:parsed.metrics.map(item=>[item.label,String(item.value)]),note:"ערכים מתוך תשובת המשחק, ללא שינוי עובדים או ייצור."});
      if(Object.keys(parsed.costs).length) groups.push({id:"costs",title:"עלות השדרוג הבא",columns:["משאב","עלות","מלאי זמין","חסר","מצב"],rows:Object.entries(parsed.costs).map(([resource,cost])=>{
        const stock=parseAvailableResources(html)?.[resource];return [({wood:"עץ",wine:"יין",marble:"שיש",crystal:"קריסטל",sulfur:"גופרית"})[resource],String(cost),stock==null?"לא זמין":String(stock),stock==null?"לא זמין":String(Math.max(0,cost-stock)),stock==null?"לא ניתן לחשב":stock>=cost?"יש מספיק":"חסרים משאבים"];
      }),note:"העלות נקראת מהמשחק; לא נעשה שימוש בטבלאות עלויות של תוסף אחר."});
      const units=globalThis.IkariamReadInsights.parseRecruitment(source);
      if(units.length) groups.push({id:"recruitment",title:"פרטי יחידות וספינות",columns:["יחידה / ספינה","זמינות מדווחת","עלות ליחידה","אזרחים ליחידה","מצב גיוס","שדרוג התקפה","שדרוג הגנה"],rows:units.map(unit=>[
        unit.label,unit.available==null?"לא זמין":String(unit.available),Object.entries(unit.costs).map(([key,amount])=>({wood:"עץ",wine:"יין",marble:"שיש",crystal:"קריסטל",sulfur:"גופרית"}[key])+": "+amount).join(" · ")||"לא זמין",
        unit.citizens==null?"לא זמין":String(unit.citizens),unit.locked?unit.reason||"הגיוס חסום":"אפשרות גיוס מוצגת במשחק",unit.offense||"לא זמין",unit.defense||"לא זמין",
      ]),note:"נתוני מגורי החיילים או המספנה; קריאה בלבד, ללא גיוס או שינוי תור."});
      parsed.tables.forEach((table,index)=>groups.push({id:"table-"+index,title:"מידע מהמשחק · "+(index+1),...table,note:"קריאה בלבד. כפתורים, טפסים, קישורים וסקריפטים אינם מועתקים."}));
      if(parsed.notes.length) groups.push({id:"notes",title:"סטטוסים נוספים",columns:["מידע"],rows:parsed.notes.map(text=>[text]),note:"הטקסט כפי שהמשחק מחזיר בשפת החשבון."});
    }
    if(!groups.length) throw new Error("פרטי התצוגה לא פוענחו; אין להסיק מכך שהערכים הם אפס");
    return {groups,columns:groups[0].columns,rows:groups[0].rows,note:"קריאת מידע מהמשחק בלבד",updatedAt:new Date().toISOString()};
  } finally {await read({view:"city",cityId:initial.cityId});}
}

// One job at a time per tab. What the user asked for on screen (priority) goes before the
// automations still waiting, right after the job that is running.
const readJobs = [];
let readBusy = false;
// Read as a passing read failure by the automations: the stopped job is simply tried again.
const STOP_MESSAGE = "קריאת המשחק נכשלה — המשימה נעצרה לבקשתך ותרוץ שוב בבדיקה הבאה";
// Which job holds this tab's read queue, since when, and how many wait (shown in the panel).
let readRunning = null, readWaiting = 0;
function scheduleRead(job, label = "קריאה", {priority = false, urgent = false, operationId = null, yieldable = false, pirate = false, user = false} = {}) {
  return new Promise((resolve, reject) => {
    const entry = {job, label, priority, operationId, yieldable, pirate, user, resolve, reject};
    const first = readJobs.findIndex(item => !item.priority);
    if (urgent) readJobs.unshift(entry); else if (priority && first >= 0) readJobs.splice(first, 0, entry); else readJobs.push(entry);
    // No job is stopped automatically for a raid (user report, 2026-10-18): a round checks every
    // minute or two, so the balancing scan that completes the buildings was cut again and again and
    // never finished. The user stops a running job from the raids panel when he chooses to.
    readWaiting = readJobs.length;
    void pumpReads();
  });
}
async function pumpReads() {
  if (readBusy) return;
  readBusy = true;
  try {
    while (readJobs.length) {
      const entry = readJobs.shift();readWaiting = readJobs.length;
      readRunning = {label: entry.label, since: Date.now(), operationId: entry.operationId, yieldable: entry.yieldable, posted: false, stop: null};
      globalThis.IkariamCurrentJob = readRunning;
      try { entry.resolve(await entry.job()); } catch (error) { entry.reject(error); }
      globalThis.IkariamCurrentJob = null;readRunning = null;
    }
  } finally { readBusy = false; }
}
// Cooperative scheduling, Opera only: a scan keeps its stack and progress while
// at most two pirate jobs run at an explicit safe boundary. No concurrent fetches.
// A building run (a city read and one upgrade) steps in the same way (user report, 2026-10-29: the 48,000
// balancing held the tab while the builders stood idle).
// The user's own requests from the panel go first (user decision, 2026-10-27: "verify in game" waited
// behind a whole account read and was reported as a closed tab).
// Firefox too (user decision, 2026-10-30: the next capture leaves within seconds of the crew's return; a balancing
// scan or a shipment held it for up to four minutes).
async function yieldToPirates() {
  if(!readRunning?.yieldable) return;
  const parent=readRunning;
  try {
    for(let count=0;count<2;count++) {
      const user=readJobs.findIndex(entry=>entry.user),index=user>=0?user:readJobs.findIndex(entry=>entry.pirate);
      if(index<0) break;
      const [entry]=readJobs.splice(index,1);readWaiting=readJobs.length;
      readRunning={label:entry.label,since:Date.now(),operationId:entry.operationId,yieldable:false,posted:false,stop:null};
      globalThis.IkariamCurrentJob=readRunning;
      try {entry.resolve(await entry.job());} catch(error) {entry.reject(error);}
    }
  } finally {readRunning=parent;globalThis.IkariamCurrentJob=parent;readWaiting=readJobs.length;}
}
async function pirateTiming(accountKey,entry) {
  const key='pirate-timing-v1-'+accountKey,list=(await chrome.storage.local.get(key))[key]??[];
  await chrome.storage.local.set({[key]:[...list,entry].slice(-200)});
}
let lastIdentity=null;
// For the load diagnostics in page-fetch.js: which account this tab is, and its queue.
let diagAccount=null;
globalThis.IkariamDiagAccount=()=>{if(diagAccount)return diagAccount;const page=parseCurrentPage();if(page?.found&&page.ownerName)diagAccount=[page.ownerName,page.mundo,page.servidor].join('|');return diagAccount;};
globalThis.IkariamDiagQueue=()=>({running:readRunning?.label??null,runningForSec:readRunning?Math.round((Date.now()-readRunning.since)/1000):0,waiting:readJobs.length,labels:readJobs.slice(0,5).map(item=>item.label)});
function readQueueStatus() {
  if (!readRunning) return "ממתין לתור הקריאות בלשונית";
  const elapsed = Math.floor((Date.now() - readRunning.since) / 1000);
  return "ממתין לתור — כרגע רץ בלשונית: " + readRunning.label + " (" + Math.floor(elapsed / 60) + ":" + String(elapsed % 60).padStart(2, "0") + " דקות)" + (readWaiting > 1 ? " · " + (readWaiting - 1) + " נוספים בתור" : "");
}
function textOnly(html) {
  const doc = new DOMParser().parseFromString(String(html), "text/html");
  doc.querySelectorAll("script,style").forEach(element => element.remove());
  return doc.body.textContent.replace(/\s+/g," ").trim();
}

function parseMilitaryTable(html) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  const entries = [];
  const tables = Array.from(doc.querySelectorAll("table"));
  const numeric = cell => {
    if (!cell) return null;
    const copy = cell.cloneNode(true);
    copy.querySelectorAll(".tooltip,script,style").forEach(node => node.remove());
    const text = copy.textContent.trim();
    if (!/^\d[\d.,\s\u00a0\u202f]*$/.test(text)) return null;
    const count = Number(text.replace(/[.,\s\u00a0\u202f]/g, ""));
    return Number.isSafeInteger(count) ? count : null;
  };
  const cells = row => Array.from(row.children).filter(node => /^(TD|TH)$/.test(node.tagName));
  for (const table of tables) {
    const rows = Array.from(table.querySelectorAll("tr")).filter(row => row.closest("table") === table);
    for (let rowIndex = 0; rowIndex < rows.length; rowIndex++) {
      const rowCells = cells(rows[rowIndex]);
      const labeled = rowCells.map((cell,index) => ({cell,index,tooltip:cell.querySelector(".tooltip")}))
        .filter(item => item.tooltip && item.tooltip.closest("table") === table);
      if (!labeled.length) continue;
      const paired = [];
      for (const {cell,index,tooltip} of labeled) {
        const name = decodeUnicodeEscape(tooltip.textContent.trim());
        if (!name) continue;
        // Some responses put label+count together, others use header and
        // quantity rows; never zip unrelated tooltips from the whole page.
        let count = numeric(cell);
        if (count === null && labeled.length === 1) {
          const candidates = rowCells.filter(candidate => candidate !== cell)
            .map(numeric).filter(value => value !== null);
          if (candidates.length === 1) count = candidates[0];
        }
        if (count === null) {
          for (let next = rowIndex + 1; next < rows.length; next++) {
            const nextCells = cells(rows[next]);
            // A new header starts a new unit group.
            if (nextCells.some(candidate => candidate.querySelector(".tooltip"))) break;
            count = numeric(nextCells[index]);
            if (count !== null) break;
          }
        }
        if (count === null) continue;
        const classes = [cell.getAttribute("class") ?? "", ...Array.from(cell.querySelectorAll("[class]"))
          .map(node => node.getAttribute("class") ?? "")].join(" ");
        const kind = /(?:^|\s)ship_/.test(classes) ? "fleet" :
          /(?:^|\s)unit_/.test(classes) ? "army" : null;
        paired.push({name,count,kind});
      }
      // A military header may not be partially read: unknown counts are
      // missing data, not zero. Ignore unrelated fully nonnumeric rows.
      if (paired.length && paired.length !== labeled.length)
        throw new Error("לא ניתן לקרוא את כל הכמויות בטבלת היחידות");
      entries.push(...paired);
    }
  }
  if (!entries.length) throw new Error("לא נמצאה טבלת יחידות עם כמויות שניתן לקרוא");
  // Keep upstream's documented 15-ground-unit boundary ONLY when a complete
  // combined table is available. Explicit CSS markers handle separate tables.
  if (entries.some(entry => entry.kind === null) && entries.length < 15)
    throw new Error("לא ניתן להבחין בין יחידות קרקע לספינות בתגובה זו");
  return entries.map((entry,index) => ({...entry,kind:entry.kind ?? (index <= 14 ? "army" : "fleet")}));
}

// Actual ownership, route and mission fields used by Ikabot shipMovements.py.
function movementGroups(movements, section) {
  const columns=["מוצא","יעד","משימה","הגעה","מצב","מטען","חיילים","ספינות במשלוח"];
  const groups=[{id:"own",title:"כוחות שלי"},{id:"alliance",title:"כוחות ברית"},
    {id:"hostile",title:"כוחות עוינים"},{id:"other",title:"כוחות אחרים / בעלות לא ידועה"}]
    .map(group=>({...group,columns,rows:[],note:"תנועות גלויות ביועץ הצבאי בלבד; אין כאן סריקה של כלל חשבונות הברית."}));
  const value=amount=>amount===undefined || amount===null ? "לא זמין" : textOnly(String(amount));
  const city=place=>textOnly(decodeUnicodeEscape(place.name))+
    (place.avatarName ? " ("+textOnly(decodeUnicodeEscape(place.avatarName))+")" : "");
  for(const m of movements) {
    if(!m || !m.origin || !m.target || !m.event) throw new Error("פרטי תנועה אינם תואמים");
    // The military screen includes naval forces too. Do not discard a convoy
    // because army.amount is zero or unavailable while fleet details exist.
    // Missing totals are not proof that this is a non-naval movement either.
    // Keep every advisor movement; its reported troop/ship columns show type.
    const flag=value=>value===true || value===1 || value==="1" || value==="true";
    const id=flag(m.isOwnArmyOrFleet) ? "own" : flag(m.isHostile) ? "hostile" : flag(m.isSameAlliance) ? "alliance" : "other";
    const returning=flag(m.event.isFleetReturning);
    const cargo=(m.resources??[]).map(r=>value(r.amount)+" "+
      ({wood:"עץ",wine:"יין",marble:"שיש",glass:"קריסטל",sulfur:"גופרית",gold:"זהב"}[r.cssClass?.split(" ")[1]]??"משאב לא מזוהה")).join(" · ");
    const ships=(m.fleet?.ships??[]).map(ship=>{
      const name=ship.name || ship.title || (ship.cssClass==="ship_transport"?"ספינות תובלה":ship.cssClass);
      return textOnly(decodeUnicodeEscape(name??"סוג לא זמין"))+": "+value(ship.amount);
    }).join(" · ") || (m.fleet?.amount!==undefined ? "סך ספינות: "+value(m.fleet.amount)+" (פירוט סוגים לא זמין)" : "לא זמין");
    const eta=Number(m.eventTime);
    groups.find(group=>group.id===id).rows.push([
      city(returning?m.target:m.origin),city(returning?m.origin:m.target),
      textOnly(decodeUnicodeEscape(m.event.missionText??"לא זמין")),
      Number.isFinite(eta)?new Date(eta*1000).toLocaleString("he-IL"):"לא זמין",
      returning?"בחזרה":"בדרך",cargo||"לא דווח מטען",value(m.army?.amount),ships,
    ]);
  }
  return groups;
}

// eventTime describes the end of the CURRENT movement stage, not every arrival.
function transportTimeline(movements,owner) {
 const yes=value=>value===true||value===1||value==='1'||value==='true';
 const number=value=>value==null||value===''?null:Number.isFinite(Number(value))?Number(value):null;
 return movements.filter(m=>!yes(m.isHostile)&&(yes(m.isOwnArmyOrFleet)||decodeUnicodeEscape(m.origin?.avatarName??'')===owner)&&
   Array.isArray(m.fleet?.ships)&&m.fleet.ships.some(ship=>ship.cssClass==='ship_transport'&&number(ship.amount)>0)).map(m=>{
    const returning=yes(m.event?.isFleetReturning),mission=textOnly(decodeUnicodeEscape(m.event?.missionText??'')),phase=returning?'returning':/loading|העמסה|טעינה/i.test(mission)?'loading':/transport|משלוח|הובלת|העברת|תובלה/i.test(mission)?'sailing':'unknown';
    const eta=number(m.eventTime),origin=returning?m.target:m.origin,target=returning?m.origin:m.target;
    return {id:String(m.event?.id??''),originName:textOnly(decodeUnicodeEscape(origin?.name??'')),destinationName:textOnly(decodeUnicodeEscape(target?.name??'')),
      originCityId:String(origin?.cityId??origin?.id??''),destinationCityId:String(target?.cityId??target?.id??''),phase,
      stageEndsAt:eta>0?eta*1000:null,ships:m.fleet.ships.filter(ship=>ship.cssClass==='ship_transport').reduce((sum,ship)=>sum+(number(ship.amount)??0),0),
      cargo:(m.resources??[]).map(r=>({resource:KEY_RESOURCE(r.cssClass),amount:number(String(r.amount??'').replace(/[, .\u00a0]/g,''))}))};
   });
}
function KEY_RESOURCE(css) {return ['wood','wine','marble','crystal','sulfur'].find(key=>String(css).split(/\s+/).includes(key==='crystal'?'glass':key))??'unknown';}
// Locate the verified field across update commands instead of assuming that
// the only populated viewScriptParams is at one fixed response index.
function advisorMovements(response) {
  const arrays=[],seen=new Set();
  let nodes=0;
  function visit(value,depth) {
    if(!value || typeof value!=="object" || depth>10 || ++nodes>10000) return;
    const movements=value.viewScriptParams?.militaryAndFleetMovements;
    if(movements!==undefined) {
      if(!Array.isArray(movements)) throw new Error("מבנה התנועות אינו תואם");
      arrays.push(movements);
    }
    for(const child of Object.values(value)) visit(child,depth+1);
  }
  visit(response,0);
  if(!arrays.length) throw new Error("שדה התנועות לא נמצא בתגובת היועץ");
  return arrays.flat().filter(movement=>{
    const key=JSON.stringify(movement);
    if(seen.has(key)) return false;
    seen.add(key);return true;
  });
}

let lastMilitaryResponseShape=[];
function militaryResponseShape(response) {
  const shape=[];
  function visit(value,path,depth) {
    if(depth>8 || shape.length>=2000) return;
    if(value && typeof value==="object") {
      const keys=Object.keys(value).filter(key=>!/token|password|cookie|session|blackbox|actionRequest|authorization/i.test(key));
      shape.push({path,type:Array.isArray(value)?"array":"object",length:Array.isArray(value)?value.length:undefined,keys:keys.slice(0,100)});
      for(const key of keys.slice(0,100)) visit(value[key],path+"."+key,depth+1);
    } else shape.push({path,type:typeof value});
  }
  visit(response,"response",0);
  return shape;
}
function militaryDiagnostics() {
  const doc=new DOMParser().parseFromString(document.documentElement.outerHTML,"text/html");
  doc.querySelectorAll("script,style,input,button,select,textarea,iframe").forEach(node=>node.remove());
  const tables=Array.from(doc.querySelectorAll("table")).slice(0,60).map(table=>{
    const copy=table.cloneNode(true);
    for(const element of [copy,...copy.querySelectorAll("*")]) {
      for(const attribute of Array.from(element.attributes)) {
        if(!["class","id","alt","title","colspan","rowspan"].includes(attribute.name)) element.removeAttribute(attribute.name);
      }
    }
    return copy.outerHTML.slice(0,30000);
  });
  return {capturedAt:new Date().toISOString(),tables:tables.slice(0,60),responseShape:lastMilitaryResponseShape,
    note:"טבלאות העמוד המוצג בלבד. אין סקריפטים, טפסים, עוגיות, כתובות בקשות או טוקנים. שמות שחקנים וערים מופיעים בטבלאות."};
}

// Preserve actual advisor tables without guessing ownership or private schema.
// Only cell text is returned: no forms, links, scripts or authentication fields.
function advisorTableGroups(html) {
  if(typeof html!=="string") return [];
  const doc=new DOMParser().parseFromString(html,"text/html");
  doc.querySelectorAll("script,style,input,button,select,textarea").forEach(node=>node.remove());
  const groups=[];
  for(const table of Array.from(doc.querySelectorAll("table")).slice(0,60)) {
    const records=Array.from(table.querySelectorAll("tr")).filter(row=>row.closest("table")===table);
    const header=records.find(row=>Array.from(row.children).some(cell=>cell.tagName==="TH"));
    const clean=cell=>{
      const copy=cell.cloneNode(true);
      for(const icon of copy.querySelectorAll("img")) {
        const label=icon.getAttribute("alt") || icon.getAttribute("title");
        if(label) icon.replaceWith(copy.ownerDocument.createTextNode(" "+label+" "));
      }
      return textOnly(decodeUnicodeEscape(copy.textContent??""));
    };
    const cells=row=>Array.from(row.children).filter(cell=>["TH","TD"].includes(cell.tagName)).slice(0,50);
    const width=Math.max(0,...records.map(row=>cells(row).length));
    const columns=header ? cells(header).map(clean) : Array.from({length:width},(_,index)=>"שדה מקור "+(index+1));
    if(!columns.length || !columns.some(Boolean)) continue;
    const rows=records.slice(header?records.indexOf(header)+1:0).slice(0,200).map(row=>
      cells(row).map(clean)
    ).filter(row=>row.some(Boolean));
    if(!rows.length) continue;
    const caption=table.querySelector("caption")?.textContent;
    groups.push({id:"advisor-table-"+groups.length,title:caption?textOnly(caption):"מידע מהיועץ הצבאי — טבלה "+(groups.length+1),
      columns,rows,note:"טבלת המקור מהיועץ, כולל מידע שאינו תנועה. שיוך הכוחות מוצג רק אם הוא מופיע במקור. עד 200 שורות לטבלה."});
  }
  return groups;
}

// Discover tabs from actual server markup, never invent tab names/endpoints.
function advisorReadTabs(html) {
  if(typeof html!=="string") return [];
  const doc=new DOMParser().parseFromString(html,"text/html");
  const tabs=new Map();
  for(const link of doc.querySelectorAll("a[href]")) {
    let url;
    try {url=new URL(link.getAttribute("href"),location.href);} catch {continue;}
    if(url.origin!==new URL(location.href).origin || url.pathname!=="/index.php") continue;
    const params=url.searchParams;
    if(params.get("view")!=="militaryAdvisor" || params.has("action") || params.has("function") || !params.get("activeTab")) continue;
    const tab=params.get("activeTab");
    if(!tabs.has(tab)) tabs.set(tab,{activeTab:tab,currentTab:params.get("currentTab")??tab,
      title:textOnly(link.textContent??"")||tab});
    if(tabs.size>=4) break;
  }
  return Array.from(tabs.values());
}

async function collectSection(section) {
  const initial=await resolveCurrentPage();
  if (!initial.found || !initial.cityId) throw new Error("לא זוהה חשבון מחובר");
  const allowed=["army","fleet","movements","research","trade","pirates","bonuses"];
  if (!allowed.includes(section)) throw new Error("קריאה אינה נתמכת");
  let token;
  let count=0;
  async function request(params, post=false) {
    if (++count>100) throw new Error("הסריקה הגיעה למגבלת הבקשות");
    await new Promise(resolve=>setTimeout(resolve,550));
    const options={credentials:"same-origin",redirect:"error",signal:AbortSignal.timeout(15000)};
    if(post) {
      if(!token) throw new Error("לא נמצא טוקן לקריאת מידע");
      params.actionRequest=token;
      options.method="POST";
      options.headers={"Content-Type":"application/x-www-form-urlencoded"};
      options.body=new URLSearchParams(params).toString();
    }
    const response=await (globalThis.IkariamPageFetch??fetch)("/index.php"+(post?"":"?"+new URLSearchParams(params)),options);
    if(!response.ok) throw new Error("קריאת המשחק נכשלה");
    const html=await response.text();
    const next=html.match(/actionRequest"?:\s*"([^"]+)"/)?.[1];
    if(next) token=next;
    return html;
  }
  const home=await request({view:"city",cityId:initial.cityId});
  const cityMatch=home.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/);
  if (!cityMatch) throw new Error("החיבור למשחק אינו תקין");
  const current=JSON.parse(cityMatch[1]);
  if(decodeUnicodeEscape(current.ownerName)!==initial.ownerName) throw new Error("החשבון השתנה");
  const base={cityId:initial.cityId,currentCityId:initial.cityId,backgroundView:"city",ajax:"1"};
  let columns=[],rows=[],note="",groups,timeline,dailyBonuses,productionBonuses;
  try {
    if(section==="bonuses") {
      const cinema=await request({...base,view:"cinema",templateView:"cinema"});
      dailyBonuses=globalThis.IkariamReadInsights.parseDailyBonuses(cinema);
      try {
        const premium=await request({...base,view:"premium",templateView:"premium"});
        productionBonuses=globalThis.IkariamReadInsights.parseProductionBonuses(premium);
      } catch {productionBonuses=[];}
      note="קצב הייצור נקרא מכותרת המשחק; אין להוסיף אליו בונוס פעם נוספת.";
    } else if(section==="army" || section==="fleet") {
      const match=home.match(/relatedCityData:\s*JSON\.parse\('(.+?),\\"additionalInfo/);
      if(!match) throw new Error("רשימת ערים חסרה");
      const related=JSON.parse((match[1]+"}").replace(/\\/g,"").replace(/city_/g,""));
      // pedirInfo.getIdsOfCities(all=True) includes occupied/stationed locations.
      const locations=Object.keys(related);
      if(locations.length>60) throw new Error("מספר ערים חריג");
      const outside=[],warnings=[];
      columns=["עיר",section==="army"?"יחידה":"ספינת מלחמה","כמות"];
      for(const id of locations) {
        try {
        const response=JSON.parse(await request({...base,view:"cityMilitary",cityId:id,currentCityId:id,
          activeTab:"tabUnits",currentTab:"tabUnits",templateView:"cityMilitary"},true));
        const html=response?.[1]?.[1]?.[1];
        if(typeof html!=="string") throw new Error("תגובת צבא אינה תואמת");
        const entries = parseMilitaryTable(html);
        for (const entry of entries) {
          if (entry.kind === section && entry.count > 0)
            (related[id].relationship==="ownCity"?rows:outside).push([textOnly(decodeUnicodeEscape(related[id].name??id)),entry.name,String(entry.count)]);
        }
        } catch(error) {
          warnings.push([textOnly(decodeUnicodeEscape(related[id].name??id)),String(error.message??error)]);
        }
      }
      note="חיל מצב בערים שלך; המקור אינו מספק שיוך בעלות לכל יחידה. התנועות מופרדות לפי הבעלות המדווחת ביועץ הצבאי.";
      const advisor=JSON.parse(await request({...base,view:"militaryAdvisor",oldView:"city",oldBackgroundView:"city"},true));
      lastMilitaryResponseShape=militaryResponseShape(advisor);
      const movements=advisorMovements(advisor);
      groups=[{id:"garrison",title:"חיל מצב בערים שלי",columns,rows,note},
        {id:"outside",title:"כוחות בערים מחוץ לחשבון",columns,rows:outside,
          note:"ערים מוחזקות או אחרות המופיעות ברשימת הערים של החשבון. בעלות היחידות אינה נגזרת מבעלות העיר; המידע מוגבל להרשאות המשחק."},
        ...movementGroups(movements,section),...advisorTableGroups(advisor?.[1]?.[1]?.[1])];
      for(const tab of advisorReadTabs(advisor?.[1]?.[1]?.[1])) {
        try {
          const response=JSON.parse(await request({...base,view:"militaryAdvisor",oldView:"city",oldBackgroundView:"city",
            activeTab:tab.activeTab,currentTab:tab.currentTab},true));
          const html=response?.[1]?.[1]?.[1];
          if(typeof html!=="string") throw new Error("תצוגת היועץ אינה תואמת");
          groups.push(...advisorTableGroups(html).map(group=>({...group,id:tab.activeTab+"-"+group.id,title:tab.title+" — "+group.title})));
        } catch(error) {warnings.push([tab.title,String(error.message??error)]);}
      }
      if(warnings.length) groups.push({id:"warnings",title:"קריאות שלא הושלמו",columns:["עיר","בעיה"],rows:warnings,
        note:"הנתונים חלקיים. כשל קריאה אינו אומר שאין כוחות בעיר."});
    } else if(section==="movements") {
      const response=JSON.parse(await request({...base,view:"militaryAdvisor",oldView:"city",oldBackgroundView:"city"},true));
      lastMilitaryResponseShape=militaryResponseShape(response);
      const movements=advisorMovements(response);
      groups=movementGroups(movements,section);
      timeline=transportTimeline(movements,initial.ownerName);
      columns=groups[0].columns;
      rows=groups.flatMap(group=>group.rows);
      note="המשימה נלקחת מהמשחק. בתנועה חוזרת מוצגת עיר החזרה כיעד. ספינות מוצגות לפי סוג וכמות בכל משלוח.";
    } else if(section==="research") {
      const response=JSON.parse(await request({...base,view:"researchAdvisor",oldView:"updateGlobalData",templateView:"researchAdvisor"},true));
      const parsed=globalThis.IkariamReadInsights.parseResearchView(response);
      columns=["תחום מחקר","המחקר הבא","מידע התקדמות"];rows=parsed.rows;
      note="מחקר שייך לחשבון. נתון שלא פוענח מסומן במפורש; מדענים וקצב המחקר נקראים מהערים והאקדמיות.";
    } else if(section==="pirates") {
      // Fortress location/level comes from actual city positions; shared points
      // are parsed with autoPirate.getPirateFortressPoints's exact regexes.
      const match=home.match(/relatedCityData:\s*JSON\.parse\('(.+?),\\"additionalInfo/);
      if(!match) throw new Error("רשימת ערים חסרה");
      const related=JSON.parse((match[1]+"}").replace(/\\/g,"").replace(/city_/g,""));
      columns=["עיר","רמת מבצר","נקודות לכידה","עוצמת צוות"];
      for(const id of Object.keys(related).filter(id=>related[id].relationship==="ownCity").slice(0,60)) {
        const html=id===initial.cityId?home:await request({view:"city",cityId:id});
        const raw=JSON.parse(html.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/)[1]);
        const fortress=transformPositions(raw.position).find(b=>b.building==="pirateFortress");
        if(!fortress) continue;
        const data=await request({...base,view:"pirateFortress",cityId:id,currentCityId:id,position:"17",
          activeTab:"tabCrew",templateView:"pirateFortress"},true);
        const capture=data.match(/\\"capturePoints\\":\\"(\d+)\\"/)?.[1];
        const crew=data.match(/\\"completeCrewPoints\\":(\d+)/)?.[1];
        if(capture===undefined || crew===undefined) throw new Error("נקודות פיראטים אינן תואמות");
        rows.push([decodeUnicodeEscape(raw.name),String(fortress.level),capture,crew]);
        break;
      }
      note="הנקודות ועוצמת הצוות הן נתוני חשבון; טיימר המשימה עדיין אינו מחובר.";
    } else if(section==="trade") {
      const building=transformPositions(current.position).find(b=>b.building==="branchOffice");
      if(!building) {columns=["מידע"];rows=[["אין בית מסחר בעיר הפתוחה"]];}
      else {
        const response=JSON.parse(await request({...base,view:"branchOffice",position:String(building.position)},true));
        const html=response?.[1]?.[1]?.[1];
        if(typeof html!=="string") throw new Error("תגובת בית המסחר אינה תואמת");
        columns=["עיר","מוכר","משאב","כמות","מחיר ליחידה"];
        for(const match of html.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/g)) {
          const row=match[1],city=row.match(/<td class="short_text80">(.*?)<br\/>\((.*?)\)/);
          const amount=row.match(/<div class="tooltip">([\d,.]+)<\/div>/);
          const price=row.match(/<td style="white-space:nowrap;">(\d+)/);
          const resource=row.match(/href="\?view=takeOffer&destinationCityId=(\d+)&oldView=branchOffice&activeTab=bargain&cityId=(\d+)&position=(\d+)&type=(\d+)&resource=(\w+)"/);
          if(city && amount && price && resource)
            rows.push([textOnly(city[1]),textOnly(city[2]),({resource:"עץ","1":"יין","2":"שיש","3":"קריסטל","4":"גופרית"}[resource[5]]??resource[5]),amount[1],price[1]]);
        }
        if(!rows.length) throw new Error("לא ניתן לאמת הצעות מסחר מהתצוגה הנוכחית; חיפוש בכל המשאבים עדיין אינו מחובר");
      }
      note="הצעות מהתצוגה הקיימת של בית המסחר בעיר הפתוחה, ללא שינוי סינון או ביצוע עסקה.";
    }
    return {columns,rows,note,groups,timeline,dailyBonuses,productionBonuses,updatedAt:new Date().toISOString()};
  } finally {await request({view:"city",cityId:initial.cityId});}
}
// pedirInfo.chooseForeignCity + getJson.getIsland, with exact identity checks.
async function resolveExternalTarget(target,request,ownPlayer,allowMissingIslandName=false) {
  const discoverIslandName=allowMissingIslandName&&target?.islandName==='';
  globalThis.IkariamTransportPlan.validateExternalTarget(discoverIslandName?{...target,islandName:'discover'}:target);
  const map=await request({view:"worldmap_iso",islandX:target.x,islandY:target.y,oldBackgroundView:"island",islandWorldviewScale:1});
  const match=map.match(/jsonData = '(.*?)';/);
  if(!match) throw new Error("לא ניתן לקרוא את מפת האיים");
  const islandId=String(JSON.parse(match[1]).data?.[String(target.x)]?.[String(target.y)]?.[0]??"");
  if(!/^\d+$/.test(islandId)) throw new Error("לא נמצא אי בקואורדינטות האלה");
  const html=await request({view:"island",islandId});
  const data=html.match(/ajax.Responder, (\[\[[\S\s]*?\]\])\);/);
  if(!data) throw new Error("לא ניתן לקרוא את פרטי האי");
  const island=JSON.parse(data[1])?.[1]?.[1];
  const exact=(value)=>decodeUnicodeEscape(String(value??"")).normalize("NFC").trim();
  if(!island || String(island.id)!==islandId || Number(island.xCoord)!==target.x || Number(island.yCoord)!==target.y || !discoverIslandName&&exact(island.name)!==exact(target.islandName)) throw new Error("שם האי או המיקום אינם תואמים למשחק");
  const cities=island.cities?.filter(city=>city.type==="city" && city.state==="" && exact(city.ownerName??city.Name)===exact(target.playerName) && exact(city.name)===exact(target.cityName))??[];
  if(cities.length!==1) {
    // What the island does have, so a wrong letter case or name is seen at once (user report, 2026-10-27:
    // "polis" was typed for the game's city name).
    const lower=value=>exact(value).toLowerCase(),all=(island.cities??[]).filter(city=>city.type==="city");
    const his=all.filter(city=>lower(city.ownerName??city.Name)===lower(target.playerName));
    if(cities.length>1) throw new Error("נמצאו כמה ערים בשם הזה של השחקן באי; לא אומת");
    if(his.length) throw new Error("באי ["+target.x+":"+target.y+"] יש לשחקן "+exact(his[0].ownerName??his[0].Name)+" את הערים: "+his.map(city=>exact(city.name)+(city.state?" ("+city.state+")":"")).join(", ")+" — יש להקליד את השם בדיוק כמו במשחק");
    throw new Error("לשחקן "+exact(target.playerName)+" אין עיר באי ["+target.x+":"+target.y+"]"+(all.length?"; השחקנים באי: "+[...new Set(all.map(city=>exact(city.ownerName??city.Name)))].slice(0,12).join(", "):""));
  }
  const city=cities[0],cityId=String(city.id),ownerId=String(city.ownerId??city.Id??"");
  if(!/^\d+$/.test(cityId) || !/^\d+$/.test(ownerId) || exact(target.playerName)===exact(ownPlayer)) throw new Error("לא אומתה עיר של חשבון אחר");
  if(target.cityId && (target.cityId!==cityId || target.ownerId!==ownerId || target.islandId!==islandId)) throw new Error("בעלות העיר או יעד המשלוח השתנו; המסלול נעצר");
  return {x:target.x,y:target.y,islandName:exact(island.name),playerName:exact(city.ownerName??city.Name),cityName:exact(city.name),cityId,ownerId,islandId,verifiedAt:Date.now()};
}
// A read-only travel quote for one route (Firefox, steady supply planning): the game's own transport
// form of the origin city gives the loading queue, loading speed and voyage values; the same formula
// the shipment uses (transport-plan.js) turns them into times. Nothing is sent; the city view is restored.
// Firefox steady supply: this account's trade ships at sea, read from the fleet movements the way Ikabot
// reads them (militaryAdvisor, militaryAndFleetMovements): each group's ships, phase and the end of its
// current stage, so the planner knows when ships come back (user decision, 2026-10-28).
async function fleetTimeline() {
  if(mainEdition()) throw new Error('יומן הספינות זמין בפיירפוקס בלבד');
  const initial=await resolveCurrentPage();
  if(!initial.found) throw new Error("יש להתחבר לחשבון במשחק");
  const request=async (params,post=false)=>{
    const options={credentials:"same-origin",redirect:"error",signal:AbortSignal.timeout(15000)};
    if(post) {options.method="POST";options.headers={"Content-Type":"application/x-www-form-urlencoded"};options.body=new URLSearchParams(params).toString();}
    const response=await (globalThis.IkariamPageFetch??fetch)("/index.php"+(post?"":"?"+new URLSearchParams(params)),options);
    if(!response.ok) throw new Error("קריאת תנועות הספינות נכשלה");
    return response.text();
  };
  const home=await request({view:"city",cityId:initial.cityId});
  const token=home.match(/actionRequest"?:\s*"([^"]+)"/)?.[1];
  if(!token) throw new Error("לא נמצא טוקן לקריאת התנועות");
  const free=home.match(/GlobalMenu_freeTransporters">(\d+)</)?.[1],total=home.match(/maxTransporters">(\d+)</)?.[1];
  const movements=advisorMovements(JSON.parse(await request({view:"militaryAdvisor",oldView:"city",oldBackgroundView:"city",backgroundView:"city",currentCityId:initial.cityId,actionRequest:token,ajax:1},true)))
    .map(m=>({...m,origin:m.origin?{...m.origin,name:decodeUnicodeEscape(m.origin.name),avatarName:decodeUnicodeEscape(m.origin.avatarName)}:m.origin,
      target:m.target?{...m.target,name:decodeUnicodeEscape(m.target.name),avatarName:decodeUnicodeEscape(m.target.avatarName)}:m.target}));
  return {at:Date.now(),free:free===undefined?null:Number(free),total:total===undefined?null:Number(total),fleets:transportTimeline(movements,initial.ownerName)};
}
// Firefox: the account's capture points as its pirate fortress shows them ("נקודות לכידה", capturePoints),
// read from the first city that has a fortress (user decision, 2026-10-28: Opera orders its raids by them).
async function readCapturePoints() {
  if(mainEdition()) throw new Error('נקודות הלכידה נקראות בפיירפוקס בלבד');
  const initial=await resolveCurrentPage();
  if(!initial.found) throw new Error("יש להתחבר לחשבון במשחק");
  const request=async (params,post=false)=>{
    const options={credentials:"same-origin",redirect:"error",signal:AbortSignal.timeout(15000)};
    if(post) {options.method="POST";options.headers={"Content-Type":"application/x-www-form-urlencoded"};options.body=new URLSearchParams(params).toString();}
    const response=await (globalThis.IkariamPageFetch??fetch)("/index.php"+(post?"":"?"+new URLSearchParams(params)),options);
    if(!response.ok) throw new Error("קריאת נקודות הלכידה נכשלה");
    return response.text();
  };
  try {
    const home=await request({view:"city",cityId:initial.cityId});
    const match=home.match(/relatedCityData:\s*JSON\.parse\('(.+?),\\"additionalInfo/);
    if(!match) throw new Error("רשימת ערים חסרה");
    const related=JSON.parse((match[1]+"}").replace(/\\/g,"").replace(/city_/g,""));
    const own=Object.keys(related).filter(id=>related[id].relationship==="ownCity");
    for(const id of [initial.cityId,...own.filter(id=>id!==initial.cityId)].slice(0,60)) {
      const html=id===initial.cityId?home:await request({view:"city",cityId:id});
      const raw=JSON.parse(html.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/)[1]);
      const fortress=transformPositions(raw.position).find(b=>b.building==="pirateFortress");
      if(!fortress) continue;
      const data=await request({view:"pirateFortress",cityId:id,currentCityId:id,position:String(fortress.position),backgroundView:"city",activeTab:"tabBootyQuest",templateView:"pirateFortress",ajax:"1"},true);
      const points=data.match(/\\?"capturePoints\\?":\\?"?(\d+)/)?.[1];
      if(points===undefined) throw new Error("נקודות הלכידה לא נמצאו במבצר");
      return {at:Date.now(),points:Number(points)};
    }
    throw new Error("אין מבצר פיראטים בחשבון");
  } finally {try {await request({view:"city",cityId:initial.cityId});} catch {}}
}
async function quoteTransport(originCityId,target,amount) {
  if(mainEdition()) throw new Error('הצעת זמן הובלה זמינה בפיירפוקס בלבד');
  if(!/^\d+$/.test(String(originCityId))||!/^\d+$/.test(String(target?.cityId))||!/^\d+$/.test(String(target?.islandId))||!(amount>0)) throw new Error('בקשת זמן הובלה אינה תקינה');
  const initial=await resolveCurrentPage();
  if(!initial.found) throw new Error("יש להתחבר לחשבון במשחק");
  const request=async params=>{
    const response=await (globalThis.IkariamPageFetch??fetch)("/index.php?"+new URLSearchParams(params),{credentials:"same-origin",redirect:"error",signal:AbortSignal.timeout(15000)});
    if(!response.ok) throw new Error("קריאת זמן ההובלה נכשלה");
    return response.text();
  };
  try {
    await request({view:"city",cityId:String(originCityId)});
    const form=await request({view:'transport',destinationCityId:String(target.cityId),islandId:String(target.islandId),backgroundView:'city',currentCityId:String(originCityId),templateView:'transport',ajax:1});
    return globalThis.IkariamTransportPlan.transportTiming(form,amount);
  } finally {try {await request({view:"city",cityId:initial.cityId});} catch {}}
}
async function verifyExternalTarget(target,allowMissingIslandName=false) {
  const initial=await resolveCurrentPage();
  if(!initial.found) throw new Error("יש להתחבר לחשבון במשחק");
  const request=async params=>{
    const response=await (globalThis.IkariamPageFetch??fetch)("/index.php?"+new URLSearchParams(params),{credentials:"same-origin",redirect:"error",signal:AbortSignal.timeout(15000)});
    if(!response.ok) throw new Error("בדיקת היעד נכשלה");
    return response.text();
  };
  try {return await resolveExternalTarget(target,request,initial.ownerName,allowMissingIslandName);}
  finally {try {await request({view:"city",cityId:initial.cityId});} catch {}}
}
// Main-only local bridge gate. The game request itself remains on the existing token queue.
async function mainPilotOperation(rule,operation,extra={}) {
  if(!mainEdition()||!chrome.storage?.local||!chrome.runtime?.sendMessage)return {applicable:false};
  const values=await chrome.storage.local.get(['main-supply-bridge-v1','main-supply-allocation-fence-v2']);
  const config=values['main-supply-bridge-v1'],fence=values['main-supply-allocation-fence-v2'];
  const fenced=fence?.active&&fence.accountKey===rule.accountKey&&(fence.mode==='dispatch'||String(fence.pilot?.cityId)===String(rule.destinationCityId)&&fence.pilot?.resource===rule.resource);
  if(!config?.enabled&&!fenced)return {applicable:false};
  const result=await chrome.runtime.sendMessage({type:'MAIN_SUPPLY_ALLOCATION',operation,accountKey:rule.accountKey,operationId:rule.mainSupplyOperationId??rule.inFlight??rule.gameOperationId,originCityId:String(rule.originCityId),cityId:String(rule.destinationCityId),resource:rule.resource,...extra});
  if(!result?.ok)throw new Error('שמירת הפיילוט לא אומתה; המטען לא ישוחזר ללא בדיקה');
  return result;
}
async function queueMainSupplyScan(rule,result,startedAt) {
  if(!mainEdition()||!result.report?.mainCoordinationInputs)return result;
  const config=(await chrome.storage.local.get('main-supply-bridge-v1'))['main-supply-bridge-v1'];
  if(!config?.enabled||config.accountKey!==rule.accountKey)return result;
  const key='main-supply-outbox-v2-'+rule.accountKey,old=(await chrome.storage.local.get(key))[key]??{nextSequence:1};
  const scanId=String(rule.inFlight??'scan')+'-'+result.report.scannedAt;
  if(old.lastQueuedScanId===scanId)return result;
  const report=result.report;
  const compact=JSON.parse(JSON.stringify({scannedAt:report.scannedAt,cities:report.cities,mainCoordinationInputs:report.mainCoordinationInputs,unresolvedShipments:report.unresolvedShipments,unmetNeeds:report.unmetNeeds,shortages:report.shortages,wine:report.wine}));
  await chrome.storage.local.set({[key]:{...old,nextSequence:old.nextSequence+1,lastQueuedScanId:scanId},['main-supply-scan-v2-'+rule.accountKey+'-'+old.nextSequence]:{scanId,scanSequence:old.nextSequence,scanStartedAt:startedAt,report:compact}});
  return result;
}
// Finite execution of one cargo chunk, using Ikabot planRoutes.sendGoods.
// No automatic replay of a mutation after timeout or an unrecognized response.
async function executeAutomationTransport(rule,onTiming) {
  globalThis.IkariamTransportPlan.validateTransportRule(rule);
  const initial=await resolveCurrentPage();
  if(!initial.found || [initial.ownerName,initial.mundo,initial.servidor].join("|")!==rule.accountKey) throw new Error("החשבון השתנה; לא נשלחו משאבים");
  let token;
  let cargoSubmitted=false,pilotReservation=null;
  let stage="קריאת עיר המוצא";
  async function request(params,post=false,retriedToken=false) {
    await new Promise(resolve=>setTimeout(resolve,550));
    const options={credentials:"same-origin",redirect:"error",signal:AbortSignal.timeout(15000)};
    let query=params;
    if(post) {
      // Session.__token() fetches the current page if an action consumed
      // its token without providing the next token in its response.
      if(!token) await request({});
      if(!token) throw new Error("לא נמצא טוקן תקף");
      options.method="POST";options.headers={"Content-Type":"application/x-www-form-urlencoded"};
      query={...params,actionRequest:token};
    }
    // Session.post(params=...) passes params as the query string, with an
    // empty POST payload. Preserve that exact upstream request contract.
    const isCargo=post && params.action==="transportOperations";
    if(isCargo && rule.gameAutomationId) {
      const state=(await chrome.storage.local.get('game-automations-v1'))['game-automations-v1'];
      if(!state?.rules?.some(item=>item.id===rule.gameAutomationId&&item.enabled&&!item.deleted&&item.inFlight===rule.gameOperationId)) throw new Error('אוטומציית היין נעצרה לפני שליחת המטען');
    }
    if(isCargo&&mainEdition()&&chrome.storage?.local) {
      const key='main-build-mode-'+rule.accountKey,mode=(await chrome.storage.local.get(key))[key];
      if(mode?.enabled&&String(mode.cityId)!==String(rule.originCityId)) throw new Error('העיר המרכזית השתנתה; המטען לא נשלח. התכנון יחודש בסריקה הבאה');
    }
    if(isCargo&&mainEdition()){
      try{if(pilotReservation?.applicable)throw new Error('למטען כבר נרשמה כוונה; אין שליחה חוזרת');pilotReservation=await mainPilotOperation(rule,'prepare',{amount:Number(params[rule.resource==='wood'?'cargo_resource':'cargo_tradegood'+globalThis.IkariamTransportPlan.RESOURCE_KEYS.indexOf(rule.resource)]??0)});}
      catch(error){error.mainPilotHeld=true;throw error;}
    }
    if(isCargo) {if(mainEdition()&&onTiming)await onTiming({sendPhase:"dispatching",dispatchAt:Date.now()});cargoSubmitted=true;}
    const response=await (globalThis.IkariamPageFetch??fetch)("/index.php?"+new URLSearchParams(query),options);
    if(!response.ok) throw new Error("בקשת המשלוח נכשלה");
    const text=await response.text();
    const nextToken=text.match(/actionRequest"?:\s*"([^"]+)"/)?.[1];
    if(post && text.includes("TXT_ERROR_WRONG_REQUEST_ID")) {
      // The server explicitly rejected this request. Unlike timeouts, this
      // is safe to retry once, following upstream Session.post's refresh.
      if(isCargo) cargoSubmitted=false;
      token=undefined;
      if(retriedToken) throw new Error("המשחק דחה את הטוקן גם לאחר רענון; המשלוח לא התקבל");
      await request({});
      return request(params,true,true);
    }
    token=nextToken??(post && params.action?undefined:token);
    return text;
  }
  function city(html,id) {
    const match=html.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/);
    if(!match) throw new Error("מבנה נתוני העיר אינו תואם");
    const raw=JSON.parse(match[1]);
    if(String(raw.id)!==id || decodeUnicodeEscape(raw.ownerName)!==initial.ownerName) throw new Error("ניתן לשלוח רק בין ערים שלך");
    const resources=parseAvailableResources(html),capacity=parseWarehouseCapacity(html);
    if(!resources || !Number.isSafeInteger(capacity)) throw new Error("לא ניתן לאמת משאבים ומקום פנוי");
    const sale=html.match(/branchOfficeResources:\s*JSON\.parse\('\{\\"resource\\":\\"(\d+)\\",\\"1\\":\\"(\d+)\\",\\"2\\":\\"(\d+)\\",\\"3\\":\\"(\d+)\\",\\"4\\":\\"(\d+)\\"}\'\)/);
    const index=globalThis.IkariamTransportPlan.RESOURCE_KEYS.indexOf(rule.resource);
    return {raw,resources,space:Math.max(0,capacity-resources[rule.resource]-(sale?Number(sale[index+1]):0))};
  }
  try {
    const originHtml=await request({view:"city",cityId:rule.originCityId});
    const origin=city(originHtml,rule.originCityId);
    stage="קריאת עיר היעד והמקום הפנוי";
    let destinationHtml="",destination;
    if(rule.externalTarget) {
      const target=await resolveExternalTarget(rule.externalTarget,request,initial.ownerName);
      if(target.cityId!==rule.destinationCityId) throw new Error("מזהה עיר היעד אינו תואם");
      // planRoutes.executeRoutes deliberately omits foreign warehouse limits:
      // the other player's stocks/capacity are not visible to this account.
      destination={raw:{id:target.cityId,islandId:target.islandId,name:target.cityName},space:Number.MAX_SAFE_INTEGER};
    } else {
      destinationHtml=await request({view:"city",cityId:rule.destinationCityId});
      destination=city(destinationHtml,rule.destinationCityId);
      if(Number.isSafeInteger(rule.policyDestinationCap)&&rule.policyDestinationCap>=0) destination.space=Math.min(destination.space,Math.max(0,rule.policyDestinationCap-destination.resources[rule.resource]));
    }
    if(!/^\d+$/.test(String(destination.raw.islandId))) throw new Error("אי היעד לא אומת");
    // Existing shipments are allowed. Each rule plans its own remaining cargo
    // against fresh stock, free ships and warehouse space; only an identical
    // operation ID is protected against replay.
    stage="קריאת קיבולת ספינות המסחר";
    const navyHtml=await request({view:"merchantNavy"});
    const navyMatch=navyHtml.match(/ajax.Responder, (\[\[[\S\s]*?\]\])\);/);
    if(!navyMatch) throw new Error("קיבולת ספינות המסחר אינה זמינה");
    const shipCapacity=Number(JSON.parse(navyMatch[1])?.[3]?.[1]?.singleTransporterCapacity);
    stage="אימות המלאי וספינות פנויות במוצא";
    const currentHtml=await request({});
    const currentMatch=currentHtml.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/);
    if(!currentMatch) throw new Error("לא ניתן לאמת את העיר הנוכחית לפני החלפת העיר");
    const currentId=String(JSON.parse(currentMatch[1]).id);
    if(!/^\d+$/.test(currentId)) throw new Error("מזהה העיר הנוכחית אינו תקין");
    const freshHtml=await request({view:"city",cityId:rule.originCityId});
    const fresh=city(freshHtml,rule.originCityId);
    const shipsMatch=freshHtml.match(/GlobalMenu_freeTransporters">(\d+)</);
    if(!shipsMatch) throw new Error("כמות ספינות פנויות אינה זמינה");
    // A war shipment ends when the city has run out (under one 500 load), not when the plan is met.
    if(rule.war&&fresh.resources[rule.resource]<500) return {status:"empty",remaining:0,message:"לא נשאר בעיר משאב לשליחה — המשלוח הסתיים"};
    const plan=globalThis.IkariamTransportPlan.planTransport(rule,{stock:fresh.resources[rule.resource],freeSpace:destination.space,ships:Number(shipsMatch[1]),shipCapacity});
    if(mainEdition()&&rule.mainSupplyPolicy) {
      const freePoints=freshHtml.match(/"maxActionPoints"\s*:\s*"?(\d+)/)?.[1]??freshHtml.match(/js_GlobalMenu_maxActionPoints"[^>]*>\s*(\d+)/)?.[1];
      if(freePoints!==undefined&&Number(freePoints)===0)return {status:'waiting',remaining:rule.remaining,waitingReason:'action-points',message:'אין נקודות פעולה פנויות בעיר המוצא; שאר הערים ייבדקו'};
      plan.amount=Math.floor(plan.amount/500)*500;plan.ships=Math.ceil(plan.amount/shipCapacity);plan.remaining=rule.remaining-plan.amount;
    }
    if(plan.amount===0) return {...(mainEdition()&&rule.mainSupplyPolicy?{waitingReason:Number(shipsMatch[1])===0?"ships":"stock-or-space",sourceStock:fresh.resources[rule.resource],destinationStock:destination.resources?.[rule.resource]}:{}),status:plan.remaining>0?"waiting":"empty",remaining:plan.remaining,message:plan.remaining>0?"ממתין לספינות, למשאבים או למקום פנוי":"אין משאבים לשליחה במחזור הזה"};
    const proposalFields={function:'loadTransportersWithFreight',originName:decodeUnicodeEscape(origin.raw.name),destinationName:decodeUnicodeEscape(destination.raw.name),resource:rule.resource,amount:plan.amount,transporters:plan.ships};
    const proposal={key:JSON.stringify(proposalFields),fields:proposalFields,cityName:proposalFields.originName,createdAt:Date.now()};
    if(rule.reviewMode==='manual' && (rule.approval?.key!==proposal.key || Date.now()-rule.approval.approvedAt>180000)) {
      const skipped=rule.skippedPlans?.includes(proposal.key);
      return {status:'waiting',remaining:rule.remaining??plan.remaining,proposal:skipped?null:proposal,message:skipped?'המשלוח דולג; ממתין לשינוי בכמות או בתנאים':'הבדיקה הושלמה — משלוח ממתין לאישור שלך'};
    }
    stage="בחירת עיר המוצא למשלוח";
    const changed=await request({action:"header",function:"changeCurrentCity",oldView:"city",cityId:rule.originCityId,backgroundView:"city",currentCityId:currentId,ajax:1},true);
    if(changed.includes('"type":11')) throw new Error("המשחק דחה את בחירת עיר המוצא");
    const index=globalThis.IkariamTransportPlan.RESOURCE_KEYS.indexOf(rule.resource);
    const params={action:"transportOperations",function:"loadTransportersWithFreight",destinationCityId:rule.destinationCityId,
      islandId:destination.raw.islandId,oldView:"",position:"",avatar2Name:"",city2Name:"",type:"",activeTab:"",transportDisplayPrice:"0",
      premiumTransporter:"0",capacity:"5",max_capacity:"5",jetPropulsion:"0",backgroundView:"city",currentCityId:rule.originCityId,
      templateView:"transport",currentTab:"tabSendTransporter",ajax:1,transporters:plan.ships};
    for(let i=0;i<5;i++) if(fresh.resources[globalThis.IkariamTransportPlan.RESOURCE_KEYS[i]]>0)
      params[i===0?"cargo_resource":"cargo_tradegood"+i]=i===index?plan.amount:0;
    // Timing is optional: follow only a transport link actually supplied by the game.
    // Missing timing must never prevent an otherwise valid shipment.
    let timing=null;
    try {
      const document=new DOMParser().parseFromString(freshHtml+destinationHtml,"text/html");
      for(const link of document.querySelectorAll('a[href]')) {
        const url=new URL(link.getAttribute("href"),location.href);
        if(url.origin!==location.origin || !url.pathname.endsWith("/index.php") || url.searchParams.get("view")!=="transport" ||
          url.searchParams.has("action") || url.searchParams.has("function") || url.searchParams.get("destinationCityId")!==rule.destinationCityId) continue;
        timing=globalThis.IkariamTransportPlan.transportTiming(await request(Object.fromEntries(url.searchParams)),plan.amount);
        break;
      }
      timing??=globalThis.IkariamTransportPlan.transportTiming(changed,plan.amount);
      if(!timing) {
        // The read-only transport form exposes loading, distance and speed modifiers.
        const form=await request({view:'transport',destinationCityId:rule.destinationCityId,islandId:destination.raw.islandId,backgroundView:'city',currentCityId:rule.originCityId,templateView:'transport',ajax:1});
        timing=globalThis.IkariamTransportPlan.transportTiming(form,plan.amount);
      }
    } catch { /* Timing unavailable; the cargo contract stays unchanged. */ }
    if(onTiming)await onTiming({timing,amount:plan.amount,ships:plan.ships,...(mainEdition()?{sendPhase:"prepared"}:{})});
    stage="שליחת המטען למשחק";
    const response=JSON.parse(await request(params,true));
    stage="אימות תשובת המשלוח";
    const type=response?.[3]?.[1]?.[0]?.type;
    if(mainEdition()&&onTiming&&[10,11].includes(type))await onTiming({sendPhase:type===10?"accepted":"rejected",responseAt:Date.now()});
    if(pilotReservation?.applicable&&[10,11].includes(type))await mainPilotOperation(rule,'receipt',{result:type===10?'sent':'failed',...(type===10&&Number.isSafeInteger(timing?.arrivalAt)?{arrivalAt:timing.arrivalAt}:{})});
    if(type===11) return {status:"waiting",remaining:rule.remaining,message:"המשחק לא קיבל את המשלוח; ממתין לבדיקת הספינות הבאה"};
    if(type!==10) throw new Error("תוצאת המשלוח לא אומתה — יש לבדוק תנועות לפני חידוש");
    return {status:"sent",amount:plan.amount,ships:plan.ships,timing,remaining:plan.remaining,message:`נשלחו ${plan.amount} יחידות משאב מ${decodeUnicodeEscape(origin.raw.name)} אל ${decodeUnicodeEscape(destination.raw.name)}`};
  } catch(error) {
    if(mainEdition()&&error.mainPilotHeld&&!cargoSubmitted)return {status:'waiting',waitingReason:'pilot-reservation',remaining:rule.remaining,message:'שמירת הפיילוט ממתינה לבירור; לא נשלח מטען לעיר ולמשאב האלה. שאר האספקה ממשיכה'};
    if(pilotReservation?.applicable&&cargoSubmitted){try{await mainPilotOperation(rule,'receipt',{result:'unknown'});}catch{ /* Keep durable intent when receipt acknowledgement is unavailable. */ }}
    error.mutationSubmitted=cargoSubmitted;
    error.message=stage+": "+error.message;
    throw error;
  } finally {try {await request({view:"city",cityId:initial.cityId});} catch { /* Never replay an accepted shipment due to restoration failure. */ }}
}
// Resources the building queues of this account wait for (saved by the building
// automation when an upgrade lacks resources): the policy supplies them first and never
// exports them to the main account.
async function buildingNeeds(accountKey) {
  const state=(await chrome.storage.local.get('game-automations-v1'))['game-automations-v1'];
  const needs={};
  for(const task of state?.rules??[]) {
    const recruitment=mainEdition()&&task.kind==='barbarians'&&task.progress?.mainBarbarianRound;
    const need=recruitment?task.progress?.mainRecruitNeed:task.progress?.need;
    if((!recruitment&&task.kind!=='building')||task.accountKey!==accountKey||!task.enabled||task.deleted||!need?.resources||Date.now()-(need.at??0)>21600000) continue;
    needs[task.cityId]??={};
    for(const [resource,amount] of Object.entries(need.resources)) if(Number.isSafeInteger(amount)&&amount>0) needs[task.cityId][resource]=Math.max(needs[task.cityId][resource]??0,amount);
  }
  return needs;
}
// The next 48 hours of building in each city (premium construction list first, then the
// uniformity plan; see build-forecast.js): reserved in the city and brought ahead of time.
const mainEdition=()=>{try {return /\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name??'');} catch {return false;}};
// The main edition supplies step by step (user decision, 2026-10-16): at levels 40–50, 48 hours of
// building in 11 cities made every city keep a huge reserve and none could give. There the next two
// upgrades after the active one are brought ahead, for every city in every scan, from the scan's
// own read of the cities (the premium list first, then the target levels) — not only for the
// cities whose building check happened to run, so free ships are never left idle.
async function mainForecast(accountKey,snapshot,readCostTable=null) {
  const F=globalThis.IkariamBuildForecast;if(!F) return {};
  const tablesKey='cost-tables-v3-'+accountKey,snapKey='account-snapshot-'+accountKey;
  const values=await chrome.storage.local.get(['uniform-plan-v1',tablesKey,snapKey,'main-build-queue-v1']);
  const plans=values['uniform-plan-v1']?.accounts?.[accountKey]?.cities??[],tables=values[tablesKey]??{};
  const stored=values[snapKey]?.snapshot?.cities??[];
  const gateOpen=F.reducersReady(snapshot?.cities);
  const rank=(building,build)=>build&&building==='warehouse'?-1:['carpentering','architect'].includes(building)?0:1;
  const forecast={},diagnostics=[],attempted=new Set(),queues={};
  const retryKey='main-cost-table-retries-'+accountKey;
  const retries=readCostTable?((await chrome.storage.local.get(retryKey))[retryKey]??{}):{};
  // Which resource each tooltip image of the game's build list stands for, learned once per image.
  const iconsKey='main-resource-icons-v1',icons=(await chrome.storage.local.get(iconsKey))[iconsKey]??{},iconOf=src=>String(src).replace(/^\/\/[^/]+/,'');let iconsChanged=false;
  for(const city of snapshot?.cities??[]) {
    let buildings=city.buildings?.length?city.buildings:stored.find(item=>String(item.id)===String(city.id))?.buildings;
    const plan=plans.find(item=>String(item.cityId)===String(city.id));
    if(!buildings?.length) continue;
    // The agent's own build list (user decision, 2026-10-29: it leads, and Firefox must supply it): its buildings
    // up to their listed levels, first in its order, right after the game's own list; not held for the reducers.
    // One entry per row, ranked by its place in the list: the forecast takes the rows exactly in the list's order,
    // also when rows of different buildings alternate (user check, 2026-10-29).
    const agent=[],queued=values['main-build-queue-v1']?.[String(city.id)]??[];
    for(const row of queued) {
      const at=buildings.find((item,index)=>Number(item?.position??index)===Number(row.position));
      if(!at||at.building!==row.building) continue;
      agent.push({building:row.building,position:Number(row.position),target:row.level,build:false,rank:-10+agent.length/1000});
    }
    const agentBuildings=new Set(agent.map(item=>item.building));
    // The game's build-list window is the full list (an entry of the building now under construction has
    // no mark on the city's buildings); when it cannot be read, the marks are used as before.
    let gameEntries=null;
    if(readCostTable?.readList) try {const entries=await readCostTable.readList(city.id);if(entries) {buildings=F.applyConstructionList(buildings,entries);gameEntries=entries;}} catch { /* Marks retained. */ }
    // The game's own build list comes first (user decision, 2026-10-18): every upgrade queued in it,
    // in every city, whatever its length; only a city with nothing queued gets the next two steps of
    // its uniformity plan.
    const listed=F.constructionList(buildings).length>0;
    if(!listed&&!plan&&!agent.length) continue;
    let items=[];
    try {
      const run=()=>listed?F.forecast({buildings,plan:agent,tables,now:Date.now(),horizonMs:Infinity,strictList:true})
        :F.forecast({buildings,plan:[...agent,...(plan?.items??[]).map(item=>({building:item.building,position:item.position??0,target:item.target,build:item.build,rank:rank(item.building,item.build)}))],tables,now:Date.now(),horizonMs:Infinity});
      let result=run();
      for(const building of result.missingTables) {
        if(!readCostTable||attempted.has(building)||attempted.size>=3||Date.now()-(retries[building]??0)<600000) continue;
        attempted.add(building);retries[building]=Date.now();
        await chrome.storage.local.set({[retryKey]:retries});
        try {
          const table=await readCostTable(building,city.id);
          if(table&&Object.keys(table.levels??{}).length) {tables[building]={...table,at:Date.now()};await chrome.storage.local.set({[tablesKey]:tables});}
        } catch { /* Read failure: retain a visible missing-table diagnostic; never invent costs. */ }
      }
      result=run();
      if(result.missingTables.length) diagnostics.push({cityId:city.id,cityName:city.name,missingTables:result.missingTables});
      items=result.items;
      // Only use a live quote for the next level currently exposed by the game.
      const first=items[0],actual=first&&buildings.find(item=>item.building===first.building&&!item.isBusy&&Number(item.level)+1===first.level);
      if(first&&actual&&readCostTable?.readQuote) {
        try {
          const quote=await readCostTable.readQuote(city.id,actual);
          if(!Object.keys(quote?.costs??{}).length||Object.keys(first.costs).some(key=>!Number.isSafeInteger(quote.costs[key])||quote.costs[key]<0))throw new Error('incomplete costs');
          items=[{...first,costs:quote.costs,seconds:Number.isFinite(quote.durationMs)?quote.durationMs/1000:first.seconds,costSource:'live-game-quote',quotedAt:Date.now()},...items.slice(1)];
        } catch {diagnostics.push({cityId:city.id,cityName:city.name,missingTables:[],costWarning:'next-upgrade-quote-unavailable; table estimate retained'});}
      } else if(first&&readCostTable?.readQuote) diagnostics.push({cityId:city.id,cityName:city.name,missingTables:[],costWarning:'next-upgrade-not-currently-quotable; table estimate retained'});
      // Only the actual game list overrides the account-wide reducer prerequisite.
      // Extension targets still wait; strictList above never appends them to this queue.
      if(!gateOpen&&!listed) items=items.filter(item=>['carpentering','architect'].includes(item.building)||agentBuildings.has(item.building));
      // The game's list window leads: every waiting entry with the game's own cost and finish time
      // (user decision, 2026-10-22: the game is more exact than the cost tables). An image is known once
      // its amount matches one resource of the table estimate for the same building and level; an entry
      // whose cost is neither in the game nor in a table ends the list there — nothing is guessed.
      if(listed&&gameEntries?.length) {
        for(const entry of gameEntries) {
          entry.building=String(buildings.find((item,index)=>Number(item?.position??index)===entry.position)?.building??'').split(' ')[0]||null;
          const estimate=items.find(item=>item.list&&item.building===entry.building&&item.level===entry.level)?.costs??{};
          for(const icon of entry.icons??[]) if(!icons[iconOf(icon.src)]) {
            const near=Object.entries(estimate).filter(([,value])=>Number.isSafeInteger(value)&&value>0&&Math.abs(value-icon.amount)<=Math.max(2,value*0.01)).map(([resource])=>resource);
            if(near.length===1&&!Object.values(icons).includes(near[0])) {icons[iconOf(icon.src)]=near[0];iconsChanged=true;}
          }
        }
        const active=buildings.find(item=>item?.isBusy);let previous=active&&Number(active.completed)>0?Number(active.completed)*1000:null;
        const game=gameEntries.map(entry=>{
          const costs={};let known=(entry.icons??[]).length>0;
          for(const icon of entry.icons??[]) {const resource=icons[iconOf(icon.src)];if(resource) costs[resource]=icon.amount;else known=false;}
          const seconds=Number.isSafeInteger(entry.endAt)&&previous!==null&&entry.endAt>=previous?(entry.endAt-previous)/1000:null;
          previous=Number.isSafeInteger(entry.endAt)?entry.endAt:null;
          const estimate=items.find(item=>item.list&&item.building===entry.building&&item.level===entry.level);
          return {building:entry.building,label:'list',level:entry.level,list:true,costs:known?costs:estimate?.costs??null,seconds:seconds??estimate?.seconds??null,endAt:entry.endAt??null,
            costSource:known?'live-game-quote':estimate?.costSource??'table-estimate'};
        });
        const stop=game.findIndex(item=>!item.building||!item.costs);
        items=stop<0?game:game.slice(0,stop);
      }
      const busy=buildings.find(item=>item?.isBusy);
      queues[city.id]={items,neededAt:busy?(Number(busy.completed)>0?Number(busy.completed)*1000:null):Date.now(),missingTables:result.missingTables};
    } catch {continue;}
    for(const item of items) for(const [resource,amount] of Object.entries(item.costs??{})) if(Number.isSafeInteger(amount)&&amount>0) {
      forecast[city.id]??={};forecast[city.id][resource]=(forecast[city.id][resource]??0)+amount;
    }
  }
  if(iconsChanged) await chrome.storage.local.set({[iconsKey]:icons});
  await chrome.storage.local.set({['main-build-supply-diagnostics-'+accountKey]:{at:Date.now(),cities:diagnostics,reducersGate:{ready:gateOpen}}});
  await chrome.storage.local.set({['main-build-supply-queues-'+accountKey]:{at:Date.now(),cities:queues}});
  return forecast;
}
async function buildingForecast(accountKey,snapshot,readCostTable=null) {
  if(mainEdition()) return mainForecast(accountKey,snapshot,readCostTable);
  const state=(await chrome.storage.local.get('game-automations-v1'))['game-automations-v1'];
  const forecast={};
  for(const task of state?.rules??[]) {
    const plan=task.progress?.forecast;
    if(task.kind!=='building'||task.accountKey!==accountKey||!task.enabled||task.deleted||!plan?.resources||Date.now()-(plan.at??0)>6*3600000) continue;
    forecast[task.cityId]??={};
    // A value no building can cost in 48 hours is a misread table, never a reserve.
    for(const [resource,amount] of Object.entries(plan.resources)) if(Number.isSafeInteger(amount)&&amount>0&&amount<20000000) forecast[task.cityId][resource]=Math.max(forecast[task.cityId][resource]??0,amount);
  }
  return forecast;
}
// Cities gathering a resource (consolidation, or buying it in the market) keep it.
async function heldResources(accountKey) {
  const state=(await chrome.storage.local.get('game-automations-v1'))['game-automations-v1'];
  const holds={};
  for(const task of state?.rules??[]) if(task.accountKey===accountKey&&task.enabled&&!task.deleted&&(task.kind==='consolidate'||task.kind==='market'&&task.marketMode==='buy')&&task.marketResource) (holds[task.cityId]??={})[task.marketResource]=true;
  return holds;
}
// Last 40 steps of transport runs in this tab, for diagnosing a run that never reports progress.
async function transportTrace(id,step,extra={}) {
  try {const key='transport-trace-v1',list=(await chrome.storage.local.get(key))[key]??[];
    await chrome.storage.local.set({[key]:[{at:Date.now(),id:String(id??'').slice(0,8),step,queue:globalThis.IkariamDiagQueue?.()??null,...extra},...list].slice(0,40)});} catch { /* Diagnostics only. */ }
}
async function executeAccountPolicy(rule) {
  const scanStartedAt=Date.now();
  await transportTrace(rule.inFlight,'job-start');
  const initial=await resolveCurrentPage();
  await transportTrace(rule.inFlight,'page-resolved',{found:!!initial?.found});
  if([initial.ownerName,initial.mundo,initial.servidor].join("|")!==rule.accountKey) throw new Error("החשבון השתנה; האיזון לא הופעל");
  const ledgerKey="account-policy-receipts-"+rule.id;
  let ledger=(await chrome.storage.local.get(ledgerKey))[ledgerKey]??[];
  const shipments=[],attempts=[],reconciledInRun=[];
  const publish=(stage,extra={})=>chrome.storage.local.set({['transport-progress-'+rule.inFlight]:{stage,updatedAt:Date.now(),...extra}});
  await publish('ממתין לתור הקריאות ומכין סריקה');
  // Free merchant ships are account-wide: with all ships at sea, one page read is enough
  // and the full scan waits for the next check (two minutes later).
  if(!rule.reviewMode||rule.reviewMode==='auto') {
    const response=await (globalThis.IkariamPageFetch??fetch)('/index.php?'+new URLSearchParams({view:'city',cityId:initial.cityId}),{credentials:'same-origin',redirect:'error',signal:AbortSignal.timeout(15000)});
    const free=response.ok?(await response.text()).match(/GlobalMenu_freeTransporters">(\d+)</)?.[1]:null;
    if(free==='0'&&!mainEdition()) return {status:'waiting',remaining:0,shipments:[],noShips:true,message:'כל ספינות המסחר בדרך; בדיקה חוזרת בעוד 2 דקות'};
  }
  async function scan() {
    const read=async (params,post=false,fresh=false)=>{
      const options={credentials:"same-origin",redirect:"error",signal:AbortSignal.timeout(15000)};
      if(mainEdition()&&fresh)options.cache="no-store";
      if(post) {options.method="POST";options.headers={"Content-Type":"application/x-www-form-urlencoded"};options.body=new URLSearchParams(params).toString();}
      const response=await (globalThis.IkariamPageFetch??fetch)("/index.php"+(post?"":"?"+new URLSearchParams(params)),options);
      if(!response.ok) throw new Error("סריקת איזון נכשלה");return response.text();
    };
    await publish('קורא תנועות ומטענים בדרך');
    const home=await read({view:"city",cityId:initial.cityId});
    const token=home.match(/actionRequest"?:\s*"([^"]+)"/)?.[1];
    if(!token) throw new Error("לא נמצא טוקן לסריקת התנועות");
    let movements=advisorMovements(JSON.parse(await read({view:"militaryAdvisor",oldView:"city",oldBackgroundView:"city",backgroundView:"city",currentCityId:initial.cityId,actionRequest:token,ajax:1},true)))
      .map(m=>({...m,origin:m.origin?{...m.origin,name:decodeUnicodeEscape(m.origin.name),avatarName:decodeUnicodeEscape(m.origin.avatarName)}:m.origin,
        target:m.target?{...m.target,name:decodeUnicodeEscape(m.target.name),avatarName:decodeUnicodeEscape(m.target.avatarName)}:m.target}));
    const receiptAfter=mainEdition()?Math.max(0,...ledger.map(item=>Number(item.createdAt)||0)):0;
    const reconciledAfter=mainEdition()?Number((await chrome.storage.local.get('main-shipment-reconciled-after-'+rule.id))['main-shipment-reconciled-after-'+rule.id])||0:0;
    const allocationFence=mainEdition()?(await chrome.storage.local.get('main-supply-allocation-fence-v2'))['main-supply-allocation-fence-v2']:null;
    const allocationSnapshotAfter=allocationFence?.active&&allocationFence.accountKey===rule.accountKey?scanStartedAt:0;
    const snapshot=await cachedSnapshot(rule.accountKey,120000,Math.max(rule.lastShipment?.submittedAt??0,receiptAfter,reconciledAfter,allocationSnapshotAfter))??await sharedEnrichedSnapshot(async(cities,total)=>publish('נסרקה עיר '+cities.at(-1).name,{done:cities.length,total}));
    await publish('הסריקה הושלמה — מחשב חוסרים ועודפים',{done:snapshot.cities.length,total:snapshot.cities.length});
    if(snapshot.ownerName!==initial.ownerName) throw new Error("החשבון השתנה בסריקה");
    const freshEndpoints=new Set(),selectedReceipts=new Set();let freshAdvisor=false,reconciliationReadFailed=false;
    if(mainEdition()) {
      const candidates=ledger.filter(item=>item.kind==='balance'&&['pending','accepted'].includes(item.status)&&Date.now()-item.createdAt>=15*60000);
      if(candidates.length) {
        const cursorKey='main-shipment-reconcile-cursor-'+rule.id,cursor=Number((await chrome.storage.local.get(cursorKey))[cursorKey])||0;
        const offset=cursor%candidates.length,selected=[...candidates.slice(offset),...candidates.slice(0,offset)].slice(0,2);
        for(const item of selected)selectedReceipts.add(item);
        await chrome.storage.local.set({[cursorKey]:(offset+selected.length)%candidates.length});
        for(const id of new Set(selected.flatMap(item=>[item.originCityId,item.destinationCityId]))) {
          try {
            const city=snapshot.cities.find(item=>String(item.id)===String(id));if(!city)continue;
            const text=await read({view:'city',cityId:String(id)},false,true);
            const match=text.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/);
            const raw=match?JSON.parse(match[1]):null;
            const stock=parseAvailableResources(text);
            if(!raw||String(raw.id)!==String(id)||decodeUnicodeEscape(raw.ownerName)!==initial.ownerName||!stock||!['wood','wine','marble','crystal','sulfur'].every(key=>Number.isFinite(stock[key])&&stock[key]>=0))continue;
            city.resources={...city.resources,...stock};city.name=decodeUnicodeEscape(raw.name);freshEndpoints.add(String(id));
          } catch { /* A partial endpoint read cannot retire a receipt. */ }
        }
        if(selected.some(item=>freshEndpoints.has(String(item.originCityId))&&freshEndpoints.has(String(item.destinationCityId))))try {
          const current=await read({view:'city',cityId:initial.cityId},false,true),currentToken=current.match(/actionRequest"?:\s*"([^"]+)"/)?.[1];
          const currentMatch=current.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/),currentCity=currentMatch?JSON.parse(currentMatch[1]):null;
          if(!currentToken||!currentCity||String(currentCity.id)!==String(initial.cityId)||decodeUnicodeEscape(currentCity.ownerName)!==initial.ownerName)throw new Error('fresh account identity unavailable');
          movements=advisorMovements(JSON.parse(await read({view:'militaryAdvisor',oldView:'city',oldBackgroundView:'city',backgroundView:'city',currentCityId:initial.cityId,actionRequest:currentToken,ajax:1},true,true)))
            .map(m=>({...m,origin:m.origin?{...m.origin,name:decodeUnicodeEscape(m.origin.name),avatarName:decodeUnicodeEscape(m.origin.avatarName)}:m.origin,target:m.target?{...m.target,name:decodeUnicodeEscape(m.target.name),avatarName:decodeUnicodeEscape(m.target.avatarName)}:m.target}));
          freshAdvisor=true;
        } catch {reconciliationReadFailed=true;}
      }
    }
    const reservations=globalThis.IkariamAccountPolicy.cargoReservations(snapshot.cities,movements,initial.ownerName);
    const reconciled=[];
    for(const receipt of ledger) {
      const source=snapshot.cities.find(city=>city.id===receipt.originCityId);
      const destination=snapshot.cities.find(city=>city.id===receipt.destinationCityId);
      if(!source || receipt.kind==="balance" && !destination) throw new Error("עיר מתוך משלוח קודם חסרה בסריקה");
      const matching=movements.filter(m=>m.origin?.name===source.name && m.origin?.avatarName===initial.ownerName &&
        m.target?.name===(destination?.name??receipt.externalTarget?.cityName) &&
        m.target?.avatarName===(destination?initial.ownerName:receipt.externalTarget?.playerName) &&
        m.resources?.some(r=>Number(String(r.amount??0).replace(/[, .\u00a0]/g,''))>0&&String(r.cssClass).split(/\s+/).includes(receipt.resource==="crystal"?"glass":receipt.resource)));
      const returning=matching.some(m=>m.event?.isFleetReturning===true || m.event?.isFleetReturning===1 || m.event?.isFleetReturning==="1");
      if(returning&&!mainEdition())throw new Error("משלוח מנוהל חוזר למוצא; יש לבדוק את סיבת החזרה במשחק");
      if(matching.length) receipt.observed=true;
      // A run interrupted around the send leaves its receipt pending. A dispatched cargo
      // shows up in the movements (or as a stock drop at the source) immediately, so after
      // a few minutes without either it was not sent; movements cover anything in transit.
      if(mainEdition()&&selectedReceipts.has(receipt)&&['pending','accepted'].includes(receipt.status)&&Date.now()-receipt.createdAt>=15*60000) {
        const decision=globalThis.IkariamAccountPolicy.reconcileMainShipment(receipt,{source,destination,movements,player:initial.ownerName,now:Date.now(),fresh:freshAdvisor&&freshEndpoints.has(String(receipt.originCityId))&&freshEndpoints.has(String(receipt.destinationCityId))});
        receipt.reconciliation=decision.evidence;receipt.verification={status:decision.status,reason:decision.reason,at:Date.now()};
        if(decision.status==='reconciled') {
          receipt.status='settled';
          reconciled.push({id:receipt.id,originCityId:receipt.originCityId,destinationCityId:receipt.destinationCityId,resource:receipt.resource,amount:receipt.amount,createdAt:receipt.createdAt,resolvedAt:Date.now(),decision:'reconciled-current-state',reason:decision.reason,evidence:decision.evidence});
          continue;
        }
      }
      if(returning&&mainEdition()) {receipt.status='pending';receipt.reconciliation=null;receipt.verification={status:'returning',reason:'המטען חוזר למוצא; הסוכן ימתין לחזרתו ואז יחשב את החוסר מחדש',at:Date.now()};continue;}
      if(receipt.status==="pending") {
        if(mainEdition()) {
          const decision=globalThis.IkariamAccountPolicy.assessPendingShipment(receipt,{source,destination,matching,now:Date.now()});
          if(!receipt.reconciliation)receipt.verification={...decision,at:Date.now()};
          if(decision.status==='not-sent'||decision.status==='delivered') {receipt.status='settled';continue;}
          if(decision.status==='accepted')receipt.status='accepted';
        }
        if(matching.length || source.resources[receipt.resource]<=receipt.sourceStockBefore-receipt.amount) receipt.status="accepted";
        else if(mainEdition()&&receipt.status==="pending") {receipt.lastVerificationAt=Date.now();continue;}
        else if(!mainEdition()&&Date.now()-receipt.createdAt>180000) {receipt.status="settled";continue;}
        else if(!mainEdition()) throw new Error("משלוח קודם עדיין לא אומת בתנועות; ממתין לבדיקה הבאה");
      }
      if(receipt.kind==="balance") {
        if(!matching.length && (receipt.observed || destination.resources[receipt.resource]>=receipt.destinationStockBefore+receipt.amount)) receipt.status="settled";
      } else if(source.resources[receipt.resource]<=receipt.sourceStockBefore-receipt.amount || receipt.observed && !matching.length) receipt.status="settled";
    }
    ledger=ledger.filter(item=>item.status!=="settled");
    if(mainEdition()&&reconciled.length) {
      const key='main-shipment-resolutions-'+rule.id,previous=(await chrome.storage.local.get(key))[key]??[];
      await chrome.storage.local.set({[ledgerKey]:ledger,['main-shipment-reconciled-after-'+rule.id]:Date.now(),[key]:[...previous.filter(item=>Date.now()-item.resolvedAt<7*86400000),...reconciled].slice(-200)});
      reconciledInRun.push(...reconciled);
    } else await chrome.storage.local.set({[ledgerKey]:ledger});
    if(reconciliationReadFailed)throw new Error('קריאת המשחק נכשלה באימות התנועות; תתבצע בדיקה חוזרת ללא שליחה');
    const localIncoming={},localOutgoing={};
    for(const receipt of ledger) {
      localOutgoing[receipt.originCityId]??={};localOutgoing[receipt.originCityId][receipt.resource]=(localOutgoing[receipt.originCityId][receipt.resource]??0)+receipt.amount;
      if(receipt.kind==="balance") {localIncoming[receipt.destinationCityId]??={};localIncoming[receipt.destinationCityId][receipt.resource]=(localIncoming[receipt.destinationCityId][receipt.resource]??0)+receipt.amount;}
    }
    for(const [kind,local] of [["incoming",localIncoming],["outgoing",localOutgoing]]) for(const [id,resources] of Object.entries(local)) {
      reservations[kind][id]??={};for(const [resource,amount] of Object.entries(resources)) reservations[kind][id][resource]=Math.max(amount,reservations[kind][id][resource]??0);
    }
    // Reads stay inside the current tab job and follow the existing Ikipedia lookup.
    const readCostTable=async(building,cityId)=>{
      let page=await read({view:'city',cityId});
      let currentToken=page.match(/actionRequest"?:\s*"([^"]+)"/)?.[1];
      if(!currentToken) throw new Error('לא נמצא טוקן לקריאת עלויות');
      const help=async params=>{
        const source=await read({...params,backgroundView:'city',currentCityId:cityId,actionRequest:currentToken,ajax:1});
        try {const commands=JSON.parse(source);currentToken=commands.find(item=>item[0]==='updateGlobalData')?.[1]?.actionRequest??currentToken;} catch { /* HTML response */ }
        return globalThis.IkariamReadInsights.viewHtml(source);
      };
      const index=await help({view:'buildingDetail',buildingId:0,helpId:1,templateView:'ikipedia'});
      const document=new DOMParser().parseFromString(index,'text/html');
      const button=[...document.querySelectorAll('.button_building')].find(item=>item.classList.contains(building));
      const link=button?.getAttribute('onclick')?.match(/ajaxHandlerCall\('\?([^']*)'/)?.[1];
      if(!link) throw new Error('קישור עלות לא זוהה');
      const params=Object.fromEntries(new URLSearchParams(link.replace(/&amp;/g,'&')));delete params.actionRequest;
      // Only the game's help view is accepted; an unexpected action is never followed.
      if(params.action||params.view!=='buildingDetail') throw new Error('קישור עלות אינו תצוגת עזרה');
      return globalThis.IkariamBuildForecast.parseCostTable(await help({...params,templateView:'buildingDetail'}));
    };
    // The game's build-list window of a city (read only): the waiting entries in queue order.
    if(mainEdition()) readCostTable.readList=async cityId=>{
      // At most one read per city every ten minutes (fewer requests to the game server).
      const cached=globalThis.__ikaListCache?.get(String(cityId));if(cached&&Date.now()-cached.at<600000) return cached.entries;
      const entries=await readListNow(cityId);(globalThis.__ikaListCache??=new Map()).set(String(cityId),{at:Date.now(),entries});return entries;
    };
    const readListNow=async cityId=>{
      const page=await read({view:'city',cityId},false,true);
      const currentToken=page.match(/actionRequest"?:\s*"([^"]+)"/)?.[1];
      if(!currentToken)throw new Error('list token unavailable');
      return globalThis.IkariamBuildForecast.parseConstructionListHtml(globalThis.IkariamReadInsights.viewHtml(await read({view:'buildingConstructionList',cityId,position:0,backgroundView:'city',currentCityId:cityId,actionRequest:currentToken,ajax:1},false,true)));
    };
    if(mainEdition()) readCostTable.readQuote=async(cityId,building)=>{
      const page=await read({view:'city',cityId},false,true);
      const match=page.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/),raw=match?JSON.parse(match[1]):null;
      if(!raw||String(raw.id)!==String(cityId)||decodeUnicodeEscape(raw.ownerName)!==initial.ownerName)throw new Error('quote city identity unavailable');
      const actual=raw.position?.find((item,index)=>String(item?.position??index)===String(building.position)&&item?.building===building.building);
      if(!actual||actual.isBusy||Number(actual.level)!==Number(building.level))throw new Error('building changed before quote');
      const currentToken=page.match(/actionRequest"?:\s*"([^"]+)"/)?.[1];
      if(!currentToken)throw new Error('quote token unavailable');
      return globalThis.IkariamReadInsights.parseCityView(await read({view:building.building,position:building.position,backgroundView:'city',currentCityId:cityId,actionRequest:currentToken,ajax:1},false,true));
    };
    return {snapshot,reservations,readCostTable};
  }
  try {
    // Up to four chunks per scan: wine supply first, then free exports and remaining balances.
    // One full scan per run (about 200 requests): rescanning before every chunk held the
    // tab's read queue for many minutes. After each accepted send the in-memory stocks are
    // adjusted, and executeAutomationTransport re-reads the origin before sending anyway.
    let report;
    // Full balancing runs at 01:00 and 06:00 Israel time; the rest of the day free ships carry
    // surplus to the main account (urgent wine and upgrade supplies still go at any hour).
    const hour=Number(new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Jerusalem",hour:"2-digit",hourCycle:"h23"}).format(new Date()));
    // Main edition (user decision, 2026-10-18): building supply for the game's build list and the
    // 48,000 wine balance both run at any hour; crystal, sulfur, wood and marble have no 48,000 base
    // and go only where a queued upgrade needs them.
    const balanceWindow=mainEdition()?true:(Array.isArray(rule.balanceHours)?rule.balanceHours:[1,6]).includes(hour);
    const {snapshot,reservations,readCostTable}=await scan();
    const needs=await buildingNeeds(rule.accountKey),holds=await heldResources(rule.accountKey);
    // Firefox edition: the satisfaction guard's unhappy cities get wine first (user decision, 2026-10-20).
    const wineFirst=mainEdition()?[]:((((await chrome.storage.local.get('satisfaction-v1'))['satisfaction-v1']??{})[rule.accountKey]?.cities)??[]).filter(city=>city.unhappy).map(city=>city.cityId);
    let forecast=await buildingForecast(rule.accountKey,snapshot,readCostTable);
    const supplyQueues=mainEdition()?((await chrome.storage.local.get('main-build-supply-queues-'+rule.accountKey))['main-build-supply-queues-'+rule.accountKey]?.cities??null):null;
    if(supplyQueues) for(const [id,queue] of Object.entries(supplyQueues)) if(queue.missingTables?.length&&!queue.items?.length) {
      // A reducer-complete city has no eligible upgrades while the account gate is shut.
      // Missing tables for prohibited future buildings must not freeze its donor stock.
      const city=snapshot.cities.find(item=>String(item.id)===String(id));
      const gatedComplete=mainEdition()&&globalThis.IkariamBuildForecast?.reducersReady(snapshot.cities)===false&&city&&globalThis.IkariamBuildForecast?.reducersReady([city])===true&&globalThis.IkariamBuildForecast.constructionList(city.buildings).length===0;
      if(!gatedComplete) holds[id]={...holds[id],wood:true,wine:true,marble:true,crystal:true,sulfur:true};
    }
    const finish=async result=>{
      if(mainEdition()&&result.report?.mainCoordinationInputs){
        result.report.mainCoordinationInputs.incoming=Object.fromEntries(Object.entries(reservations.incoming??{}).map(([id,resources])=>[id,{...resources}]));
        result.report.cities=result.report.cities.map(city=>({...city,resources:{...snapshot.cities.find(item=>String(item.id)===String(city.id)).resources}}));
      }
      return queueMainSupplyScan(rule,result,scanStartedAt);
    };
    let supplyRound=null;
    const wineCarryKey='main-wine-carry-'+rule.accountKey;
    let wineCarry=mainEdition()?((await chrome.storage.local.get(wineCarryKey))[wineCarryKey]??{}):{};
    const buildSupplyDiagnostics=mainEdition()?(await chrome.storage.local.get('main-build-supply-diagnostics-'+rule.accountKey))['main-build-supply-diagnostics-'+rule.accountKey]:null;
    // Keep using free ships in the same run: balances first, then surplus exports. A chunk the
    // game does not take (no ships, full warehouse) is skipped for this run; three in a row end it.
    const runSkipped=new Set(),unavailableOrigins=new Set();let misses=0,activeSupplyCity=null;
    for(let step=0;step<Math.min(40,rule.shipmentBudget??40);step++) {
      // Previous shipment is settled locally; the next transport does a fresh preflight.
      await yieldToPirates();
      const flags=await chrome.storage.local.get(['transport-stop-'+rule.id,'transport-pause-'+rule.id]);
      if(flags['transport-stop-'+rule.id]) break;
      // "Pause in this account" holds only what leaves the account (exports to the main account);
      // balancing between its own cities goes on. Read every step, so it applies mid-run too.
      const holdExports=!!rule.paused||!!flags['transport-pause-'+rule.id];
      const mainModeKey='main-build-mode-'+rule.accountKey;
      const mainMode=mainEdition()?((await chrome.storage.local.get(mainModeKey))[mainModeKey]??{}):{};
      const plan=(targets,round=null)=>globalThis.IkariamAccountPolicy.planAccountPolicy(snapshot,{...rule,mainBuildSupply:mainEdition(),mainRoundLoads:mainEdition(),mainCityDispatch:mainEdition(),mainActiveSupplyCity:mainEdition()?activeSupplyCity:null,mainUnavailableOrigins:mainEdition()?[...unavailableOrigins]:[],mainCentralCityId:mainEdition()&&mainMode.enabled?String(mainMode.cityId??''):null,buildDeadlines:mainEdition()?round?.neededAt:null,exportEnabled:rule.exportEnabled&&!holdExports&&!rule.wineOnly&&!rule.warActive,exportOnly:!balanceWindow,needs,forecast:targets,holds,wineFirst,...(mainEdition()?{floors:{wood:0,marble:0,crystal:0,sulfur:0}}:{})},reservations);
      if(mainEdition()&&supplyQueues&&globalThis.IkariamBuildForecast?.supplyRounds) {
        supplyRound=globalThis.IkariamBuildForecast.supplyRounds({snapshot,queues:supplyQueues,reservations,plan});
        forecast=supplyRound.forecast;report=supplyRound.report;
      } else report=plan(forecast);
      // Wine-only mode: only wine moves between the account's cities; nothing leaves the account.
      // Firefox wine balancing (user decision, 2026-10-22): the balancing moves wine only, so wood and marble
      // and the merchant ships stay for the main account's steady supply.
      // Firefox: a city upgrading its governor's residence still receives what the upgrade lacks from the
      // account's other cities (user decision, 2026-10-23: full satisfaction first; with wine-only balancing
      // the upgrades waited forever for crystal, sulfur and marble).
      const governorCities=!mainEdition()&&!rule.warActive?new Set((((await chrome.storage.local.get('game-automations-v1'))['game-automations-v1']?.rules)??[]).filter(item=>item.accountKey===rule.accountKey&&item.kind==='building'&&item.autopilot==='satisfaction'&&item.enabled&&!item.deleted).map(item=>String(item.cityId))):new Set();
      if(rule.wineOnly||rule.warActive||!mainEdition()&&rule.wineBalanceOnly) {report.actions=report.actions.filter(action=>action.kind==="balance"&&(action.resource==="wine"||governorCities.has(String(action.destinationCityId))));report.action=report.actions[0]??null;}
      if(mainEdition()) {report.actions=report.actions.filter(action=>action.kind==="balance");report.action=report.actions[0]??null;}
      if(mainEdition()) {
        const buildNeeds=Object.fromEntries(snapshot.cities.map(city=>[city.id,{wine:Math.max(needs[city.id]?.wine??0,forecast[city.id]?.wine??0)}]));
        const scheduled=globalThis.IkariamAccountPolicy.mainWineSchedule(report,snapshot,reservations,wineCarry,hour<7,buildNeeds);
        wineCarry=scheduled.pending;report.actions=scheduled.actions.map(action=>({...action,amount:Math.min(Math.ceil(action.amount/500)*500,Math.floor((snapshot.cities.find(city=>city.id===action.originCityId).resources[action.resource]-(action.sourceReserve??0)-(reservations.outgoing?.[action.originCityId]?.[action.resource]??0))/500)*500)})).filter(action=>action.amount>=500);report.action=report.actions[0]??null;
        await chrome.storage.local.set({[wineCarryKey]:wineCarry});
      }
      // Main edition (user decision, 2026-10-16): the free ships go first to the city that lacks the
      // most for its next steps, then the next one — the same order the shipments log shows.
      if(mainEdition()) {
        const lack=id=>{const city=snapshot.cities.find(item=>String(item.id)===String(id));return Object.entries(forecast[id]??{}).reduce((sum,[resource,amount])=>sum+Math.max(0,amount-(Number(city?.resources?.[resource])||0)),0);};
        // Wine for a city about to run dry first, then the build list (the city lacking the most
        // first), then the 48,000 wine balance.
        const rank=action=>action.resource==="wine"&&report.wine.criticalCityIds.includes(action.destinationCityId)?0:action.resource!=="wine"||lack(action.destinationCityId)>0&&Number(forecast[action.destinationCityId]?.wine)>0?1:2;
        const deadline=action=>{
          const neededAt=supplyRound?.neededAt?.[action.destinationCityId];
          if(!Number.isFinite(neededAt)) return Infinity;
          const known=[...ledger].reverse().find(item=>item.originCityId===action.originCityId&&item.destinationCityId===action.destinationCityId&&Date.now()-item.createdAt<600000&&Number.isFinite(item.timing?.travelSeconds));
          const seconds=known?known.timing.travelSeconds+(known.amount===action.amount?(known.timing.loadingSeconds??0)+(known.timing.queueSeconds??0):0):0;
          action.buildNeededAt=neededAt;action.dispatchBy=neededAt-seconds*1000;action.transportTimingKnown=!!known;
          return action.dispatchBy;
        };
        for(const action of report.actions) {deadline(action);action.supplyPriority=rank(action);}
        report.actions=[...report.actions].sort((a,b)=>rank(a)-rank(b)||(a.supplyCityOrder??Infinity)-(b.supplyCityOrder??Infinity)||(supplyRound?deadline(a)-deadline(b):lack(b.destinationCityId)-lack(a.destinationCityId)));report.action=report.actions[0]??null;
      }
      const unresolved=mainEdition()?ledger.filter(receipt=>receipt.status==='pending'):[];
      if(unresolved.length) {
        report.actions=report.actions.filter(action=>!globalThis.IkariamAccountPolicy.shipmentIsQuarantined(action,unresolved));
        report.action=report.actions[0]??null;
      }
      const signature=action=>[action.kind,action.originCityId,action.destinationCityId,action.resource,action.amount].join(':');
      const candidates=report.actions.filter(action=>!(rule.skippedPlans??[]).includes(signature(action))&&!runSkipped.has(signature(action)));
      let action=mainEdition()?globalThis.IkariamAccountPolicy.mainCitySupplyAction(candidates,activeSupplyCity,report.wine?.criticalCityIds??[]):candidates[0];
      if(mainEdition()&&action?.supplyPriority===1)activeSupplyCity=action.destinationCityId;
      const plans=candidates.slice(0,100).map(action=>{
        const source=snapshot.cities.find(city=>city.id===action.originCityId);
        const destination=snapshot.cities.find(city=>city.id===action.destinationCityId);
        return {...action,key:signature(action),originName:source.name,destinationName:destination?.name??action.externalTarget?.cityName,
          sourceStock:source.resources[action.resource],destinationStock:destination?.resources[action.resource]??null,
          reason:action.scarceWine?'חלוקת יין בחשבון קטן לפי הצריכה והייצור; שמירה על רציפות האספקה':'עודפים פנויים לאחר שמירת מלאי, חוסרים ומטענים בדרך'};
      });
      const scanReport={...(mainEdition()?{mainSupplyRevision:'2026-10-20-city-supply-v1',mainCoordinationInputs:{forecast,needs,queueItems:Object.fromEntries(Object.entries(supplyQueues??{}).map(([id,queue])=>[id,queue.items.map(item=>({building:item.building,level:item.level,list:!!item.list}))])),incoming:Object.fromEntries(Object.entries(reservations.incoming??{}).map(([id,resources])=>[id,{...resources}])),wineTargets:Object.fromEntries(snapshot.cities.map(city=>[city.id,Math.max(wineCarry[city.id]??0,(hour<7||report.wine.criticalCityIds.includes(city.id))?report.wine.targets[city.id]??0:0)]))},unavailableOrigins:[...unavailableOrigins],reconciledShipments:reconciledInRun,sourceBudgets:report.sourceBudgets??[],buildSupplyInputs:{needs,holds,forecastLoaded:!!globalThis.IkariamBuildForecast?.forecast,layersLoaded:!!globalThis.IkariamBuildForecast?.supplyRounds},advancedBuildMode:mainMode,centralSupplyShortage:rule.balanceEnabled&&!unavailableOrigins.has(String(mainMode.cityId))?globalThis.IkariamAccountPolicy.mainCentralSupplyShortage(report,snapshot,mainMode,{queues:supplyQueues,depth:supplyRound?.depth,reservations}):null,costAccuracy:'live-game-quote for currently quotable next upgrades; remaining levels use research-14-percent table estimate'}:{}),unresolvedShipments:unresolved.map(item=>({id:item.id,originCityId:item.originCityId,destinationCityId:item.destinationCityId,resource:item.resource,amount:item.amount,createdAt:item.createdAt})),target:48000,balanceWindow,buildSupplyDiagnostics,supplyRound:supplyRound?{depth:supplyRound.depth,neededAt:supplyRound.neededAt,blocked:supplyRound.blocked}:null,unmetNeeds:report.unmetNeeds??[],wine:report.wine,exportBlocked:report.exportBlocked,shortages:report.shortages,pending:ledger.length,scannedAt:Date.now(),
        cities:snapshot.cities.map(city=>({id:city.id,name:city.name,...(mainEdition()?{coordinates:city.coordinates??null,islandId:city.islandId??null,storageCapacity:city.storageCapacity,resourceCapacities:city.resourceCapacities??null}:{}),resources:city.resources,hasTavern:(city.buildings??[]).some(b=>b.building==="tavern"),population:city.population,populationGrowthPerHour:city.populationGrowthPerHour,wineConsumptionPerHour:city.wineConsumptionPerHour,productionPerHour:city.productionPerHour})),plans};
      // The whole build list of every city (the user's game list first, then the agent's targets) is published
      // for the Firefox suppliers, not only the rounds Opera covers itself (user report, 2026-10-22: half a
      // million wood and marble in the lists while Firefox ships stood idle). A step the warehouse cannot hold ends it.
      const fullDepth={};
      if(mainEdition()) {
        const full={};
        for(const city of snapshot.cities) {
          const id=String(city.id),queue=supplyQueues?.[id];if(!queue)continue;
          const cap=key=>Number.isSafeInteger(city.resourceCapacities?.[key])?city.resourceCapacities[key]:city.storageCapacity;
          let sum={},count=0;
          for(const item of queue.items??[]) {
            const next={...sum};for(const [key,value] of Object.entries(item.costs??{}))next[key]=(next[key]??0)+value;
            if(Object.entries(next).some(([key,value])=>!Number.isSafeInteger(value)||value<0||value>cap(key)))break;
            sum=next;count++;
          }
          full[id]=sum;fullDepth[id]=count;
        }
        scanReport.mainCoordinationInputs.externalForecast=full;
      }
      if(mainEdition())scanReport.mainCoordinationInputs.queueTiming=Object.fromEntries(Object.entries(supplyQueues??{}).map(([id,queue])=>[id,{neededAt:queue.neededAt??null,items:queue.items.slice(0,Math.max(fullDepth[id]??0,supplyRound?.depth[id]??0)).map(item=>({building:item.building,level:item.level,list:!!item.list,costs:item.costs,seconds:item.seconds??null,costSource:item.costSource??null}))}]));
      // Publish the completed read/plan before any cargo operation. A later failed or
      // waiting shipment must not discard a valid scan or starve the Firefox bridge.
      if(mainEdition()&&step===0)await queueMainSupplyScan(rule,{report:scanReport},scanStartedAt);
      // Internal balancing off: the scan only reports the shortages to the Firefox suppliers (user decision, 2026-10-22).
      if(mainEdition()&&!rule.balanceEnabled) {report.scanReport=scanReport;break;}
      if(rule.reviewMode==='manual') {
        const approval=rule.approval;
        action=approval && Date.now()-approval.approvedAt<=180000?candidates.find(item=>signature(item)===approval.key):null;
        if(!action) return await finish({status:'waiting',remaining:0,shipments,report:scanReport,
          message:plans.length?'הסריקה הושלמה — פעולות ממתינות לאישור שלך':'הסריקה הושלמה — אין פעולה זמינה שלא דולגה'});
      }
      report.scanReport=scanReport;
      if(!action) break;

      if(ledger.length>=200) throw new Error("מגבלת משלוחים שלא אומתו הגיעה ל־200; נדרשת בדיקה");
      const source=snapshot.cities.find(city=>city.id===action.originCityId),destination=snapshot.cities.find(city=>city.id===action.destinationCityId);
      await publish('מתכונן לשלוח מ־'+source.name+' אל '+(destination?.name??action.externalTarget?.cityName)+' · '+action.amount.toLocaleString('he-IL')+' '+({wood:'עץ',wine:'יין',marble:'שיש',crystal:'קריסטל',sulfur:'גופרית'}[action.resource]??action.resource)+(action.kind==='export'?' (העברה לראשי)':' (איזון)'),{phase:'send',sent:shipments.length,planned:Math.min(candidates.length+shipments.length,Math.min(40,rule.shipmentBudget??40))});
      const receipt={...action,id:rule.inFlight+"-"+step,status:"pending",amount:action.amount,sourceStockBefore:source.resources[action.resource],destinationStockBefore:destination?.resources[action.resource],createdAt:Date.now()};
      ledger.push(receipt);await chrome.storage.local.set({[ledgerKey]:ledger});
      let result;
      try {result=await executeAutomationTransport({...action,accountKey:rule.accountKey,sendMode:"reserve",quantity:action.sourceReserve??48000,
        remaining:action.amount,...(mainEdition()?{mainSupplyPolicy:true,mainSupplyOperationId:receipt.id}:{}),intervalMinutes:2,maxCycles:1,policyDestinationCap:action.kind==="balance"?action.destinationCap??48000:undefined},async info=>{Object.assign(receipt,info);await chrome.storage.local.set({[ledgerKey]:ledger});});}
      catch(error) {
        if(error.mutationSubmitted===false) {ledger=ledger.filter(item=>item.id!==receipt.id);await chrome.storage.local.set({[ledgerKey]:ledger});}
        throw error;
      }
      attempts.push({kind:action.kind,originName:source.name,destinationName:destination?.name??action.externalTarget?.cityName,resource:action.resource,amount:action.amount,sent:result.status==="sent",message:result.message,...(mainEdition()?{waitingReason:result.waitingReason??null}:{} )});
      if(result.status!=="sent") {ledger=ledger.filter(item=>item.id!==receipt.id);await chrome.storage.local.set({[ledgerKey]:ledger});runSkipped.add(signature(action));
        if(mainEdition()){
          activeSupplyCity=null;
          if(result.waitingReason==='action-points')unavailableOrigins.add(String(action.originCityId));
          if(Number.isSafeInteger(result.sourceStock))source.resources[action.resource]=result.sourceStock;
          if(destination&&Number.isSafeInteger(result.destinationStock))destination.resources[action.resource]=result.destinationStock;
          if(result.waitingReason==='ships')break;
        }
        if(++misses>=3&&!mainEdition())break;continue;}
      misses=0;
      receipt.status="accepted";receipt.amount=result.amount;await chrome.storage.local.set({[ledgerKey]:ledger});
      source.resources[action.resource]=Math.max(0,source.resources[action.resource]-result.amount);
      if(destination) {reservations.incoming[destination.id]??={};reservations.incoming[destination.id][action.resource]=(reservations.incoming[destination.id][action.resource]??0)+result.amount;}
      shipments.push({...result,reason:plans.find(plan=>plan.key===signature(action))?.reason,originName:source.name,destinationName:destination?.name??action.externalTarget?.cityName,kind:action.kind,originCityId:action.originCityId,destinationCityId:action.destinationCityId,resource:action.resource,submittedAt:Date.now()});
      report.scanReport.plans=plans.filter(plan=>plan.key!==signature(action));

      if(rule.reviewMode==='manual') break;
    }
    const failed=attempts.find(item=>!item.sent);
    return await finish({status:shipments.length?"sent":"waiting",remaining:0,shipments,report:{...report?.scanReport,target:48000,shortages:report?.shortages??[],pending:ledger.length,scannedAt:Date.now(),sentShipments:shipments.length,attempts},
      message:(mainEdition()&&reconciledInRun.length?`טופלו ${reconciledInRun.length} רשומות משלוח ישנות; החוסרים חושבו מחדש לפי המצב במשחק · `:'')+(mainEdition()&&ledger.some(item=>item.status==='pending')?'משלוח קודם עדיין בבדיקה; המשאב בערי המוצא והיעד מושהה למניעת כפילות, שאר האספקה ממשיכה · ':'')+(balanceWindow?"":mainEdition()?"":"מחוץ לשעות האיזון המלא (01:00, 06:00) — קודם העברה לראשי, אחר כך איזונים · ")+(!shipments.length&&failed?"לא נשלח: "+failed.originName+" אל "+failed.destinationName+" · "+failed.amount+" "+({wood:"עץ",wine:"יין",marble:"שיש",crystal:"קריסטל",sulfur:"גופרית"}[failed.resource]??failed.resource)+" — "+failed.message:shipments.length?shipments.map(item=>(item.kind==="balance"?"איזון משאבים: ":"העברה לחשבון הראשי: ")+item.message).join(" · "):report?.exportBlocked==="wine-unparsed"?"העברה לראשי מושהית: נתוני צריכה/ייצור יין לא פוענחו בחשבון קטן":report?.exportBlocked?"העברה לראשי מושהית: יין קריטי (פחות מ־12 שעות) בעיר בחשבון":!rule.exportEnabled?"העברת עודפים לראשי כבויה; איזון בלבד":!rule.externalTarget?"לא הוגדר יעד מאומת למשתמש הראשי":"הסריקה הושלמה; אין עודפים פנויים או שהספינות בהפלגה")});
  } catch(error) {error.mutationSubmitted=shipments.length>0 || ledger.some(item=>item.status==="pending");throw error;}
}
const acceptedTransportOperations=new Set();
const gameActions=globalThis.IkariamGameAutomationActions?.createActions({resolveCurrentPage,decodeUnicodeEscape,verifyExternalTarget,transformPositions,parseAvailableResources,collectAccountSnapshot,advisorMovements,executeAutomationTransport,parseMilitaryTable});
const acceptedGameOperations=new Set();
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type==='IKARIAM_AGENT_PIRACY_CHECK') {
    if(!gameActions?.checkPiracy||message.rule?.kind!=='pirates'){sendResponse({ok:false,reason:'בקשת בדיקה אינה תקינה'});return false;}
    scheduleRead(()=>gameActions.checkPiracy(message.rule),'בדיקת מצב פיראטים').then(result=>sendResponse({ok:true,result}),error=>sendResponse({ok:false,reason:error.message}));return true;
  }
  // "בדוק עכשיו במשחק" of the raids table (Opera): reads only, ahead of the queue as the user's own request.
  if(message?.type==='IKARIAM_AGENT_RAID_PROBE') {
    const cities=(Array.isArray(message.cities)?message.cities:[]).map(city=>({name:String(city?.name??'').trim(),x:Number(city?.x),y:Number(city?.y)})).filter(city=>city.name&&Number.isInteger(city.x)&&Number.isInteger(city.y)&&city.x>0&&city.y>0&&city.x<=100&&city.y<=100);
    if(!mainEdition()||!gameActions?.raidProbe||!/^\d+$/.test(message.cityId??'')||typeof message.playerName!=='string'||!cities.length) {sendResponse({ok:false,reason:'בקשת הבדיקה אינה תקינה'});return false;}
    scheduleRead(()=>gameActions.raidProbe({kind:'pirates',cityId:message.cityId,accountKey:message.accountKey,reserve:0,entries:[]},message.playerName,cities),'בדיקת יעד פשיטה',{priority:true,user:true}).then(result=>sendResponse({ok:true,result}),error=>sendResponse({ok:false,reason:error.message}));return true;
  }
  if(message?.type==='IKARIAM_AGENT_AUTOMATION_CATALOG') {
    if(!gameActions || !globalThis.IkariamAutomationRules.KINDS.includes(message.kind) || !/^\d+$/.test(message.cityId??'')) {sendResponse({ok:false,reason:'בקשת אפשרויות אינה תקינה'});return false;}
    scheduleRead(()=>gameActions.catalog({kind:message.kind,cityId:message.cityId,accountKey:message.accountKey,reserve:0}),'אפשרויות לטופס',{priority:true}).then(catalog=>sendResponse({ok:true,catalog}),error=>sendResponse({ok:false,reason:error.message}));return true;
  }
  if(message?.type==='IKARIAM_AGENT_GAME_AUTOMATION') {
    const id=message.rule?.inFlight;
    if(!gameActions || typeof id!=='string'||!/^[\w-]{1,80}$/.test(id)) {sendResponse({ok:false,reason:'מזהה הרצה אינו תקין'});return false;}
    if(acceptedGameOperations.has(id)) {sendResponse({ok:true,accepted:true});return false;}
    acceptedGameOperations.add(id);
    const key='game-result-'+id;
    chrome.storage.local.get([key,'game-automations-v1']).then(async stored=>{
      if(stored[key]) {acceptedGameOperations.delete(id);sendResponse({ok:true,accepted:true});return;}
      const rule=stored['game-automations-v1']?.rules?.find(rule=>rule.id===message.rule.id&&rule.enabled&&!rule.deleted&&rule.inFlight===id);
      if(!rule) throw new Error('הרצה אינה תואמת לאוטומציה הפעילה');
      await chrome.storage.local.set({[key]:{status:'pending',phase:'queued',raidTracking:1,createdAt:Date.now()}});
      sendResponse({ok:true,accepted:true});
      // An answered pirate captcha jumps the tab's queue (a shipment scan can hold it for minutes).
      const raids=rule.kind==='pirates'?((await chrome.storage.local.get('pirate-raids-v1'))['pirate-raids-v1']??{})[rule.accountKey]:null;
      // Where the seconds between the crew's return and the next capture go (Firefox, 2026-10-30): every stage of
      // a run, the last 200 per account (times only, no game data).
      const timing=rule.kind==='pirates'&&!mainEdition()?{due:Number(rule.progress?.missionEndsAt)||null,dispatched:rule.dispatchedAt??null,queued:Date.now(),holder:readRunning?.label??null,waiting:readJobs.length}:null;
      void scheduleRead(async()=>{
        if(timing) timing.started=Date.now();
        await chrome.storage.local.set({[key]:{status:'pending',phase:'running',raidTracking:1,createdAt:Date.now()}});
        return gameActions.step(rule);
      },"אוטומציה: "+(rule.kind??"משימה"),{priority:rule.kind==='pirates'&&(mainEdition()||!!rule.captchaAnswer||!!raids?.running||Number(rule.pirateMission)===1&&rule.pirateStrategy!=='auto'),urgent:rule.kind==='pirates'&&!!raids?.running,operationId:id,yieldable:rule.kind!=='pirates',pirate:rule.kind==='pirates'||mainEdition()&&rule.kind==='building'}).then(
        result=>{
          if(timing) void pirateTiming(rule.accountKey,{...timing,sent:result?.progress?.missionStartedAt??null,done:Date.now(),status:result?.status??null}).catch(()=>{});
          return chrome.storage.local.set({[key]:{status:'complete',ok:true,result,createdAt:Date.now()}});
        },
        error=>chrome.storage.local.set({[key]:{status:'complete',ok:false,reason:error.message,mutationSubmitted:error.mutationSubmitted??true,createdAt:Date.now()}})
      ).catch(()=>console.error('[automation] result persistence failed')).finally(()=>acceptedGameOperations.delete(id));
    }).catch(()=>{acceptedGameOperations.delete(id);sendResponse({ok:false,reason:'לא ניתן לאמת ולשמור את תחילת ההרצה'});});return true;
  }
  // For the tab watchdog: is one job holding this tab's queue for too long?
  if(message?.type==='IKARIAM_AGENT_QUEUE_HEALTH') {sendResponse({ok:true,runningSince:readRunning?.since??null,label:readRunning?.label??null,waiting:readJobs.length});return false;}
  // The raids panel shows what holds this tab's queue (user request, 2026-10-18), and a job still
  // waiting can be taken out of it. A running job is never cut: it may be in the middle of a send.
  if(message?.type==='IKARIAM_AGENT_QUEUE_LIST') {
    sendResponse({ok:true,running:readRunning?{label:readRunning.label,since:readRunning.since,operationId:readRunning.operationId??null,posted:!!readRunning.posted,stopping:!!readRunning.stop}:null,
      waiting:readJobs.map((job,index)=>({index,label:job.label,operationId:job.operationId??null,priority:!!job.priority}))});return false;
  }
  if(message?.type==='IKARIAM_AGENT_QUEUE_CANCEL'&&mainEdition()) {
    const index=readJobs.findIndex((job,i)=>i===message.index&&job.label===message.label&&(job.operationId??null)===(message.operationId??null));
    if(index<0) {sendResponse({ok:false,reason:'המשימה כבר לא ממתינה בתור (התחילה או הסתיימה)'});return false;}
    const [job]=readJobs.splice(index,1);readWaiting=readJobs.length;
    const error=new Error('בוטלה מתור הלשונית לבקשתך');error.mutationSubmitted=false;job.reject(error);
    sendResponse({ok:true});return false;
  }
  // Stopping the running job is the user's choice (raids panel): it stops before its next request.
  if(message?.type==='IKARIAM_AGENT_QUEUE_STOP'&&mainEdition()) {
    if(!readRunning||readRunning.since!==message.since||readRunning.label!==message.label) {sendResponse({ok:false,reason:'המשימה כבר הסתיימה'});return false;}
    readRunning.stop=STOP_MESSAGE;sendResponse({ok:true,posted:!!readRunning.posted});return false;
  }
  // The crew read from the game for the raids panel: the fortress city of the pirate automation
  // itself (another city does not show the crew), and only while the tab is idle — a running job
  // moves between cities, so reading then would show whichever city it left selected.
  if(message?.type==='IKARIAM_AGENT_PIRATE_LIVE'&&mainEdition()) {
    if(!/^\d+$/.test(String(message.cityId??''))) {sendResponse({ok:false,reason:'עיר המבצר אינה ידועה'});return false;}
    scheduleRead(async()=>{
      const response=await (globalThis.IkariamPageFetch??fetch)('/index.php?'+new URLSearchParams({view:'city',cityId:String(message.cityId)}),{credentials:'same-origin',redirect:'error',signal:AbortSignal.timeout(15000)});
      if(!response.ok) throw new Error('קריאת מצב הצוות נכשלה');
      const text=(await response.text()).replace(/\\"/g,'"');
      const ship=text.match(/"showPirateFortressShip"\s*:\s*([01])/)?.[1];
      return {crewHome:ship==null?null:ship==='1',checkedAt:Date.now()};
    },'בדיקת מצב הצוות',{priority:true,pirate:true}).then(result=>sendResponse({ok:true,result}),error=>sendResponse({ok:false,reason:error.message}));return true;
  }
  if(message?.type==='IKARIAM_AGENT_PRIORITIZE_RAID') {
    const index=readJobs.findIndex(job=>job.operationId===message.operationId);
    if(index>=0) {const [job]=readJobs.splice(index,1);readJobs.unshift(job);}
    sendResponse({ok:true,promoted:index>=0});return false;
  }
  if(message?.type==='IKARIAM_AGENT_VACATION') {
    if(!gameActions?.vacation || typeof message.accountKey!=='string') {sendResponse({ok:false,reason:'בקשת מצב חופשה אינה תקינה'});return false;}
    scheduleRead(()=>gameActions.vacation(message.accountKey),'מצב חופשה',{priority:true}).then(result=>sendResponse({ok:true,result}),error=>sendResponse({ok:false,reason:error.message}));return true;
  }
  if(message?.type==="IKARIAM_AGENT_READ_CITY_VIEW") {
    scheduleRead(()=>collectCityReadView(message.cityId,message.kind,message.position),'תצוגת עיר',{priority:true}).then(report=>sendResponse({ok:true,report}),error=>sendResponse({ok:false,reason:error.message}));
    return true;
  }
  if(message?.type==="IKARIAM_AGENT_CAPTURE_POINTS") {
    scheduleRead(()=>readCapturePoints(),'נקודות לכידה',{priority:false}).then(result=>sendResponse({ok:true,result}),error=>sendResponse({ok:false,reason:error.message}));
    return true;
  }
  if(message?.type==="IKARIAM_AGENT_FLEET_TIMELINE") {
    scheduleRead(()=>fleetTimeline(),'יומן ספינות',{priority:false}).then(fleet=>sendResponse({ok:true,fleet}),error=>sendResponse({ok:false,reason:error.message}));
    return true;
  }
  if(message?.type==="IKARIAM_AGENT_TRANSPORT_QUOTE") {
    scheduleRead(()=>quoteTransport(message.originCityId,message.target,Number(message.amount)),'זמן הובלה',{priority:false}).then(timing=>sendResponse({ok:true,timing}),error=>sendResponse({ok:false,reason:error.message}));
    return true;
  }
  if(message?.type==="IKARIAM_AGENT_VERIFY_EXTERNAL_TARGET") {
    scheduleRead(()=>verifyExternalTarget(message.target,message.allowMissingIslandName===true),'אימות יעד',{priority:true,user:true}).then(target=>sendResponse({ok:true,target}),error=>sendResponse({ok:false,reason:error.message}));
    return true;
  }
  if(message?.type==="IKARIAM_AGENT_AUTOMATION_TRANSPORT") {
    const operationId=message.rule?.inFlight;
    if(typeof operationId!=="string" || !/^[a-zA-Z0-9-]{1,80}$/.test(operationId)) {
      sendResponse({ok:false,reason:"מזהה המשלוח אינו תקין"});return false;
    }
    const key="transport-result-"+operationId;
    if(acceptedTransportOperations.has(operationId)) {
      sendResponse({ok:true,accepted:true,operationId});return false;
    }
    acceptedTransportOperations.add(operationId);
    // A short acknowledgement replaces the long-lived result message channel.
    // Existing operation IDs are never dispatched a second time.
    chrome.storage.local.get([key,"transport-automation-v1"]).then(async stored=>{
      if(stored[key]) {acceptedTransportOperations.delete(operationId);sendResponse({ok:true,accepted:true,operationId});return;}
      const authorized=stored["transport-automation-v1"]?.rules?.some(rule=>rule.id===message.rule.id && rule.enabled && rule.inFlight===operationId);
      if(!authorized) throw new Error("המשלוח אינו תואם להרצה הפעילה");
      await chrome.storage.local.set({[key]:{status:"pending",createdAt:Date.now()}});
      sendResponse({ok:true,accepted:true,operationId});
      void transportTrace(operationId,'accepted',{policy:!!message.rule.policyMode});
      void scheduleRead(()=>message.rule.policyMode?executeAccountPolicy(message.rule):executeAutomationTransport(message.rule),message.rule.policyMode?"איזון והעברה לראשי (48,000)":"משלוח מתוזמן",{yieldable:!!message.rule.policyMode}).then(
        result=>chrome.storage.local.set({[key]:{status:"complete",ok:true,result,createdAt:Date.now()}}),
        error=>{void transportTrace(operationId,'error',{message:String(error?.message??error).slice(0,200)});return chrome.storage.local.set({[key]:{status:"complete",ok:false,reason:error.message,mutationSubmitted:error.mutationSubmitted??(message.rule.policyMode?false:true),createdAt:Date.now()}});}
      ).catch(error=>console.error("[automation] result persistence failed",error.message))
        .finally(()=>acceptedTransportOperations.delete(operationId));
    }).catch(()=>{acceptedTransportOperations.delete(operationId);sendResponse({ok:false,reason:"לא ניתן לשמור או לאמת את מצב המשלוח; ההרצה לא התחילה"});});
    return true;
  }
  if(message?.type==="IKARIAM_AGENT_MILITARY_DIAGNOSTICS") {
    try {sendResponse({ok:true,diagnostics:militaryDiagnostics()});}
    catch(error) {sendResponse({ok:false,reason:error.message});}
    return false;
  }
  if(message?.type!=="IKARIAM_AGENT_READ_SECTION") return false;
  scheduleRead(()=>collectSection(message.section),'קריאת חלונית',{priority:true}).then(
    report=>sendResponse({ok:true,report}),
    error=>sendResponse({ok:false,reason:error.message}));
  return true;
});
})();



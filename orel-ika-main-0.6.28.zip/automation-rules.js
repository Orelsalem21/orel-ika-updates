(() => {
const KINDS=['building','tavern','wine','recruit','workshop','research','experiment','miracle','barbarians','attacks','daily','pirates','workers','shrine','station','islands','reorganize','donate','market','consolidate','reinforce'];
const ALERT_KINDS=['reinforce','attacks','wine','pirates','islands','workers','daily','building','barbarians'];
const integer=(value,min,max)=>Number.isSafeInteger(value)&&value>=min&&value<=max;
function validateRule(input) {
  if(!input || !KINDS.includes(input.kind) || !/^\d{1,20}$/.test(input.cityId??'')) throw new Error('סוג האוטומציה או העיר אינו תקין');
  if(!integer(input.intervalMinutes,2,1440) || !integer(input.maxCycles,1,10000) || !integer(input.reserve,0,100000000)) throw new Error('מרווח הבדיקה, מספר המחזורים או המלאי השמור אינו תקין');
  if(input.startAt!=null && (!integer(input.startAt,1,8640000000000000) || input.startAt<Date.now())) throw new Error('מועד ההתחלה חייב להיות עתידי');
  const entries=input.entries??[];
  if(!Array.isArray(entries) || entries.length>100) throw new Error('ניתן להגדיר עד 100 פריטים');
  if(['building','recruit','workshop','research'].includes(input.kind) && entries.length===0) throw new Error('יש להוסיף פריטים לתור');
  const identifiers=new Set();
  for(const entry of entries) {
    if(!entry || typeof entry.key!=='string' || !/^[\w:-]{1,80}$/.test(entry.key) || identifiers.has(entry.key)) throw new Error('פריט תור כפול או לא תקין');
    identifiers.add(entry.key);
    if(!integer(entry.target,1,1000000)) throw new Error('הרמה או הכמות חייבת להיות מספר חיובי');
    if(input.kind==='building' && (!integer(entry.position,0,60) || entry.target>100)) throw new Error('מיקום או רמת מבנה אינם תקינים');
    if(input.kind==='station' && !/^\d{3}$/.test(entry.key)) throw new Error('יחידה להצבה אינה תקינה');
    if(input.kind==='workshop'&&entry.target>25 || input.kind==='research'&&entry.target!==1) throw new Error('רמת בית המלאכה או כמות המחקר אינה תקינה');
  }
  if(input.kind==='wine' && (!integer(input.hours,1,168) || !integer(input.transferAmount,1,1000000))) throw new Error('סף היין או כמות ההשלמה אינם תקינים');
  if(input.kind==='attacks'&&input.intervalMinutes<3) throw new Error('התראות תקיפה נבדקות לפחות כל שלוש דקות');
  if(input.kind==='daily' && typeof input.collectTasks!=='boolean') throw new Error('יש לבחור האם לאסוף משימות שהושלמו');
  const units=value=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length<=15&&Object.entries(value).every(([id,count])=>/^3\d\d$/.test(id)&&integer(count,1,100000));
  const custom=input.customUnits!=null;
  if(custom && (!units(input.customUnits.units)||!Object.keys(input.customUnits.units).length||input.customUnits.loot!=null&&!units(input.customUnits.loot))) throw new Error('הרכב התקיפה המותאם אינו תקין');
  if(input.kind==='barbarians' && (!integer(input.maxBarbarianLevel,1,custom?60:39) || typeof input.autoRecruit!=='boolean')) throw new Error('יש לבחור רמת ברברים עד 39 (או עד 60 בהרכב מותאם) ואפשרות השלמת כוחות');
  if(input.targetIslandId!=null && input.targetIslandId!=='' && !/^\d{1,12}$/.test(input.targetIslandId)) throw new Error('אי היעד אינו תקין');
  if(input.kind==='pirates' && (!integer(input.pirateMission,1,9) || !integer(input.convertAmount??0,0,100000000))) throw new Error('יש לבחור משימת פיראטים 1–9');
  const percents=['woodPercent','luxuryPercent','scientistPercent','priestPercent'];
  if(input.kind==='workers' && (percents.every(key=>input[key]==null) || percents.some(key=>input[key]!=null&&!integer(input[key],0,100)))) throw new Error('יש לבחור אחוז עובדים בין 0 ל־100 לפחות לסוג אחד');
  if(input.kind==='shrine' && (!Array.isArray(input.gods)||!input.gods.length||input.gods.length>6||new Set(input.gods).size!==input.gods.length||!input.gods.every(god=>integer(god,1,6)))) throw new Error('יש לבחור אלים להפעלה');
  if(['station','reorganize'].includes(input.kind)) {
    const other=input.kind==='station'?input.destinationCityId:input.templateCityId;
    if(!/^\d{1,20}$/.test(other??'') || other===input.cityId) throw new Error('יש לבחור עיר שנייה שונה בחשבון');
    if(input.kind==='station' && !['army','fleet'].includes(input.deployType)) throw new Error('יש לבחור צבא או צי');
  }
  if(input.kind==='reinforce') {
    if(!/^3\d\d$/.test(String(input.battleUnit??''))||!integer(input.battleTarget,1,100000)||!['station','pillage','defend'].includes(input.battleMission)||!/^\d{1,20}$/.test(String(input.battleCityId??''))) throw new Error('יש לבחור יחידה, כמות, סוג קרב ועיר יעד');
    if(input.battleCoords!=null&&!(integer(input.battleCoords.x,1,100)&&integer(input.battleCoords.y,1,100))) throw new Error('קואורדינטות היעד אינן תקינות');
    if(input.battleCities!=null&&!(Array.isArray(input.battleCities)&&input.battleCities.every(id=>/^\d{1,20}$/.test(String(id))))) throw new Error('רשימת הערים אינה תקינה');
  }
  const coords=input.islandCoords??[];
  if(input.kind==='islands' && (!Array.isArray(coords)||coords.length>20||!coords.every(item=>/^\d{1,3}:\d{1,3}$/.test(item))||input.intervalMinutes<3)) throw new Error('קואורדינטות האיים אינן תקינות (עד 20, בפורמט X:Y) או שהמרווח קצר משלוש דקות');
  // Marketplace and consolidation (Ikabot buy/sell/consolidateResources).
  if(['market','consolidate'].includes(input.kind) && !['wood','wine','marble','crystal','sulfur'].includes(input.marketResource)) throw new Error('יש לבחור משאב');
  if(input.kind==='market' && (!['buy','sell'].includes(input.marketMode)||!integer(input.marketPrice,1,1000)||!integer(input.marketTarget,0,100000000)||!integer(input.goldReserve??0,0,1000000000))) throw new Error('יש לבחור קנייה או מכירה, מחיר (1–1000 זהב ליחידה) וכמות יעד');
  if(input.kind==='consolidate' && !integer(input.marketTarget??0,0,100000000)) throw new Error('הכמות שנשארת בכל עיר אינה תקינה');
  if(input.kind==='donate' && (!['resource','tradegood','auto'].includes(input.donateTarget)||!integer(input.donateAmount,1,100000000))) throw new Error('יעד או כמות התרומה אינם תקינים');
  if(input.kind==='daily' && input.favourCap!=null && (!integer(input.favourCap,1,1000000)||!integer(input.favourMargin??500,0,100000))) throw new Error('סף החסד אינו תקין');
  return {kind:input.kind,cityId:input.cityId,intervalMinutes:input.intervalMinutes,maxCycles:input.maxCycles,reserve:input.reserve,
    entries:entries.map(entry=>({key:entry.key,target:entry.target,...(entry.position!==undefined?{position:entry.position}:{}),label:String(entry.label??entry.key).slice(0,150)})),
    startAt:input.startAt??null,hours:input.hours??24,transferAmount:input.transferAmount??10000,autoTransfer:input.autoTransfer===true,
    autoRecruit:input.autoRecruit===true,maxBarbarianLevel:input.maxBarbarianLevel??9,collectTasks:input.collectTasks===true,collectVideos:input.collectVideos===true,autopilot:typeof input.autopilot==='string'&&/^(wine|barbarians|attacks|daily|uniform|tavern|pirates|research|miracle|satisfaction)$/.test(input.autopilot)?input.autopilot:null,allDayVideos:input.kind==='daily'&&input.allDayVideos===true,telegram:ALERT_KINDS.includes(input.kind)&&input.telegram===true,
    procure:input.kind==='building'&&input.procure===true,performTasks:input.performTasks===true,collectAmbrosia:input.collectAmbrosia===true,favourGuard:input.favourGuard!==false,favourCap:input.favourCap??2500,favourMargin:input.favourMargin??500,
    targetIslandId:input.kind==='barbarians'&&input.targetIslandId?String(input.targetIslandId):null,customUnits:input.kind==='barbarians'&&custom?{units:{...input.customUnits.units},loot:{...(input.customUnits.loot??{})}}:null,hephaestus:input.hephaestus===true,
    continuous:input.kind==='pirates'&&input.continuous===true,pirateMission:input.pirateMission??null,pirateStrategy:input.kind==='pirates'&&input.pirateStrategy==='auto'?'auto':'fixed',convertPoints:input.convertPoints===true,convertAmount:input.convertAmount??0,
    ...Object.fromEntries(percents.map(key=>[key,input.kind==='workers'?input[key]??null:null])),overcharge:input.overcharge===true,protectGold:input.protectGold!==false,
    gods:input.kind==='shrine'?[...input.gods]:[],destinationCityId:input.kind==='station'?input.destinationCityId:null,deployType:input.kind==='station'?input.deployType:null,
    templateCityId:input.kind==='reorganize'?input.templateCityId:null,islandCoords:input.kind==='islands'?[...coords]:[],watchFights:input.watchFights===true,
    marketMode:input.kind==='market'?input.marketMode:null,marketResource:['market','consolidate'].includes(input.kind)?input.marketResource:null,marketPrice:input.kind==='market'?input.marketPrice:null,marketTarget:['market','consolidate'].includes(input.kind)?input.marketTarget??0:null,goldReserve:input.kind==='market'?input.goldReserve??0:null,
    donateTarget:input.kind==='donate'?input.donateTarget:null,donateAmount:input.donateAmount??0,vacationReply:input.kind==='attacks'&&input.vacationReply===true,morning:input.morning===true,comfort:input.kind==='tavern'&&input.comfort===true,...(input.kind==='reinforce'?{battleUnit:String(input.battleUnit),battleTarget:input.battleTarget,battleMission:input.battleMission,battleCityId:String(input.battleCityId),battleCityName:String(input.battleCityName??'').slice(0,80),battleIslandId:input.battleIslandId?String(input.battleIslandId):null,battleCoords:input.battleCoords?{x:input.battleCoords.x,y:input.battleCoords.y}:null,battleCities:input.battleCities?.map(String)??[]}:{}),happinessSupport:input.kind==='building'&&input.happinessSupport===true&&entries.every(e=>/:(?:museum|tavern)$/.test(e.key))};
}
// The tavern always serves the most wine (user decision, 2026-10-15); no level is computed.
function trainingPlan(entries,recipes,stock,citizens,reserve) {
  if(!Number.isFinite(citizens)) throw new Error('מספר האזרחים הפנויים אינו זמין');
  const remaining={...stock,citizens},orders=[];
  for(const entry of entries) {
    const recipe=recipes.find(unit=>String(unit.id)===entry.key);
    if(!recipe || recipe.locked) throw new Error('יחידה אינה זמינה לגיוס: '+entry.label);
    let quantity=entry.target;
    for(const [resource,cost] of Object.entries(recipe.costs)) {
      if(!['wood','wine','marble','crystal','sulfur','citizens'].includes(resource)) continue;
      if(!Number.isFinite(cost) || cost<0 || !Number.isFinite(remaining[resource])) throw new Error('עלות או מלאי אינם זמינים לגיוס');
      if(cost>0) quantity=Math.min(quantity,Math.max(0,Math.floor((remaining[resource]-(resource==='citizens'?0:reserve))/cost)));
    }
    if(quantity>0) {
      for(const [resource,cost] of Object.entries(recipe.costs)) if(resource in remaining) remaining[resource]-=cost*quantity;
      orders.push({id:recipe.id,quantity,label:recipe.label});
    }
  }
  return orders;
}
globalThis.IkariamAutomationRules={KINDS,ALERT_KINDS,validateRule,trainingPlan};
})();

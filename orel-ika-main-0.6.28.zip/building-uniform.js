// Building uniformity (user spec, 2026-10-13): every city of every account is brought, step by
// step, to the same target levels. Pure decisions only — the building automation executes them.
//  - never lowers or demolishes; a building at or above its target is done;
//  - workshop and embassy are never touched; the optician and fireworker have no target;
//  - black market, sea chart archive and shipyard are only upgraded where they already exist;
//  - production buildings only on an island of their resource (the winery on a wine island…);
//  - one pirate fortress per account goes to 18 (the highest one already built), the others stay;
//  - a missing building is built in a free plot — never by demolishing; no plot = blocked;
//  - the wall may not pass the town hall (a game rule);
//  - the architect's office and the carpentry come first (they lower every other cost), then the
//    lowest level, so the cities rise evenly.
export const UNIFORM_TARGETS={townHall:24,museum:5,tavern:30,academy:10,warehouse:20,port:25,branchOffice:20,safehouse:30,wall:10,barracks:20,
  forester:20,vineyard:20,winegrower:25,stonemason:25,glassblowing:25,alchemist:25,carpentering:30,architect:30,temple:20};
// The regular temple (מקדש, miracles) goes to 20 (a temple already above it stays: nothing is ever
// lowered). The gods' shrine (מקדש האלים = shrineOfOlympus) is one per account (user decision,
// 2026-10-15): the one it has goes to 25; an account without one builds it in the palace city.
const EXISTING_ONLY={blackMarket:25,marineChartArchive:20,shipyard:20};const SHRINE=25;
const LUXURY={winegrower:'wine',stonemason:'marble',glassblowing:'crystal',alchemist:'sulfur'};
export const UNIFORM_FIRST=['architect','carpentering'];
export const UNIFORM_LABELS={palace:'ארמון',palaceColony:'מגורי מושל',townHall:'בניין העירייה',museum:'מוזיאון',tavern:'בית מרזח',academy:'אקדמיה',warehouse:'מחסן',
  port:'נמל',branchOffice:'תחנת סחר',safehouse:'מקום מחבוא',wall:'חומת העיר',barracks:'מגורי חיילים',forester:'בית יערן',vineyard:'מכבש יין',winegrower:'יקב',
  stonemason:'חרש אבן',glassblowing:'מנפח זכוכית',alchemist:'מגדל האלכימאי',carpentering:'נגריה',architect:'משרד האדריכל',temple:'מקדש',shrineOfOlympus:'מקדש האלים',
  pirateFortress:'מבצר פיראטים',blackMarket:'שוק שחור',marineChartArchive:'ארכיון תרשים ימי',shipyard:'מספנה'};
// Storage goal (Firefox, user decision 2026-10-27): with the uniformity plan off, a city that holds
// less than the 48,000 of the account balancing upgrades its warehouses only, until it holds 48,000.
export const STORAGE_GOAL=48000;
// An unknown capacity plans nothing.
export const storageEntries=(plan,capacity)=>capacity==null||!(Number(capacity)<STORAGE_GOAL)?[]:(plan?.entries??[]).filter(entry=>/:warehouse$/.test(entry.key));
export const isStorageRule=rule=>rule?.autopilot==='uniform'&&(rule.entries??[]).length>0&&rule.entries.every(entry=>/:warehouse$/.test(entry.key));
export const UNIFORM_STATUS={done:'הושלם',resources:'ממתין למשאבים',queue:'ממתין לתור בנייה',busy:'בתהליך שדרוג',blocked:'חסום עקב תנאי משחק',none:'לא רלוונטי'};
// A city without a warehouse (a new colony) builds one first: it holds what the rest needs.
const rank=item=>[item.building==='warehouse'&&item.build?-1:UNIFORM_FIRST.includes(item.building)?0:1,item.level];
const byPriority=(a,b)=>{const x=rank(a),y=rank(b);return x[0]-y[0]||x[1]-y[1]||(b.target-b.level)-(a.target-a.level);};

// user: the main-account edition's target levels (user decision, 2026-10-16) —
// {global:{building:level}, cities:{cityId:{building:level}}}. Given, they replace the fixed
// targets entirely: a building without a target is not planned, nothing else is added.
const userTargets=(user,cityId)=>Object.fromEntries(Object.entries({...(user?.global??{}),...(user?.cities?.[String(cityId)]??{})}).filter(([,level])=>Number.isInteger(level)&&level>0));
export function uniformPlan(cities,{user=null,mainGate=false}={}) {
  const list=(cities??[]).filter(city=>city&&city.id!=null);
  const reducersReady=list.length>0&&list.every(city=>UNIFORM_FIRST.every(name=>(Number((city.buildings??[]).find(item=>item.building===name)?.level)||0)>=50));
  const built=city=>(city.buildings??[]).filter(item=>item&&item.building&&item.building!=='empty');
  const capitalOf=city=>city.isCapital===true||built(city).some(item=>item.building==='palace');
  const hasCapital=list.some(capitalOf);
  const shrineCity=list.find(city=>built(city).some(item=>item.building==='shrineOfOlympus'));
  // The account's pirate fortress for level 18: the highest one already built.
  let fortress=null;
  for(const city of list) for(const item of built(city)) if(item.building==='pirateFortress'&&(!fortress||Number(item.level)>fortress.level)) fortress={cityId:String(city.id),level:Number(item.level)||0};
  const result=list.map(city=>{
    const capital=capitalOf(city),have=built(city),items=[];
    const townHall=Number(have.find(item=>item.building==='townHall')?.level)||0;
    const targets=user?userTargets(user,city.id):{...UNIFORM_TARGETS};
    if(mainGate) for(const name of UNIFORM_FIRST) targets[name]=Math.max(50,targets[name]??0);
    // A colony's corruption ends when its governor's residence reaches (number of cities − 1)
    // (Ikariam wiki, Government); never below the user's 5.
    if(!user) {
      if(capital) targets.palace=6; else if(hasCapital) targets.palaceColony=Math.max(5,list.length-1);
      if(shrineCity?String(shrineCity.id)===String(city.id):capital) targets.shrineOfOlympus=SHRINE;
    }
    // The island's resource: from a production building already in the city, else from the city's
    // actual luxury production. The header's tradegood is not trusted (it can belong to another
    // city); when neither is known, no production building is planned.
    const booster=Object.entries(LUXURY).find(([building])=>have.some(item=>item.building===building))?.[1];
    const producing=['wine','marble','crystal','sulfur'].find(resource=>Number(city.productionPerHour?.[resource])>0);
    const island=booster??producing??null;
    for(const [building,resource] of Object.entries(LUXURY)) if(island!==resource&&!have.some(item=>item.building===building)) delete targets[building];
    for(const item of have) {
      const target=user?targets[item.building]:item.building==='pirateFortress'?(fortress?.cityId===String(city.id)?18:1):targets[item.building]??EXISTING_ONLY[item.building];
      if(!target) continue;
      const level=Number(item.level)||0,entry={building:item.building,label:UNIFORM_LABELS[item.building]??item.building,position:item.position,level,target,remaining:Math.max(0,target-level)};
      if(level>=target) entry.status=UNIFORM_STATUS.done;
      else if(item.isBusy) {entry.status=UNIFORM_STATUS.busy;if(Number.isFinite(Number(item.completed))&&Number(item.completed)>0) entry.completedAt=Number(item.completed)*1000;}
      else if(item.isMaxLevel) Object.assign(entry,{status:UNIFORM_STATUS.blocked,reason:'המבנה ברמה המרבית שהמשחק מאפשר'});
      else if(item.building==='wall'&&level>=townHall) Object.assign(entry,{status:UNIFORM_STATUS.blocked,reason:'החומה אינה יכולה לעלות מעל רמת בניין העירייה'});
      else entry.status=UNIFORM_STATUS.queue;
      items.push(entry);
    }
    // Missing buildings go to the free plots by priority; the palace itself is never built.
    const plots={land:(city.buildings??[]).filter(item=>item?.building==='empty'&&(item.type==null||item.type==='land')).length,
      shore:(city.buildings??[]).filter(item=>item?.building==='empty'&&item.type==='shore').length};
    const missing=Object.entries(targets).filter(([building])=>building!=='palace'&&!have.some(item=>item.building===building))
      .map(([building,target])=>({building,label:UNIFORM_LABELS[building]??building,position:null,level:0,target,remaining:target,build:true})).sort(byPriority);
    for(const entry of missing) {
      const kind=entry.building==='port'?'shore':'land';
      if(plots[kind]>0) {plots[kind]--;entry.status=UNIFORM_STATUS.queue;}
      else Object.assign(entry,{status:UNIFORM_STATUS.blocked,reason:'אין מגרש פנוי בעיר (ללא הריסת מבנים)'});
      items.push(entry);
    }
    items.sort(byPriority);
    if(mainGate&&!reducersReady) for(const item of items) if(!UNIFORM_FIRST.includes(item.building)&&item.status!==UNIFORM_STATUS.done&&item.status!==UNIFORM_STATUS.busy) {item.status=UNIFORM_STATUS.blocked;item.reason='ממתין לנגרייה ואדריכל ברמה 50 בכל ערי החשבון';}
    // The building automation's queue: everything not done and not blocked, highest priority first.
    const wall=items.find(item=>item.building==='wall');
    const entries=items.filter(item=>(!mainGate||reducersReady||UNIFORM_FIRST.includes(item.building))&&(item.status===UNIFORM_STATUS.queue||item.status===UNIFORM_STATUS.busy)).map(item=>({
      key:item.build?'new:'+item.building:item.position+':'+item.building,position:item.build?0:item.position,
      target:item===wall?Math.min(item.target,Math.max(townHall,item.level+1)):item.target,label:item.label}));
    // The cost reducers, by the game's rule of 1% per level (carpentry: wood, architect: marble).
    const level=name=>Number(have.find(item=>item.building===name)?.level)||0;
    const known=value=>value&&typeof value==='object'?value:null;
    return {cityId:String(city.id),name:city.name??String(city.id),isCapital:capital,items,entries,
      discount:{wood:level('carpentering'),marble:level('architect')},workers:known(city.workers),production:known(city.productionPerHour),resources:known(city.resources),tradegood:island,
      progress:items.length?Math.round(items.reduce((sum,item)=>sum+Math.min(item.level,item.target),0)/items.reduce((sum,item)=>sum+item.target,0)*100):100,
      remaining:items.reduce((sum,item)=>sum+item.remaining,0),done:items.filter(item=>item.status===UNIFORM_STATUS.done).length};
  });
  return {fortressCityId:fortress?.cityId??null,cities:result};
}

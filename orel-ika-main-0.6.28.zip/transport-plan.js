(() => {
// Port of resourceTransportManager.do_it's amount calculation and
// planRoutes.executeRoutes's single-resource cargo split. No network here.
const RESOURCE_KEYS=["wood","wine","marble","crystal","sulfur"];
function validateTransportRule(rule) {
  if(!rule || !/^\d+$/.test(rule.originCityId) || !/^\d+$/.test(rule.destinationCityId) || rule.originCityId===rule.destinationCityId)
    throw new Error("יש לבחור שתי ערים שונות בחשבון");
  if(!RESOURCE_KEYS.includes(rule.resource) || !["amount","reserve"].includes(rule.sendMode)) throw new Error("הגדרת המשאב אינה תקינה");
  if(rule.startAt!=null && (!Number.isSafeInteger(rule.startAt) || rule.startAt<=0 || rule.startAt>8640000000000000)) throw new Error("מועד ההתחלה אינו תקין");
  if(rule.startImmediately!=null && typeof rule.startImmediately!=="boolean" || rule.startImmediately && rule.startAt!=null) throw new Error("יש לבחור התחלה עכשיו או מועד עתידי");
  if(rule.externalTarget) validateExternalTarget(rule.externalTarget);
  for(const [key,min,max] of [["quantity",rule.sendMode==="reserve"?0:1,100000000],[rule.intervalMinutes!=null?"intervalMinutes":"intervalHours",1,rule.intervalMinutes!=null?10080:168],["maxCycles",1,100]])
    if(!Number.isSafeInteger(rule[key]) || rule[key]<min || rule[key]>max) throw new Error("כמות, תזמון או מספר מחזורים אינם תקינים");
}
function planTransport(rule, data) {
  validateTransportRule(rule);
  for(const key of ["stock","freeSpace","ships","shipCapacity"])
    if(!Number.isSafeInteger(data[key]) || data[key]<0 || (key==="shipCapacity" && data[key]===0)) throw new Error("חסר נתון מאומת לתכנון המשלוח: "+key);
  const desired=rule.remaining??(rule.sendMode==="reserve"?Math.max(0,data.stock-rule.quantity):Math.min(rule.quantity,data.stock));
  const amount=Math.max(0,Math.min(desired,data.stock,data.freeSpace,data.ships*data.shipCapacity,
    rule.sendMode==="reserve"?Math.max(0,data.stock-rule.quantity):data.stock));
  return {amount,ships:Math.ceil(amount/data.shipCapacity),remaining:desired-amount};
}

// getJson.getTransportLoadingAndTravelTime: ordinary transporters, full capacity, no Triton.
function transportTiming(html,amount,now=Date.now()) {
  const values={};
  for(const key of ["transporterSpeed","worldBonus","governmentBonus","poseidonEffect","marineChartArchiveBonus","minimumJourneyDuration","distance","fleetJourneyTime","queueTime","loadingSpeed"]) {
    const match=html.match(new RegExp("['\\\"]"+key+"['\\\"]\\s*:\\s*([\\d.]+)\\s*,"));
    if(!match || !Number.isFinite(Number(match[1]))) return null;
    values[key]=Number(match[1]);
  }
  const speed=Math.floor(values.transporterSpeed)*values.worldBonus*values.governmentBonus*(1+values.poseidonEffect);
  if(speed<=0 || values.loadingSpeed<=0 || amount<=0) return null;
  const queueSeconds=Math.max(0,Math.floor(values.queueTime-now/1000));
  const loadingSeconds=Math.floor(amount/values.loadingSpeed);
  const travelSeconds=Math.max(values.minimumJourneyDuration,Math.ceil(values.distance*values.fleetJourneyTime/speed*values.marineChartArchiveBonus));
  return {estimated:true,queueSeconds,loadingSeconds,travelSeconds,loadingStartsAt:now+queueSeconds*1000,
    departureAt:now+(queueSeconds+loadingSeconds)*1000,arrivalAt:now+(queueSeconds+loadingSeconds+travelSeconds)*1000};
}
function validateExternalTarget(target) {
  if(!target || !Number.isSafeInteger(target.x) || !Number.isSafeInteger(target.y) || target.x<1 || target.y<1 || target.x>100 || target.y>100 ||
    [target.playerName,target.islandName,target.cityName].some(value=>typeof value!=="string" || !value.trim() || value.length>100))
    throw new Error("יש למלא קואורדינטות בין 1 ל־100 ושמות מדויקים של השחקן, האי והעיר");
}
globalThis.IkariamTransportPlan={RESOURCE_KEYS,validateTransportRule,planTransport,transportTiming,validateExternalTarget};
})();

// 48-hour building forecast (user decision, 2026-10-14): what each city will build in the next
// 48 hours and what that costs, so balancing brings it ahead of time and the export to the main
// account never takes it. Costs come from the game's own Ikipedia tables (Ikabot
// constructionList.getResourcesNeeded), one table per building per account, so the server's
// numbers and the account's research reductions are the ones used. The order is the premium
// construction list the user set in the game first, then the uniformity plan.
(() => {
const KEYS=['wood','wine','marble','crystal','sulfur'];
const NAMES={wood:/עץ|wood/i,wine:/יין|wine/i,marble:/שיש|marble/i,crystal:/קריסטל|זכוכית|crystal|glass/i,sulfur:/גופרית|sulfur|sulphur/i};
// Each level of these buildings lowers its resource's cost by 1% (the game's rule).
const REDUCER={wood:'carpentering',wine:'vineyard',marble:'architect',crystal:'optician',sulfur:'fireworker'};
const HORIZON_MS=48*3600000,TABLE_TTL_MS=7*86400000,RESEARCH=0.14;
const text=value=>String(value).replace(/<[^>]*>/g,' ').replace(/&nbsp;| /g,' ').replace(/\s+/g,' ').trim();
// A cell shows its value twice (the value and its tooltip), so only the first text piece is read;
// reading the whole cell joined them into one number (4,358 → 43,584,358 — user report, 2026-10-15).
const pieces=value=>String(value??'').split(/<[^>]*>/).map(piece=>piece.replace(/&nbsp;| /g,' ').trim()).filter(Boolean);
const amount=value=>{const first=pieces(value).find(piece=>/\d/.test(piece));const digits=String(first??'').replace(/[,.\s']/g,'');return /^\d+$/.test(digits)?Number(digits):0;};
const duration=value=>{const first=pieces(value).find(piece=>seconds(piece)!==null);return first!==undefined?seconds(first):seconds(value);};

// Build time cells: "1ש 20ד 5שנ", "5י 1ש 9ד" (days as the game writes them from two days up; user report,
// 2026-10-28: the days were dropped, so a five-day level read as one hour), "2d 3h", "45m 10s"…
function seconds(value) {
  const t=text(value);let total=0,found=false;
  for(const [pattern,factor] of [[/(\d+)\s*(?:ימים|יום|ימ|י|d)(?![a-zA-Zא-ת])/i,86400],[/(\d+)\s*(?:שעות|שעה|ש(?!נ)|h)/i,3600],[/(\d+)\s*(?:דקות|דקה|ד|m(?!s))/i,60],[/(\d+)\s*(?:שניות|שנייה|שנ|s)(?![a-zA-Zא-ת])/i,1]]) {
    const match=t.match(pattern);if(match) {total+=Number(match[1])*factor;found=true;}
  }
  if(!found&&/^\d+:\d{2}(:\d{2})?$/.test(t)) {const parts=t.split(':').map(Number);total=parts.length===3?parts[0]*3600+parts[1]*60+parts[2]:parts[0]*60+parts[1];found=true;}
  return found?total:null;
}
// One Ikipedia cost table: {resources:[column resources or null], levels:{N:{costs:[...], seconds}}}.
function parseCostTable(html) {
  const source=String(html??'');
  const headers=[...source.matchAll(/<th class="costs">([\s\S]*?)<\/th>/g)].map(match=>match[1]);
  const levels={};
  for(const row of source.matchAll(/<td class="level">\s*(\d+)\s*<\/td>([\s\S]*?)(?=<td class="level">|<\/table>|$)/g)) {
    const cells=[...row[2].matchAll(/<td class="costs">([\s\S]*?)<\/td>(?=\s*(?:<td|<\/tr>|$))/g)].map(match=>match[1]);
    if(!cells.length) continue;
    const timed=cells.length===headers.length&&headers.length>1&&seconds(cells.at(-1))!==null;
    levels[Number(row[1])]={costs:(timed?cells.slice(0,-1):cells).map(amount),seconds:timed?duration(cells.at(-1)):null};
  }
  const columns=Math.max(0,...Object.values(levels).map(level=>level.costs.length));
  const named=headers.slice(0,columns).map(header=>KEYS.find(key=>NAMES[key].test(header.match(/(?:title|alt)="([^"]*)"/)?.[1]??''))??KEYS.find(key=>new RegExp('icon_'+key+'|/'+key+'[_.]','i').test(header))??null);
  return {resources:named.length===columns&&named.every(Boolean)?named:null,columns,levels};
}
// Column resources: named in the table, else matched to costs the game showed for a level
// (canonical order), else the common shapes (wood; wood and marble).
function columnsOf(table,hint) {
  if(table.resources) return table.resources;
  const known=hint&&KEYS.filter(key=>Number(hint[key])>0);
  if(known?.length===table.columns) return known;
  return table.columns===1?['wood']:table.columns===2?['wood','marble']:null;
}
// The cost of one level in a city: the table's value (research already applied) less the
// city's reducer buildings; calibrated by the cost the game showed for that level when known.
function levelCost(table,level,reducers,hint) {
  const row=table?.levels?.[level],resources=table&&columnsOf(table,hint);
  if(!row||!resources) return null;
  const costs={};
  resources.forEach((resource,index)=>{
    const value=row.costs[index]??0;if(!value) return;
    const cut=(Number(reducers?.[resource])||0)/100/(1-RESEARCH);
    costs[resource]=Math.ceil(value*Math.max(0,1-cut));
  });
  return {costs,seconds:row.seconds};
}
// The premium construction list: buildings marked with their place in the game's queue.
function constructionList(buildings) {
  // A building queued more than once is marked with every place it holds (" 3, 4"): one entry per
  // place, each one more level (user report, 2026-10-22: such lists were dropped whole in Opera).
  const main=(()=>{try {return /\bmain\b/.test(globalThis.chrome?.runtime?.getManifest?.()?.version_name??'');} catch {return false;}})();
  if(main) return (buildings??[]).filter(item=>item&&item.building&&item.building!=='empty')
    .flatMap(item=>String(item.inConstructionList??'').split(',').map(value=>Number(value.trim())).filter(order=>Number.isInteger(order)&&order>0).map(order=>({...item,order})))
    .sort((a,b)=>a.order-b.order);
  return (buildings??[]).filter(item=>item&&item.building&&item.building!=='empty'&&Number(String(item.inConstructionList??'').trim())>0)
    .map(item=>({...item,order:Number(String(item.inConstructionList).trim())})).sort((a,b)=>a.order-b.order);
}
// The game's build-list window (view buildingConstructionList, ul#constructionList): the waiting
// entries in queue order, each {position, order, level}. The position marks on the city's buildings
// miss an entry of the building now under construction (user check, 2026-10-22: tavern 35 waiting in
// place 2 of יין 1 had no mark). null when the window is not recognised — never a guessed list.
function parseConstructionListHtml(html,DOMParserImpl=globalThis.DOMParser) {
  if(!DOMParserImpl||typeof html!=='string') return null;
  const document=new DOMParserImpl().parseFromString(html,'text/html'),list=document.querySelector('#constructionList');
  if(!list) return null;
  const entries=[];
  for(const item of list.querySelectorAll('li')) {
    if(item.classList.contains('currentUnit')||item.querySelector('.currentUnit')) continue;
    const numbers=(item.querySelector('.amount')?.textContent??'').match(/\d+/g)?.map(Number)??[];
    const link=[...item.querySelectorAll('[href],[onclick]')].map(node=>(node.getAttribute('href')??'')+' '+(node.getAttribute('onclick')??'')).join(' ').replace(/&amp;/g,'&');
    const position=link.match(/[?&]position=(\d+)/)?.[1];
    if(numbers.length<2||position===undefined) return null;
    // The entry's own cost from its tooltip: each amount stands next to its resource's image (the image
    // tells the resource, never the order); and its finish time from the game's countdown (Unix seconds).
    const icons=[...item.querySelectorAll('.tooltip img')].map(image=>({src:String(image.getAttribute('src')??'').replace(/^https?:/,''),amount:Number(String(image.parentElement?.textContent??'').replace(/[^\d]/g,''))})).filter(icon=>icon.src&&Number.isSafeInteger(icon.amount)&&icon.amount>0);
    const clock=[...item.querySelectorAll('script')].map(node=>node.textContent??'').join(' ');
    const endAt=Number(clock.match(/enddate:\s*'?(\d{9,})/)?.[1])*1000,currentAt=Number(clock.match(/currentdate:\s*'?(\d{9,})/)?.[1])*1000;
    entries.push({position:Number(position),order:numbers[0],level:numbers[numbers.length-1],icons,...(Number.isSafeInteger(endAt)&&endAt>0?{endAt}:{}),...(Number.isSafeInteger(currentAt)&&currentAt>0?{currentAt}:{})});
  }
  return entries.sort((a,b)=>a.order-b.order);
}
// The marks rebuilt from the window: each building carries every place it holds in the list.
function applyConstructionList(buildings,entries) {
  return (buildings??[]).map((item,index)=>{
    const position=Number(item?.position??index),orders=entries.filter(entry=>entry.position===position).map(entry=>entry.order);
    return item?{...item,inConstructionList:orders.length?' '+orders.join(', '):''}:item;
  });
}
// What the city builds in the next 48 hours, and its cost. plan: the uniformity entries
// [{building, target, build, rank}] (rank as the building automation sorts them).
function forecast({buildings,plan=[],tables={},hints={},now=Date.now(),horizonMs=HORIZON_MS,townHall=null,strictList=false}) {
  const sim={},levelOf=key=>sim[key];
  const reducers=Object.fromEntries(Object.entries(REDUCER).map(([resource,building])=>[resource,Number((buildings??[]).find(item=>item?.building===building)?.level)||0]));
  for(const item of buildings??[]) if(item?.building&&item.building!=='empty') sim[item.position+':'+item.building]=(Number(item.level)||0)+(item.isBusy?1:0);
  const busy=(buildings??[]).find(item=>item?.isBusy);
  let clock=busy&&Number(busy.completed)>0?Math.max(0,Number(busy.completed)*1000-now):0;
  const total=Object.fromEntries(KEYS.map(key=>[key,0])),items=[],missing=new Set();
  const take=(building,key,label)=>{
    const level=levelOf(key)+1,step=levelCost(tables[building],level,reducers,hints[building]);
    if(!step) {missing.add(building);return false;}
    const ms=(step.seconds??3600)*1000;
    // Everything that starts within the horizon needs its resources by its start.
    if(items.length&&clock>=horizonMs) return null;
    for(const [resource,value] of Object.entries(step.costs)) total[resource]+=value;
    sim[key]=level;clock+=ms;items.push({building,label,level,costs:step.costs,seconds:step.seconds,list:label==='list'});
    return true;
  };
  // First the user's own list, in its order (each entry is one more level).
  for(const item of constructionList(buildings)) {const taken=take(item.building,item.position+':'+item.building,'list');if(taken===null||strictList&&taken===false) return result();}
  // Then the uniformity plan: the same order the building automation uses, level by level.
  const open=plan.map(entry=>({...entry,key:entry.build?'new:'+entry.building:entry.position+':'+entry.building}));
  for(const entry of open) if(entry.build) sim[entry.key]=0;
  for(let guard=0;guard<80;guard++) {
    const candidates=open.filter(entry=>levelOf(entry.key)<entry.target&&!entry.stuck&&!(entry.building==='wall'&&townHall!==null&&levelOf(entry.key)>=townHall));
    if(!candidates.length) break;
    candidates.sort((a,b)=>(a.rank??1)-(b.rank??1)||levelOf(a.key)-levelOf(b.key));
    const next=candidates[0],taken=take(next.building,next.key,next.label??next.building);
    if(taken===null) break;
    if(taken===false) next.stuck=true;
  }
  return result();
  function result() {return {at:now,hours:Math.round(clock/360000)/10,resources:Object.fromEntries(Object.entries(total).filter(([,value])=>value>0)),items,missingTables:[...missing]};}
}
// When each planned upgrade starts (user request, 2026-10-15): one builder per city, so each one
// starts after the one before it ends, and only once the city holds its cost — from the stock,
// the city's own production per hour and the shipments already on their way (not balancing that
// has not been sent yet). Returns per item: startAt, endAt and what it waits for.
function schedule({items,now,busyUntil=null,stock={},production={},arrivals=[]}) {
  const have={...stock};let clock=Math.max(now,busyUntil??0);
  const pending=[...arrivals].filter(item=>Number.isFinite(item.at)&&item.amount>0).sort((a,b)=>a.at-b.at);
  const at=(resource,time)=>(have[resource]??0)+Math.max(0,Number(production[resource])||0)*(time-now)/3600000+pending.filter(item=>item.resource===resource&&item.at<=time).reduce((sum,item)=>sum+item.amount,0);
  // The earliest moment the resource reaches the amount, or null when nothing will bring it.
  const ready=(resource,amount,from)=>{
    if(at(resource,from)>=amount) return from;
    const rate=Math.max(0,Number(production[resource])||0)/3600000;
    let time=from;
    for(const item of pending.filter(item=>item.resource===resource&&item.at>from)) {
      const byRate=rate>0?time+(amount-at(resource,time))/rate:Infinity;
      if(byRate<=item.at) return Math.ceil(byRate);
      time=item.at;if(at(resource,time)>=amount) return time;
    }
    return rate>0?Math.ceil(time+(amount-at(resource,time))/rate):null;
  };
  const out=[];
  for(const item of items) {
    const waits=[];let start=clock;
    for(const [resource,cost] of Object.entries(item.costs??{})) {
      const when=ready(resource,cost,clock);
      if(when===null) {waits.push({resource,missing:Math.max(0,Math.ceil(cost-at(resource,clock))),rate:0,arrival:null,at:null});start=null;continue;}
      if(when>clock) waits.push({resource,missing:Math.ceil(cost-at(resource,clock)),rate:Math.round(Number(production[resource])||0),arrival:pending.find(entry=>entry.resource===resource&&entry.at>clock)?.at??null,at:when});
      if(start!==null) start=Math.max(start,when);
    }
    if(start===null) {out.push({...item,startAt:null,endAt:null,waits});break;}
    for(const [resource,cost] of Object.entries(item.costs??{})) have[resource]=(have[resource]??0)-cost;
    const end=start+(item.seconds??3600)*1000;
    out.push({...item,startAt:start,endAt:end,waits});clock=end;
  }
  return out;
}
// Opera caller only. Expand one queued upgrade per city in each round. Advance
// only after actual stock/incoming cargo covers this round, or when its remaining
// gaps cannot currently be supplied. Never promise a shipment that was not sent.
function supplyRounds({snapshot,queues,reservations={incoming:{}},plan,now=Date.now()}) {
 const targets={},depth={},neededAt={},blocked=[],frozen=new Set();
 const cap=(city,key)=>Number.isSafeInteger(city.resourceCapacities?.[key])?city.resourceCapacities[key]:city.storageCapacity;
 const expected=(city,key)=>city.resources[key]+(reservations.incoming?.[city.id]?.[key]??0);
 let report=plan(targets);
 for(let round=0;round<80;round++) {
  let expanded=false;
  for(const city of snapshot.cities) {
   const id=String(city.id),queue=queues[id],index=depth[id]??0,item=queue?.items?.[index];
   if(!item||frozen.has(id)) continue;
   const next={...(targets[id]??{})};
   for(const [key,value] of Object.entries(item.costs??{})) next[key]=(next[key]??0)+value;
   if(Object.entries(next).some(([key,value])=>!Number.isSafeInteger(value)||value<0||value>cap(city,key))) {
    blocked.push({cityId:id,reason:'storage-capacity',depth:index+1});frozen.add(id);continue;
   }
   let start=queue.neededAt??null;
   for(let i=0;i<index;i++) {const seconds=queue.items[i].seconds;start=start!==null&&Number.isFinite(seconds)?start+seconds*1000:null;}
   targets[id]=next;depth[id]=index+1;neededAt[id]=start;expanded=true;
  }
  if(!expanded) break;
  report=plan(targets,{neededAt,depth});
  const gaps=new Set();
  for(const city of snapshot.cities) if(Object.entries(targets[city.id]??{}).some(([key,value])=>value>expected(city,key)))gaps.add(String(city.id));
  const feasible=report.actions.some(action=>gaps.has(String(action.destinationCityId))&&(targets[action.destinationCityId]?.[action.resource]??0)>expected(snapshot.cities.find(city=>String(city.id)===String(action.destinationCityId)),action.resource));
  if(feasible) break;
  // An unsuppliable city retains this round's reserves, but cannot prevent
  // other already-covered cities from preparing their following upgrade.
  for(const id of gaps) if(!frozen.has(id)) {blocked.push({cityId:id,reason:'no-available-donor',depth:depth[id]});frozen.add(id);}
 }
 return {forecast:targets,report,depth,neededAt,blocked};
}
function reducersReady(cities) {
 return !!cities?.length&&cities.every(city=>['carpentering','architect'].every(name=>Number((city.buildings??[]).find(item=>item.building===name)?.level)>=50));
}
globalThis.IkariamBuildForecast={KEYS,HORIZON_MS,TABLE_TTL_MS,parseCostTable,levelCost,constructionList,parseConstructionListHtml,applyConstructionList,forecast,schedule,seconds,supplyRounds,reducersReady};
})();

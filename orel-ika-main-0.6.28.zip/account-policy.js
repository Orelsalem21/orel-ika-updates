(() => {
const TARGET=48000;
// One merchant ship carries 500. Exports and balancing move whole ship loads (multiples of 500,
// never less), so no ship sails part-empty (user decision, 2026-10-13). Wine (its own buffer)
// and queued-upgrade supplies are sent in their exact amount.
const MIN_CHUNK=500;
const loads=amount=>Math.floor(amount/MIN_CHUNK)*MIN_CHUNK;
const KEYS=["wood","wine","marble","crystal","sulfur"];
// Wine is balanced first: every city keeps at least 48,000 wine before any
// other resource is balanced or exported. Cities consume wine continuously, so a
// city is refilled once it drops below 48,000 + 1 hour of consumption, up to
// 48,000 + 4 hours, and donors keep that same buffer. This avoids a stream of
// tiny shipments every scan. Unknown consumption falls back to exactly 48,000.
const ORDER=["wine","wood","marble","crystal","sulfur"];
const WINE_TRIGGER_HOURS=1,WINE_BUFFER_HOURS=4;
const usage=city=>Number.isFinite(city.wineConsumptionPerHour)&&city.wineConsumptionPerHour>0?city.wineConsumptionPerHour:0;
const floor=(city,resource)=>resource==="wine"?TARGET+Math.ceil(usage(city)*WINE_BUFFER_HOURS):TARGET;
const trigger=(city,resource)=>resource==="wine"?TARGET+Math.ceil(usage(city)*WINE_TRIGGER_HOURS):TARGET;
const flag=value=>value===true || value===1 || value==="1" || value==="true";
function cargoReservations(cities,movements,player) {
  if(!Array.isArray(movements)) throw new Error("תנועות חסרות; לא ניתן לתכנן איזון בטוח");
  const incoming={},outgoing={};
  const clean=value=>String(value??"").normalize("NFC").trim();
  const find=place=>{
    if(clean(place?.avatarName) && clean(place.avatarName)!==clean(player)) return null;
    const matches=cities.filter(city=>clean(city.name)===clean(place?.name));
    if(!matches.length) return null;
    // A movement without the player's name, or toward two cities of the same name, is left out instead of
    // stopping every shipment of the account (user report, 2026-10-25: 148 retries in Orakel7): one city
    // of that name without a name on the movement is that city; two are not attributed.
    if(matches.length!==1) return null;
    return matches[0].id;
  };
  for(const movement of movements) {
    if(flag(movement.isHostile) || !Array.isArray(movement.resources) || !movement.resources.length) continue;
    if(!movement.origin || !movement.target || !movement.event) throw new Error("נתוני תנועה חלקיים");
    const returning=flag(movement.event.isFleetReturning);
    const source=find(returning?movement.target:movement.origin),destination=find(returning?movement.origin:movement.target);
    for(const resource of movement.resources) {
      const css=String(resource.cssClass??"").split(/\s+/);
      const key=KEYS.find(key=>css.includes(key==="crystal"?"glass":key));
      if(!key) {if(css.includes("gold")) continue;throw new Error("סוג מטען לא מוכר; האיזון נעצר");}
      const text=String(resource.amount??"").replace(/[,.\s\u00a0]/g,"");
      if(!/^\d+$/.test(text) || !Number.isSafeInteger(Number(text))) throw new Error("כמות מטען אינה תקינה");
      if(destination) {incoming[destination]??={};incoming[destination][key]=(incoming[destination][key]??0)+Number(text);}
      if(source) {outgoing[source]??={};outgoing[source][key]=(outgoing[source][key]??0)+Number(text);}
    }
  }
  return {incoming,outgoing};
}
// Water-fill scarce wine by net depletion, keeping only a small operating buffer
// in producing cities. Future production is a rate, never available inventory.
function wineAllocation(cities,reservations) {
 const expected=city=>Math.max(0,city.resources.wine-(reservations.outgoing?.[city.id]?.wine??0))+(reservations.incoming?.[city.id]?.wine??0);
 const total=cities.reduce((sum,c)=>sum+expected(c),0);
 const scarce=total<cities.reduce((sum,c)=>sum+Math.min(c.storageCapacity,floor(c,"wine")),0);
 const known=cities.every(c=>Number.isFinite(c.wineConsumptionPerHour)&&c.wineConsumptionPerHour>=0&&Number.isFinite(c.productionPerHour?.wine)&&c.productionPerHour.wine>=0);
 if(!scarce||!known)return {scarce,known,total,targets:Object.fromEntries(cities.map(c=>[c.id,floor(c,"wine")])),expected};
 const base=c=>Math.min(c.storageCapacity,Math.ceil(c.wineConsumptionPerHour*4));
 const drain=c=>Math.max(0,c.wineConsumptionPerHour-c.productionPerHour.wine);
 const baseTotal=cities.reduce((sum,c)=>sum+base(c),0);
 let targets;
 if(baseTotal>=total)targets=Object.fromEntries(cities.map(c=>[c.id,Math.floor(base(c)*total/(baseTotal||1))]));
 else {
  const amount=h=>cities.reduce((sum,c)=>sum+Math.min(c.storageCapacity,base(c)+drain(c)*h),0);
  let low=0,high=1;while(amount(high)<total&&high<1e9)high*=2;
  for(let i=0;i<60;i++){const mid=(low+high)/2;if(amount(mid)>total)high=mid;else low=mid;}
  targets=Object.fromEntries(cities.map(c=>[c.id,Math.floor(Math.min(c.storageCapacity,base(c)+drain(c)*low))]));
  // If all cities produce enough wine, share remaining stock instead of emptying them.
  if(cities.every(c=>drain(c)===0))targets=Object.fromEntries(cities.map(c=>[c.id,Math.floor(Math.min(c.storageCapacity,total/cities.length))]));
 }
 return {scarce,known,total,targets,expected};
}
// holds: {cityId:{resource:true}} — a city gathering that resource (consolidation, a market
// purchase) never gives it away, so balancing and gathering cannot ship it back and forth.
function planAccountPolicy(snapshot,{balanceEnabled,exportEnabled,externalTarget,exportOnly=false,needs={},forecast={},holds={},exportResources=null,floors=null,wineFirst=[],mainBuildSupply=false,buildDeadlines=null,mainCentralCityId=null,mainRoundLoads=false,mainUnavailableOrigins=[],mainCityDispatch=false,mainActiveSupplyCity=null},reservations={incoming:{},outgoing:{}}) {
  if(!snapshot?.cities?.length || snapshot.cities.length>60) throw new Error("סריקת ערים מלאה נדרשת לאיזון");
  const cities=snapshot.cities;
  if(new Set(cities.map(city=>city.id)).size!==cities.length) throw new Error("רשימת הערים כוללת עיר כפולה");
  for(const city of cities) {
    if(!/^\d+$/.test(city.id) || !Number.isSafeInteger(city.storageCapacity) || city.storageCapacity<0) throw new Error("נתוני מחסן חסרים");
    for(const key of KEYS) if(!Number.isSafeInteger(city.resources[key]) || city.resources[key]<0) throw new Error("נתוני משאב חסרים");
  }
  const wine=wineAllocation(cities,reservations);
  // A queued building upgrade raises that city's target to its cost (capped by the warehouse).
  const need=(city,resource)=>Math.min(city.storageCapacity,Number.isSafeInteger(needs?.[city.id]?.[resource])?needs[city.id][resource]:0);
  // The next 48 hours of building (user decision, 2026-10-14): kept in the city and topped up
  // ahead of time in full ship loads; never urgent, so it rides the normal balancing.
  const ahead=(city,resource)=>Math.min(city.storageCapacity,Number.isSafeInteger(forecast?.[city.id]?.[resource])?forecast[city.id][resource]:0);
  // Equal shares (user decision, 2026-10-14): when an account does not hold 48,000 of a resource
  // for every city, that resource is spread evenly between its cities instead — a city with 0
  // next to cities with 100,000 gets its share. What a city specifically needs (a queued upgrade,
  // the next 48 hours of building) comes first; everyone else is levelled to the same amount.
  // Wine keeps its own scarcity rule (by consumption).
  const even={};
  for(const resource of KEYS.filter(key=>key!=="wine"&&!(floors&&Number.isFinite(floors[key])))) {
    const expected=city=>Math.max(0,city.resources[resource]-(reservations.outgoing?.[city.id]?.[resource]??0))+(reservations.incoming?.[city.id]?.[resource]??0);
    const total=cities.reduce((sum,city)=>sum+expected(city),0);
    if(total>=cities.reduce((sum,city)=>sum+Math.min(city.storageCapacity,TARGET),0)) continue;
    const special=city=>Math.min(city.storageCapacity,Math.max(need(city,resource),ahead(city,resource)));
    const specialTotal=cities.reduce((sum,city)=>sum+special(city),0);
    let level;
    if(specialTotal>=total) level=null;
    else {
      const fill=value=>cities.reduce((sum,city)=>sum+Math.max(special(city),Math.min(city.storageCapacity,value)),0);
      let low=0,high=TARGET;for(let i=0;i<50;i++){const mid=(low+high)/2;if(fill(mid)>total)high=mid;else low=mid;}
      level=Math.round(low);
    }
    even[resource]=Object.fromEntries(cities.map(city=>[city.id,level===null?Math.floor(special(city)*total/(specialTotal||1)):Math.max(special(city),Math.min(city.storageCapacity,level))]));
  }
  // A levelled city is refilled only when it is a real gap away (no stream of tiny ships).
  const evenSlack=(city,resource)=>Math.max(2*MIN_CHUNK,Math.floor(even[resource][city.id]*0.1));
  // floors (main-account edition): a resource with floor 0 has no 48,000 base — it only goes
  // where building needs it (the 48 hours ahead and the current upgrades).
  const base=(city,resource)=>floors&&Number.isFinite(floors[resource])?floors[resource]:floor(city,resource);
  const floorFor=(city,resource)=>even[resource]?even[resource][city.id]:base(city,resource);
  const triggerFor=(city,resource)=>even[resource]?Math.max(0,even[resource][city.id]-evenSlack(city,resource)):floors&&Number.isFinite(floors[resource])?floors[resource]:trigger(city,resource);
  const reserveFor=(city,resource)=>holds?.[city.id]?.[resource]?city.resources[resource]:Math.max(resource==="wine"&&wine.scarce&&wine.known?wine.targets[city.id]:floorFor(city,resource),need(city,resource),ahead(city,resource));
  // An unhappy city (satisfaction guard, Firefox) is supplied with wine as if it were running dry.
  const unhappy=new Set((Array.isArray(wineFirst)?wineFirst:[]).map(String));
  const wineCritical=cities.filter(c=>{
    if(unhappy.has(String(c.id))) return true;
    if(!Number.isFinite(c.wineConsumptionPerHour))return false;
    const production=Number.isFinite(c.productionPerHour?.wine)?c.productionPerHour.wine:0;
    const drain=Math.max(0,c.wineConsumptionPerHour-production);
    return drain>0&&Math.max(0,c.resources.wine-(reservations.outgoing?.[c.id]?.wine??0))/drain<12;
  });
  const eligibleDonor=city=>!mainBuildSupply||(!mainUnavailableOrigins.includes(String(city.id))&&(mainCentralCityId===null||String(city.id)===String(mainCentralCityId)));
  // Use one consistent destination order across all resources. Prefer a city
  // whose selected build step can be funded, rather than splitting scarce
  // resources across several cities that then cannot finish any step.
  const cityOrder=new Map();
  if(mainBuildSupply&&mainCityDispatch){
    const ranked=cities.map(city=>{
      let complete=true,total=0;
      for(const key of KEYS){
        const target=Math.max(need(city,key),ahead(city,key));
        let missing=Math.max(0,target-city.resources[key]-(reservations.incoming?.[city.id]?.[key]??0));
        if(mainRoundLoads)missing=Math.ceil(missing/500)*500;
        total+=missing;if(!missing)continue;
        const available=cities.filter(donor=>donor.id!==city.id&&eligibleDonor(donor)).reduce((sum,donor)=>sum+Math.max(0,donor.resources[key]-reserveFor(donor,key)-(reservations.outgoing?.[donor.id]?.[key]??0)),0);
        if(available<missing)complete=false;
      }
      return {city,complete,total,at:buildDeadlines?.[city.id]??Infinity};
    }).sort((a,b)=>Number(b.complete)-Number(a.complete)||Number(String(b.city.id)===String(mainActiveSupplyCity))-Number(String(a.city.id)===String(mainActiveSupplyCity))||a.at-b.at||a.total-b.total||String(a.city.id).localeCompare(String(b.city.id)));
    ranked.forEach((item,index)=>cityOrder.set(String(item.city.id),index));
  }
  const exportBlocked=wineCritical.length?"wine-critical":wine.scarce&&!wine.known?"wine-unparsed":null;
  // unmetNeeds: what a queued upgrade still lacks after every city of the account gave what it can.
  const shortages=[],balances=[],exports=[],unmetNeeds=[],sourceBudgets=[];
  for(const resource of ORDER) {
    // amount: what a city can give beyond everything it keeps (its next 48 hours of building
    // included); spare: beyond only the 48,000 base and its own current upgrade. A city whose
    // building is stuck right now (or below half its target, or short of wine) is supplied from
    // the spare — a neighbour's future plans never hold today's builder idle (user report,
    // 2026-10-15: 118,000 wood stayed in one city while the others had none).
    const keepNow=(city,resource)=>holds?.[city.id]?.[resource]?city.resources[resource]:Math.max(resource==="wine"&&wine.scarce&&wine.known?wine.targets[city.id]:floorFor(city,resource),need(city,resource));
    const donors=cities.filter(eligibleDonor).map(city=>{const out=reservations.outgoing?.[city.id]?.[resource]??0;
      return {city,amount:Math.max(0,city.resources[resource]-reserveFor(city,resource)-out),spare:Math.max(0,city.resources[resource]-keepNow(city,resource)-out)};}).sort((a,b)=>b.spare-a.spare);
    if(mainBuildSupply)for(const donor of donors)sourceBudgets.push({cityId:donor.city.id,resource,
      stock:donor.city.resources[resource],outgoing:reservations.outgoing?.[donor.city.id]?.[resource]??0,
      held:!!holds?.[donor.city.id]?.[resource],currentNeed:need(donor.city,resource),forecastNeed:ahead(donor.city,resource),
      reserve:reserveFor(donor.city,resource),available:donor.amount,urgentAvailable:donor.spare});
    const deficits=cities.map(city=>{
      const expected=city.resources[resource]+(reservations.incoming?.[city.id]?.[resource]??0);
      const target=reserveFor(city,resource);
      // A city producing its own trade good is not topped up with it while it produces
      // (wine: while production covers consumption). Unknown or zero production is filled.
      // Wood is produced everywhere and stays balanced. A queued upgrade still gets supplied.
      const produced=city.productionPerHour?.[resource];
      const selfSupplied=resource!=="wood"&&Number.isFinite(produced)&&produced>0&&(resource!=="wine"||produced>=usage(city));
      // …unless its own 48 hours of production cannot cover the next 48 hours of building.
      if(selfSupplied&&!need(city,resource)&&!(mainBuildSupply&&ahead(city,resource)>expected)&&!(ahead(city,resource)>city.resources[resource]+produced*48)) return {city,amount:0};
      const threshold=Math.max(resource==="wine"&&wine.scarce&&wine.known?Math.max(0,target-Math.max(100,usage(city))):triggerFor(city,resource),need(city,resource),ahead(city,resource));
      // Only what the warehouse can actually take is a deficit; a full or small warehouse
      // must not lock other cities' surplus away from the main account.
      const room=Math.max(0,city.storageCapacity-expected);
      let wanted=expected<threshold?Math.max(0,target-expected):0;
      if(mainBuildSupply&&mainRoundLoads&&wanted>0) wanted=Math.ceil(wanted/500)*500;
      if(resource!=="wine"&&!need(city,resource)&&!(mainBuildSupply&&ahead(city,resource)>expected)&&wanted<MIN_CHUNK) wanted=0;
      // Below half its target (a colony at 0 next to full cities): supplied at any hour, before exports.
      return {city,wanted,amount:Math.min(room,wanted),severe:expected<target*0.5};
    }).filter(item=>item.wanted>0).sort((a,b)=>{
      if(mainBuildSupply&&mainCityDispatch){
        const critical=item=>resource==='wine'&&wineCritical.some(city=>city.id===item.city.id)?0:1;
        const order=critical(a)-critical(b)||(cityOrder.get(String(a.city.id))??Infinity)-(cityOrder.get(String(b.city.id))??Infinity);
        if(order)return order;
      }
      if(mainBuildSupply&&buildDeadlines) {
        const critical=item=>resource==='wine'&&wineCritical.some(city=>city.id===item.city.id)?0:1;
        const at=item=>Number.isFinite(buildDeadlines[item.city.id])?buildDeadlines[item.city.id]:Infinity;
        const order=critical(a)-critical(b)||at(a)-at(b);if(order)return order;
      }
      return b.amount-a.amount;
    });
    let deficitTotal=deficits.reduce((sum,item)=>sum+item.amount,0);
    const wantedTotal=deficits.reduce((sum,item)=>sum+item.wanted,0);
    if(wantedTotal) shortages.push({resource,amount:wantedTotal,unreachable:cities.some(city=>city.storageCapacity<floor(city,resource)),
      cities:deficits.map(item=>({cityId:item.city.id,amount:item.amount}))});
    if(balanceEnabled) for(const deficit of deficits) {
      const free=Math.max(0,deficit.city.storageCapacity-deficit.city.resources[resource]-(reservations.incoming?.[deficit.city.id]?.[resource]??0));
      let needed=Math.min(deficit.amount,free);
      const now=resource==="wine"&&wineCritical.some(c=>c.id===deficit.city.id)||need(deficit.city,resource)>0||deficit.severe;
      // Opera must not shuttle a scarce building resource back and forth as
      // each emptied donor becomes the next severe deficit. Keep its own list.
      const useSpare=now&&(!mainBuildSupply||resource==="wine"&&wineCritical.some(c=>c.id===deficit.city.id));
      for(const donor of donors) {
        const exact=resource==="wine"||need(deficit.city,resource)>0||mainBuildSupply&&ahead(deficit.city,resource)>0;
        const can=useSpare?donor.spare:donor.amount;
        const amount=mainBuildSupply&&mainRoundLoads?loads(Math.min(needed,can)):exact?Math.min(needed,can):loads(Math.min(needed,can));
        // Too little for a ship load here: try the next city, and keep this one's stock.
        if(amount<=0 || donor.city.id===deficit.city.id) continue;
        balances.push({originCityId:donor.city.id,destinationCityId:deficit.city.id,resource,amount,kind:"balance",...(mainBuildSupply&&mainCityDispatch?{supplyCityOrder:cityOrder.get(String(deficit.city.id))}:{}),destinationCap:reserveFor(deficit.city,resource)+(mainBuildSupply&&mainRoundLoads?499:0),sourceReserve:useSpare?keepNow(donor.city,resource):reserveFor(donor.city,resource),scarceWine:resource==="wine"&&wine.scarce,
          // Sent even outside the balancing hours: wine for under 12 hours, or a queued upgrade.
          urgent:now});
        donor.amount=Math.max(0,donor.amount-amount);donor.spare-=amount;needed-=amount;
      }
      if((need(deficit.city,resource)>0||mainBuildSupply&&ahead(deficit.city,resource)>0)&&needed>0) unmetNeeds.push({cityId:deficit.city.id,resource,amount:needed});
    }
    // Reserve resources for every deficit, even when a receiver is full/blocked.
    // The export policy cannot drain funds needed for balancing.
    const originalDonors=cities.map(city=>({city,amount:Math.max(0,city.resources[resource]-reserveFor(city,resource)-(reservations.outgoing?.[city.id]?.[resource]??0))})).sort((a,b)=>b.amount-a.amount);
    for(const donor of originalDonors) {
      const reserved=Math.min(deficitTotal,donor.amount);deficitTotal-=reserved;
      const amount=loads(donor.amount-reserved);
      // Critical or undecoded wine only holds back wine; other surplus keeps the ships working.
      if(exportEnabled && externalTarget && amount>=MIN_CHUNK && !even[resource] && (!Array.isArray(exportResources)||exportResources.includes(resource)) && !(resource==="wine"&&(exportBlocked||wine.scarce))) exports.push({originCityId:donor.city.id,destinationCityId:externalTarget.cityId,resource,amount,kind:"export",externalTarget});
    }
  }
  const wineBalances=balances.filter(a=>a.resource==="wine"),otherBalances=balances.filter(a=>a.resource!=="wine");
  // Balance first (wine, then the rest); only surplus left after every deficit is exported.
  // Largest exports first, so free ships leave with full loads.
  exports.sort((a,b)=>b.amount-a.amount);
  // Outside the balancing hours: urgent supplies, then exports to the main account, then the
  // remaining balances — so free ships always carry something (user decision, 2026-10-12).
  const actions=!balanceEnabled?exports:exportOnly?[...balances.filter(a=>a.urgent),...exports,...balances.filter(a=>!a.urgent)]:[...wineBalances,...otherBalances,...exports];
  return {...(mainBuildSupply?{sourceBudgets}:{}),target:TARGET,shortages,unmetNeeds,actions,action:actions[0]??null,wine:{scarce:wine.scarce,known:wine.known,total:wine.total,targets:wine.targets,criticalCityIds:wineCritical.map(c=>c.id),criticalHours:12},exportBlocked};
}
// Opera keeps a destination until its currently sendable build resources are
// exhausted. Critical wine can preempt it; an impossible destination is skipped.
function mainCitySupplyAction(actions,activeCityId,criticalCityIds=[]) {
 const critical=actions.find(action=>action.resource==='wine'&&criticalCityIds.includes(action.destinationCityId));
 if(critical)return critical;
 return actions.find(action=>String(action.destinationCityId)===String(activeCityId)&&action.supplyPriority===1)??actions[0]??null;
}
// Opera caller only: keep fixed night top-up targets during the day, while
// critical wine and wine required for building can always be supplied.
function mainWineSchedule(report,snapshot,reservations,previous={},night=false,buildNeeds={}) {
 const pending={...previous},expected=id=>{
   const city=snapshot.cities.find(city=>String(city.id)===String(id));
   return city?city.resources.wine+(reservations.incoming?.[city.id]?.wine??0):Infinity;
 };
 for(const [id,target] of Object.entries(pending)) if(!Number.isFinite(target)||expected(id)>=target) delete pending[id];
 if(night) for(const deficit of report.shortages.find(item=>item.resource==='wine')?.cities??[]) if(deficit.amount>0) pending[deficit.cityId]=expected(deficit.cityId)+deficit.amount;
 const budget={},actions=[];
 for(const action of report.actions) {
   if(night||action.resource!=='wine'||report.wine.criticalCityIds.includes(action.destinationCityId)) {actions.push(action);continue;}
   const id=action.destinationCityId;
   budget[id]??=Math.max(0,Math.max(pending[id]??0,buildNeeds[id]?.wine??0)-expected(id));
   const amount=Math.min(action.amount,budget[id]);budget[id]-=amount;
   if(amount>0) actions.push({...action,amount});
 }
 return {pending,actions};
}
// Only positive evidence resolves an interrupted send; elapsed time is not evidence.
function assessPendingShipment(receipt,{source,destination,matching=[],now=Date.now()}) {
 if(receipt.sendPhase==='rejected'||receipt.sendPhase==='prepared')return {status:'not-sent',reason:'השליחה לא הגיעה לבקשת המטען או נדחתה במפורש; ניתן לתכנן מחדש לפי המלאי העדכני'};
 if(matching.length)return {status:'accepted',reason:'נמצאה תנועת מטען תואמת במשחק'};
 const before=receipt.destinationStockBefore,stock=destination?.resources?.[receipt.resource];
 if(Number.isFinite(before)&&Number.isFinite(stock)&&stock>=before+receipt.amount)return {status:'delivered',reason:'מלאי היעד מכסה את המשלוח; מתכנן את החוסר הבא לפי המלאי הנוכחי'};
 if(receipt.sendPhase==='accepted')return {status:'accepted',reason:'נשמר אישור קבלה מפורש מהמשחק'};
 const origin=source?.resources?.[receipt.resource];
 if(Number.isFinite(origin)&&Number.isFinite(receipt.sourceStockBefore)&&origin<=receipt.sourceStockBefore-receipt.amount)return {status:'accepted',reason:'ירידת מלאי המוצא תואמת את המטען; ממתין לאימות הגעה'};
 return {status:'unknown',reason:'הסוכן בדק תנועות ומלאי בשתי הערים; אין ראיה מספקת לאישור או לשליחה חוזרת'};
}

// Opera caller only. Reconcile current demand, never claim an unknowable historical delivery.
// Two distinct, successful endpoint+advisor reads are needed; age by itself proves nothing.
function reconcileMainShipment(receipt,{source,destination,movements,player,now=Date.now(),fresh=false}) {
 const wait=reason=>({status:'pending',reason,evidence:null});
 if(receipt.kind!=='balance'||!source||!destination||!fresh||!Array.isArray(movements))return wait('ממתין לקריאה מלאה ועדכנית של שתי הערים והתנועות');
 if(!Number.isFinite(receipt.createdAt)||now-receipt.createdAt<15*60000)return wait('השליחה עדיין חדשה; ממתין לאימות רגיל לפני התאמה מחדש');
 if(!KEYS.includes(receipt.resource)||![source,destination].every(city=>Number.isFinite(city.resources?.[receipt.resource])&&city.resources[receipt.resource]>=0))return wait('מלאי עדכני חסר; לא ניתן לשחרר את הרשומה');
 const clean=value=>String(value??'').normalize('NFC').trim();
 const same=(place,city)=>place?.cityId!=null||place?.id!=null?String(place.cityId??place.id)===String(city.id):clean(place?.name)===clean(city.name)&&clean(place?.avatarName)===clean(player);
 for(const movement of movements) {
  if(!movement||!movement.origin||!movement.target)return wait('תיאור התנועות חלקי; ההתאמה מחדש ממתינה לקריאה תקינה');
  if([movement.origin,movement.target].every(place=>place.cityId==null&&place.id==null&&(!clean(place.name)||!clean(place.avatarName))))return wait('תנועה ללא זיהוי ערים מונעת אימות מלא של המסלול');
  const os=same(movement.origin,source),od=same(movement.origin,destination),ts=same(movement.target,source),td=same(movement.target,destination);
  if(os&&td||od&&ts)return wait('נמצאה תנועה בין ערי המשלוח, כולל טעינה או חזרה; ממתין לסיומה');
  if((os||od||ts||td)&&[movement.origin,movement.target].some(place=>place.cityId==null&&place.id==null&&(!clean(place.name)||!clean(place.avatarName))))return wait('לא ניתן לשייך תנועה לערי המשלוח בוודאות');
 }
 const prior=receipt.reconciliation;
 if(!prior||!Number.isFinite(prior.firstCleanAt)||prior.firstCleanAt>now||!Number.isFinite(prior.lastCleanAt)||prior.lastCleanAt>now)return {status:'pending',reason:'בדיקה ראשונה הושלמה: אין מטען פעיל במסלול; ממתין לבדיקה נפרדת לפני חישוב החוסר מחדש',evidence:{firstCleanAt:now,lastCleanAt:now,checks:1}};
 if(now-prior.lastCleanAt<60000)return {status:'pending',reason:'ממתין לבדיקה נפרדת של הערים והתנועות; אין שליחה חוזרת',evidence:prior};
 return {status:'reconciled',reason:'שתי בדיקות עדכניות לא מצאו מטען פעיל במסלול; הרשומה הישנה נסגרה והחוסר יחושב מחדש מהמלאי ומהמטענים הנוכחיים',evidence:{firstCleanAt:prior.firstCleanAt,lastCleanAt:now,checks:2,sourceStock:source.resources[receipt.resource],destinationStock:destination.resources[receipt.resource]}};
}

// An unresolved send quarantines that resource at both endpoints. Other routes/resources
// may continue, but no retry or reverse transfer can hide or duplicate this cargo.
function shipmentIsQuarantined(action,receipts) {
 return receipts.some(receipt=>receipt.status==='pending'&&receipt.resource===action.resource&&
  [action.originCityId,action.destinationCityId].some(id=>id!=null&&[receipt.originCityId,receipt.destinationCityId].some(other=>other!=null&&String(id)===String(other))));
}

// Opera caller only: shortages left after reserving the donor's own build stock
// and allocating its available cargo. This is missing inventory, not a ship/AP delay.
function mainCentralSupplyShortage(report,snapshot,mode,context={}) {
 if(!mode?.enabled)return null;
 const city=snapshot.cities.find(item=>String(item.id)===String(mode.cityId));if(!city)return null;
 const gaps=new Map();
 for(const item of report.unmetNeeds??[]) if(KEYS.includes(item.resource)&&Number.isFinite(item.amount)&&item.amount>0)
  gaps.set(item.cityId+':'+item.resource,{cityId:String(item.cityId),resource:item.resource,amount:Math.ceil(item.amount/500)*500});
 for(const deficit of report.shortages?.find(item=>item.resource==='wine')?.cities??[]) {
  if(!report.wine?.criticalCityIds?.includes(deficit.cityId))continue;
  const allocated=(report.actions??[]).filter(action=>action.destinationCityId===deficit.cityId&&action.resource==='wine').reduce((sum,action)=>sum+action.amount,0);
  const amount=Math.ceil(Math.max(0,deficit.amount-allocated)/500)*500,key=deficit.cityId+':wine';
  if(amount>0&&amount>(gaps.get(key)?.amount??0))gaps.set(key,{cityId:String(deficit.cityId),resource:'wine',amount});
 }
 if(!gaps.size)return null;
 const resources={};for(const item of gaps.values())resources[item.resource]=(resources[item.resource]??0)+item.amount;
 const destinations=[...new Set([...gaps.values()].map(item=>item.cityId))];
 const details=mainCentralSupplyDetails(report,snapshot,context,gaps);
 return {cityId:String(city.id),cityName:city.name,resources,destinations,details,sourceBudgets:(report.sourceBudgets??[]).filter(item=>String(item.cityId)===String(city.id)),at:Date.now()};
}

// Shared by Opera report recovery; this only describes stored data, never plans a send.
function mainCentralSupplyDetails(report,snapshot,context={},gaps=new Map()) {
 return snapshot.cities.map(receiverCity=>{
  const id=String(receiverCity.id);
  const receiver=snapshot.cities.find(item=>String(item.id)===id),queue=context.queues?.[id];
  const depth=context.depth?.[id]??1,upgrades=(queue?.items??[]).slice(0,depth).map(item=>({building:item.building,level:item.level,costs:item.costs,costSource:item.costSource??'table-estimate'}));
  const recommendation=Array.isArray(receiver?.buildings)?['carpentering','architect'].map(building=>{
   const actual=receiver.buildings.find(item=>item.building===building),level=Number(actual?.level??0);
   return {building,level,gap:Math.max(0,50-level),busy:!!actual?.isBusy};
  }).filter(item=>item.gap>0).sort((a,b)=>b.gap-a.gap)[0]??null:null;
  const costs={},missing={},planned={},unfunded={};
  for(const upgrade of upgrades)for(const [key,value]of Object.entries(upgrade.costs??{}))costs[key]=(costs[key]??0)+value;
  for(const key of KEYS){
   const shortage=report.shortages?.find(item=>item.resource===key)?.cities?.find(item=>String(item.cityId)===id)?.amount??0;
   const allocated=(report.actions??[]).filter(item=>String(item.destinationCityId)===id&&item.resource===key).reduce((sum,item)=>sum+item.amount,0);
   const gap=gaps.get(id+':'+key)?.amount??0;
   if(shortage>0)missing[key]=shortage;
   if(allocated>0)planned[key]=allocated;
   if(gap>0)unfunded[key]=gap;
  }
  // Attribute the alert's rounded remainder to actual queued upgrades in order.
  // Rounding surplus from one stage can cover the next; never count it twice.
  const remaining={...unfunded},budget={};
  for(const key of KEYS)budget[key]=(receiver?.resources?.[key]??0)+(context.reservations?.incoming?.[id]?.[key]??0)+(planned[key]??0);
  for(const upgrade of upgrades){
   upgrade.unfunded={};
   for(const [key,value]of Object.entries(upgrade.costs??{})){
    const lack=Math.max(0,value-(budget[key]??0)),extra=Math.min(remaining[key]??0,Math.ceil(lack/500)*500);
    if(extra>0){upgrade.unfunded[key]=extra;remaining[key]-=extra;}
    budget[key]=Math.max(0,(budget[key]??0)+extra-value);
   }
  }
  const otherNeeds=Object.fromEntries(Object.entries(remaining).filter(([,value])=>value>0));
  return {cityId:id,cityName:receiver?.name??id,recommendation,upgrades,layerCount:upgrades.length,
   queueMismatch:!!recommendation&&!!upgrades.length&&upgrades[0].building!==recommendation.building,
   otherNeeds,costs,stock:receiver?.resources??{},incoming:context.reservations?.incoming?.[id]??{},missing,planned,unfunded,
   missingTables:queue?.missingTables??[]};
 }).sort((a,b)=>(b.recommendation?.gap??-1)-(a.recommendation?.gap??-1)||a.cityName.localeCompare(b.cityName));
}

globalThis.IkariamAccountPolicy={mainCitySupplyAction,mainCentralSupplyDetails,mainCentralSupplyShortage,TARGET,MIN_CHUNK,ORDER,WINE_TRIGGER_HOURS,WINE_BUFFER_HOURS,cargoReservations,planAccountPolicy,wineAllocation,mainWineSchedule,shipmentIsQuarantined,assessPendingShipment,reconcileMainShipment};
})();

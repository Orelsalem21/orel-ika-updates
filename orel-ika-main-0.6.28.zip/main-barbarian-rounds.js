// Opera-only control plane. Game requests stay in the existing serial tab executor.
export const MAIN_BARBARIANS='main-barbarian-rounds-v1';
export function createMainBarbarianRounds(chrome,{now,uuid,write,log}) {
 const read=async accountKey=>((await chrome.storage.local.get(MAIN_BARBARIANS))[MAIN_BARBARIANS]??{})[accountKey];
 const save=async(accountKey,round)=>{const all=(await chrome.storage.local.get(MAIN_BARBARIANS))[MAIN_BARBARIANS]??{};await chrome.storage.local.set({[MAIN_BARBARIANS]:{...all,[accountKey]:round}});};
 async function start(state,accountKey,cityId=null,scanOnly=false) {
  if((await read(accountKey))?.running)throw new Error('סבב ברברים כבר פעיל; אין צורך להפעיל שוב');
  const snap=(await chrome.storage.local.get('account-snapshot-'+accountKey))['account-snapshot-'+accountKey];
  const cities=snap?.snapshot?.cities;
  if(!cities?.length||!Number.isFinite(snap.at)||now()-snap.at>86400000)throw new Error('נדרשת סריקת ערים עדכנית לפני הפעלת הסבב');
  const selected=cities.filter(city=>cityId===null||String(city.id)===String(cityId));
  if(!selected.length||selected.some(city=>!/^\d+$/.test(String(city.id))||!/^\d+$/.test(String(city.islandId))))throw new Error('לא אומתו העיר והאי שלה בסריקה');
  const round={id:uuid(),running:true,scanOnly,startedAt:now(),index:0,cities:[]};
  for(const city of selected) {
   const candidates=state.rules.filter(rule=>rule.accountKey===accountKey&&rule.kind==='barbarians'&&!rule.deleted&&String(rule.cityId)===String(city.id));
   if(candidates.some(rule=>rule.uncertain)||candidates.filter(rule=>rule.inFlight).length>1)throw new Error('תוצאת תקיפה קודמת בעיר '+city.name+' עדיין אינה ידועה');
   // Prefer the rule already running, keeping recruitment and unknown-action receipts intact.
   let rule=candidates.find(rule=>rule.inFlight)??candidates.find(rule=>rule.enabled)??candidates[0];
   const created=!rule;
   if(!rule) {rule={id:uuid(),accountKey,kind:'barbarians',cityId:String(city.id),entries:[],intervalMinutes:2,maxCycles:10000,reserve:0,autoRecruit:true,maxBarbarianLevel:39,telegram:false,autopilot:'main-barbarian-round',enabled:false,cycles:0,progress:{},nextRunAt:now()};state.rules.push(rule);}
   round.cities.push({cityId:String(city.id),name:city.name??String(city.id),islandId:String(city.islandId),ruleId:rule.id,created,wasEnabled:rule.enabled,autoRecruit:rule.autoRecruit,status:'waiting'});
  }
  // Persist the intent before changing dispatch eligibility; a reload resumes the same round.
  await save(accountKey,round);await prepare(state,accountKey);await write(state);return round;
 }
 async function prepare(state,accountKey) {
  const round=await read(accountKey);if(!round?.running)return round;
  for(const item of round.cities) {
   const rule=state.rules.find(rule=>rule.id===item.ruleId&&!rule.deleted);
   if(!rule) {item.status='skipped';item.reason='המשימה הוסרה על ידי המשתמש';continue;}
   const done=rule.progress?.mainBarbarianDone;
   if(done?.roundId===round.id) {item.status=done.status;item.reason=done.reason;}
  }
  const next=round.cities.findIndex(item=>!['done','skipped'].includes(item.status));
  if(round.stopRequested||next<0) {
   if(round.cities.some(item=>state.rules.some(rule=>rule.id===item.ruleId&&(rule.inFlight||rule.uncertain))))return round;
   for(const item of round.cities) {
    const rule=state.rules.find(rule=>rule.id===item.ruleId);if(!rule)continue;
    if(rule.progress) {delete rule.progress.mainBarbarianRound;delete rule.progress.mainRecruitNeed;}
    rule.autoRecruit=item.autoRecruit;rule.enabled=item.wasEnabled&&!rule.deleted;rule.nextRunAt=now()+120000;
    if(item.created) {rule.enabled=false;rule.deleted=true;}
   }
   const temporary=new Set(round.cities.filter(item=>item.created).map(item=>item.ruleId));
   state.rules=state.rules.filter(rule=>!temporary.has(rule.id));
   if(chrome.storage.local.remove)await chrome.storage.local.remove([...temporary].map(id=>'main-barbarian-operation-'+id));
   round.running=false;round.finishedAt=now();round.completed=round.cities.filter(item=>item.status==='done').length;
   round.skipped=round.cities.filter(item=>item.status==='skipped').length;
   round.message=round.stopRequested?'סבב הברברים נעצר לבקשתך; כוחות שכבר יצאו ממשיכים במשחק':round.skipped?`סבב הברברים הסתיים: ${round.completed} הושלמו, ${round.skipped} דולגו עם סיבה`:`סבב הברברים בוצע בהצלחה בכל ${round.cities.length} הערים`;
   if(round.scanOnly&&!round.stopRequested)round.message='סריקת רמות הברברים הסתיימה';
   const entry={id:uuid(),accountKey,ruleId:round.id,time:now(),status:'complete',message:round.message};
   state.events.unshift(entry);await save(accountKey,round);return round;
  }
  round.index=next;
  const item=round.cities[next],rule=state.rules.find(rule=>rule.id===item.ruleId&&!rule.deleted);
  if(rule&&!rule.inFlight) {
   rule.progress??={};
   if(rule.progress.mainBarbarianRound?.id!==round.id)rule.progress.mainBarbarianRound={id:round.id,scanOnly:round.scanOnly,phase:'preparing'};
   if(!rule.uncertain) {rule.autoRecruit=true;rule.enabled=true;rule.nextRunAt=Math.min(rule.nextRunAt??now(),now());}
   item.status=rule.uncertain?'attention':'active';item.reason=rule.status;
  }
  await save(accountKey,round);return round;
 }
 const allows=(rule,round)=>!round?.running||rule.kind!=='barbarians'||rule.id===round.cities[round.index]?.ruleId;
 async function stop(accountKey){const round=await read(accountKey);if(round?.running){round.stopRequested=true;await save(accountKey,round);}return round;}
 return {start,prepare,allows,stop};
}

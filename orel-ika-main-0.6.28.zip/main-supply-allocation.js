// Opera pilot coordinator. No network, listeners or game mutations at module load.
import {demandTiming,compareDemandTiming} from './main-supply-timing.js';
export const ALLOCATION_CONTRACT='allocation-v2.1';
export const DISPATCH_CONTRACT='allocation-v3-proposed';
export const ALLOCATION_FENCE='main-supply-allocation-fence-v2';
const BOOK='main-supply-allocation-book-v2';
const openStates=new Set(['requested','accepted','intent','sent','unknown','in-transit']);
const uuid=()=>crypto.randomUUID();
const digest=async value=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(value))))].map(x=>x.toString(16).padStart(2,'0')).join('');
export function pilotHealth(health){return health?.schema===2&&health.mode==='pilot'&&health.contractRevision===ALLOCATION_CONTRACT&&health.capabilities?.includes('claims')&&health.pilot?.cityId&&health.pilot?.resource&&health.pilot?.supplierAccountKey&&Number.isSafeInteger(health.pilot.cap);}
export function dispatchHealth(h){const d=h?.dispatch;return h?.schema===2&&h.mode==='dispatch'&&h.contractRevision===DISPATCH_CONTRACT&&['claims','shared-reservations','durable-intent','per-scan-incoming','multi-claim'].every(c=>h.capabilities?.includes(c))&&d&&Number.isSafeInteger(d.maxOpenClaims)&&d.maxOpenClaims>=1&&d.maxOpenClaims<=100&&Number.isSafeInteger(d.maxClaimAmount)&&d.maxClaimAmount>0&&d.maxClaimAmount%500===0&&(d.suppliers===null||Array.isArray(d.suppliers))&&['auto','manual'].includes(d.approval);}
export const allocationHealth=h=>!!(pilotHealth(h)||dispatchHealth(h));
export async function pendingScans(api,accountKey){
  const all=await api.storage.local.get(null),prefix='main-supply-scan-v2-'+accountKey+'-';
  return Object.entries(all).filter(([key,value])=>key.startsWith(prefix)&&value?.report&&Number.isSafeInteger(value.scanSequence)).map(([storageKey,value])=>({...value,storageKey})).sort((a,b)=>a.scanSequence-b.scanSequence);
}
export async function settleScan(api,accountKey,entry,result,now=Date.now()){
  await api.storage.local.set({['main-supply-scan-receipt-v2-'+accountKey+'-'+entry.scanSequence]:{scanId:entry.scanId,scanSequence:entry.scanSequence,scannedAt:entry.report.scannedAt,at:now,result}});
  await api.storage.local.remove(entry.storageKey);
}
export async function pilotObservation(entry,accountKey,demandFromReport,mode='pilot'){
  const report=entry.report,input=report.mainCoordinationInputs;
  const base=demandFromReport(accountKey,report);
  if(!base)throw new Error('נתוני הסריקה לפיילוט אינם תקפים');
  const eligible={};for(const item of report.unmetNeeds??[])eligible[item.cityId+':'+item.resource]=(eligible[item.cityId+':'+item.resource]??0)+item.amount;
  for(const item of report.shortages?.find(x=>x.resource==='wine')?.cities??[])if(input.wineTargets?.[item.cityId]>0)eligible[item.cityId+':wine']=item.amount;
  const cities={};for(const city of report.cities??[]){
    // relatedCityData supplies strings such as "[46:32] ", including trailing whitespace.
    const coords=typeof city.coordinates==='string'?city.coordinates.trim().match(/^(?:\[(\d+)\s*:\s*(\d+)\]|(\d+)\s*:\s*(\d+))$/):null;
    cities[String(city.id)]={name:String(city.name??''),playerName:accountKey.split('|')[0],islandId:city.islandId??null,x:coords?Number(coords[1]??coords[3]):null,y:coords?Number(coords[2]??coords[4]):null};
  }
  // Construction is open to the Firefox suppliers in full (user decision, 2026-10-22: parallel supply);
  // Opera's own transfers still take what no supplier claimed, through the same service.
  return {schema:2,mode,accountKey,scanId:entry.scanId,scanSequence:entry.scanSequence,scanStartedAt:entry.scanStartedAt,scannedAt:report.scannedAt,
    queueFingerprint:await digest(input.queueItems??{}),cities,incomingAllocations:[],...(input.currentState?{currentState:input.currentState}:{}),
    demands:base.demands.map(d=>{const city=report.cities.find(c=>String(c.id)===d.cityId),capacity=city?.resourceCapacities?.[d.resource]??city?.storageCapacity;const space=Number.isSafeInteger(capacity)?Math.max(0,capacity-(city.resources[d.resource]??0)-(input.incoming?.[d.cityId]?.[d.resource]??0)):0;const externalEligible=d.purpose==='construction'?d.amount:Math.min(d.amount,Math.floor((eligible[d.cityId+':'+d.resource]??0)/500)*500);return {...d,timing:demandTiming({...d,externalEligible},report),externalEligible,capacityAvailable:Math.floor(space/500)*500};}).sort(compareDemandTiming)};
}
export function createOperaAllocationCoordinator(api,{call,demandFromReport,now=Date.now}){
  if(!/\bmain\b/.test(api.runtime.getManifest?.()?.version_name??''))return null;
  let serial=Promise.resolve();
  const queued=work=>{const result=serial.then(work);serial=result.catch(()=>{});return result;};
  const get=async key=>(await api.storage.local.get(key))[key];
  async function book(){return await get(BOOK)??{accepts:{},internal:{}};}
  const save=next=>api.storage.local.set({[BOOK]:next});
  async function fence(config,health){
    const old=await get(ALLOCATION_FENCE);
    if(!allocationHealth(health)){if(old?.active)throw new Error('ערוץ ההקצאות הושהה; השמירות המקומיות נשארו פעילות');return null;}
    const value={active:true,accountKey:config.accountKey,mode:health.mode,pilot:health.pilot??null,dispatch:health.dispatch??null,at:now()};await api.storage.local.set({[ALLOCATION_FENCE]:value});return value;
  }
  const sync=(config,health)=>queued(async()=>{
    if(!await fence(config,health))return null;
    for(const entry of await pendingScans(api,config.accountKey)){
      if(now()-entry.report.scannedAt>=3600000){await settleScan(api,config.accountKey,entry,'expired-without-publication',now());continue;}
      const payload=await pilotObservation(entry,config.accountKey,demandFromReport,health.mode);
      await call(config,'/v1/demands',payload,'PUT');
      await settleScan(api,config.accountKey,entry,'published-v2',now());
    }
    const remote=await call(config,'/v1/claims'),observation=(await call(config,'/v1/demands')).observation;
    let local=await book();
    for(const claim of remote.claims??[]){
      if(claim.owner==='producer')continue;
      // Persist holds before accept; a lost accept response must not permit local duplicate cargo.
      if(openStates.has(claim.state))local.accepts[claim.claimId]={...local.accepts[claim.claimId],claimId:claim.claimId,cityId:claim.cityId,resource:claim.resource,amount:claim.acceptedAmount??claim.amount,state:claim.state};
      else delete local.accepts[claim.claimId];
    }
    await save(local);
    for(const claim of remote.claims??[]){
      if(claim.owner!=='consumer'||claim.state!=='requested')continue;
      // A missing/expired scan is not proof that the city no longer needs the cargo.
      if(!observation)continue;
      const demand=observation?.demands.find(x=>x.id===claim.demandId);
      const acceptedAmount=Math.floor(Math.min(claim.amount,claim.availableAmount??demand?.externalEligible??0)/500)*500;
      const prior=local.accepts[claim.claimId];
      const acceptance=prior?.acceptance??{operationKey:uuid(),acceptedAmount};
      local.accepts[claim.claimId]={...prior,acceptance};await save(local);
      const result=await call(config,'/v1/claims/'+claim.claimId+'/accept',acceptance);
      local.accepts[claim.claimId]={...local.accepts[claim.claimId],state:result.state,amount:result.acceptedAmount??0};await save(local);
    }
    // Close every fully sent claim once this published scan started after its last arrival (Opera's own
    // shipments: after their receipt). Each claim on its own; a refusal leaves it held.
    if(observation&&Number.isSafeInteger(observation.scanStartedAt)){
      local.resolves??={};
      for(const claim of (await call(config,'/v1/claims')).claims??[]){
        if(claim.state!=='sent'&&claim.state!=='unknown')continue;
        const after=claim.state==='unknown'?(Number.isSafeInteger(claim.updatedAt)?claim.updatedAt+3*3600000:null):Number.isSafeInteger(claim.arrivalAt)?claim.arrivalAt:claim.owner==='producer'?claim.updatedAt:null;
        if(!Number.isSafeInteger(after)||observation.scanStartedAt<=after)continue;
        local.resolves[claim.claimId]??=uuid();await save(local);
        try{await call(config,'/v1/claims/'+claim.claimId+'/resolve',{operationKey:local.resolves[claim.claimId],result:'reconciled-current-state',evidence:{kind:'reconciled-scan',observedAt:now(),scanId:observation.scanId,originCityId:claim.originCityId,destinationCityId:claim.cityId}});}
        catch{ /* Held until a later scan can close it. */ }
      }
    }
    const claims=(await call(config,'/v1/claims')).claims??[];
    return {mode:health.mode,ready:!!observation,count:observation?.demands.length??0,scannedAt:observation?.scannedAt??null,allocation:{open:claims.filter(c=>openStates.has(c.state)).length,needsReview:claims.filter(c=>['intent','unknown'].includes(c.state)).length}};
  });
  const handle=message=>queued(async()=>{
    const config=await get('main-supply-bridge-v1'),oldFence=await get(ALLOCATION_FENCE);
    const matches=oldFence?.active&&oldFence.accountKey===message.accountKey&&(oldFence.mode==='dispatch'||String(oldFence.pilot?.cityId)===String(message.cityId)&&oldFence.pilot?.resource===message.resource);
    if(!config?.enabled||config.accountKey!==message.accountKey){if(matches)throw new Error('ערוץ הפיילוט מנותק; העיר והמשאב נשארים שמורים');return {applicable:false};}
    let health;try{health=await call(config,'/v1/health');}catch(e){if(matches)throw e;return {applicable:false};}
    if(!allocationHealth(health)){if(matches)throw new Error('ערוץ ההקצאות הושהה; אין שליחה פנימית לפני בירור השמירות');return {applicable:false};}
    await fence(config,health);
    if(health.mode==='pilot'&&(String(health.pilot.cityId)!==String(message.cityId)||health.pilot.resource!==message.resource))return {applicable:false};
    if(!message.operationId)throw new Error('נדרש מזהה יציב למשלוח בפיילוט');
    if(!/^[a-zA-Z0-9-]{1,100}$/.test(message.operationId))throw new Error('מזהה פעולה לא תקין');
    let local=await book(),entry=local.internal[message.operationId];
    if(message.operation==='prepare'){
      if(entry?.intentConfirmed)throw new Error('למשלוח הזה כבר נרשמה כוונה; אין שליחה חוזרת');
      if(!entry){entry={claimId:uuid(),claimKey:uuid(),intentKey:uuid(),receiptKey:uuid(),originCityId:message.originCityId,cityId:String(message.cityId),resource:message.resource,amount:message.amount};local.internal[message.operationId]=entry;await save(local);}
      if(entry.amount!==message.amount)throw new Error('כמות הפיילוט השתנתה; נדרש תכנון חדש');
      if(!entry.request){
        const observation=(await call(config,'/v1/demands')).observation,demand=observation?.demands.find(d=>d.cityId===entry.cityId&&d.resource===entry.resource);
        if(!demand)throw new Error('אין חוסר עדכני שמאפשר משלוח פנימי בפיילוט');
        entry.request={operationKey:entry.claimKey,claimId:entry.claimId,demandId:demand.id,revision:observation.revision,supplierAccountKey:message.accountKey,originCityId:entry.originCityId,amount:entry.amount};await save(local);
      }
      if(!entry.reserved){
        // Internal supply leads, but cancellation can only win BEFORE a remote intent.
        const remote=entry.reservationAttempted?{claims:[]}:await call(config,'/v1/claims');
        entry.cancellations??={};
        for(const claim of remote.claims??[])if(claim.owner==='consumer'&&claim.cityId===entry.cityId&&claim.resource===entry.resource&&['requested','accepted'].includes(claim.state)){
          entry.cancellations[claim.claimId]??=uuid();await save(local);
          await call(config,'/v1/claims/'+claim.claimId+'/cancel',{operationKey:entry.cancellations[claim.claimId]});
        }
        // Cancelling a claim changes the ledger revision: refresh before first reservation.
        if(!entry.reservationAttempted&&Object.keys(entry.cancellations).length){const observation=(await call(config,'/v1/demands')).observation;entry.request.revision=observation.revision;await save(local);}
        entry.reservationAttempted=true;await save(local);
        await call(config,'/v1/reservations',entry.request);entry.reserved=true;await save(local);
      }
      // Mark ambiguous intent locally BEFORE HTTP: a lost response cannot authorize a replay.
      entry.intentAttempted=true;await save(local);
      await call(config,'/v1/claims/'+entry.claimId+'/intent',{operationKey:entry.intentKey,amount:entry.amount});
      entry.intentConfirmed=true;await save(local);return {applicable:true,claimId:entry.claimId};
    }
    if(message.operation==='receipt'){
      if(!entry?.intentConfirmed)throw new Error('אין כוונת משלוח שמורה');
      entry.receipt??={operationKey:entry.receiptKey,result:message.result,sentAmount:message.result==='sent'?entry.amount:0,...(message.result==='sent'&&Number.isSafeInteger(message.arrivalAt)?{arrivalAt:message.arrivalAt}:{}),...(message.result==='failed'?{evidence:{kind:'explicit-game-rejection',observedAt:now()}}:{})};await save(local);
      const result=await call(config,'/v1/claims/'+entry.claimId+'/receipt',entry.receipt);entry.state=result.state;await save(local);return {applicable:true};
    }
    throw new Error('פעולת פיילוט לא מוכרת');
  });
  return {sync,handle};
}

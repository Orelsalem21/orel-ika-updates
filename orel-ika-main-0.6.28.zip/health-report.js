// Daily health report (07:00 Israel time, once a day, all accounts): what the automations did
// in the last 24 hours and what needs attention in the extension so everything runs smoothly —
// failures grouped by cause, stuck operations, idle merchant ships and disconnects.
// Built only from the extension's own logs; sent to the shared Telegram/Discord channel.
const KEY='health-report-v1',HOUR=7,DAY=86400000;
const KIND={building:'שדרוג מבנים',tavern:'טברנה',wine:'יין',recruit:'גיוס',workshop:'בית מלאכה',research:'מחקר',experiment:'ניסוי',miracle:'נס',
  barbarians:'ברברים',attacks:'התראות תקיפה',daily:'בונוסים יומיים',pirates:'פיראטים',workers:'עובדים',shrine:'מקדש',station:'תחנה',reinforce:'תגבורת לקרב',islands:'איים',reorganize:'ארגון מחדש',donate:'תרומה'};
const israelDay=epoch=>new Date(epoch).toLocaleDateString('en-CA',{timeZone:'Asia/Jerusalem'});
const israelHour=epoch=>Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jerusalem',hour:'2-digit',hourCycle:'h23'}).format(new Date(epoch)));
const name=key=>String(key??'').split('|')[0]||'חשבון';

// Only what went wrong or did not happen (user decision, 2026-10-15), grouped as in the game.
// Nothing to report → one line saying so.
const CATEGORY={building:'🏗️ בנייה',workers:'👷 פועלים, מדענים וזהב',research:'🔬 מחקר',experiment:'🔬 מחקר',
  recruit:'⚔️ צבא, ברברים וקרבות',barbarians:'⚔️ צבא, ברברים וקרבות',workshop:'⚔️ צבא, ברברים וקרבות',station:'⚔️ צבא, ברברים וקרבות',reinforce:'⚔️ צבא, ברברים וקרבות',attacks:'⚔️ צבא, ברברים וקרבות',islands:'⚔️ צבא, ברברים וקרבות',
  pirates:'🏴‍☠️ פיראטים',wine:'🍷 יין ובית מרזח',tavern:'🍷 יין ובית מרזח',daily:'🎁 בונוסים ומשימות יומיות',miracle:'⛩️ מקדש, נסים ואלים',shrine:'⛩️ מקדש, נסים ואלים',
  market:'📦 משלוחים, איזון ומסחר',consolidate:'📦 משלוחים, איזון ומסחר',donate:'📦 משלוחים, איזון ומסחר',reorganize:'🏗️ בנייה'};
const ORDER=['🏗️ בנייה','👷 פועלים, מדענים וזהב','📦 משלוחים, איזון ומסחר','🍷 יין ובית מרזח','⚔️ צבא, ברברים וקרבות','🏴‍☠️ פיראטים','🔬 מחקר','🎁 בונוסים ומשימות יומיות','⛩️ מקדש, נסים ואלים','🔌 לשוניות וחיבור'];
export function buildHealthReport({game,transport,watchdog,now,wineOnly={},supply=null,snapshots={}}) {
  const since=now-DAY,sections=new Map(),add=(category,line)=>{if(!sections.has(category)) sections.set(category,new Set());sections.get(category).add(line);};
  const rules=new Map((game?.rules??[]).map(rule=>[rule.id,rule]));
  const live=(game?.rules??[]).filter(rule=>!rule.deleted);
  const gameEvents=(game?.events??[]).filter(event=>event.time>=since);
  const shipEvents=(transport?.events??[]).filter(event=>event.time>=since);
  const policies=(transport?.rules??[]).filter(rule=>rule.policyMode&&!rule.deleted);
  const accounts=[...new Set([...live,...policies].map(rule=>rule.accountKey))].filter(Boolean).sort();
  const category=kind=>CATEGORY[kind]??'🏗️ בנייה';
  // Failures, grouped by account, automation and message.
  const failures=new Map();
  for(const event of gameEvents.filter(event=>['error','unknown'].includes(event.status))) {
    const kind=rules.get(event.ruleId)?.kind,key=category(kind)+'\u0000'+name(event.accountKey)+' · '+(KIND[kind]??'אוטומציה')+': '+event.message;
    failures.set(key,(failures.get(key)??0)+1);
  }
  for(const event of shipEvents.filter(event=>['failed','uncertain'].includes(event.status))) {
    const key='📦 משלוחים, איזון ומסחר\u0000'+name(event.accountKey)+' · משלוחים: '+event.message;
    failures.set(key,(failures.get(key)??0)+1);
  }
  for(const [key,count] of [...failures].sort((a,b)=>b[1]-a[1]).slice(0,30)) {
    const [section,text]=key.split('\u0000');
    const hint=/קריאת המשחק נכשלה|חרגה מזמן|timed out|Failed to fetch/i.test(text)?' — המשחק איטי או הלשונית עמוסה':/לא התקבלה תוצאה|תוצאת פעולה אינה ידועה|נותקה/.test(text)?' — כנראה רענון או ניתוק של הלשונית':'';
    add(section,text+' ×'+count+hint);
  }
  // Stuck or stopped right now.
  for(const rule of live.filter(rule=>rule.uncertain||rule.inFlight&&now-(rule.dispatchedAt??0)>30*60000)) add(category(rule.kind),name(rule.accountKey)+' · '+(KIND[rule.kind]??rule.kind)+': תקוע ('+rule.status+') — לבדוק במשחק ולשחרר');
  for(const rule of live.filter(rule=>!rule.enabled&&(rule.failures??0)>=3)) add(category(rule.kind),name(rule.accountKey)+' · '+(KIND[rule.kind]??rule.kind)+': נעצר אחרי 3 כשלים ('+rule.status+')');
  for(const rule of live.filter(rule=>rule.kind==='pirates'&&rule.enabled&&rule.progress?.captcha)) add('🏴‍☠️ פיראטים',name(rule.accountKey)+': ממתין לקפצ׳ה — ענה לתמונה בטלגרם');
  for(const rule of policies.filter(rule=>!rule.enabled&&/^נעצר: |נדרשת בדיקה/.test(rule.status??''))) add('📦 משלוחים, איזון ומסחר',name(rule.accountKey)+': מדיניות 48,000 נעצרה — '+rule.status);
  // What did not happen although it is switched on.
  for(const account of accounts) {
    const own=gameEvents.filter(event=>event.accountKey===account&&event.status==='changed');
    const on=kind=>live.some(rule=>rule.accountKey===account&&rule.kind===kind&&rule.enabled);
    const policy=policies.find(rule=>rule.accountKey===account);
    // A wine-only account ships and builds on purpose only at night / not at all: not a problem.
    if(wineOnly[account]) continue;
    if(policy?.enabled&&!shipEvents.some(event=>event.accountKey===account&&event.status==='sent')) {
      const cities=policy.report?.cities??[],small=cities.length>0&&cities.every(city=>Object.values(city.resources??{}).every(amount=>amount<48000));
      add('📦 משלוחים, איזון ומסחר',name(account)+': לא יצא אף משלוח ב־24 שעות'+(small?' (חשבון קטן — אין עודף; המשאבים מתחלקים בין הערים שווה בשווה)':' — '+(policy.status??'')));
    }
    if(on('building')&&!own.some(event=>rules.get(event.ruleId)?.kind==='building')) add('🏗️ בנייה',name(account)+': לא התחיל אף שדרוג ב־24 שעות');
    if(on('pirates')&&!own.some(event=>rules.get(event.ruleId)?.kind==='pirates')) add('🏴‍☠️ פיראטים',name(account)+': לא יצאה אף משימת פיראטים ב־24 שעות');
    if(live.some(rule=>rule.accountKey===account&&rule.kind==='daily'&&rule.allDayVideos&&rule.enabled)&&!own.some(event=>/בונוס קולנוע/.test(event.message))) add('🎁 בונוסים ומשימות יומיות',name(account)+': לא נאסף אף בונוס קולנוע ב־24 שעות');
    const held=live.find(rule=>rule.accountKey===account&&rule.kind==='daily'&&/בונוס התגמול בקולנוע \(50\) ממתין/.test(rule.status??''));
    if(held) add('🎁 בונוסים ומשימות יומיות',name(account)+': בונוס התגמול (50) לא נאסף — התגמול קרוב לתקרה');
  }
  // Steady supply to the main account (Firefox, user decision 2026-10-22): claims stuck for hours and
  // merchant ships that stay idle are reported.
  for(const entry of supply?.entries??[]) {
    const age=now-(entry.intentAt??entry.updatedAt??entry.createdAt??now);
    if(entry.state==='intent'&&age>4*3600000) add('📦 משלוחים, איזון ומסחר',name(entry.supplier?.accountKey)+': אספקה לחשבון הראשי ('+entry.resource+' '+(entry.acceptedAmount??entry.amount)+' לעיר '+entry.cityId+') עדיין בשליחה אחרי '+Math.round(age/3600000)+' שעות');
    if(entry.state==='unknown') add('📦 משלוחים, איזון ומסחר',name(entry.supplier?.accountKey)+': אספקה לעיר '+entry.cityId+' בתוצאה לא ידועה; תיסגר אוטומטית אחרי 3 שעות');
  }
  for(const [account,snapshot] of Object.entries(snapshots)) {
    const cities=snapshot?.snapshot?.cities??[],free=Math.max(0,...cities.map(city=>Number(city.tradeShips?.available)).filter(Number.isFinite)),total=Math.max(0,...cities.map(city=>Number(city.tradeShips?.total)).filter(Number.isFinite));
    if(total>0&&free>=total/2) add('📦 משלוחים, איזון ומסחר',name(account)+': '+free+' מתוך '+total+' ספינות סחר פנויות בזמן הדוח');
  }
  // Disconnects.
  const drops=(watchdog?.log??[]).filter(item=>item.time>=since);
  for(const item of drops.slice(0,10)) add('🔌 לשוניות וחיבור',new Date(item.time).toLocaleTimeString('he-IL',{timeZone:'Asia/Jerusalem',hour:'2-digit',minute:'2-digit'})+' '+item.message);
  const lines=['🩺 דוח בריאות יומי — '+israelDay(now)+' · רק תקלות ומה שלא קרה',''];
  if(!sections.size) lines.push('✅ לא היו תקלות ב־24 השעות האחרונות — הכול עבד.');
  for(const section of ORDER.filter(item=>sections.has(item))) {lines.push(section+':');for(const line of [...sections.get(section)].slice(0,12)) lines.push('- '+line);lines.push('');}
  const coverage=[game?.events?.at(-1)?.time,transport?.events?.at(-1)?.time].filter(Boolean);
  if(coverage.length&&Math.max(...coverage)>since&&Math.min(...[game?.events?.[0]?.time,transport?.events?.[0]?.time].filter(Boolean))>since) lines.push('ℹ️ היומן מכסה פחות מ־24 שעות; ייתכן שחסרים אירועים מוקדמים יותר.');
  return lines.join('\n').trim().slice(0,3900);
}

export function createHealthReport(chrome,{notify,now=()=>Date.now()}) {
  let running=false;
  // Firefox supply journal and the supplier accounts' merchant ships (absent in Opera: nothing added).
  async function supplyInputs() {
    let all;try {all=await chrome.storage.local.get(null)??{};} catch {return {};}
    return {supply:all['firefox-supply-claims-v1']??null,snapshots:all['firefox-supply-claims-v1']?Object.fromEntries(Object.entries(all).filter(([key])=>key.startsWith('account-snapshot-')&&!/Orakel8|Orelkaful8/.test(key)).map(([key,value])=>[key.slice('account-snapshot-'.length),value])):{}};
  }
  async function tick() {
    if(running) return;running=true;
    try {
      const stored=await chrome.storage.local.get([KEY,'game-automations-v1','transport-automation-v1','tab-watchdog-v1','wine-only-v1','hidden-accounts-v1']);
      const state=stored[KEY]??{};
      if(israelHour(now())<HOUR||state.lastDay===israelDay(now())) return;
      // A hidden account (Firefox, user decision 2026-10-25) is left out of the report.
      const hidden=new Set(/\bmain\b/.test(chrome.runtime?.getManifest?.()?.version_name??'')?[]:(stored['hidden-accounts-v1']??['Orakel8|42|il','Orelkaful8|42|il']));
      // Firefox has no pirates (user decision, 2026-10-28): their automations and events stay out of the report.
      const firefox=!/\bmain\b/.test(chrome.runtime?.getManifest?.()?.version_name??''),pirate=new Set(firefox?(stored['game-automations-v1']?.rules??[]).filter(rule=>rule.kind==='pirates'&&!(Number(rule.pirateMission)===1&&rule.pirateStrategy!=='auto')).map(rule=>rule.id):[]);
      const visible=value=>value&&{...value,rules:(value.rules??[]).filter(rule=>!hidden.has(rule.accountKey)&&!pirate.has(rule.id)),events:(value.events??[]).filter(event=>!hidden.has(event.accountKey)&&!pirate.has(event.ruleId))};
      const text=buildHealthReport({game:visible(stored['game-automations-v1']),transport:visible(stored['transport-automation-v1']),watchdog:stored['tab-watchdog-v1'],wineOnly:stored['wine-only-v1']?.accounts??{},now:now(),...(await supplyInputs())});
      let sent=false;try {await notify('all',text);sent=true;} catch { /* Kept for the panel below. */ }
      await chrome.storage.local.set({[KEY]:{lastDay:israelDay(now()),last:{at:now(),text,sent}}});
    } finally {running=false;}
  }
  // On demand (the button in the window): built now, sent now, kept as the last report.
  async function sendNow() {
    const stored=await chrome.storage.local.get([KEY,'game-automations-v1','transport-automation-v1','tab-watchdog-v1','wine-only-v1']);
    const text=buildHealthReport({game:stored['game-automations-v1'],transport:stored['transport-automation-v1'],watchdog:stored['tab-watchdog-v1'],wineOnly:stored['wine-only-v1']?.accounts??{},now:now(),...(await supplyInputs())});
    await notify('all',text);
    await chrome.storage.local.set({[KEY]:{...(stored[KEY]??{}),last:{at:now(),text,sent:true}}});
    return {text,at:now()};
  }
  return {tick,sendNow};
}

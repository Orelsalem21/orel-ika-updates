// Planning for the main account's shortages in steady work (Firefox; docs/SUPPLY_ALLOCATION_PROTOCOL_DRAFT.md,
// timing contract be661a4). Pure functions only: no game request, no shipment, no claim.
// - What a city can give: its spare stock (supply-donors.js: satisfaction, wine for its tavern, the
//   floor, its building queues' current step; nothing in a war), less what is already committed from
//   it — shipping routes still going and claims not yet sent — so the same stock is never promised
//   twice to Opera and to the account's own automations.
// - Which shortage first (new claims only): critical wine, then construction by the external
//   deadline, then routine wine. A shortage without a known deadline counts as due 24 hours after the
//   service first saw it (firstSeenAt, kept while the shortage lasts), so it ages and is never starved
//   by newer dated ones; it is still shown as "deadline unknown".
// - Which supplier: with a fresh game quote of each route, the one that arrives in time with the most;
//   when none arrives in time, the earliest (a quick partial supply beats waiting for a big one).
//   Without quotes, the most stock; the arrival is then shown as unknown.
import { cityAvailable, DONOR_DEFAULTS } from './supply-donors.js';
const RANK = { 'critical-wine': 0, construction: 1, 'wine-balance': 2 };
const UNKNOWN_DUE = 24 * 3600000, STEP = 500;
// At most about two hours of loading at one port per claim (user report, 2026-10-22: one load of 73,500
// tied 147 ships for 13 hours of loading); the rest goes to other ports in parallel.
export const MAX_LOADING_SECONDS = 2 * 3600;
const due = demand => demand?.timing ? (Object.hasOwn(demand.timing, 'externalNeededAt') ? demand.timing.externalNeededAt : demand.timing.neededAt) ?? null : null;
export const demandDue = due;

export function orderDemands(demands, now = Date.now()) {
  const effective = demand => due(demand) ?? (Number.isSafeInteger(demand.firstSeenAt) ? demand.firstSeenAt : now) + UNKNOWN_DUE;
  return [...(demands ?? [])].sort((a, b) => (RANK[a.timing?.priority] ?? 1) - (RANK[b.timing?.priority] ?? 1) || effective(a) - effective(b) || (b.claimable ?? b.amount) - (a.claimable ?? a.amount) || a.cityId.localeCompare(b.cityId) || a.resource.localeCompare(b.resource));
}
// The part of a shortage due by a moment (overdue steps included); unmapped amounts have no date.
export function dueBy(demand, moment) {
  const steps = demand?.timing?.steps ?? [];
  return steps.filter(step => step.neededAt !== null && step.neededAt <= moment).reduce((sum, step) => sum + (step.externalAmount ?? step.amount), 0);
}

// Committed from each city: routes still going (their remaining amount, or what they sent after the
// city was read) and claims of this client not yet sent.
export function commitments({ routes = [], claims = [], readAt = {} } = {}) {
  const held = {};
  const add = (accountKey, cityId, resource, amount) => { if (amount > 0) { const key = accountKey + ':' + cityId + ':' + resource;held[key] = (held[key] ?? 0) + amount; } };
  for (const route of routes) {
    if (route.deleted) continue;
    const sent = Number(route.sentTotal) || 0, quantity = Number(route.quantity) || 0;
    // A stopped route (off, its last run without a known result) sends nothing more: its remaining amount is
    // free again (user report, 2026-10-22: two stopped war routes held two million wood of Orakel3); what
    // it may have sent is already out of the stock the game reads.
    const stopped = !route.enabled && /^נעצר|נדרשת בדיקה/.test(route.status ?? '');
    if ((route.enabled || route.inFlight) && !stopped) add(route.accountKey, String(route.originCityId), route.resource, route.sendMode === 'amount' ? Math.max(0, quantity - sent) : 0);
    if (sent > 0 && (route.lastShipment?.submittedAt ?? 0) > (readAt[route.accountKey] ?? Infinity)) add(route.accountKey, String(route.originCityId), route.resource, sent);
  }
  for (const claim of claims) if (['new', 'requested', 'accepted', 'intenting'].includes(claim.state) || claim.state === 'intent' && !claim.receiptBody)
    add(claim.supplier.accountKey, claim.supplier.cityId, claim.resource, claim.acceptedAmount ?? claim.amount);
  return held;
}

// Every supplier city for one resource, after its keeps and its commitments; accounts without a free
// merchant ship are listed as waiting for ships.
export function inventory(accounts, resource, { routes = [], claims = [], war = false, options = {} } = {}) {
  if (war) return [];
  const readAt = Object.fromEntries((accounts ?? []).map(account => [account.accountKey, account.readAt ?? 0]));
  const held = commitments({ routes, claims, readAt }), result = [];
  // One ship's load per account, measured from that account's own past loads (amount / ships); unknown
  // until a load was recorded — then claims are not bounded by it (no game parameter is guessed).
  const perShip = {};
  for (const route of routes) for (const part of route.parts ?? []) if (part.ships > 0 && part.amount > 0) perShip[route.accountKey] = Math.max(perShip[route.accountKey] ?? 0, Math.floor(part.amount / part.ships));
  // The account's merchant ships are shared by its ports: a claim made after the account was last read
  // and not yet reported holds its ships (amount / one ship's load), so parallel claims never count the
  // same ships twice. A claim made before the read is already in the read's free ships.
  const loading = {};
  for (const claim of claims) if (['new', 'requested', 'accepted', 'intenting', 'intent'].includes(claim.state) && !claim.receiptBody && (claim.createdAt ?? 0) > (readAt[claim.supplier?.accountKey] ?? 0) && perShip[claim.supplier?.accountKey])
    loading[claim.supplier.accountKey] = (loading[claim.supplier.accountKey] ?? 0) + Math.ceil((claim.acceptedAmount ?? claim.amount) / perShip[claim.supplier.accountKey]);
  for (const account of accounts ?? []) {
    // Free ships from the newer of the account read and the fleet ledger, plus the ships coming home within
    // fifteen minutes (their next load is claimed now and leaves as they arrive; user decision, 2026-10-28).
    const fleet = account.fleet && Date.now() - (account.fleet.at ?? 0) < 900000 ? account.fleet : null;
    const read = Math.max(0, ...(account.cities ?? []).map(city => Number(city.tradeShips?.available)).filter(Number.isFinite));
    const free = fleet && Number.isFinite(fleet.free) && fleet.at > (account.readAt ?? 0) ? fleet.free : read;
    const soon = (fleet?.fleets ?? []).filter(item => item.phase === 'returning' && item.stageEndsAt && item.stageEndsAt <= Date.now() + 900000).reduce((sum, item) => sum + (Number(item.ships) || 0), 0);
    const ships = Math.max(0, free + soon - (loading[account.accountKey] ?? 0));
    for (const city of account.cities ?? []) {
      const own = cityAvailable(city, resource, account.rules ?? [], { ...DONOR_DEFAULTS, ...options });
      const committed = held[account.accountKey + ':' + String(city.id) + ':' + resource] ?? 0;
      const available = Math.max(0, own.available - committed);
      if (available >= STEP) result.push({ accountKey: account.accountKey, cityId: String(city.id), cityName: city.name ?? String(city.id), available, committed, keep: own.keep, building: own.building, ships, loadCapacity: perShip[account.accountKey] ? ships * perShip[account.accountKey] : null, readAt: account.readAt ?? null });
    }
  }
  // Full satisfaction first (user decision, 2026-10-23): what the account's governor upgrades still lack
  // (their own read of the shortfall, at most six hours old) stays in the account for its balancing; only
  // the rest goes to the main account, from the cities with the most first.
  for (const account of accounts ?? []) {
    const lack = (account.rules ?? []).filter(rule => rule.kind === 'building' && rule.autopilot === 'satisfaction' && rule.enabled && !rule.deleted && Date.now() - (rule.progress?.need?.at ?? 0) < 21600000)
      .reduce((sum, rule) => sum + Math.max(0, Number(rule.progress?.need?.resources?.[resource]) || 0), 0);
    let keep = lack;
    for (const item of result.filter(entry => entry.accountKey === account.accountKey).sort((a, b) => b.available - a.available)) {
      if (keep <= 0) break;
      const taken = Math.min(keep, item.available);item.available -= taken;item.keptForGovernors = taken;keep -= taken;
    }
  }
  return result.filter(item => item.available >= STEP).sort((a, b) => b.available - a.available);
}

// One supplier for one shortage. quotes: {[accountKey:cityId]: {arrivalAt}} from fresh game quotes.
export function chooseSupplier(demand, candidates, { quotes = {}, now = Date.now(), cap = Infinity } = {}) {
  const wanted = Math.min(demand?.claimable ?? demand?.amount ?? 0, cap);
  if (!(wanted >= STEP)) return null;
  const options = (candidates ?? []).filter(item => item.ships > 0).map(item => {
    // Never more than the supplier's free ships can load now (ships always working: the rest goes to
    // another supplier in parallel instead of waiting for these ships to come back).
    const quote = quotes[item.accountKey + ':' + item.cityId];
    // The port's loading rate, from the game's transport form of this route (amount / loading seconds).
    const rate = quote && quote.loadingSeconds > 0 && quote.quotedAmount > 0 ? quote.quotedAmount / quote.loadingSeconds : null;
    // Loading time allowed: up to two hours (1:59 is fine), and — when Opera gave a need time — no more
    // than lets queue + loading + voyage arrive by it (user decision, 2026-10-22). If even a small load
    // cannot make it, the two hours stay: a quick partial supply is still the best.
    const deadline = due(demand), queue = Number(quote?.queueSeconds) || 0, voyage = Number(quote?.travelSeconds) || 0;
    const inTime = deadline !== null && rate && Number.isFinite(voyage) ? (deadline - now) / 1000 - queue - voyage : null;
    const loading = inTime !== null && inTime > 0 ? Math.min(MAX_LOADING_SECONDS, inTime) : MAX_LOADING_SECONDS;
    const amount = Math.floor(Math.min(wanted, item.available, item.loadCapacity ?? Infinity, rate ? rate * loading : Infinity) / STEP) * STEP;
    // The arrival of the amount actually claimed (not of the quoted one), from the same game values.
    const arrivalAt = rate && quote?.travelSeconds != null ? Math.round(now + (queue + amount / rate + voyage) * 1000) : Number.isSafeInteger(quote?.arrivalAt) ? quote.arrivalAt : null;
    // How long this load holds its ships: queue, loading, the voyage there and the voyage back.
    const roundTrip = rate && quote?.travelSeconds != null ? queue + amount / rate + 2 * voyage : null;
    return { ...item, amount, arrivalAt, roundTrip, voyage: quote?.travelSeconds != null && Number.isFinite(voyage) ? voyage : null };
  }).filter(item => item.amount >= STEP);
  if (!options.length) return null;
  // Trade ships are the scarcest thing the accounts have: of the options that arrive in time, the nearest port —
  // the fewest ship hours for every 500 (user decision, 2026-10-30: not the one with the most stock; a round trip
  // that counted the loading time favoured small loads). Voyages within a fifth (or ten minutes) of the shortest
  // count as equal, and the bigger load wins among them.
  const thrifty = list => {
    const known = list.filter(item => item.voyage !== null);
    if (!known.length) return null;
    const best = Math.min(...known.map(item => item.voyage));
    return known.filter(item => item.voyage <= best * 1.2 + 600).sort((a, b) => b.amount - a.amount || a.voyage - b.voyage)[0];
  };
  const deadline = due(demand), timed = options.filter(item => item.arrivalAt !== null);
  if (deadline !== null && timed.length) {
    const inTime = timed.filter(item => item.arrivalAt <= deadline);
    const thrift = thrifty(inTime);
    if (thrift) return { ...thrift, reason: 'מגיע בזמן מהנמל הקרוב ביותר' };
    if (inTime.length) { const pick = inTime.sort((a, b) => b.amount - a.amount || a.arrivalAt - b.arrivalAt)[0];return { ...pick, reason: 'מגיע בזמן עם הכמות הגדולה ביותר' }; }
    const pick = timed.sort((a, b) => a.arrivalAt - b.arrivalAt || b.amount - a.amount)[0];
    return { ...pick, reason: 'אף ספק לא מגיע בזמן — הספק המהיר ביותר, גם אם חלקי' };
  }
  const thrift = thrifty(options);
  if (thrift) return { ...thrift, reason: deadline === null ? 'מועד הצורך אינו ידוע — הנמל הקרוב ביותר' : 'הנמל הקרוב ביותר' };
  const pick = options.sort((a, b) => b.amount - a.amount || (a.arrivalAt ?? Infinity) - (b.arrivalAt ?? Infinity))[0];
  return { ...pick, reason: deadline === null ? 'מועד הצורך אינו ידוע — הספק עם הכמות הגדולה ביותר' : 'זמן ההגעה אינו ידוע — הספק עם הכמות הגדולה ביותר' };
}

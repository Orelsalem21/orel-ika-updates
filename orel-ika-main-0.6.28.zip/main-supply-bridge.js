// Opera-only background publisher. Observation mode never reserves or sends cargo.
import {createOperaAllocationCoordinator,allocationHealth,pendingScans,settleScan} from './main-supply-allocation.js';
export const BRIDGE_URL='http://127.0.0.1:18746';
const CONFIG='main-supply-bridge-v1',STATUS='main-supply-bridge-status-v1';
const resources=['wood','marble','wine','crystal','sulfur'];
export function bridgeConnectionError(code,endpoint='/v1/status',httpStatus=null){
  const messages={permission:'אין הרשאה ל־localhost — כבה והפעל את המתג ואשר את ההרשאה',unauthorized:'401 — המפתח נדחה; באופרה נדרש producerKey מהתיקייה הקבועה',forbidden:'403 — השירות דחה את הגישה או את מקור הבקשה',network:'השירות לא עונה לבקשת הדפדפן או שהדפדפן חסם אותה',timeout:'השירות לא ענה בתוך 5 שניות',protocol:'השירות החזיר תשובה שאינה תואמת לערוץ observe'};
  return {code,endpoint,httpStatus,message:messages[code]??`השירות החזיר שגיאה ${httpStatus??''}`};
}
export function demandFromReport(accountKey,report,now=Date.now()) {
  const input=report?.mainCoordinationInputs;
  if(!input||!Number.isFinite(report.scannedAt)||now-report.scannedAt>3600000||report.scannedAt>now+30000)return null;
  const blocked=new Set((report.unresolvedShipments??[]).flatMap(x=>[`${x.originCityId}:${x.resource}`,`${x.destinationCityId}:${x.resource}`]));
  const demands=[];
  for(const city of report.cities??[]) for(const resource of resources){
    if(blocked.has(`${city.id}:${resource}`))continue;
    const build=Math.max(input.forecast?.[city.id]?.[resource]??0,input.needs?.[city.id]?.[resource]??0,input.externalForecast?.[city.id]?.[resource]??0);
    const target=Math.max(build,resource==='wine'?(input.wineTargets?.[city.id]??0):0);
    const stock=city.resources?.[resource],incoming=input.incoming?.[city.id]?.[resource]??0;
    if(![target,stock,incoming].every(x=>Number.isSafeInteger(x)&&x>=0))continue;
    const amount=Math.ceil(Math.max(0,target-stock-incoming)/500)*500;
    if(amount)demands.push({cityId:String(city.id),resource,amount,purpose:resource==='wine'&&target>build?'wine':'construction'});
  }
  return {schema:1,mode:'observe',accountKey,scannedAt:report.scannedAt,demands};
}
export function createMainSupplyBridge(api,{fetcher=fetch,now=Date.now}={}){
  if(!/\bmain\b/.test(api.runtime.getManifest?.()?.version_name??''))return null;
  const call=async(config,path,body,method=body?'POST':'GET')=>{
    const response=await fetcher(BRIDGE_URL+path,{method,headers:{Authorization:'Bearer '+config.key,...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(5000),cache:'no-store'});
    const result=await response.json();if(!response.ok)throw Object.assign(new Error('פעולת הקצאה נדחתה ('+response.status+')'),{status:response.status});return result;
  };
  const allocation=createOperaAllocationCoordinator(api,{call,demandFromReport,now});
  let busy=false;
  async function tick(){
    if(busy)return;busy=true;
    let activeConfig=null,permitted=false;
    try{
      const values=await api.storage.local.get([CONFIG,STATUS,'transport-automation-v1']);
      const config=values[CONFIG];if(!config?.enabled)return;
      activeConfig=config;
      if(!await api.permissions.contains({origins:['http://127.0.0.1/*']})){
        await api.storage.local.set({[STATUS]:{ok:false,serviceConnected:false,at:now(),peer:null,peerCheckedAt:now(),serviceError:bridgeConnectionError('permission')}});return;
      }
      permitted=true;
      const policy=values['transport-automation-v1']?.rules?.find(x=>x.policyMode&&x.accountKey===config.accountKey&&!x.deleted);
      if(!policy?.enabled)throw new Error('אספקת החשבון כבויה; החוסרים האחרונים יפוגו אוטומטית');
      if(allocationHealth(values[STATUS]?.peer)){
        const result=await allocation.sync(config,values[STATUS].peer);
        await api.storage.local.set({[STATUS]:{ok:result.ready,at:now(),...result,message:result.ready?result.mode==='dispatch'?'סונכרנו חוסרי החשבון וההקצאות לעבודה שוטפת':'סונכרנו חוסרי הפיילוט וההקצאות; משלוח פיירפוקס דורש אישור משתמש':'אין סריקת אספקה תקפה לערוץ ההקצאות; אין אישור לשליחה חדשה עד לפרסום סריקה מלאה'}});return;
      }
      const pending=await pendingScans(api,config.accountKey);
      for(const item of pending)if(now()-item.report.scannedAt>=3600000)await settleScan(api,config.accountKey,item,'expired-without-publication',now());
      const entry=pending.find(x=>now()-x.report.scannedAt<3600000);
      if(policy.inFlight&&!entry)throw new Error('ממתין לסיום סריקת האספקה');
      const payload=demandFromReport(config.accountKey,entry?.report??policy.report,now());
      if(!payload)throw new Error('ממתין לסריקה חדשה עם נתוני התיאום');
      const response=await fetcher(BRIDGE_URL+'/v1/demands',{method:'PUT',headers:{Authorization:'Bearer '+config.key,'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(5000),cache:'no-store'});
      if(!response.ok)throw new Error('שירות התיאום דחה את הבקשה ('+response.status+')');
      if(entry)await settleScan(api,config.accountKey,entry,'published-v1',now());
      await api.storage.local.set({[STATUS]:{ok:true,at:now(),scannedAt:payload.scannedAt,count:payload.demands.length,mode:'observe',message:'מחובר · פרסום חוסרים בלבד; שליחה מפיירפוקס טרם הופעלה'}});
    }catch(error){await api.storage.local.set({[STATUS]:{ok:false,at:now(),message:error.message?.startsWith('שירות')||/[א-ת]/.test(error.message??'')?error.message:'לא ניתן להתחבר לשירות המקומי'}});}
    finally{
      if(activeConfig&&permitted){
        let peer=null,serviceConnected=false,serviceError=null;
        try{
          const response=await fetcher(BRIDGE_URL+'/v1/status',{headers:{Authorization:'Bearer '+activeConfig.key},signal:AbortSignal.timeout(5000),cache:'no-store'});
          if(!response.ok){
            serviceError=bridgeConnectionError(response.status===401?'unauthorized':response.status===403?'forbidden':'http','/v1/status',response.status);
            if(response.status===403){
              let reason;try{reason=(await response.json()).error;}catch{ /* Keep the HTTP cause if the body is not JSON. */ }
              const reasons={'producer key required':'403 — נדרש producerKey של אופרה; מפתח הקריאה של פיירפוקס אינו מתאים','invalid origin':'403 — השירות דחה את מקור הבקשה מהדפדפן','invalid host':'403 — השירות דחה את כתובת ה־Host של הבקשה'};
              if(Object.hasOwn(reasons,reason))serviceError.message=reasons[reason];
            }
          }
          else{const result=await response.json();serviceConnected=result.schema===1&&result.mode==='observe'||allocationHealth(result);if(!serviceConnected)serviceError=bridgeConnectionError('protocol');else if(result.accountKey===activeConfig.accountKey||result.accountKey===null)peer=result;}
        }catch(error){serviceError=bridgeConnectionError(error?.name==='TimeoutError'||error?.name==='AbortError'?'timeout':error?.name==='SyntaxError'?'protocol':'network');}
        const previous=(await api.storage.local.get(STATUS))[STATUS]??{};
        await api.storage.local.set({[STATUS]:{...previous,...(serviceError?{ok:false,message:serviceError.message}:{}),serviceError,peer,serviceConnected,peerCheckedAt:now()}});
        const event={accountKey:activeConfig.accountKey,phase:serviceError?'error':previous.ok?'published':previous.message?.includes('ממתין')?'waiting':'error',errorCode:serviceError?.code??null,httpStatus:serviceError?.httpStatus??null,serviceConnected,scannedAt:previous.scannedAt??null,count:previous.count??null,revision:peer?.revision??null,readCurrent:peer?.readCurrent===true,ackCurrent:peer?.ackCurrent===true};
        const historyKey='main-supply-bridge-events-v1',history=(await api.storage.local.get(historyKey))[historyKey]??[];
        const last=history.at(-1),{at:_at,...lastState}=last??{};
        if(JSON.stringify(lastState)!==JSON.stringify(event))await api.storage.local.set({[historyKey]:[...history,{at:now(),...event}].slice(-80)});
      }
      busy=false;
    }
  }
  api.alarms.create('main-supply-bridge',{periodInMinutes:1});
  api.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='main-supply-bridge')void tick();});
  api.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&(changes[CONFIG]||changes['transport-automation-v1']||Object.keys(changes).some(key=>key.startsWith('main-supply-scan-v2-'))))void tick();});
  api.runtime.onMessage.addListener((message,sender,reply)=>{
    if(message?.type==='MAIN_SUPPLY_ALLOCATION'){
      if(sender.id!==api.runtime.id||!/^https:\/\/[^/]+\.ikariam\.gameforge\.com\//.test(sender.url??''))return false;
      void allocation.handle(message).then(result=>reply({ok:true,...result}),()=>reply({ok:false,message:'פעולת הפיילוט מושהית; אין לשלוח לפני אימות השמירה'}));return true;
    }
    if(message?.type!=='MAIN_SUPPLY_BRIDGE_SYNC')return false;
    if(sender.id!==api.runtime.id||!sender.url?.startsWith(api.runtime.getURL('')))return false;
    void tick().then(()=>reply({ok:true}));return true;
  });
  void tick();return {tick};
}

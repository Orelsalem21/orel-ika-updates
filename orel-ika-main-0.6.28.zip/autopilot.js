// "Just switch it on" automations (user decision, 2026-10-13). For each enabled switch the agent
// keeps the right automations on every open account and city by itself, 24/7, with Telegram;
// switching it off stops exactly the automations it created. Settings the user does not choose:
//  wine       — every city: alert below 12 hours of wine; the 48,000 policy (or the rule itself
//               when no policy runs) brings wine from the account's other cities.
//  barbarians — one city per island (highest barracks, with a port): Ikabot presets with
//               recruitment, up to village level 39.
//  attacks    — one per account, every 3 minutes.
//  daily      — one per account: completed daily-task rewards (favour cap 2,500), unless the
//               morning routine already collects them there.
// autopilot-status-v1 tells the panel, per switch and account, how many automations run and
// what is missing (shown on the card and, when the user must act, on the dashboard).
import { uniformPlan, storageEntries } from './building-uniform.js';
import './satisfaction.js';
import { carePlan, CARE_KEY, CARE_STATUS, CARE_DEFAULTS } from './satisfaction-care.js';
const STATUS='autopilot-status-v1';
const TRANSIENT=/קריאת המשחק נכשלה|חרגה מזמן ההמתנה|timed out|Failed to fetch|NetworkError|העיר אינה שייכת לחשבון המחובר/i;
// Building uniformity: 'dry' (the default) only plans and shows the plan; 'run' keeps one
// building queue per city from the plan; 'off' stops it. The plan of every account is kept in
// uniform-plan-v1 for the panel (accounts without an open tab keep their last plan).
const UNIFORM_MODE='uniform-mode-v1',UNIFORM_PLAN='uniform-plan-v1';
const uniformConfig=(cityId,entries)=>({kind:'building',cityId,entries,intervalMinutes:5,maxCycles:10000,reserve:0,autopilot:'uniform',telegram:false});
const sameEntries=(a,b)=>JSON.stringify((a??[]).map(entry=>[entry.key,entry.target]))===JSON.stringify((b??[]).map(entry=>[entry.key,entry.target]));
const MISSING={miracle:'אין עיר עם מקדש בחשבון',wine:'לא נקראו ערי החשבון עדיין',barbarians:'אין עיר עם צריפים ונמל לתקיפת ברברים',attacks:'לא נקראו ערי החשבון עדיין',daily:'שגרת הבוקר כבר אוספת את הפרסים בחשבון הזה'};
const OFF='autopilot-off-v1',KEY='autopilot-v1',DEFAULTS={wine:true,barbarians:true,attacks:true,daily:true,miracle:true},EVERY=5*60000;
const GAME=/^https:\/\/s\d+-\w+\.ikariam\.gameforge\.com\//;
// The main-account edition (Opera, user decision 2026-10-16): the alliance's main account. Its
// buildings follow the user's own target levels (build-targets-v1), nothing leaves the account
// (no export), no regular temple and no automatic research (the user chooses).
const MAIN_EDITION_RE=/\bmain\b/;
const MAIN=()=>{try {return MAIN_EDITION_RE.test(globalThis.chrome?.runtime?.getManifest?.()?.version_name??"");} catch {return false;}};
export const BUILD_TARGETS='build-targets-v1';

const configs={
  tavern:cityId=>({kind:"tavern",cityId,entries:[],intervalMinutes:60,maxCycles:10000,reserve:0,autopilot:"tavern",telegram:false}),
  wine:cityId=>({kind:'wine',cityId,entries:[],intervalMinutes:30,maxCycles:10000,reserve:0,hours:12,transferAmount:10000,autoTransfer:true,telegram:true}),
  barbarians:cityId=>({kind:'barbarians',cityId,entries:[],intervalMinutes:5,maxCycles:10000,reserve:0,autoRecruit:true,maxBarbarianLevel:39,telegram:true}),
  attacks:cityId=>({kind:'attacks',cityId,entries:[],intervalMinutes:3,maxCycles:10000,reserve:0,telegram:true}),
  // Temple (user decision, 2026-10-14): every city with a temple activates its island's miracle;
  // checked every 12 hours whether the activation is available again.
  miracle:cityId=>({kind:'miracle',cityId,entries:[],intervalMinutes:720,maxCycles:10000,reserve:0,telegram:false}),
  daily:cityId=>({kind:'daily',cityId,entries:[],intervalMinutes:30,maxCycles:10000,reserve:0,collectTasks:true,performTasks:true,collectVideos:false,favourGuard:true,favourCap:2500,favourMargin:500,telegram:true}),
};

// Which cities of an account each switch covers.
export function autopilotTargets(kind,cities,rules) {
  if(!cities?.length) return [];
  const others=rules.filter(rule=>!rule.autopilot&&!rule.deleted&&rule.enabled&&rule.kind===kind);
  if(kind==='tavern') return cities.filter(city=>(city.buildings??[]).some(item=>item.building==='tavern')&&!others.some(rule=>String(rule.cityId)===String(city.id))).map(city=>city.id);
  if(kind==='wine') return cities.filter(city=>!others.some(rule=>String(rule.cityId)===String(city.id))).map(city=>city.id);
  if(kind==='attacks') return [cities[0].id];
  if(kind==='daily') return others.some(rule=>rule.collectTasks)?[]:[cities[0].id];
  if(kind==='miracle') return cities.filter(city=>(city.buildings??[]).some(item=>item.building==='temple')&&!others.some(rule=>String(rule.cityId)===String(city.id))).map(city=>city.id);
  // One army per island (user decision, 2026-10-27: several cities on one island attack the same village, so
  // only one of them keeps and recruits an army): the city with barracks and a port and the highest barracks;
  // an island without such a city takes its best one still (it waits for the prerequisites). An island where
  // the user runs a barbarian automation of their own is left to it.
  if(kind==='barbarians'&&MAIN()) return cities.filter(city=>city.islandId&&!others.some(rule=>String(rule.cityId)===String(city.id))).map(city=>city.id);
  if(kind==='barbarians') {
    const level=(city,name)=>Number((city.buildings??[]).find(item=>item.building===name)?.level)||0;
    const score=city=>[level(city,'barracks')>0&&level(city,'port')>0?1:0,level(city,'barracks'),level(city,'port')];
    const better=(a,b)=>{const x=score(a),y=score(b);return (x[0]-y[0]||x[1]-y[1]||x[2]-y[2])>0;};
    const best=new Map();
    for(const city of cities.filter(city=>city.islandId)) {const island=String(city.islandId);if(!best.has(island)||better(city,best.get(island))) best.set(island,city);}
    const userIslands=new Set(others.map(rule=>String(cities.find(city=>String(city.id)===String(rule.cityId))?.islandId)));
    return [...best.entries()].filter(([island])=>!userIslands.has(island)).map(([,city])=>city.id);
  }
  return [];
}

// Full autonomy (user decision, 2026-10-13): one switch, on by default. Turned on, it switches on
// every automation once (the autopilot switches, building uniformity, tavern management); then, per
// account, it sets up what is still missing: the 48,000 balancing policy (with the export to the
// main account once a main target is known; accounts in growOnly only balance their own cities)
// and continuous pirate raids in the city with the highest pirate fortress. Whatever the user
// changes afterwards is kept: nothing the user switched off is switched on again.
const FULL='full-auto-v1',FULL_DEFAULTS={enabled:true,growOnly:['Orakel7'],appliedAt:null};
// Switches inside the full-autonomy window (the others map to existing keys): balancing, export
// to the main account and pirate raids act on every account when flipped; workers is read by the
// building uniformity before it adds workers.
export const FEATURES={balance:true,export:true,pirates:true,workers:true,rescue:true,research:true,scientists:true};
const PIRACY_LEVEL={1:1,2:3,3:5,4:7,5:9,6:11,7:13,8:15,9:17};
// The hour-long raid when the fortress allows it (fewer captchas than the short ones), else the longest available.
export function pirateMission(level) {
  const allowed=Object.entries(PIRACY_LEVEL).filter(([,need])=>need<=level).map(([mission])=>Number(mission));
  return allowed.length?(allowed.includes(5)?5:Math.max(...allowed)):null;
}
export function createAutopilot(chrome,{game,identify,transport=null,now=()=>Date.now()}) {
  let running=false,lastRun=0,pending=false;
  // Satisfaction guard (Firefox edition, user decision 2026-10-20: before every other task). Each
  // account's cities are read again every 30 minutes (the town hall gives satisfaction and growth);
  // an unhappy city's tavern serves the most wine whatever the tavern switch says, and the result
  // goes to the balancing (wine first), the builders (governor's residence and tavern first) and
  // the dashboard (satisfaction-v1).
  const readAsked=new Map();
  async function satisfaction(tab,accountKey,cities,state) {
    const entry=(await chrome.storage.local.get('account-snapshot-'+accountKey))['account-snapshot-'+accountKey];
    if(!(entry?.at&&now()-entry.at<30*60000)&&now()-(readAsked.get(accountKey)??0)>30*60000) {
      readAsked.set(accountKey,now());
      try {void chrome.tabs.sendMessage(tab.id,{type:'IKARIAM_AGENT_READ_ACCOUNT_JOB',requestId:'satisfaction-'+now(),accountKey})?.catch?.(()=>{});} catch { /* Read again next round. */ }
    }
    const result=globalThis.IkariamSatisfaction.assess(cities??[]);
    const all=(await chrome.storage.local.get('satisfaction-v1'))['satisfaction-v1']??{};
    await chrome.storage.local.set({'satisfaction-v1':{...all,[accountKey]:{at:entry?.at??null,checkedAt:now(),cities:result}}});
    // Wine and taverns are satisfaction care's task now (user decision, 2026-10-22: one automation for
    // satisfaction and wine): it keeps 24 hours of wine in every city and every tavern at the most wine.
    // A tavern stopped because the game refused to serve without wine comes back once wine is there.
    const wineOf=id=>Number((cities??[]).find(item=>String(item.id)===String(id))?.resources?.wine)||0;
    for(const rule of state.rules.filter(item=>item.kind==='tavern'&&!item.deleted&&!item.enabled&&!item.inFlight&&!item.uncertain&&/המשחק דחה/.test(item.status??'')&&wineOf(item.cityId)>=100&&now()-(item.lastFailureAt??0)>=7200000))
      state=await game.handle({operation:'release',accountKey,id:rule.id});
    return state;
  }
  // Satisfaction care (Firefox, see satisfaction-care.js): wine always, every governor's residence
  // at the number of colonies, then the marble of a handled account to the main account's marble
  // city. A city gets a new shipment only once the account was read after its last one finished,
  // so stock read before a shipment is never sent twice.
  async function oneOff(accountKey,routes,rule) {
    const before=new Set(routes.map(item=>item.id));
    const saved=await transport.handle({operation:'save',accountKey,rule:{sendMode:'amount',intervalMinutes:2,maxCycles:1,startImmediately:true,oneOff:true,...rule}});
    const route=(saved.rules??[]).find(item=>!before.has(item.id));
    if(route) await transport.handle({operation:'toggle',accountKey,id:route.id,enabled:true});
    return (await transport.handle({operation:'list',accountKey})).rules??[];
  }
  async function care(accountKey,cities,state) {
    const config={...CARE_DEFAULTS,...((await chrome.storage.local.get(CARE_KEY))[CARE_KEY]??{})};
    const all=(await chrome.storage.local.get(CARE_STATUS))[CARE_STATUS]??{},sent={...(all[accountKey]?.sent??{})},mine=new Set(all[accountKey]?.rules??[]);
    const readAt=(await chrome.storage.local.get('account-snapshot-'+accountKey))['account-snapshot-'+accountKey]?.at??0;
    const report={at:now(),readAt,enabled:!!config.enabled,errors:[],shipped:[]};
    const save=async()=>chrome.storage.local.set({[CARE_STATUS]:{...((await chrome.storage.local.get(CARE_STATUS))[CARE_STATUS]??{}),[accountKey]:{...report,sent,rules:[...mine].filter(id=>state.rules.some(rule=>rule.id===id&&!rule.deleted))}}});
    // Switched off: the residence queues it opened stop (an upgrade already started in the game ends there).
    if(!config.enabled) {
      for(const rule of state.rules.filter(rule=>mine.has(rule.id)&&rule.enabled&&!rule.inFlight&&!rule.deleted)) state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:false});
      await save();return state;
    }
    if(!cities?.length) {await save();return state;}
    const skip=(config.skipGovernors??[]).includes(accountKey.split('|')[0]);
    // No automatic balancing is switched on (user decision, 2026-10-22: the merchant ships work for the
    // main account first; the cities' wine is kept by this care).
    const plan=carePlan(cities,{...config,skipGovernors:skip}),name=id=>(cities.find(city=>String(city.id)===String(id))?.name)??String(id);
    // An account left out of the residence task: the residence queues care opened there stop.
    if(skip) for(const rule of state.rules.filter(rule=>rule.kind==='building'&&rule.autopilot==='satisfaction'&&rule.enabled&&!rule.inFlight&&!rule.deleted&&(mine.has(rule.id)||(rule.entries??[]).every(entry=>/palaceColony$/.test(String(entry.key)))))) {
      try {state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:false});} catch(error) {report.errors.push('עצירת מגורי מושל: '+error.message);}
    }
    Object.assign(report,{skipGovernors:skip,needed:plan.needed,governors:plan.governors.map(({entry,...item})=>item),wine:plan.wine,handled:plan.handled});
    const fresh=key=>readAt>(sent[key]??0);
    if(transport) {
      let routes=(await transport.handle({operation:'list',accountKey})).rules??[];
      for(const item of plan.wine.filter(item=>item.from&&fresh('wine:'+item.cityId))) {
        if(routes.some(rule=>rule.resource==='wine'&&String(rule.destinationCityId)===item.cityId&&(rule.enabled||rule.inFlight))) continue;
        try {routes=await oneOff(accountKey,routes,{originCityId:item.from,destinationCityId:item.cityId,resource:'wine',quantity:item.quantity});sent['wine:'+item.cityId]=now();report.shipped.push({resource:'wine',from:item.from,to:item.cityId,quantity:item.quantity});}
        catch(error) {report.errors.push('יין ל'+item.name+': '+error.message);}
      }
    }
    for(const item of plan.governors) {
      try {
        let rule=state.rules.find(rule=>rule.kind==='building'&&rule.autopilot==='satisfaction'&&String(rule.cityId)===item.cityId&&!rule.deleted);
        if(rule?.inFlight) continue;
        // A building queue the user switched on in the city keeps the builder; it is reported, never overridden.
        if(state.rules.some(other=>other.kind==='building'&&!other.autopilot&&other.enabled&&!other.deleted&&String(other.cityId)===item.cityId)) {report.errors.push('מגורי מושל ב'+item.name+': בעיר פועל תור בנייה ידני שלך — מגורי המושל ממתינים לסיומו');continue;}
        // A queue that used up its cycles starts over as a new one.
        if(rule&&rule.cycles>=rule.maxCycles) {state=await game.handle({operation:'delete',accountKey,id:rule.id});rule=null;}
        if(rule) {
          const current=(rule.entries??[]).find(entry=>entry.key===item.entry.key);
          if(!current||Number(current.target)<item.entry.target) state=await game.handle({operation:'set-entries',accountKey,id:rule.id,entries:[...(rule.entries??[]).filter(entry=>!/palaceColony$/.test(String(entry.key))),item.entry]});
          const live=state.rules.find(entry=>entry.id===rule.id);
          if(live&&!live.enabled&&!live.uncertain) {mine.add(rule.id);state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:true});}
        } else {
          const before=new Set(state.rules.map(entry=>entry.id));
          state=await game.handle({operation:'save',accountKey,rule:{kind:'building',autopilot:'satisfaction',cityId:item.cityId,procure:true,reserve:0,intervalMinutes:5,maxCycles:10000,telegram:false,entries:[item.entry]}});
          const created=state.rules.find(entry=>!before.has(entry.id));
          if(created) {mine.add(created.id);state=await game.handle({operation:'toggle',accountKey,id:created.id,enabled:true});}
        }
      } catch(error) {report.errors.push('מגורי מושל ב'+item.name+': '+error.message);}
    }
    // Every tavern serves the most wine (user decision, 2026-10-22), whatever the tavern switch says;
    // a tavern queue the user switched on in the city is left as it is.
    for(const city of cities.filter(city=>(city.buildings??[]).some(item=>item.building==='tavern'))) {
      const id=String(city.id);
      if(state.rules.some(rule=>rule.kind==='tavern'&&String(rule.cityId)===id&&!rule.deleted&&rule.enabled)) continue;
      try {
        const own=state.rules.find(rule=>rule.kind==='tavern'&&String(rule.cityId)===id&&!rule.deleted&&rule.autopilot==='satisfaction');
        // A tavern the game refused is not switched back on for two hours (user report, 2026-10-25: 283
        // refusals in Orakel2 as care re-enabled it every round).
        if(own) {if(!own.inFlight&&!own.uncertain&&!(/המשחק דחה/.test(own.status??'')&&now()-(own.lastFailureAt??0)<7200000)) state=await game.handle({operation:'toggle',accountKey,id:own.id,enabled:true});continue;}
        const before=new Set(state.rules.map(rule=>rule.id));
        state=await game.handle({operation:'save',accountKey,rule:{...configs.tavern(id),autopilot:'satisfaction'}});
        const created=state.rules.find(rule=>!before.has(rule.id));
        if(created) state=await game.handle({operation:'toggle',accountKey,id:created.id,enabled:true});
      } catch(error) {report.errors.push('בית מרזח ב'+name(id)+': '+error.message);}
    }
    // Leftovers are cleaned so nothing gets stuck (user decision, 2026-10-22): one-off routes whose result
    // stayed unknown for three hours and that no open supply claim still owns are removed (a load at sea
    // goes on; a needed shipment is planned anew), and a second enabled tavern queue in a city is stopped.
    // A stopped one-off route that still names its interrupted run is removed the same way (user report,
    // 2026-10-26: 78 of them piled up over nine days); the removal keeps the run's id, so it is never replayed.
    if(transport) try {
      const journal=(await chrome.storage.local.get('firefox-supply-claims-v1'))['firefox-supply-claims-v1']?.entries??[];
      const owned=new Set(journal.filter(entry=>['new','requested','accepted','intenting','intent','sent','unknown','in-transit'].includes(entry.state)).map(entry=>entry.routeId).filter(Boolean));
      for(const rule of ((await transport.handle({operation:'list',accountKey})).rules??[]).filter(rule=>rule.oneOff&&!rule.enabled&&(rule.inFlight?/^נעצר|נדרשת בדיקה/:/נדרשת בדיקה/).test(rule.status??'')&&now()-(rule.lastRunAt??rule.nextRunAt??0)>3*3600000&&!owned.has(rule.id))) {
        try {await transport.handle({operation:'delete',accountKey,id:rule.id});} catch { /* Next round. */ }
      }
    } catch(error) {report.errors.push('ניקוי מסלולים ישנים: '+error.message);}
    const seenTavern=new Set();
    for(const rule of state.rules.filter(rule=>rule.kind==='tavern'&&rule.enabled&&!rule.deleted&&!rule.inFlight).sort((a,b)=>Number(!!a.autopilot)-Number(!!b.autopilot))) {
      const id=String(rule.cityId);
      if(!seenTavern.has(id)) {seenTavern.add(id);continue;}
      try {state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:false});} catch { /* Next round. */ }
    }
    const target=config.target,war=(await chrome.storage.local.get('war-mode-v1'))['war-mode-v1']?.active===true;
    if(plan.handled&&war) report.errors.push('שיש: מצב מלחמה פעיל — השיש נשאר לבקשות המלחמה ונשלח אחריה');
    // With the marble export off, its routes still waiting are removed (user report, 2026-10-22: leftover
    // routes of 80,000–235,000 marble kept all of Orakel5's 212 ships busy). A load already at sea goes on.
    if(config.sendMarble!==true&&transport&&target?.playerName&&target?.cityName) {
      try {
        const leftover=((await transport.handle({operation:'list',accountKey})).rules??[]).filter(rule=>rule.oneOff&&!rule.war&&rule.resource==='marble'&&rule.externalTarget&&String(rule.externalTarget.playerName)===target.playerName&&String(rule.externalTarget.cityName)===target.cityName&&!rule.inFlight);
        for(const rule of leftover) {try {await transport.handle({operation:'delete',accountKey,id:rule.id});report.shipped.push({resource:'marble',from:rule.originCityId,quantity:0,removed:true});} catch { /* Removed next round. */ }}
      } catch(error) {report.errors.push('ניקוי משלוחי שיש ישנים: '+error.message);}
    }
    if(config.sendMarble===true&&plan.handled&&!war&&transport&&target?.playerName&&target?.cityName) {
      const ours=rule=>rule.oneOff&&!rule.war&&rule.resource==='marble'&&rule.externalTarget&&String(rule.externalTarget.playerName)===target.playerName&&String(rule.externalTarget.cityName)===target.cityName;
      let routes=(await transport.handle({operation:'list',accountKey})).rules??[];
      // Finished marble shipments are history (they would fill the 100-route limit).
      for(const rule of routes.filter(rule=>ours(rule)&&!rule.enabled&&!rule.inFlight)) {
        if(/^נעצר|^נדרשת בדיקה/.test(rule.status??'')) report.errors.push('שיש מ'+name(rule.originCityId)+': '+rule.status);
        try {await transport.handle({operation:'delete',accountKey,id:rule.id});} catch { /* Removed next round. */ }
      }
      routes=(await transport.handle({operation:'list',accountKey})).rules??[];
      for(const item of plan.marble.filter(item=>fresh('marble:'+item.cityId))) {
        // Any marble shipment of the city still going (also the account's balancing or export) goes first.
        if(routes.some(rule=>rule.resource==='marble'&&String(rule.originCityId)===item.cityId&&(rule.enabled||rule.inFlight))) continue;
        try {routes=await oneOff(accountKey,routes,{originCityId:item.cityId,destinationCityId:'0',resource:'marble',quantity:item.quantity,externalTarget:{...target}});sent['marble:'+item.cityId]=now();report.shipped.push({resource:'marble',from:item.cityId,quantity:item.quantity});}
        catch(error) {report.errors.push('שיש מ'+name(item.cityId)+': '+error.message);}
      }
    }
    await save();
    return state;
  }
  const settings=async()=>({...DEFAULTS,...((await chrome.storage.local.get(KEY))[KEY]??{})});
  async function tick(force=false) {
    if(running) {if(force) pending=true;return;}
    if(!force&&now()-lastRun<EVERY) return;
    running=true;lastRun=now();
    try {
      const full={...FULL_DEFAULTS,...((await chrome.storage.local.get(FULL))[FULL]??{})};
      if(full.enabled&&!full.appliedAt) {
        full.appliedAt=now();
        await chrome.storage.local.set({[FULL]:full,[KEY]:{...DEFAULTS},'uniform-mode-v1':'run','tavern-auto-v1':{enabled:true,accounts:'all'}});
      }
      // Firefox: attack alerts are switched on once (user decision, 2026-10-22: the only defence that warns in time).
      if(!MAIN()&&!(await chrome.storage.local.get('attacks-on-v1'))['attacks-on-v1']) {
        const stored=(await chrome.storage.local.get(KEY))[KEY]??{};
        await chrome.storage.local.set({[KEY]:{...DEFAULTS,...stored,attacks:true},'attacks-on-v1':now()});
      }
      const on=await settings();
      full.features={...FEATURES,...(full.features??{})};
      const applied={...FEATURES,...(full.appliedFeatures??{})},changed=Object.keys(FEATURES).filter(key=>full.features[key]!==applied[key]);
      const known={target:null};
      if(full.enabled&&transport) try {known.target=(await transport.handle({operation:'overview'})).accounts.map(item=>item.policy?.externalTarget).find(Boolean)??null;} catch { /* No policies yet. */ }
      const tavern=(await chrome.storage.local.get("tavern-auto-v1"))["tavern-auto-v1"]??{enabled:false,accounts:[]};
      // Switched off in one account from its card (user decision, 2026-10-15): {kind:[accountKey]}.
      const off=(await chrome.storage.local.get(OFF))[OFF]??{};const isOff=(kind,accountKey)=>Array.isArray(off[kind])&&off[kind].includes(accountKey);
      const status={at:now(),kinds:{}},note=(kind,account,entry)=>{(status.kinds[kind]??={})[account]=entry;};
      // Firefox with the uniformity plan off still raises the warehouses of cities under 48,000 ('storage').
      const chosen=(await chrome.storage.local.get(UNIFORM_MODE))[UNIFORM_MODE],mode=chosen==='run'?'run':MAIN()?'off':'storage';
      const plans={at:now(),mode,accounts:{...((await chrome.storage.local.get(UNIFORM_PLAN))[UNIFORM_PLAN]?.accounts??{})}};
      const tabs=(await chrome.tabs.query({})).filter(tab=>GAME.test(tab.url??''));
      // Firefox: a hidden account gets no new automations (user decision, 2026-10-25); its settings stay.
      const hidden=new Set(MAIN()?[]:((await chrome.storage.local.get('hidden-accounts-v1'))['hidden-accounts-v1']??['Orakel8|42|il','Orelkaful8|42|il']));
      for(const tab of tabs) {
        const accountKey=await identify(tab).catch(()=>null);
        if(accountKey&&hidden.has(accountKey)) continue;
        if(!accountKey) {for(const kind of Object.keys(configs)) if(on[kind]) note(kind,tab.title??'לשונית',{rules:0,reason:'לשונית המשחק לא מזוהה (לא מחוברת או בטעינה)',action:true});continue;}
        const cities=(await chrome.storage.local.get('account-snapshot-'+accountKey))['account-snapshot-'+accountKey]?.snapshot?.cities;
        let state;try {state=await game.handle({operation:'list',accountKey});} catch(error) {for(const kind of Object.keys(configs)) if(on[kind]) note(kind,accountKey,{rules:0,reason:error.message});continue;}
        if(!MAIN()) try {state=await satisfaction(tab,accountKey,cities,state);} catch(error) {console.warn('[automation] satisfaction',accountKey,error.message);}
        if(!MAIN()) try {state=await care(accountKey,cities,state);} catch(error) {console.warn('[automation] satisfaction care',accountKey,error.message);}
        try {state=await uniform(accountKey,cities,state,isOff('building',accountKey)?'off':mode,plans);} catch(error) {console.warn('[automation] uniform',accountKey,error.message);}
        if(changed.length) try {state=await applyFeatures(accountKey,state,full,known,changed);} catch(error) {console.warn('[automation] switches',accountKey,error.message);}
        if(full.enabled) try {state=await autonomy(accountKey,cities,state,full,known,note,isOff);} catch(error) {note('full',accountKey,{rules:0,reason:error.message});console.warn('[automation] autonomy',accountKey,error.message);}
        for(const kind of Object.keys(configs)) {
          const mine=state.rules.filter(rule=>rule.autopilot===kind&&!rule.deleted);
          try {
            // Firefox: while satisfaction care runs, its wine (24 hours in every city) and the wine-only
            // balancing cover the cities; the older per-city wine refill would ship the same wine again.
            const careWine=kind==='wine'&&!MAIN()&&((await chrome.storage.local.get(CARE_KEY))[CARE_KEY]?.enabled??CARE_DEFAULTS.enabled);
            const enabled=!careWine&&!(MAIN()&&kind==='miracle')&&!isOff(kind,accountKey)&&(kind==="tavern"?tavern.enabled&&(tavern.accounts==="all"||tavern.accounts?.includes(accountKey)):on[kind]);
            if(!enabled) {
              for(const rule of mine.filter(rule=>rule.enabled&&!rule.inFlight)) await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:false});
              continue;
            }
            const targets=autopilotTargets(kind,cities,state.rules);
            if(!targets.length) note(kind,accountKey,{rules:0,reason:cities?.length?(kind==='tavern'?'אין טברנות זמינות או שקיים ניהול ידני בעיר':MISSING[kind]):'לא נקראו ערי החשבון עדיין',action:kind==='barbarians'&&!!cities?.length});
            for(const cityId of targets) {
              let rule=mine.find(item=>item.cityId===cityId);
              if(!rule) {
                const before=new Set(state.rules.map(item=>item.id));
                const saved=await game.handle({operation:'save',accountKey,rule:{...configs[kind](cityId),autopilot:kind}});
                rule=saved.rules.find(item=>!before.has(item.id));state=saved;
                if(rule) state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:true});
              } else if(!rule.enabled&&!rule.inFlight&&!rule.uncertain&&(rule.status==='מושבתת'||/^נשמרה/.test(rule.status??'')||TRANSIENT.test(rule.status??''))) {
                // Stopped by a passing read failure (a slow game, an extension update): back on by itself.
                // Switched off earlier (by this switch or by hand): the switch is the master.
                state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:true});
              }
            }
            // Barbarians: the switch's automations in the other cities of an island stop (their army stays home).
            if(kind==='barbarians'&&!MAIN()) for(const rule of mine.filter(rule=>rule.enabled&&!rule.inFlight&&!targets.some(id=>String(id)===String(rule.cityId)))) state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:false});
            if(targets.length) {
              const managed=state.rules.filter(rule=>rule.autopilot===kind&&!rule.deleted);
              const active=managed.filter(rule=>rule.enabled&&!rule.uncertain);
              const stopped=managed.find(rule=>!rule.enabled||rule.uncertain);
              note(kind,accountKey,{rules:active.length,...(!active.length&&stopped?{reason:stopped.status??'האוטומציה נשמרה אך אינה פעילה',action:true}:{})});
            }
          } catch(error) {note(kind,accountKey,{rules:0,reason:error.message});console.warn('[automation] autopilot',kind,accountKey,error.message);}
        }
      }
      if(changed.length) {const stored={...FULL_DEFAULTS,...((await chrome.storage.local.get(FULL))[FULL]??{})};await chrome.storage.local.set({[FULL]:{...stored,appliedFeatures:{...full.features}}});}
      await chrome.storage.local.set({[STATUS]:status,[UNIFORM_PLAN]:plans});
    } finally {running=false;if(pending) {pending=false;await tick(true);}}
  }
  // A switch flipped in the window: balancing / export / pirates follow it on this account.
  async function applyFeatures(accountKey,state,full,known,changed) {
    const name=accountKey.split('|')[0],f=full.features;
    if(transport&&(changed.includes('balance')||changed.includes('export'))) {
      const policy=(await transport.handle({operation:'list',accountKey}))?.policy;
      if(policy) {
        const target=policy.externalTarget??known.target,mayExport=!!target&&String(target.playerName)!==name&&!full.growOnly.includes(name);
        const exportEnabled=!MAIN()&&(changed.includes('export')?f.export&&mayExport:policy.exportEnabled===true);
        const balanceEnabled=changed.includes('balance')?f.balance:policy.balanceEnabled!==false;
        await transport.handle({operation:'configure-policy',accountKey,policy:{balanceEnabled,exportEnabled,...(exportEnabled&&target?{externalTarget:target}:{})}});
      }
    }
    const offHere=Array.isArray(((await chrome.storage.local.get(OFF))[OFF]??{}).pirates)&&((await chrome.storage.local.get(OFF))[OFF].pirates.includes(accountKey));
    // In Firefox the runtime shows only the mission-1 raids in the capital (user decision, 2026-10-28), so the
    // switch turns only those on and off there.
    if(changed.includes('pirates')&&!(f.pirates&&offHere)) for(const rule of state.rules.filter(rule=>rule.kind==='pirates'&&!rule.deleted&&!rule.inFlight&&!rule.uncertain&&rule.enabled!==f.pirates))
      state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:f.pirates});
    return state;
  }
  async function autonomy(accountKey,cities,state,full,known,note,isOff=()=>false) {
    const name=accountKey.split('|')[0],done=[],f=full.features;
    if(transport&&f.balance) {
      const view=await transport.handle({operation:'list',accountKey});
      if(!view?.policy) {
        const target=known.target,isMain=!!target&&String(target.playerName)===name;
        const exportEnabled=!MAIN()&&f.export&&!!target&&!isMain&&!full.growOnly.includes(name);
        await transport.handle({operation:'configure-policy',accountKey,policy:{balanceEnabled:true,exportEnabled,reviewMode:'auto',...(exportEnabled?{externalTarget:target}:{})}});
        done.push(exportEnabled?'איזון וייצוא לראשי':'איזון בין ערי החשבון');
        if(exportEnabled) (full.exportSet??={})[accountKey]=true;
      } else if(!MAIN()&&f.export&&known.target&&!view.policy.exportEnabled&&!view.policy.externalTarget&&!(full.exportSet??{})[accountKey]&&String(known.target.playerName)!==name&&!full.growOnly.includes(name)) {
        // The main target became known after this policy was set up: export is switched on once.
        (full.exportSet??={})[accountKey]=true;
        await transport.handle({operation:'configure-policy',accountKey,policy:{balanceEnabled:view.policy.balanceEnabled!==false,exportEnabled:true,externalTarget:known.target}});
        done.push('ייצוא לחשבון הראשי');
      }
      await chrome.storage.local.set({[FULL]:full});
    }
    // A pirate automation saved but never switched on (the switch-on was refused, e.g. for a missing
    // Telegram connection in the main edition) is switched on by the pirates switch.
    const saved=f.pirates&&!isOff('pirates',accountKey)&&state.rules.find(rule=>rule.kind==='pirates'&&!rule.deleted&&!rule.enabled&&!rule.inFlight&&!rule.uncertain&&/^נשמרה/.test(rule.status??''));
    // Firefox needs the pirate bot first: until it is set the raid waits saved, and the pass goes on.
    if(saved&&!state.rules.some(rule=>rule.kind==='pirates'&&!rule.deleted&&rule.enabled)) try {state=await game.handle({operation:'toggle',accountKey,id:saved.id,enabled:true});done.push('פשיטות פיראטים ברצף');} catch { /* Switched on once the pirate bot is set. */ }
    if(MAIN()&&f.pirates&&!isOff('pirates',accountKey)&&cities?.length&&!state.rules.some(rule=>rule.kind==='pirates'&&!rule.deleted)) {
      const level=city=>Math.max(0,...(city.buildings??[]).filter(item=>item?.building==='pirateFortress').map(item=>Number(item.level)||0));
      const best=[...cities].sort((a,b)=>level(b)-level(a))[0],mission=best?pirateMission(level(best)):null;
      if(mission) {
        const before=new Set(state.rules.map(item=>item.id));
        state=await game.handle({operation:'save',accountKey,rule:{kind:'pirates',cityId:String(best.id),entries:[],intervalMinutes:2,maxCycles:10000,reserve:0,pirateMission:mission,pirateStrategy:'auto',continuous:true,convertPoints:false,convertAmount:0,telegram:true,autopilot:'pirates'}});
        const rule=state.rules.find(item=>!before.has(item.id));
        if(rule) state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:true});
        done.push('פשיטות פיראטים ברצף (משימה '+mission+')');
      }
    }
    // Firefox (user decision, 2026-10-28): only mission 1, back to back, in the capital — the city with the palace —
    // and only when it has a pirate fortress; never another city or another mission.
    if(!MAIN()&&f.pirates&&!isOff('pirates',accountKey)&&cities?.length&&!state.rules.some(rule=>rule.kind==='pirates'&&!rule.deleted)) {
      const capital=cities.find(city=>(city.buildings??[]).some(item=>item?.building==='palace'));
      const fortress=capital?Math.max(0,...(capital.buildings??[]).filter(item=>item?.building==='pirateFortress').map(item=>Number(item.level)||0)):0;
      if(fortress>=1) {
        const before=new Set(state.rules.map(item=>item.id));
        state=await game.handle({operation:'save',accountKey,rule:{kind:'pirates',cityId:String(capital.id),entries:[],intervalMinutes:2,maxCycles:10000,reserve:0,pirateMission:1,pirateStrategy:'fixed',continuous:true,convertPoints:false,convertAmount:0,telegram:true,autopilot:'pirates'}});
        const rule=state.rules.find(item=>!before.has(item.id));
        if(rule) try {state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:true});done.push('פשיטות פיראטים ברצף (משימה 1, עיר הבירה)');} catch { done.push('פשיטת פיראטים נשמרה — ממתינה לבוט טלגרם לפיראטים'); }
      }
    }
    // Research on demand: one per account once a research blocks an attack or recruitment.
    const blocked=f.research!==false||state.rules.some(rule=>rule.enabled&&!rule.deleted&&/נדרש מחקר/.test(rule.status??''));
    if(!MAIN()&&cities?.length&&blocked&&!isOff('research',accountKey)&&!state.rules.some(rule=>rule.kind==='research'&&rule.autopilot==='research'&&!rule.deleted)) {
      const before=new Set(state.rules.map(item=>item.id));
      state=await game.handle({operation:'save',accountKey,rule:{kind:'research',cityId:String(cities[0].id),entries:[{key:'auto',target:1,label:'מחקר לפי הצורך'}],intervalMinutes:30,maxCycles:10000,reserve:0,autopilot:'research'}});
      const rule=state.rules.find(item=>!before.has(item.id));
      if(rule) state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:true});
      done.push('מחקר לפי הצורך');
    }
    note('full',accountKey,{rules:done.length,...(done.length?{action:false,set:done}:{})});
    return state;
  }
  async function uniform(accountKey,cities,state,mode,plans) {
    if(!cities?.length) return state;
    const user=MAIN()?((await chrome.storage.local.get(BUILD_TARGETS))[BUILD_TARGETS]??{global:{},cities:{}}):null;
    const plan=uniformPlan(cities,{user,mainGate:MAIN()}),mine=state.rules.filter(rule=>rule.autopilot==='uniform'&&!rule.deleted);
    // In Firefox an approved satisfaction upgrade holds the city's builder like a manual queue, except in storage
    // mode while it only waits: it may be waiting for more than the warehouse holds, so the warehouse goes first.
    const holds=rule=>!rule.autopilot||!MAIN()&&rule.autopilot==='satisfaction'&&(mode!=='storage'||rule.inFlight);
    const manual=new Set(state.rules.filter(rule=>rule.kind==='building'&&holds(rule)&&rule.enabled&&!rule.deleted).map(rule=>String(rule.cityId)));
    for(const city of plan.cities) {
      city.manual=manual.has(city.cityId);
      if(mode==='off') continue;
      const entries=mode==='storage'?storageEntries(city,cities.find(item=>String(item.id)===city.cityId)?.storageCapacity):city.entries;
      let rule=mine.find(item=>String(item.cityId)===city.cityId);
      // A building queue the user set up in the city wins; the two would compete for one builder.
      if(city.manual||!entries.length) {if(rule?.enabled&&!rule.inFlight) state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:false});continue;}
      try {
        if(!rule) {
          const before=new Set(state.rules.map(item=>item.id));
          state=await game.handle({operation:'save',accountKey,rule:uniformConfig(city.cityId,entries)});
          rule=state.rules.find(item=>!before.has(item.id));
        } else if(!rule.inFlight&&!sameEntries(rule.entries,entries)) state=await game.handle({operation:'set-entries',accountKey,id:rule.id,entries});
        if(rule&&!rule.enabled&&!rule.inFlight&&!rule.uncertain) state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:true});
      } catch(error) {city.error=error.message;}
    }
    if(mode==='off') for(const rule of mine.filter(rule=>rule.enabled&&!rule.inFlight)) state=await game.handle({operation:'toggle',accountKey,id:rule.id,enabled:false});
    const snapshot=(await chrome.storage.local.get('account-snapshot-'+accountKey))['account-snapshot-'+accountKey]?.snapshot;
    const number=value=>Number.isFinite(value)?value:null;
    plans.accounts[accountKey]={at:now(),fortressCityId:plan.fortressCityId,cities:plan.cities,gold:number(snapshot?.gold),netGold:number(snapshot?.goldProductionPerHour)};
    return state;
  }
  return {tick,settings,fullKey:FULL,key:KEY,statusKey:STATUS,uniformKey:UNIFORM_MODE,planKey:UNIFORM_PLAN};
}

// Battle reinforcement (user decision, 2026-10-14): during a running battle the agent reads the
// latest round every 16 minutes (a round is 15), counts the account's units of the chosen type on
// the field and in reserve, and fills what was lost back up to the user's number. The gap is split
// between the account's own cities by arrival time — a near city trains more and closes the gap
// first, a far one trains a little that arrives for a later round — and each city sends what it
// trained to the battle as soon as it is ready. Only inside the same account: never between the
// user's accounts. Missions: an own city (station), a player's city (pillage), an ally's city
// (defend). The game's report markup follows IkaEasy and the CR Converter engine
// (militaryAdvisorCombatList → militaryAdvisorReportView → militaryAdvisorDetailedReportView).
(() => {
const text=value=>String(value??'').replace(/<[^>]*>/g,' ').replace(/&nbsp;| /g,' ').replace(/\s+/g,' ').trim();
const int=value=>{const digits=String(value??'').replace(/[^\d]/g,'');return digits?Number(digits):null;};
const unitOf=className=>String(className??'').match(/(?:^|\D)(3\d\d|2\d\d)(?:\D|$)/)?.[1]??null;

// The battles listed in the military advisor: report links with their combat id.
function parseCombatList(html) {
  const battles=[],seen=new Set();
  for(const match of String(html??'').matchAll(/href="([^"]*combatId=(\d+)[^"]*)"/g)) {
    if(seen.has(match[2])) continue;seen.add(match[2]);
    const row=String(html).slice(Math.max(0,match.index-1500),match.index+500);
    battles.push({combatId:match[2],running:/\brunning\b/.test(row.split(/<tr\b/).at(-1)??row),href:match[1].replace(/&amp;/g,'&')});
  }
  return battles;
}
// One battle's report: still running (the round timer), where, and the link to its rounds.
function parseReport(html) {
  const source=String(html??'');
  const link=source.match(/combatRound=(\d+)(?:&amp;|&)detailedCombatId=(\d+)/)??source.match(/detailedCombatId=(\d+)(?:&amp;|&)combatRound=(\d+)/);
  const round=link?(link[0].startsWith('combatRound')?{round:Number(link[1]),detailedCombatId:link[2]}:{round:Number(link[2]),detailedCombatId:link[1]}):null;
  const place=text(source.match(/<h3 class="header"[^>]*>([\s\S]*?)<\/h3>/)?.[1]??'');
  return {running:/combatRoundTimer/.test(source),place,round,attacker:text(source.match(/class="attacker"[^>]*>([\s\S]*?)<\/div>/)?.[1]),defender:text(source.match(/class="defender"[^>]*>([\s\S]*?)<\/div>/)?.[1])};
}
// One round (the detailed report): round number, both sides' names, and per side and unit the
// units left on the field, lost this round and waiting in reserve.
function parseRound(html,DOMParserClass=globalThis.DOMParser) {
  const source=String(html??'');
  const counter=source.match(/(\d+)\s*\/\s*(\d+)\s*</);
  const result={round:counter?Number(counter[1]):null,total:counter?Number(counter[2]):null,attacker:'',defender:'',sides:{attacker:{},defender:{}}};
  if(!DOMParserClass||!/battlefield/.test(source)) return result;
  const doc=new DOMParserClass().parseFromString(source,'text/html');
  result.attacker=text(doc.querySelector('#attacker, .container_attacker')?.textContent);
  result.defender=text(doc.querySelector('#defender, .container_defender')?.textContent);
  for(const side of ['attacker','defender']) {
    const units=result.sides[side],field=doc.querySelector(side==='attacker'?'#fieldAttacker':'#fieldDefender');
    for(const slot of field?.querySelectorAll('div[id^="slot"]')??[]) {
      const unit=unitOf(slot.getAttribute('class'));if(!unit) continue;
      const number=slot.querySelector('div.number')??slot.nextElementSibling,value=text(number?.textContent);
      const left=int(value.match(/(\d[\d,.]*)/)?.[1]),lost=int(value.match(/\(\s*-\s*(\d[\d,.]*)\s*\)/)?.[1])??0;
      if(left===null) continue;
      units[unit]??={field:0,lost:0,reserve:0};units[unit].field+=left;units[unit].lost+=lost;
    }
    for(const item of doc.querySelectorAll(`ul[id^="${side}Page"] li`)) {
      const unit=unitOf(item.querySelector('div')?.getAttribute('class'));const count=int(text(item.textContent).match(/(\d[\d,.]*)/)?.[1]);
      if(!unit||count===null) continue;
      units[unit]??={field:0,lost:0,reserve:0};units[unit].reserve+=count;
    }
  }
  return result;
}
// Which side is the account: its player name in the side's header, else by the mission.
function ourSide(round,ownerName,mission) {
  const name=String(ownerName??'').trim();
  if(name&&round.attacker.includes(name)&&!round.defender.includes(name)) return 'attacker';
  if(name&&round.defender.includes(name)&&!round.attacker.includes(name)) return 'defender';
  return mission==='pillage'?'attacker':'defender';
}
// Split the gap by arrival: chunk by chunk, each to the city whose units would arrive first
// (its queue + training time + sailing time). capacity caps a city (citizens and resources).
function allocate(gap,cities,{chunk=10,now=0}={}) {
  const state=cities.filter(city=>city.unitSeconds>0&&(city.capacity??Infinity)>0).map(city=>({...city,ready:now+(city.queueSeconds??0)*1000,amount:0}));
  let left=Math.max(0,Math.floor(gap));
  while(left>0&&state.length) {
    const open=state.filter(city=>city.amount<(city.capacity??Infinity));if(!open.length) break;
    const take=city=>Math.min(chunk,left,(city.capacity??Infinity)-city.amount);
    const arrival=city=>city.ready+take(city)*city.unitSeconds*1000+(city.travelSeconds??0)*1000;
    const best=open.sort((a,b)=>arrival(a)-arrival(b))[0],amount=take(best);
    best.ready+=amount*best.unitSeconds*1000;best.amount+=amount;best.arrival=best.ready+(best.travelSeconds??0)*1000;left-=amount;
  }
  return {plan:state.filter(city=>city.amount>0).map(city=>({cityId:city.cityId,amount:city.amount,arrival:city.arrival})),unplaced:left};
}
// Sailing time to the battle (Ikabot attackBarbarians.calc_travel_time): another island takes
// 1200 s per unit of island distance; the same island 36000 / speed.
function travelSeconds(from,to,speed) {
  const dx=Number(from?.x)-Number(to?.x),dy=Number(from?.y)-Number(to?.y);
  if(Number.isFinite(dx)&&Number.isFinite(dy)&&(dx||dy)) return Math.ceil(1200*Math.hypot(dx,dy));
  return Math.ceil(36000/Math.max(1,Number(speed)||1));
}
// The game's own mission form (pillage / defend / station): every field it sends, so nothing is
// guessed; null when the page is not a mission form with army cargo fields.
function parseMissionForm(html,DOMParserClass=globalThis.DOMParser) {
  if(!DOMParserClass) return null;
  const doc=new DOMParserClass().parseFromString(String(html??''),'text/html');
  for(const form of doc.querySelectorAll('form')) {
    const fields={};
    for(const input of form.querySelectorAll('input[name],select[name]')) {
      const name=input.getAttribute('name');if(!name||['checkbox','radio','submit','button'].includes(input.getAttribute('type')??'')&&!input.hasAttribute('checked')) continue;
      fields[name]=input.getAttribute('value')??input.value??'';
    }
    if(fields.function&&Object.keys(fields).some(name=>/^cargo_army_\d+$/.test(name))) return fields;
  }
  return null;
}
globalThis.IkariamBattle={parseCombatList,parseReport,parseRound,ourSide,allocate,travelSeconds,parseMissionForm};
})();

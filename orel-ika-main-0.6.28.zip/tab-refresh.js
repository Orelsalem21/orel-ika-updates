// Optional periodic reload of the connected game tab at a random interval
// (default 3.5–4.5 hours). A reload is postponed while any automation has an
// operation in flight, so a refresh can never interrupt a submitted action.
const KEY='tab-refresh-v1';
// Reloading a game tab whose address is the lobby login link (action=loginAvatar…&token=…)
// resends a used one-time code and logs the account out. Load the game's own page instead:
// the session cookie keeps the account signed in.
export async function reloadGameTab(chrome,tab) {
  let url=null;try {url=new URL(tab.url??'');} catch { /* Unknown address: plain reload. */ }
  if(url && /^s\d+-\w+\.ikariam\.gameforge\.com$/.test(url.hostname)) return chrome.tabs.update(tab.id,{url:url.origin+'/index.php'});
  return chrome.tabs.reload(tab.id);
}

export function createTabRefresh(chrome,findTab,{now=()=>Date.now(),random=Math.random}={}) {
  let queue=Promise.resolve();
  const serial=job=>{const next=queue.then(job,job);queue=next.catch(()=>{});return next;};
  const read=async()=>({enabled:false,minMinutes:210,maxMinutes:270,nextAt:null,lastAt:null,log:[],...((await chrome.storage.local.get(KEY))[KEY]??{})});
  const write=state=>chrome.storage.local.set({[KEY]:state});
  const schedule=state=>{state.nextAt=now()+Math.round((state.minMinutes+random()*(state.maxMinutes-state.minMinutes))*60000);};
  const note=(state,message)=>{state.log=[{time:now(),message},...state.log].slice(0,20);};
  async function busy() {
    const stored=await chrome.storage.local.get(['game-automations-v1','transport-automation-v1']);
    return (stored['game-automations-v1']?.rules??[]).some(rule=>rule.inFlight&&!rule.uncertain)||(stored['transport-automation-v1']?.rules??[]).some(rule=>rule.inFlight);
  }
  async function tick() {
    const state=await read();
    if(!state.enabled) return;
    if(!state.nextAt) {schedule(state);await write(state);return;}
    if(now()<state.nextAt) return;
    const tab=await findTab();
    if(!tab?.id) {state.nextAt=now()+5*60000;note(state,'אין לשונית משחק פתוחה; ניסיון נוסף בעוד 5 דקות');await write(state);return;}
    if(await busy()) {state.nextAt=now()+2*60000;note(state,'פעולת אוטומציה בביצוע; הרענון נדחה בשתי דקות');await write(state);return;}
    try {await reloadGameTab(chrome,tab);state.lastAt=now();note(state,'לשונית המשחק רועננה');}
    catch {note(state,'רענון הלשונית נכשל');}
    schedule(state);await write(state);
  }
  async function handle(command) {
    const state=await read();
    if(command?.operation==='refresh-all') {
      if(await busy()) return {...state,deferred:true,refreshedCount:0};
      if(state.managementLastAt && now()-state.managementLastAt<240000) return {...state,deferred:true,refreshedCount:0};
      const tabs=(await chrome.tabs.query({})).filter(tab=>/^https:\/\/s\d+-\w+\.ikariam\.gameforge\.com\//.test(tab.url??''));
      let refreshedCount=0,failedCount=0;
      for(const tab of tabs) {
        if(await busy()) return {...state,deferred:true,refreshedCount,failedCount};
        try {await reloadGameTab(chrome,tab);refreshedCount++;} catch {failedCount++;}
      }
      state.managementLastAt=now();note(state,'רענון מסונכרן: '+refreshedCount+' לשוניות חשבון רועננו'+(failedCount?' · '+failedCount+' נכשלו':''));await write(state);
      return {...state,deferred:false,refreshedCount,failedCount};
    } else if(command?.operation==='configure') {
      const min=command.minMinutes,max=command.maxMinutes;
      if(!Number.isSafeInteger(min)||!Number.isSafeInteger(max)||min<30||max>1440||min>max) throw new Error('טווח הרענון חייב להיות בין 30 ל־1440 דקות, והמינימום לא גדול מהמקסימום');
      Object.assign(state,{enabled:command.enabled===true,minMinutes:min,maxMinutes:max});
      if(state.enabled) schedule(state);else state.nextAt=null;
      note(state,state.enabled?'רענון תקופתי הופעל':'רענון תקופתי הושבת');
      await write(state);
    } else if(command?.operation!=='get') throw new Error('פעולת רענון אינה נתמכת');
    return state;
  }
  return {tick:()=>serial(tick),handle:command=>serial(()=>handle(command))};
}

(() => {
const resourceKeys=['wood','wine','marble','crystal','sulfur'];
const N=value=>value==null||value===''?null:Number.isFinite(Number(value))?Number(value):null;
function commands(text) {
  const match=String(text).match(/ajax.Responder, (\[\[[\S\s]*?\]\])\);/);
  let value;try {value=JSON.parse(String(text).trim().startsWith('[')?text:match?.[1]??'null');} catch {throw new Error('תגובת המשחק אינה תואמת');}
  if(!Array.isArray(value)) throw new Error('תגובת המשחק אינה תואמת');return value;
}
function template(text) {
  return Object.assign(Object.create(null),...commands(text).filter(command=>command[0]==='updateTemplateData' && !Array.isArray(command[1])).map(command=>command[1]));
}
const html=text=>globalThis.IkariamReadInsights.viewHtml(text);
const doc=text=>new DOMParser().parseFromString(html(text),'text/html');
// Ikabot attackBarbarians.get_units: the army part of the cityMilitary view (before the fleet),
// unit ids from the army icons and amounts from the table cells in order ("-" is 0). A city
// with no army is simply zero troops, not an error, so recruitment can fill the preset.
function armyCounts(text) {
  let view=null;
  try {const data=JSON.parse(String(text).trim().startsWith('[')?String(text):'null');view=data?.[1]?.[1]?.[1];} catch { /* Not an ajax answer. */ }
  if(typeof view!=='string') view=html(text);
  const army=String(view).split('<div class="fleet')[0];
  const ids=[...army.matchAll(/<div class="army (.*?)">\s*<div class="tooltip">(.*?)<\/div>/g)].map(match=>match[1].trim());
  const amounts=[...army.matchAll(/<td>(.*?)\s*<\/td>/g)].map(match=>match[1]);
  if(ids.length&&amounts.length>=ids.length) {
    const counts={};
    ids.forEach((id,index)=>{const unit=id.replace(/^s/,'');const amount=Number(String(amounts[index]).replace(/<[^>]*>/g,'').replace(/[,.\s]/g,'').replace('-','0'));if(/^\d+$/.test(unit)&&Number.isSafeInteger(amount)&&!(unit in counts)) counts[unit]=amount;});
    if(Object.keys(counts).length) return counts;
  }
  // No unit icon at all on a readable military page: the city has no army.
  if(!/class="army /.test(army)&&/<table|tabUnits/.test(army)) return {};
  return armyCountsByTable(text);
}
function armyCountsByTable(text) {
  const result={},document=doc(text);
  const number=cell=>{
    if(!cell)return null;
    const clone=cell.cloneNode(true);clone.querySelectorAll('.tooltip,script,style').forEach(node=>node.remove());
    const value=clone.textContent.trim();return value==='-'?0:globalThis.IkariamReadInsights.numeric(value);
  };
  for(const icon of document.querySelectorAll('div.army')) {
    const id=String(icon.className).match(/(?:^|\s)s(\d+)(?:\s|$)/)?.[1];if(!id)continue;
    const cell=icon.closest('td'),row=cell?.closest('tr');if(!row)continue;
    const cells=Array.from(row.children).filter(node=>['TD','TH'].includes(node.tagName)),index=cells.indexOf(cell);
    let quantity=number(cells[index+1]);
    if(quantity===null) {
      const next=row.nextElementSibling,values=next?Array.from(next.children).filter(node=>['TD','TH'].includes(node.tagName)):[];
      quantity=number(values[index]);
    }
    // The same unit can appear twice (troops and the training queue): the first count is the
    // city's. An unreadable cell is skipped; only a page with no readable unit at all fails.
    if(!Number.isSafeInteger(quantity)||quantity<0 || id in result) continue;
    result[id]=quantity;
  }
  if(!Object.keys(result).length) throw new Error('לא ניתן לאמת את כמות הכוחות לתקיפת ברברים');return result;
}
function recipeData(text) {
  const data=template(text),units=[];
  for(const [key,value] of Object.entries(data)) {
    if(!/^js_barracksSlider\d+$/.test(key)) continue;
    const raw=typeof value?.slider?.control_data==='string'?JSON.parse(value.slider.control_data):value?.slider?.control_data;
    if(!raw || !/^\d+$/.test(String(raw.unit_type_id)) || !raw.costs || !['wood','citizens'].some(key=>key in raw.costs)) throw new Error('נתוני עלות יחידה אינם תואמים');
    const index=key.match(/\d+$/)[0],costs={};
    for(const resource of [...resourceKeys,'citizens']) {
      if(raw.costs[resource]!==undefined) {const cost=N(raw.costs[resource]);if(cost===null||cost<0) throw new Error('עלות גיוס חסרה');costs[resource]=cost;}
    }
    if(raw.costs.glass!==undefined) costs.crystal=N(raw.costs.glass);
    if(!('citizens' in costs)) throw new Error('עלות האזרחים אינה זמינה');
    const problem=String(data['js_barracksProblemTextfield'+index]?.text??'').trim(),line=data['js_barracksNoSliderLine'+index]?.class;
    const locked=/\binvisible\b/.test(data['js_barracksBuyTextfieldContainer'+index]?.class??'') || !!problem || !!line&&!/\binvisible\b/.test(line);
    units.push({id:String(raw.unit_type_id),key:String(raw.unit_type_id),label:String(raw.local_name??raw.identifier),costs,locked,reason:problem});
  }
  if(!units.length) throw new Error('לא ניתן לקרוא את רשימת היחידות ועלויות הגיוס');return units;
}
function workshopData(text,tab) {
  const data=template(text);
  if(!data.completeData || typeof data.completeData!=='object') throw new Error('נתוני בית המלאכה חסרים');
  const entries=[];
  for(const [id,upgrades] of Object.entries(data.completeData)) for(const [upgradeType,upgrade] of Object.entries(upgrades)) {
    if(!/^\d+$/.test(id)||!/^[\w-]+$/.test(upgradeType)) continue;
    const level=N(upgrade.currentLevel?.upgradeLevel),next=N(upgrade.nextLevel?.upgradeLevel);
    if(level===null) continue;
    entries.push({key:tab+':'+id+':'+upgradeType,id,upgradeType,tab,level,next,label:String(data.unitDetails?.[id]?.unitName??id)+' · '+String(upgrade.upgradeTypeDesc??upgradeType),gold:globalThis.IkariamReadInsights.numeric(upgrade.nextLevel.goldCosts),crystal:globalThis.IkariamReadInsights.numeric(upgrade.nextLevel.crystalCosts)});
  }
  return {entries,busy:!!data.inProgress || !!data.buildingInProgress,data};
}
function researchData(text) {
  const data=template(text),entries=[];
  for(const [key,value] of Object.entries(data)) {
    const match=key.match(/^js_researchAdvisorChangeResearchType(\d+)$/);if(!match||typeof value?.ajaxrequest!=='string') continue;
    const params=new URLSearchParams(value.ajaxrequest.replace(/^.*?\?/,''));
    const id=params.get('type')??value.ajaxrequest.split('=').pop();
    if(!/^[\w-]+$/.test(id??'')) continue;
    const rawLabel=data['js_researchAdvisorNextResearchName'+match[1]];
    const label=typeof rawLabel==='string'?rawLabel:rawLabel?.text;
    // A finished branch has no next research name; skip it instead of failing the whole read.
    if(!label) continue;
    entries.push({key:id,label:String(label),level:0,next:1});
  }
  if(!entries.length) throw new Error('אפשרויות המחקר לא פוענחו');return entries;
}
const presets=[
 {min:1,max:9,units:{302:90,304:21},loot:{302:1}},
 {min:10,max:19,units:{302:60,304:35,305:12,308:50},loot:{305:12,308:50}},
 {min:20,max:29,units:{302:60,304:70,305:12,307:12,308:100,309:30,310:5},loot:{305:12,308:100}},
 {min:30,max:39,units:{302:300,304:147,305:24,307:18,308:300,310:5,311:10},loot:{305:24,308:150}},
];
function createActions(bridge) {
 const extras=globalThis.IkariamGameAutomationExtras?.createExtras(bridge,{commands,template,html,doc,armyCounts});
 const isExtra=kind=>!!extras && globalThis.IkariamGameAutomationExtras.KINDS.includes(kind);
 async function context(rule) {
  const initial=await bridge.resolveCurrentPage();
  if(!initial.found || [initial.ownerName,initial.mundo,initial.servidor].join('|')!==rule.accountKey) throw new Error('החשבון השתנה; האוטומציה נעצרה');
  let token=null,count=0,submitted=false,lastPlan=null;
  const mainBuildGate=()=>{try{return /\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name??'');}catch{return false;}};
  async function reducersComplete() {
    if(!mainBuildGate()) return true;
    const key='account-snapshot-'+rule.accountKey,entry=(await chrome.storage.local.get(key))[key];
    if(!entry?.snapshot?.cities?.length||!Number.isFinite(entry.at)||Date.now()-entry.at>600000) return false;
    const cities=entry.snapshot.cities.map(item=>String(item.id)===String(rule.cityId)?{...item,buildings:city.position}:item);
    return cities.some(item=>String(item.id)===String(rule.cityId))&&globalThis.IkariamBuildForecast?.reducersReady(cities)===true;
  }

  async function request(params,mutation=false,{allowRejected=false,postRead=false,constructionBuilding=null}={}) {
    // Captured Opera request: opening piracyRaid is a POST read, not a raid action.
    const raidRead=postRead&&!mutation&&params.view==='piracyRaid'&&!params.action&&(()=>{try{return /\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name??'');}catch{return false;}})();
    if(++count>60) throw new Error('מגבלת בקשות לבדיקה אחת');
    if(mutation&&rule.kind==='barbarians'&&progress?.mainBarbarianRound&&mainBuildGate()) {
      const live=((await chrome.storage.local.get('main-barbarian-rounds-v1'))['main-barbarian-rounds-v1']??{})[rule.accountKey];
      if(!live?.running||live.stopRequested||live.id!==progress.mainBarbarianRound.id||live.cities?.[live.index]?.ruleId!==rule.id) {
        const error=new Error('סבב הברברים אינו פעיל או נעצר; לא נשלחה פעולה');error.mutationSubmitted=false;throw error;
      }
    }
    if(mutation&&['UpgradeExistingBuilding','BuildNewBuilding'].includes(params.action)) {
      const kind=params.action==='UpgradeExistingBuilding'?city.position.find(item=>String(item.position)===String(params.position))?.building:constructionBuilding;
      // A building of the agent's own list for this city passes (user decision, 2026-10-29: that list leads).
      const marked=/\d/.test(String(city.position.find(item=>String(item.position)===String(params.position))?.inConstructionList??'')),queue=((await chrome.storage.local.get('main-build-queue-v1'))['main-build-queue-v1']??{})[String(rule.cityId)]??[];
      // ...and so does a level the game's own list holds (the agent starts it only when that list stands still).
      const listed=params.action==='UpgradeExistingBuilding'&&(marked||queue.some(row=>String(row.position)===String(params.position)&&row.building===kind));
      if(!['carpentering','architect'].includes(kind)&&!listed&&!await reducersComplete()) throw new Error('ממתין לנגרייה ואדריכל ברמה 50 בכל ערי החשבון; נדרשת סריקת חשבון עדכנית');
    }
    if(mutation) {
      const fields=Object.fromEntries(Object.entries(params).filter(([key])=>!['actionRequest','ajax','backgroundView','oldView','oldBackgroundView','templateView','currentCityId'].includes(key)).sort(([a],[b])=>a.localeCompare(b)));
      lastPlan={key:JSON.stringify(fields),fields,cityId:rule.cityId,cityName:bridge.decodeUnicodeEscape(city.name),kind:rule.kind,createdAt:Date.now(),entries:rule.entries};
      if(typeof chrome.storage.local.set==='function') await chrome.storage.local.set({['game-progress-'+rule.inFlight]:lastPlan});
      if(rule.reviewMode==='manual') {
        const key=JSON.stringify(fields);
        const error=new Error('הסריקה הושלמה — פעולה ממתינה לאישור שלך');
        error.mutationSubmitted=false;
        error.proposal=lastPlan;
        if(rule.skippedPlans?.includes(key)) {error.skipped=true;throw error;}
        if(rule.approval?.key!==key || Date.now()-rule.approval.approvedAt>180000) throw error;
      }
      const stored=(await chrome.storage.local.get('game-automations-v1'))['game-automations-v1'];
      if(!stored?.rules?.some(item=>item.id===rule.id&&item.accountKey===rule.accountKey&&item.enabled&&!item.deleted&&item.inFlight===rule.inFlight)) throw new Error('האוטומציה נעצרה לפני שליחת הפעולה');
      if(!token) throw new Error('לא נמצא טוקן פעולה');
      if(submitted) throw new Error('ניתן לבצע פעולה אחת בלבד בכל בדיקה');
      submitted=true;
    }
    await new Promise(resolve=>setTimeout(resolve,550));
    if(mutation) {
      const saved=(await chrome.storage.local.get('game-automations-v1'))['game-automations-v1'];
      if(!saved?.rules?.some(item=>item.id===rule.id&&item.enabled&&!item.deleted&&item.inFlight===rule.inFlight)) {submitted=false;throw new Error('האוטומציה נעצרה לפני השליחה');}
    }
    const options={credentials:'same-origin',redirect:'error',signal:AbortSignal.timeout(15000)};
    const query={...params,...(token?{actionRequest:token}:{})};
    // Upstream Session.post(url=...) and Session.post(params=...) both send
    // action parameters in the URL, with an empty form body.
    if(mutation||raidRead){options.method='POST';options.headers={'Content-Type':'application/x-www-form-urlencoded'};options.body='';}
    let response;
    try {response=await (globalThis.IkariamPageFetch??fetch)('/index.php?'+new URLSearchParams(query),options);} catch {const error=new Error(mutation?'תוצאת הפעולה אינה ידועה; יש לבדוק במשחק':'קריאת המשחק נכשלה');error.mutationSubmitted=submitted;throw error;}
    if(!response.ok) {const error=new Error('שרת המשחק דחה את הבקשה');error.mutationSubmitted=submitted;throw error;}
    const text=await response.text();
    let entries=[];try {entries=commands(text);} catch { /* City HTML may include a wrapper. */ }
    const next=entries.find(entry=>entry[0]==='updateGlobalData')?.[1]?.actionRequest??text.match(/actionRequest"?:\s*"([^"]+)"/)?.[1]??text.match(/name="actionRequest"\s+value="([^"]+)"/)?.[1];
    if(next) token=next;
    if(mutation) {
      if(text.includes('TXT_ERROR_WRONG_REQUEST_ID')) {const error=new Error('המשחק דחה טוקן פעולה שפג; תתבצע בדיקה מחדש');error.mutationSubmitted=false;throw error;}
      const feedback=entries.filter(entry=>entry[0]==='provideFeedback').flatMap(entry=>Array.isArray(entry[1])?entry[1]:[entry[1]]);
      if(!allowRejected && (feedback.some(item=>item?.type==='error'||item?.class==='error'||Number(item?.type)===11) || entries.some(entry=>entry[0]==='changeView'&&entry[1]?.[0]==='error'))) {
        const error=new Error('המשחק דחה את הפעולה; ההרצה נעצרה לבדיקה');error.mutationSubmitted=false;throw error;
      }
    }
    return text;
  }
  const base={cityId:rule.cityId,currentCityId:rule.cityId,backgroundView:'city',ajax:1};
  let city,stock,home;
  async function cityRead() {
    home=await request({view:'city',cityId:rule.cityId});
    const match=home.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/);
    if(!match) throw new Error('עיר המקור אינה ניתנת לקריאה');
    city=JSON.parse(match[1]);
    if(String(city.id)!==rule.cityId || bridge.decodeUnicodeEscape(city.ownerName)!==initial.ownerName) throw new Error('העיר אינה שייכת לחשבון המחובר');
    city.position=bridge.transformPositions(city.position);stock=bridge.parseAvailableResources(home);
    if(!stock) throw new Error('מלאי המשאבים אינו זמין');return city;
  }
  try {await cityRead();} catch(error) {try {await request({view:'city',cityId:initial.cityId});} catch {}throw error;}
  const building=type=>{const result=city.position.find(item=>item.building===type);if(!result) throw new Error('המבנה הנדרש אינו קיים בעיר: '+type);return result;};
  const view=(type,extra={})=>request({...base,view:type,position:building(type).position,...extra});
  const progress=structuredClone(rule.progress??{});
  const result=(status,message,extras={})=>({status,message,progress,...(submitted&&lastPlan?{executedPlan:lastPlan}:{}),...extras});
  const wait=message=>result('waiting',message);
  const changed=message=>result('changed',message);
  const ensure=condition=>{if(!condition){const error=new Error('הפעולה נשלחה אך לא ניתן לאמת את השינוי; יש לבדוק במשחק');error.mutationSubmitted=true;throw error;}};
  const transport=(await chrome.storage.local.get('transport-automation-v1'))['transport-automation-v1'];
  const policy=transport?.rules?.find(item=>item.accountKey===rule.accountKey&&item.policyMode&&item.enabled&&!item.deleted);
  // Morning-routine children recruit after balancing/export, below the 48,000 baseline.
  const reserve=Math.max(rule.reserve,policy&&rule.kind!=='building'&&!rule.morning&&!rule.comfort&&!rule.happinessSupport?48000:0);
  // While every ship is at sea the policy skips its full scan, so the last report ages; it is
  // trusted for six hours (only critical wine holds automations back, see below).
  const balancePending=!!policy && !rule.morning && (!policy.report || !Number.isFinite(policy.report.scannedAt) || Date.now()-policy.report.scannedAt>6*3600000 || !Array.isArray(policy.report.shortages) || (policy.report.wine?policy.report.wine.criticalCityIds.length>0:policy.report.shortages.some(shortage=>shortage.amount>0)));
  const rawHeader=async()=>{
    const data=commands(await request({view:'updateGlobalData',ajax:1}));const h=data[0]?.[1]?.headerData;
    if(!h?.currentResources || Number(h.relatedCity?.owncity)!==1 || h.relatedCity.id!=null&&String(h.relatedCity.id)!==rule.cityId) throw new Error('נתוני הכותרת אינם שייכים לעיר');return h;
  };
  return {initial,rule,base,request,cityRead,building,view,reducersComplete,progress,result,wait,changed,ensure,rawHeader,reserve,balancePending,policy,
    markExternalSubmitted:()=>{submitted=true;},
    get city(){return city;},get stock(){return stock;},get home(){return home;},get submitted(){return submitted;},
    restore:()=>request({view:'city',cityId:initial.cityId})};
 }
 async function catalog(rule) {
  let c;try {
    c=await context(rule);let entries=[];
    if(rule.kind==='building') entries=c.city.position.filter(item=>item.building!=='empty'&&!item.isMaxLevel).map(item=>({key:item.position+':'+item.building,position:item.position,label:item.building,level:item.level,next:item.level+1}));
    else if(rule.kind==='recruit') {
      if(c.city.position.some(item=>item.building==='barracks')) entries=recipeData(await c.view('barracks')).map(item=>({...item,level:0,next:1}));
      if(c.city.position.some(item=>item.building==='shipyard')) entries=entries.concat(recipeData(await c.view('shipyard')).map(item=>({...item,key:'ship:'+item.id,level:0,next:1})));
      if(!entries.length) throw new Error('אין מגורי חיילים או מספנה בעיר');
    } else if(rule.kind==='workshop') {
      for(const tab of ['tabUnits','tabShips']) entries.push(...workshopData(await c.view('workshop',{activeTab:tab,templateView:'workshop'}),tab).entries.filter(entry=>entry.next!==null&&entry.next>entry.level&&entry.next<=c.building('workshop').level));
    } else if(rule.kind==='research') entries=researchData(await c.request({...c.base,view:'researchAdvisor',templateView:'researchAdvisor',oldView:'updateGlobalData'}));
    else if(['tavern','experiment','miracle'].includes(rule.kind)) {const type={tavern:'tavern',experiment:'academy',miracle:'temple'}[rule.kind];c.building(type);}
    else if(isExtra(rule.kind)) entries=await extras.catalog(c);
    return {entries,cityName:bridge.decodeUnicodeEscape(c.city.name)};
  } catch(error) {error.mutationSubmitted=false;throw error;} finally {if(c) await c.restore();}
 }
 async function recruit(c,entries,ship=false) {
   const type=ship?'shipyard':'barracks',source=await c.view(type);
   if(/['"]buildProgress['"]\s*,\s*\d+/.test(html(source))) return c.wait('ממתינה לסיום הגיוס בעיר');
   const recipes=recipeData(source),header=await c.rawHeader(),citizens=N(header.currentResources.citizens);
   const normalized=entries.map(entry=>({...entry,key:entry.key.replace(/^ship:/,'')}));
   if(c.rule.kind==='barbarians') {
     const unavailable=normalized.find(entry=>!recipes.some(recipe=>recipe.id===entry.key&&!recipe.locked));
     if(unavailable) {
       const recipe=recipes.find(recipe=>recipe.id===unavailable.key);
       // Paused while the research or the barracks level is missing (user decision, 2026-10-28): no recruiting
       // and no reads every few minutes; checked again every six hours, so it resumes once the units unlock.
       return {...c.wait('הגיוס מושהה עד שייפתח '+(recipe?.label??unavailable.key)+': '+(recipe?.reason||'היחידה אינה זמינה במגורי החיילים; תנאי המחקר או רמת המבנה טרם אומתו')+' · נבדק שוב בעוד 6 שעות'),idle:true,delayMs:6*3600000};
     }
   }
   let trainingStock=c.stock;
   if(c.rule.kind==='barbarians'&&c.progress.mainBarbarianRound&&(()=>{try{return /\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name??'');}catch{return false;}})()) {
     const queues=(await chrome.storage.local.get('main-build-supply-queues-'+c.rule.accountKey))['main-build-supply-queues-'+c.rule.accountKey]?.cities??{};
     const depth=c.policy?.report?.supplyRound?.depth?.[c.rule.cityId]??1,buildReserve={};
     for(const item of (queues[c.rule.cityId]?.items??[]).slice(0,depth))for(const [key,amount] of Object.entries(item.costs??{}))buildReserve[key]=(buildReserve[key]??0)+amount;
     trainingStock=Object.fromEntries(Object.entries(c.stock).map(([key,amount])=>[key,Math.max(0,amount-(buildReserve[key]??0))]));
     const resources={};
     for(const entry of normalized) {const recipe=recipes.find(item=>item.id===String(entry.key));if(!recipe)continue;for(const key of resourceKeys){const cost=(recipe.costs[key]??0)*entry.target;if(cost>0)resources[key]=(resources[key]??0)+cost;}}
     for(const key of Object.keys(resources))resources[key]+=c.reserve+(buildReserve[key]??0);
     c.progress.mainRecruitNeed={at:Date.now(),resources,label:'גיוס לסבב ברברים'};
   }
   const orders=globalThis.IkariamAutomationRules.trainingPlan(normalized,recipes,trainingStock,citizens,c.reserve);
   if(!orders.length) return c.wait('ממתינה למשאבים ולאזרחים לגיוס');
   if(c.progress.mainBarbarianRound&&(()=>{try{return /\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name??'');}catch{return false;}})())c.progress.mainRecruitNeed=null;
   await c.request({...c.base,action:'CityScreen',function:ship?'buildShips':'buildUnits',position:c.building(type).position,templateView:type,...Object.fromEntries(orders.map(order=>[order.id,order.quantity]))},true);
   // Started when the barracks shows its training timer, or — when the timer's markup is not
   // recognised — when the city's free citizens dropped: training takes them at once.
   const after=await c.view(type);
   let started=/['"]buildProgress['"]\s*,\s*\d+/.test(html(after));
   if(!started&&citizens!==null) {const left=N((await c.rawHeader()).currentResources?.citizens);started=left!==null&&left<citizens;}
   c.ensure(started);
   return {...c.changed('הוזמן גיוס: '+orders.map(order=>order.label+' × '+order.quantity).join(' · ')),orders};
 }
 // Building uniformity (autopilot "uniform"): the entries are the planner's targets for the city.
 // Each run picks from the live city the most urgent entry not yet at its target — the
 // architect's office and the carpentry first (they lower every other cost), then the lowest
 // level — and upgrades it one level or builds it in a free plot. A blocked entry is skipped for a
 // while (never retried in a loop); nothing is ever demolished or lowered. Resources come only
 // from the account's own cities. The current quote (costs, build time, missing), the next entry
 // and the order are kept on the rule for the automations window.
 // Workers: when the upgrade lacks wood or the island's resource, more workers are assigned there
 // only while the account's net gold per hour (the game header, all cities together) stays at or
 // above zero — the gold per worker is measured from the game, never assumed; a change that turns
 // the balance negative is undone on the next run.
 const FIRST=['architect','carpentering'],resourceNames={wood:'עץ',wine:'יין',marble:'שיש',crystal:'קריסטל',sulfur:'גופרית'};
 const clock=at=>new Date(at).toLocaleTimeString('he-IL',{timeZone:'Asia/Jerusalem',hour:'2-digit',minute:'2-digit'});
 const netGold=header=>{const parts=['income','godGoldResult','badTaxAccountant','upkeep','scientistsUpkeep'].map(key=>N(header?.[key]));return parts.every(value=>value!==null)?parts.reduce((a,b)=>a+b,0):null;};
 const sliderValue=slider=>{for(const key of ['value','current_value','default_value']) if(N(slider?.[key])!==null) return N(slider[key]);return null;};
 function groundOffers(text) {
   const offers=[];
   for(const item of doc(text).querySelectorAll('li.building')) {
     // Ikabot splitBuildingBlocks: the id is the one on the building's own picture (buildingimg);
     // other links in the block (requirements, details) may name other buildings.
     const id=String(item.querySelector('.buildingimg')?.getAttribute('onclick')??'').match(/buildingId=(\d+)/)?.[1];if(!id) continue;
     const costs={};
     for(const node of item.querySelectorAll('.costs li, ul.resources li')) {
       const key=Array.from(node.classList).map(name=>name==='glass'?'crystal':name).find(name=>resourceKeys.includes(name));
       // The amount sits after a hidden label ("עץ: 185"); the title may carry it too.
       const copy=node.cloneNode(true);copy.querySelectorAll('.accesshint,.tooltip').forEach(hint=>hint.remove());
       const digits=[copy.textContent,node.getAttribute('title')??''].map(text=>String(text).match(/\d[\d.,\s ]*/)?.[0]).find(Boolean);
       const value=globalThis.IkariamReadInsights.numeric(digits??'');if(key&&Number.isFinite(value)) costs[key]=value;
     }
     // The building is the first class after "building" (Ikabot: <li class="building (\w+)…">).
     const name=String(item.className).split(/\s+/).filter(Boolean).find(value=>value!=='building');
     if(name) offers.push({building:name,id,costs});
   }
   return offers;
 }
 const workerViews={resource:{field:'rw',label:'עובדי עץ'},tradegood:{field:'tw',label:'עובדי משאב היוקרה'},academy:{label:'מדענים'}};
 const academyRequest=(c,value)=>({...c.base,action:'IslandScreen',function:'workerPlan',screen:'academy',position:c.building('academy').position,s:value,templateView:'academy'});
 const workerRequest=(c,islandId,key,value)=>({islandId,cityId:c.rule.cityId,type:key,screen:key,action:'IslandScreen',function:'workerPlan',[workerViews[key].field]:value,templateView:key,ajax:1});
 // One change at most: more workers for a missing resource, within a non-negative gold balance.
 // all=true (user decision, 2026-10-14): as many workers as possible in every city while the
 // account's net gold per hour stays at zero or above — not only for a missing resource.
 // mines (wine-only mode): the mine and sawmill workers go to the maximum whatever the gold;
 // scientists still only while the gold balance is positive.
 async function uniformWorkers(c,missing,all=false,{mines=false}={}) {
   const p=c.progress,islandId=String(c.city.islandId??'');
   if(!/^\d+$/.test(islandId)) return null;
   // The workers switch in the full-autonomy window.
   const features=(await chrome.storage.local.get('full-auto-v1'))['full-auto-v1']?.features??{};
   const offList=(await chrome.storage.local.get('autopilot-off-v1'))['autopilot-off-v1']?.workers;
   if(features.workers===false||Array.isArray(offList)&&offList.includes(c.rule.accountKey)) {p.workers={at:Date.now(),note:'ניהול הפועלים כבוי'+(features.workers===false?' במצב האוטונומי':' בחשבון הזה')};return null;}
   const rules=(await chrome.storage.local.get('game-automations-v1'))['game-automations-v1']?.rules??[];
   if(rules.some(item=>item.kind==='workers'&&item.enabled&&!item.deleted&&item.accountKey===c.rule.accountKey&&String(item.cityId)===String(c.rule.cityId))) {p.workers={at:Date.now(),note:'בעיר יש אוטומציית פועלים משלך — האחידות לא משנה אותה'};return null;}
   const header=await c.rawHeader(),net=netGold(header),citizens=N(header.currentResources?.citizens);
   const luxury=resourceKeys[Number(header.producedTradegood)];
   p.gold={at:Date.now(),net,gold:N(header.gold)};
   if(net===null) {p.workers={at:Date.now(),note:'מאזן הזהב אינו ידוע; הפועלים לא שונו'};return null;}
   if(net<=0&&!mines) {p.workers={at:Date.now(),note:'מאזן הזהב לשעה אינו חיובי; ההקצאה נשארת כפי שהיא'};return null;}
   for(const [key,resource] of [['resource','wood'],['tradegood',luxury]]) {
     if(!resource||!all&&!missing.some(([name])=>name===resource)) continue;
     const slider=template(await c.request({view:key,type:key,islandId,cityId:c.rule.cityId,backgroundView:'island',currentIslandId:islandId,ajax:1})).js_ResourceSlider?.slider;
     const max=N(slider?.max_value),current=sliderValue(slider);
     if(max===null||current===null||current>=max||!(citizens>0)) continue;
     const per=p.goldPerWorker>0?p.goldPerWorker:null;
     // Unknown gold per worker: a small first step measures it from the game.
     const add=mines?Math.min(max-current,citizens):Math.min(max-current,citizens,per?Math.floor(net/per):Math.min(10,citizens));
     if(add<=0) {p.workers={at:Date.now(),note:'הוספת '+workerViews[key].label+' תוריד את מאזן הזהב מתחת לאפס; ההקצאה נשארת'};continue;}
     await c.request(workerRequest(c,islandId,key,current+add),true);
     const after=netGold(await c.rawHeader());
     if(after!==null&&net-after>0) p.goldPerWorker=(net-after)/add;
     p.gold={at:Date.now(),net:after,gold:p.gold.gold};
     if(after!==null&&after<0&&!mines) p.workersRevert={key,value:current};
     p.workers={at:Date.now(),note:workerViews[key].label+': '+current+' → '+(current+add)+' מתוך '+max+(after!==null?' · מאזן זהב '+Math.round(after).toLocaleString('he-IL')+' לשעה':'')};
     return {...c.changed('הוקצו '+add+' '+workerViews[key].label+' לייצור '+resourceNames[resource]+(all?'':' לשדרוג')+(after!==null&&after<0?' — המאזן ירד מתחת לאפס, יבוטל בבדיקה הבאה':'')),cycle:false};
   }
   // Then scientists in the academy, with what the gold balance still allows (switch "מדענים").
   if(all&&net>0&&features.scientists!==false&&c.city.position.some(item=>item.building==='academy')&&citizens>0) {
     const slider=template(await c.view('academy')).js_AcademySlider?.slider;
     const max=N(slider?.max_value),current=sliderValue(slider);
     if(max!==null&&current!==null&&current<max) {
       const per=p.goldPerScientist>0?p.goldPerScientist:null;
       const add=Math.min(max-current,citizens,per?Math.floor(net/per):Math.min(5,citizens));
       if(add>0) {
         await c.request(academyRequest(c,current+add),true);
         const after=netGold(await c.rawHeader());
         if(after!==null&&net-after>0) p.goldPerScientist=(net-after)/add;
         p.gold={at:Date.now(),net:after,gold:p.gold.gold};
         if(after!==null&&after<0) p.workersRevert={key:'academy',value:current};
         p.workers={at:Date.now(),note:'מדענים: '+current+' → '+(current+add)+' מתוך '+max+(after!==null?' · מאזן זהב '+Math.round(after).toLocaleString('he-IL')+' לשעה':'')};
         return {...c.changed('הוקצו '+add+' מדענים באקדמיה'+(after!==null&&after<0?' — המאזן ירד מתחת לאפס, יבוטל בבדיקה הבאה':'')),cycle:false};
       }
     }
   }
   return null;
 }
 // scientistsOnly (wine-only mode): the mine workers stay at the maximum; only scientists go back.
 async function goldRecovery(c,{scientistsOnly=false}={}) {
   const p=c.progress,header=await c.rawHeader(),net=netGold(header);
   p.gold={at:Date.now(),net,gold:N(header.gold)};
   if(net===null||net>=0) return null;
   const islandId=String(c.city.islandId??''),deficit=-net,cityName=bridge.decodeUnicodeEscape(c.city.name);
   const steps=[];
   if(c.city.position.some(item=>item.building==='academy')) steps.push({key:'academy',per:p.goldPerScientist>0?p.goldPerScientist:6,
     read:async()=>sliderValue(template(await c.view('academy')).js_AcademySlider?.slider),set:value=>academyRequest(c,value)});
   if(!scientistsOnly&&/^\d+$/.test(islandId)) for(const key of ['tradegood','resource']) steps.push({key,per:p.goldPerWorker>0?p.goldPerWorker:3,
     read:async()=>sliderValue(template(await c.request({view:key,type:key,islandId,cityId:c.rule.cityId,backgroundView:'island',currentIslandId:islandId,ajax:1})).js_ResourceSlider?.slider),set:value=>workerRequest(c,islandId,key,value)});
   for(const step of steps) {
     const current=await step.read();if(!(current>0)) continue;
     const cut=Math.min(current,Math.ceil(deficit/step.per));
     await c.request(step.set(current-cut),true);
     const after=netGold(await c.rawHeader());p.gold={at:Date.now(),net:after,gold:p.gold.gold};
     p.workersMaxAt=Date.now();p.workersRevert=null;
     p.workers={at:Date.now(),note:'מאזן זהב שלילי ('+Math.round(net)+'): '+workerViews[step.key].label+' '+current+' → '+(current-cut)+(after!==null?' · מאזן עכשיו '+Math.round(after):'')};
     return {...c.changed('יציאה ממינוס זהב ב'+cityName+': הוחזרו '+cut+' '+workerViews[step.key].label+' לאזרחים'+(after!==null?' · מאזן לשעה '+Math.round(after).toLocaleString('he-IL'):'')),cycle:false};
   }
   p.workers={at:Date.now(),note:'מאזן זהב שלילי ('+Math.round(net)+') ואין בעיר מדענים או פועלים להחזיר'};
   return null;
 }
 // null when the city has the resources; otherwise the waiting (or skipping) result.
 async function uniformSupply(c,rule,key,label,costs) {
   const p=c.progress,missing=Object.entries(costs).filter(([resource,cost])=>c.stock[resource]<cost).map(([resource,cost])=>[resource,cost-c.stock[resource]]);
   if(p.quote) p.quote.missing=Object.fromEntries(missing);
   if(!missing.length) return null;
   p.need={at:Date.now(),label,resources:Object.fromEntries(Object.entries(costs).map(([resource,cost])=>[resource,Math.ceil(cost)]))};
   const skip=(minutes,message)=>{p.skip[key]=Date.now()+minutes*60000;p.need=null;return c.wait(message);};
   const unmet=(c.policy?.report?.unmetNeeds??[]).filter(item=>String(item.cityId)===String(rule.cityId)&&missing.some(([resource])=>resource===item.resource));
   const receipts=c.policy?(await chrome.storage.local.get('account-policy-receipts-'+c.policy.id))['account-policy-receipts-'+c.policy.id]??[]:[];
   const arriving=receipts.filter(item=>String(item.destinationCityId)===String(rule.cityId)&&missing.some(([resource])=>resource===item.resource)&&Number.isFinite(item.timing?.arrivalAt)&&item.timing.arrivalAt>Date.now());
   if(p.quote) p.quote.arriving=arriving.map(item=>({resource:item.resource,amount:item.amount,at:item.timing.arrivalAt}));
   // Supply the upgrade directly when account balancing is unavailable.
   // The existing transport adapter verifies ownership and accounts for cargo already in transit.
   if(!c.policy?.enabled) return procure({...c,reserve:Math.max(c.reserve,48000)},missing,label);
   // Supply from the account's other cities comes first; workers are added only when the whole
   // account lacks the resource (or no balancing policy can bring it) and nothing is on its way.
   if(!arriving.length&&(unmet.length||!c.policy)) {const workers=await uniformWorkers(c,missing.filter(([resource])=>!c.policy||unmet.some(item=>item.resource===resource)));if(workers) return workers;}
   if(unmet.length) return skip(60,'ממתין למשאבים: ל'+label+' חסר בכל החשבון '+unmet.map(item=>Number(item.amount).toLocaleString('he-IL')+' '+(resourceNames[item.resource]??item.resource)).join(', ')+'; עובר לשדרוג הבא');
   if(arriving.length) {const last=Math.max(...arriving.map(item=>item.timing.arrivalAt));return {...c.wait('ממתין למשאבים: אספקה ל'+label+' בדרך עד '+clock(last)),delayMs:Math.max(120000,last-Date.now()+60000)};}
   return c.wait('ממתין למשאבים: '+label+' — האיזון מביא אותם מערי החשבון');
 }
 // The agent's own build list (Opera, user decision 2026-10-28: like the game's list, without its limit), kept per
 // city in main-build-queue-v1 and filled from the game's sidebar (agent-build-queue.js): one row per level
 // {position, building, level}, in order. A row is done once that level is built or under construction.
 const QUEUE='main-build-queue-v1';
 async function agentQueue(c,rule) {
   if(!/\bmain\b/.test(globalThis.chrome?.runtime?.getManifest?.()?.version_name??'')) return [];
   const all=(await chrome.storage.local.get(QUEUE))[QUEUE]??{},rows=all[String(rule.cityId)]??[];
   const left=rows.filter(row=>{const at=c.city.position[row.position];return at&&at.building===row.building&&(Number(at.level)||0)+(at.isBusy?1:0)<row.level;});
   if(left.length!==rows.length) {const fresh=(await chrome.storage.local.get(QUEUE))[QUEUE]??{};await chrome.storage.local.set({[QUEUE]:{...fresh,[String(rule.cityId)]:left}});}
   return left;
 }
 // The plan with the list's targets: an entry of a listed building is lifted to the list's highest level; a
 // listed building the plan does not hold is added.
 function queueEntries(entries,rows,positions) {
   const top={};for(const row of rows) top[row.position]=Math.max(top[row.position]??0,row.level);
   const out=(entries??[]).map(entry=>{const want=String(entry.key).split(':').slice(1).join(':'),pos=Number(entry.position);
     return !String(entry.key).startsWith('new:')&&top[pos]!==undefined&&positions[pos]?.building===want?{...entry,target:Math.max(Number(entry.target)||0,top[pos])}:entry;});
   for(const [pos,target] of Object.entries(top)) {
     const at=positions[pos];
     if(at&&!out.some(entry=>!String(entry.key).startsWith('new:')&&Number(entry.position)===Number(pos))) out.push({key:pos+':'+at.building,position:Number(pos),target,label:bridge.decodeUnicodeEscape(at.name??at.building)});
   }
   return out;
 }
 // The 48-hour forecast of this city (see build-forecast.js): the game's Ikipedia cost table of
 // each planned building is read once a week per account, at most one new table per check.
 async function planForecast(c,rule,rankOf,townHall) {
   const F=globalThis.IkariamBuildForecast;if(!F) return;
   // v3: the v2 tables dropped the days of long build times (2026-10-28); v1 doubled every value. Both are read again.
   const p=c.progress,key='cost-tables-v3-'+rule.accountKey;
   const tables=(await chrome.storage.local.get(key))[key]??{};
   const plan=rule.entries.map(entry=>{const building=String(entry.key).split(':').slice(1).join(':'),build=String(entry.key).startsWith('new:');
     return {building,position:entry.position,target:entry.target,build,label:entry.label,rank:rankOf({building,build})};});
   const hints=p.quote?.building?{[p.quote.building]:p.quote.costs}:{};
   const run=()=>F.forecast({buildings:c.city.position,plan,tables,hints,townHall});
   let result=run();
   p.tableTried=Object.fromEntries(Object.entries(p.tableTried??{}).filter(([,at])=>Date.now()-at<6*3600000));
   const stale=Object.keys(tables).filter(name=>Date.now()-(tables[name].at??0)>F.TABLE_TTL_MS);
   const fetch=[...result.missingTables,...stale].find(name=>!p.tableTried[name]);
   if(fetch) {
     p.tableTried[fetch]=Date.now();
     const index=html(await c.request({view:'buildingDetail',buildingId:0,helpId:1,backgroundView:'city',currentCityId:rule.cityId,templateView:'ikipedia',ajax:1}));
     const link=index.match(new RegExp('button_building '+fetch+'"[^>]*?onclick="ajaxHandlerCall\\(\'\\?([^\']*)\''))?.[1]?.replace(/&amp;/g,'&');
     if(link) {
       const params=Object.fromEntries(new URLSearchParams(link));delete params.actionRequest;
       const source=html(await c.request({...params,backgroundView:'city',currentCityId:rule.cityId,templateView:'buildingDetail',ajax:1}));
       const table=F.parseCostTable(source);
       if(Object.keys(table.levels).length) {tables[fetch]={at:Date.now(),...table};await chrome.storage.local.set({[key]:tables});result=run();}
       else if(!p.tableDebug) p.tableDebug={at:Date.now(),building:fetch,snippet:source.replace(/actionRequest[^,&<]{0,80}/gi,'actionRequest=…').slice(0,3000)};
     } else if(!p.tableDebug) p.tableDebug={at:Date.now(),building:fetch,snippet:'no link · '+index.slice(0,1500)};
   }
   p.forecast={at:result.at,hours:result.hours,resources:result.resources,items:result.items.slice(0,15).map(item=>({building:item.building,level:item.level,list:item.list,costs:item.costs})),missingTables:result.missingTables};
   // The next step of this city for the building list's shipment log (user request, 2026-10-16):
   // what it needs, what the city holds now and what is missing.
   const first=result.items[0];
   p.step=first?{at:Date.now(),building:first.building,level:first.level,list:!!first.list,costs:first.costs,
     stock:Object.fromEntries(Object.keys(first.costs??{}).map(resource=>[resource,Math.floor(Number(c.stock?.[resource])||0)])),
     missing:Object.fromEntries(Object.entries(first.costs??{}).map(([resource,cost])=>[resource,Math.max(0,Math.ceil(cost-(Number(c.stock?.[resource])||0)))]).filter(([,value])=>value>0))}:null;
   // When each planned upgrade starts: after the active one, once the city holds its cost
   // (stock, own production per hour, shipments already on the way).
   const snapshot=(await chrome.storage.local.get('account-snapshot-'+rule.accountKey))['account-snapshot-'+rule.accountKey]?.snapshot;
   const production=snapshot?.cities?.find(city=>String(city.id)===String(rule.cityId))?.productionPerHour??{};
   const receipts=c.policy?(await chrome.storage.local.get('account-policy-receipts-'+c.policy.id))['account-policy-receipts-'+c.policy.id]??[]:[];
   const arrivals=receipts.filter(item=>String(item.destinationCityId)===String(rule.cityId)&&Number.isFinite(item.timing?.arrivalAt)&&item.timing.arrivalAt>Date.now()).map(item=>({resource:item.resource,amount:item.amount,at:item.timing.arrivalAt}));
   const busy=c.city.position.find(item=>item.isBusy),busyUntil=busy&&Number(busy.completed)>0?Number(busy.completed)*1000:null;
   p.schedule={at:Date.now(),busy:busy?{building:busy.building,level:busy.level+1,endAt:busyUntil}:null,
     items:F.schedule({items:result.items,now:Date.now(),busyUntil,stock:c.stock,production,arrivals}).slice(0,15).map(item=>({building:item.building,level:item.level,list:item.list,startAt:item.startAt,endAt:item.endAt,waits:item.waits}))};
 }
 // Meanwhile-upgrade: the first of the next entries (up to four looked at) whose cost the city
 // already holds, and which the game allows now. null when none.
 async function upgradeAffordable(c,list,waiting,cityName) {
   const p=c.progress;
   for(const item of list.slice(0,4)) {
     if(item.at.canUpgrade===false) continue;
     const view=globalThis.IkariamReadInsights.parseCityView(await c.request({...c.base,view:item.want,position:item.at.position}));
     const costs=view.costs;if(!Object.keys(costs).length||Object.entries(costs).some(([resource,cost])=>!(c.stock[resource]>=cost))) continue;
     const level=item.at.level,label=item.entry.label??item.want;
     await c.request({...c.base,action:'UpgradeExistingBuilding',position:item.at.position,level,activeTab:'tabSendTransporter',templateView:item.want},true);
     await c.cityRead();const after=c.city.position[item.at.position];c.ensure(after&&(after.isBusy||after.level>level));
     p.active={label:item.want,level,completedAt:Number.isFinite(Number(after.completed))?Number(after.completed)*1000:(view.durationMs?Date.now()+view.durationMs:null)};
     return {...c.changed('בינתיים התחיל שדרוג '+label+' לרמה '+(level+1)+' בעיר '+cityName+' ('+waiting+' ממתין למשאבים)'),cycle:true};
   }
   return null;
 }
 async function uniformStep(c,rule) {
   const p=c.progress,now=Date.now(),cityName=bridge.decodeUnicodeEscape(c.city.name);
   p.skip=Object.fromEntries(Object.entries(p.skip??{}).filter(([,until])=>until>now));
   if(p.workersRevert) {
     // The last worker change turned the account's gold balance negative: undo it first.
     const {key,value}=p.workersRevert;p.workersRevert=null;
     await c.request(key==='academy'?academyRequest(c,value):workerRequest(c,String(c.city.islandId),key,value),true);
     p.workers={at:Date.now(),note:workerViews[key].label+' הוחזרו ל־'+value+' כדי לשמור על מאזן זהב לא שלילי'};
     return c.changed(p.workers.note);
   }
   // Wine-only mode (user decision, 2026-10-16): no building in this account; the mine workers stay
   // at the maximum, scientists only while there is gold, and the rest of the city is left alone.
   // In war mode (user decision, 2026-10-18) a negative gold balance also gives back luxury and then
   // sawmill workers once the scientists are gone, and the mines refill only up to the gold balance —
   // otherwise the half-hourly refill would undo the cut.
   const war=!!(await chrome.storage.local.get('war-mode-v1'))['war-mode-v1']?.active;
   // Satisfaction comes first of all (user decision, 2026-10-20): an approved satisfaction upgrade is built in war too.
   // The warehouse-only queue of a city under 48,000 (user decision, 2026-10-27) is built in wine-only accounts too.
   const storage=rule.autopilot==='uniform'&&(rule.entries??[]).length>0&&rule.entries.every(entry=>/:warehouse$/.test(entry.key));
   if(rule.autopilot!=='satisfaction'&&(war||!storage&&(await chrome.storage.local.get('wine-only-v1'))['wine-only-v1']?.accounts?.[rule.accountKey])) {
     if(now-(p.goldCheckAt??0)>5*60000) {p.goldCheckAt=now;let recovered=null;try {recovered=await goldRecovery(c,{scientistsOnly:!war});} catch(error) {if(error.mutationSubmitted) throw error;}if(recovered) return recovered;}
     if(now-(p.workersMaxAt??0)>30*60000) {p.workersMaxAt=now;const workers=await uniformWorkers(c,[],true,{mines:!war});if(workers) return workers;}
     p.current=null;p.next=null;p.need=null;p.quote=null;p.forecast=null;p.schedule=null;p.step=null;
     return {...c.wait(war?'מצב מלחמה: הבנייה מושהית עד סוף המלחמה; הפועלים ממשיכים':'מצב יין בלבד: הבנייה מושהית בחשבון הזה; הפועלים במקסימום במכרות'),idle:true,delayMs:war?5*60000:30*60000};
   }
   // Out of a negative gold balance (user decision, 2026-10-14), whatever caused it (army upkeep,
   // scientists): every 5 minutes the account's net gold is read, and while it is below zero this
   // city gives back what costs gold — scientists first, then luxury workers, then sawmill workers
   // — exactly enough to reach zero (one change per run; the next city reads the new balance).
   if(now-(p.goldCheckAt??0)>5*60000) {p.goldCheckAt=now;let recovered=null;try {recovered=await goldRecovery(c);} catch(error) {if(error.mutationSubmitted) throw error;}if(recovered) return recovered;}
   // Every half hour: fill the mines and the sawmill up to the gold balance (one change per run).
   if(now-(p.workersMaxAt??0)>30*60000) {p.workersMaxAt=now;const workers=await uniformWorkers(c,[],true);if(workers) return workers;}
   // The agent's own list leads the city after the game's own list (its rows lift the plan's targets and skip
   // the wait for the cost reducers), in the list's order.
   const queued=await agentQueue(c,rule);
   if(queued.length) rule={...rule,entries:queueEntries(rule.entries,queued,c.city.position)};
   const queueOrder=new Map();queued.forEach((row,index)=>{if(!queueOrder.has(row.building)) queueOrder.set(row.building,index);});
   const gateOpen=await c.reducersComplete();
   const busy=c.city.position.find(item=>item.isBusy);
   const townHall=c.city.position.find(item=>item.building==='townHall')?.level??0,todo=[];
   for(const entry of rule.entries) {
     if(p.skip[entry.key]) continue;
     const want=String(entry.key).split(':').slice(1).join(':');
     if(!gateOpen&&!FIRST.includes(want)&&!queueOrder.has(want)) continue;
     if(String(entry.key).startsWith('new:')) {if(!c.city.position.some(item=>item.building===want)) todo.push({entry,want,level:0,build:true});continue;}
     let at=c.city.position[entry.position];
     if(!at||at.building!==want) at=c.city.position.find(item=>item.building===want);
     if(!at||at.level>=entry.target||at.isMaxLevel||want==='wall'&&at.level>=townHall||at.isBusy) continue;
     todo.push({entry,want,level:at.level,at});
   }
   // A city without a warehouse builds one first; then the cost reducers; then — when this city's
   // barbarian attack waits for a higher barracks (user decision, 2026-10-14) — the barracks;
   // then the lowest level.
   const allRules=(await chrome.storage.local.get('game-automations-v1'))['game-automations-v1']?.rules??[];
   const needBarracks=allRules.some(item=>['barbarians','recruit'].includes(item.kind)&&item.enabled&&!item.deleted&&item.accountKey===rule.accountKey&&String(item.cityId)===String(rule.cityId)&&/דורש מבנה ברמה/.test(item.status??''));
   // Satisfaction first (Firefox edition, user decision 2026-10-20): a corrupt colony raises its
   // governor's residence before anything else, and an unhappy city its tavern next.
   const mood=globalThis.chrome?.runtime?.getManifest&&!/\bmain\b/.test(chrome.runtime.getManifest()?.version_name??'')?((((await chrome.storage.local.get('satisfaction-v1'))['satisfaction-v1']??{})[rule.accountKey]?.cities)??[]).find(city=>String(city.cityId)===String(rule.cityId)):null;
   const happiness=item=>mood?.corrupt&&item.want==='palaceColony'?-3:mood?.unhappy&&item.want==='tavern'?-2:null;
   const rank=item=>(queueOrder.has(item.want)?-100+queueOrder.get(item.want):null)??happiness(item)??(item.build&&item.want==='warehouse'?-1:FIRST.includes(item.want)?0:needBarracks&&item.want==='barracks'?0.5:1);
   todo.sort((a,b)=>rank(a)-rank(b)||a.level-b.level);
   // While a row of the agent's own list waits for its resources (Firefox is asked for them), only another row of
   // that list is built meanwhile — never a plan entry that would spend what the row waits for (user decision,
   // 2026-10-29: nothing is cancelled, the next listed building goes first, the waiting one stays on top).
   const meanwhile=()=>todo.slice(1).filter(item=>!item.build&&item.at&&(!queueOrder.has(todo[0]?.want)||queueOrder.has(item.want)));
   p.order=todo.slice(0,10).map(item=>item.entry.label+' '+item.level+'→'+(item.level+1));
   p.active=busy?{label:busy.building,level:busy.level,completedAt:Number.isFinite(Number(busy.completed))?Number(busy.completed)*1000:null}:null;
   try {await planForecast(c,rule,item=>rank({want:item.building,build:item.build}),townHall);} catch(error) {p.forecastError=String(error?.message??error).slice(0,160);}
   // The premium construction list the user set in the game leads (user decision, 2026-10-14):
   // the agent never starts something else in that city; it brings what the list's next entry costs.
   const list=globalThis.IkariamBuildForecast?.constructionList(c.city.position)??[];
   if(list.length&&!busy) {
     const first=list[0],label=bridge.decodeUnicodeEscape(first.name??first.building);
     // The observed game list leads even while Opera's extension-only targets wait for 50.
     p.current='רשימת הבנייה שלך: '+label;p.next=null;
     const view=globalThis.IkariamReadInsights.parseCityView(await c.request({...c.base,view:first.building,position:first.position}));
     if(Object.keys(view.costs).length) {p.quote={at:Date.now(),label,building:first.building,level:first.level,costs:view.costs,durationMs:view.durationMs??null};const lack=await uniformSupply(c,rule,'list:'+first.position,label,view.costs);if(lack) {p.listStall=null;return lack;}}
     // The game's list never holds the city (user decision, 2026-10-29: neither list may get stuck): when the builder
     // is free and the city has held everything its first entry costs for ten minutes and the game has not started it,
     // the agent starts that level itself.
     const key=first.position+':'+first.level;
     if(!Object.keys(view.costs).length||p.listStall?.key!==key) p.listStall=Object.keys(view.costs).length?{key,since:Date.now()}:null;
     if(p.listStall&&Date.now()-p.listStall.since>=600000) {
       const level=Number(first.level)||0;
       await c.request({...c.base,action:'UpgradeExistingBuilding',position:first.position,level,activeTab:'tabSendTransporter',templateView:first.building},true);
       await c.cityRead();const after=c.city.position[first.position];c.ensure(after&&(after.isBusy||after.level>level));
       p.listStall=null;p.active={label:first.building,level,completedAt:Number.isFinite(Number(after.completed))?Number(after.completed)*1000:null};
       return {...c.changed('רשימת הבנייה במשחק עמדה עם כל המשאבים בעיר; הסוכן התחיל בעצמו את '+label+' לרמה '+(level+1)+' בעיר '+cityName),cycle:true};
     }
     return {...c.wait('רשימת הבנייה שלך במשחק מובילה בעיר: '+label+' יתחיל כשהמשחק יגיע אליו'),...(p.listStall?{delayMs:Math.max(30000,600000-(Date.now()-p.listStall.since)+5000)}:{})};
   }
   if(busy) {
     p.next=todo[0]?.entry.label??null;
     // Checked again right when the build ends, so the next one starts at once.
     const ends=Number(busy.completed)>0?Number(busy.completed)*1000-Date.now():null;
     return {...c.wait('בתהליך שדרוג: ממתינה לסיום הבנייה הפעילה בעיר'),...(ends!==null?{delayMs:Math.min(5*60000,Math.max(20000,ends+15000))}:{})};
   }
   if(!todo.length&&!gateOpen&&!busy) return c.wait('ממתין לנגרייה ואדריכל ברמה 50 בכל ערי החשבון');
   // A satisfaction upgrade set aside for a while (resources or the game's conditions) is waited for, never reported
   // done (user report, 2026-10-29: Orakel7's governor's residences, short of sulfur, were "done" and re-opened every
   // minute for a whole day).
   const parked=rule.autopilot==='satisfaction'?rule.entries.filter(entry=>p.skip[entry.key]>Date.now()):[];
   if(parked.length&&!todo.length&&!c.city.position.some(item=>item.isBusy)) {
     const until=Math.min(...parked.map(entry=>p.skip[entry.key]));
     return {...c.wait('ממתין לשדרוג לשביעות רצון: '+parked.map(entry=>entry.label??entry.key).join(', ')+(p.quote?.missing&&Object.keys(p.quote.missing).length?' · חסר: '+Object.entries(p.quote.missing).map(([resource,amount])=>(resourceNames[resource]??resource)+' '+Math.ceil(amount).toLocaleString('en-US')).join(', '):'')),delayMs:Math.max(60000,until-Date.now()+5000)};
   }
   if(rule.autopilot==='satisfaction'&&!todo.length&&!c.city.position.some(item=>item.isBusy)) return c.result('complete','השדרוג לשביעות הרצון הושלם');
   if(!todo.length) {p.current=null;p.next=null;p.need=null;p.quote=null;return {...c.wait(Object.keys(p.skip).length?'כל השדרוגים האפשריים ממתינים (משאבים או תנאי משחק); בדיקה חוזרת בהמשך':'הושלם: כל המבנים בעיר ברמת היעד'),idle:true};}
   const next=todo[0],label=next.entry.label??next.want;p.current=label;p.next=todo[1]?.entry.label??null;
   if(next.build) {
     const grounds=c.city.position.filter(item=>item.building==='empty'&&(next.want==='port'?item.type==='shore':item.type==='land'||!item.type));
     for(const ground of grounds.slice(0,6)) {
       const offer=groundOffers(await c.request({...c.base,view:'buildingGround',position:ground.position})).find(item=>item.building===next.want);
       if(!offer) continue;
       p.quote={at:Date.now(),label,building:next.want,level:0,costs:offer.costs,durationMs:null};
       // Never build blind: without the costs the account cannot supply it (new colonies start empty).
       if(!Object.keys(offer.costs).length) {
         p.groundDebug={at:Date.now(),building:next.want,snippet:html(await c.request({...c.base,view:'buildingGround',position:ground.position})).replace(/actionRequest[^,&<]{0,80}/gi,'actionRequest=…').slice(0,4000)};
         p.skip[next.entry.key]=Date.now()+3600000;return c.wait('עלויות הבנייה של '+label+' לא נקראו מהמשחק; ינסה שוב בעוד שעה');
       }
       const lack=await uniformSupply(c,rule,next.entry.key,label,offer.costs);
       if(lack) return (lack.status!=='changed'&&!c.submitted?await upgradeAffordable(c,meanwhile(),label,cityName):null)??lack;
       // Ikabot constructBuilding: a new building is the BuildNewBuilding action.
       const answer=await c.request({...c.base,action:'BuildNewBuilding',position:ground.position,building:offer.id,templateView:'buildingGround'},true,{allowRejected:true,constructionBuilding:next.want});
       await c.cityRead();
       if(c.city.position[ground.position]?.building===next.want) {p.need=null;return {...c.changed('התחילה בניית '+label+' בעיר '+cityName),cycle:true};}
       // Something else appeared in the plot: never build blind again in this city; tell the user.
       const built=c.city.position[ground.position]?.building;
       if(built&&built!=='empty') {
         for(const entry of rule.entries) if(String(entry.key).startsWith('new:')) p.skip[entry.key]=Date.now()+24*3600000;
         p.groundDebug={at:Date.now(),wanted:next.want,built,id:offer.id,position:ground.position};
         return c.result('alert','במקום '+label+' נבנה במגרש '+built+'; בניית מבנים חדשים בעיר '+cityName+' נעצרה ל־24 שעות לבדיקה',{alerts:['⚠️ '+cityName+': במקום '+label+' נבנה '+built+'. הבנייה של מבנים חדשים בעיר נעצרה ל־24 שעות.'],cycle:true});
       }
       // The game's own reason, when it gives one.
       let reason='';try {reason=commands(answer).filter(entry=>entry[0]==='provideFeedback').flatMap(entry=>Array.isArray(entry[1])?entry[1]:[entry[1]]).map(item=>String(item?.text??'').replace(/<[^>]*>/g,'').trim()).filter(Boolean).join(' · ');} catch { /* No feedback. */ }
       // A research the account lacks does not come within the hour: tried again the next day.
       const research=/לא נחקר|not.*research/i.test(reason);
       p.skip[next.entry.key]=Date.now()+(research?24:1)*3600000;return c.wait('בניית '+label+' לא התחילה'+(reason?': '+reason.slice(0,160):' (משאבים או תנאי משחק)')+(research?'; נדרש מחקר — ינסה שוב מחר':'; ינסה שוב בעוד שעה'));
     }
     p.skip[next.entry.key]=Date.now()+6*3600000;
     return c.wait('חסום עקב תנאי משחק: '+(grounds.length?label+' אינו זמין לבנייה בעיר (מחקר או תנאי חסר)':'אין מגרש פנוי ל'+label));
   }
   const source=await c.request({...c.base,view:next.want,position:next.at.position});
   const view=globalThis.IkariamReadInsights.parseCityView(source),costs=view.costs;
   // When the build time is not recognised, a small piece of the upgrade box is kept once to fix the reader.
   if(view.durationMs==null&&!p.timeDebug) {const box=html(source),at=box.indexOf('buildingUpgrade');p.timeDebug={at:Date.now(),snippet:(at>=0?box.slice(at,at+2500):box.slice(0,1500)).replace(/actionRequest[^,&<]{0,80}/gi,'actionRequest=…')};}
   p.quote={at:Date.now(),label,building:next.want,level:next.at.level,costs,durationMs:view.durationMs??null};
   if(!Object.keys(costs).length) {p.skip[next.entry.key]=Date.now()+3600000;return c.wait('עלויות השדרוג של '+label+' לא נקראו; ינסה שוב בעוד שעה');}
   const lack=await uniformSupply(c,rule,next.entry.key,label,costs);
   // The builder never stands idle (user decision, 2026-10-15): while the first entry waits for its
   // resources, the next one the city can already pay for is upgraded meanwhile.
   if(lack) return (lack.status!=='changed'&&!c.submitted?await upgradeAffordable(c,meanwhile(),label,cityName):null)??lack;
   if(next.at.canUpgrade===false) {p.skip[next.entry.key]=Date.now()+3600000;return (await upgradeAffordable(c,meanwhile(),label,cityName))??c.wait('חסום עקב תנאי משחק: המשחק חוסם כרגע את שדרוג '+label);}
   // The city holds the resources: no waiting for the account's balancing to finish (it held
   // builders idle for hours); the 48-hour forecast keeps what the next upgrades need.
   const level=next.at.level;
   await c.request({...c.base,action:'UpgradeExistingBuilding',position:next.at.position,level,activeTab:'tabSendTransporter',templateView:next.want},true);
   await c.cityRead();const after=c.city.position[next.at.position];c.ensure(after&&(after.isBusy||after.level>level));
   p.need=null;p.active={label:next.want,level,completedAt:Number.isFinite(Number(after.completed))?Number(after.completed)*1000:(view.durationMs?Date.now()+view.durationMs:null)};
   return {...c.changed('התחיל שדרוג '+label+' לרמה '+(level+1)+' בעיר '+cityName),cycle:true};
 }
 // The city's troops by unit id: the cityMilitary view as the army panel reads it, then as
 // Ikabot reads it; a table read by unit names is matched to ids through the barracks.
 // null when no way works — a debug snippet is kept on the rule for the next check.
 async function troops(c) {
   let names=null,last='';
   for(const extra of [{activeTab:'tabUnits',currentTab:'tabUnits',templateView:'cityMilitary'},{activeTab:'tabUnits',currentTab:'multiTab1'}]) {
     const text=await c.request({...c.base,view:'cityMilitary',...extra});last=text;
     try {const counts=armyCounts(text);c.progress.armyDebug=null;return counts;} catch { /* Try the table by names. */ }
     try {
       const entries=bridge.parseMilitaryTable?.(html(text))?.filter(entry=>entry.kind==='army');
       if(entries?.length) {
         names??=recipeData(await c.view('barracks'));
         const id=name=>names.find(unit=>unit.label.trim()===String(name).trim())?.id;
         const counts={};for(const entry of entries) {const unit=id(entry.name);if(unit&&!(unit in counts)) counts[unit]=entry.count;}
         if(Object.keys(counts).length) {c.progress.armyDebug=null;return counts;}
       }
     } catch { /* Next request shape. */ }
   }
   c.progress.armyDebug={at:Date.now(),snippet:html(last).replace(/actionRequest[^,&<]{0,80}/gi,'actionRequest=…').split('<div class="fleet')[0].slice(0,4000)};
   return null;
 }
 async function step(rule) {
  let c;
  try {
   c=await context(rule);
   const p=c.progress;
   if(c.balancePending && !(rule.kind==='barbarians'&&p.mainBarbarianRound&&(()=>{try{return /\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name??'');}catch{return false;}})()) && ['recruit','workshop','experiment','barbarians','donate'].includes(rule.kind)) return c.wait('ממתינה לאיזון 48,000 בעל הקדימות הראשונה ולהשלמת החוסרים בחשבון');
   // An upgrade the user approved for satisfaction (Firefox, 2026-10-20) runs on the uniform builder:
   // it builds a missing building on a free plot, brings the materials from the account's other
   // cities and fills the sawmill and mines with workers up to the gold balance; done, it ends.
   if(rule.kind==='building'&&(rule.autopilot==='uniform'||rule.autopilot==='satisfaction')) return await uniformStep(c,rule);
   if(rule.kind==='building') {
     // An entry names its building ("position:building", or just the building); if that
     // position holds something else, the building is looked up by name in the city.
     const nameOf=entry=>String(entry.key??'').includes(':')?String(entry.key).split(':').slice(1).join(':'):String(entry.key??entry.label??'');
     for(const entry of rule.entries) {
       const want=nameOf(entry),at=c.city.position[entry.position];
       if(!at||at.building!==want) {const found=c.city.position.findIndex(item=>item?.building===want);if(found>=0) entry.position=found;}
       entry.key=entry.position+':'+want;
     }
     let index=p.index??0;
     while(index<rule.entries.length && c.city.position[rule.entries[index].position]?.level>=rule.entries[index].target && !c.city.position[rule.entries[index].position]?.isBusy) index++;
     p.index=index;
     if(index===rule.entries.length) return c.result('complete','תור שדרוגי המבנים הושלם');
     if(c.city.position.some(item=>item.isBusy)) return c.wait('ממתינה לסיום הבנייה הפעילה בעיר');
     const entry=rule.entries[index],building=c.city.position[entry.position];
     // A building that is not in the city (or already at its maximum) is skipped, not retried forever.
     if(!building || entry.key!==entry.position+':'+building.building || building.building==='empty'||building.isMaxLevel) {p.index=index+1;return c.wait((entry.label??entry.key)+(building?.isMaxLevel?' כבר ברמה המרבית':' לא נמצא בעיר')+' — דולג לשדרוג הבא בתור');}
     if(!['carpentering','architect'].includes(building.building)&&!await c.reducersComplete()) {p.need=null;return c.wait('ממתין לנגרייה ואדריכל ברמה 50 בכל ערי החשבון');}
     const source=await c.request({...c.base,view:building.building,position:entry.position}),costs=globalThis.IkariamReadInsights.parseCityView(source).costs;
     if(!Object.keys(costs).length) throw new Error('עלויות השדרוג לא פוענחו');
     const missing=Object.entries(costs).filter(([resource,cost])=>c.stock[resource]-cost<c.reserve).map(([resource,cost])=>[resource,cost+c.reserve-c.stock[resource]]);
     // Saved for the 48,000 policy, which brings these resources from other cities first.
     p.need=missing.length?{at:Date.now(),label:entry.label,resources:Object.fromEntries(Object.entries(costs).map(([resource,cost])=>[resource,Math.ceil(cost+c.reserve)]))}:null;
     if(missing.length&&c.policy) {
       // The 48,000 policy supplies the upgrade from the account's own cities only. If even the
       // whole account lacks a resource, the user is asked; otherwise the arrival is shown.
       const names={wood:'עץ',wine:'יין',marble:'שיש',crystal:'קריסטל',sulfur:'גופרית'};
       const unmet=(c.policy.report?.unmetNeeds??[]).filter(item=>String(item.cityId)===String(rule.cityId)&&missing.some(([resource])=>resource===item.resource));
       if(unmet.length) {
         p.needsIntervention={at:Date.now(),label:entry.label,missing:unmet.map(item=>({resource:item.resource,amount:item.amount}))};
         return c.wait('דורש התערבות: לשדרוג '+entry.label+' חסר בכל החשבון '+unmet.map(item=>Number(item.amount).toLocaleString('he-IL')+' '+(names[item.resource]??item.resource)).join(', '));
       }
       p.needsIntervention=null;
       const receipts=(await chrome.storage.local.get('account-policy-receipts-'+c.policy.id))['account-policy-receipts-'+c.policy.id]??[];
       const arriving=receipts.filter(item=>String(item.destinationCityId)===String(rule.cityId)&&missing.some(([resource])=>resource===item.resource)&&Number.isFinite(item.timing?.arrivalAt));
       const clock=at=>new Date(at).toLocaleTimeString('he-IL',{timeZone:'Asia/Jerusalem',hour:'2-digit',minute:'2-digit'});
       if(arriving.length) {
         const last=Math.max(...arriving.map(item=>item.timing.arrivalAt));
         return {...c.wait('אספקה לשדרוג '+entry.label+' בדרך: '+arriving.map(item=>Number(item.amount).toLocaleString('he-IL')+' '+(names[item.resource]??item.resource)+' עד '+clock(item.timing.arrivalAt)).join(', ')),delayMs:Math.max(120000,last-Date.now()+60000)};
       }
       return c.wait('חסרים משאבים לשדרוג '+entry.label+' — האיזון מביא אותם מערי החשבון');
     }
     if(missing.length) return rule.procure?await procure(c,missing,entry.label):c.wait('ממתינה למשאבים לשדרוג תוך שמירת המלאי');
     if(building.canUpgrade===false) return c.wait('המשאבים קיימים אך המשחק חוסם את השדרוג — נדרשת בדיקת תנאי המבנה');
     if(c.balancePending) return c.wait('המשאבים נבדקו; ממתינה לסיום האיזון לפני השדרוג');
     const level=building.level;
     await c.request({...c.base,action:'UpgradeExistingBuilding',position:entry.position,level,activeTab:'tabSendTransporter',templateView:building.building},true);
     await c.cityRead();const after=c.city.position[entry.position];c.ensure(after&&(after.isBusy||after.level>level));
     return {...c.changed('התחיל שדרוג '+entry.label+' בעיר '+bridge.decodeUnicodeEscape(c.city.name)),cycle:true};
   }
   if(rule.kind==='tavern') {
     const source=await c.view('tavern'),data=template(source),load=data.load_js?.params;
     const params=typeof load==='string'?JSON.parse(load):load;
     // Only the levels this tavern allows: a greyed-out (disabled) level is rejected by the game.
     const levels=Array.from(doc(source).querySelectorAll('option[value]')).filter(node=>!node.hasAttribute('disabled')).map(node=>N(node.getAttribute('value'))).filter(value=>value!==null);
     // Always the most wine, in every tavern, whatever the rule (user decision, 2026-10-15): the
     // agent never lowers the wine served — lowering it to the cheapest level left the citizens
     // neutral or unhappy. Wine supply is the balancing's job (wine is balanced first).
     const target=Math.max(...levels);
     if(!Number.isFinite(target)) throw new Error('רמות היין בטברנה לא פוענחו');
     // Firefox edition (user report, 2026-10-20): the game refuses to serve wine in a city with no
     // wine, and three refusals stopped the tavern; it now waits for the wine shipment instead.
     if(!/\bmain\b/.test(chrome.runtime?.getManifest?.()?.version_name??'')&&target>N(params?.wineServeLevel??0)&&(c.stock?.wine??0)<100) return {...c.wait('אין יין בעיר — בית המרזח ממתין למשלוח יין לפני שיגיש'),delayMs:10*60000};
     if(target===N(params?.wineServeLevel)) return c.wait('הטברנה מגישה את כמות היין המרבית');
     await c.request({...c.base,action:'CityScreen',function:'assignWinePerTick',position:c.building('tavern').position,amount:target,templateView:'tavern'},true);
     const after=template(await c.view('tavern'));const next=typeof after.load_js?.params==='string'?JSON.parse(after.load_js.params):after.load_js?.params;
     c.ensure(N(next?.wineServeLevel)===target);return {...c.changed('צריכת היין בטברנה עודכנה לרמה '+target),cycle:true};
   }
   if(rule.kind==='recruit') {
     const queues=rule.entries.filter(entry=>!(entry.key in (p.remaining??{})) || p.remaining[entry.key]>0);
     if(!queues.length) {
       for(const type of ['barracks','shipyard']) if(rule.entries.some(entry=>entry.key.startsWith('ship:')===(type==='shipyard')) && /['"]buildProgress['"]\s*,\s*\d+/.test(html(await c.view(type)))) return c.wait('ממתינה לסיום הגיוס האחרון בסבב');
       p.round=(p.round??0)+1;p.remaining={};
       return c.result(p.round>=rule.maxCycles?'complete':'waiting',p.round>=rule.maxCycles?'כל סבבי הגיוס הושלמו':'סבב הגיוס הסתיים; ממתינה לסבב הבא',{cycle:true});
     }
     if(!p.remaining || !Object.keys(p.remaining).length) p.remaining=Object.fromEntries(rule.entries.map(entry=>[entry.key,entry.target]));
     const first=rule.entries.find(entry=>p.remaining[entry.key]>0);
     if(!first) return c.wait('סבב הגיוס הסתיים; ממתינה לסבב הבא');
     const ship=first.key.startsWith('ship:');
     const result=await recruit(c,rule.entries.filter(entry=>entry.key.startsWith('ship:')===ship&&p.remaining[entry.key]>0).map(entry=>({...entry,target:p.remaining[entry.key]})),ship);
     if(result.orders) for(const order of result.orders) p.remaining[(ship?'ship:':'')+order.id]-=order.quantity;
     return result;
   }
   if(rule.kind==='workshop') {
     let index=p.index??0,entry,data,inspected=0;
     while(index<rule.entries.length) {
       if(++inspected>10) return c.wait('נבדקו עשרה פריטי בית מלאכה; ממשיכה בתור בבדיקה הבאה');
       entry=rule.entries[index];const [tab]=entry.key.split(':');data=workshopData(await c.view('workshop',{activeTab:tab,templateView:'workshop'}),tab);
       if(data.busy) return c.wait('ממתינה לסיום שדרוג בית המלאכה');
       const current=data.entries.find(item=>item.key===entry.key);if(!current) throw new Error('השדרוג שנבחר אינו מופיע בבית המלאכה');
       if(current.level>=entry.target) {p.index=++index;continue;}
       if(current.next===null || current.next<=current.level || current.next>c.building('workshop').level) throw new Error('אין רמת שדרוג נוספת זמינה ברמת בית המלאכה');
       const header=await c.rawHeader();
       if(current.crystal===null||current.gold===null||N(header.gold)===null) throw new Error('עלויות השדרוג או הזהב אינן זמינות');
       if(c.stock.crystal-current.crystal<c.reserve || Number(header.gold)<current.gold) return c.wait('ממתינה לקריסטל ולזהב לשדרוג בית המלאכה');
       await c.request({...c.base,action:'StartWorkshopUpgrade',position:c.building('workshop').position,unitId:current.id,upgradeType:current.upgradeType,activeTab:tab,templateView:'workshop'},true);
       const after=workshopData(await c.view('workshop',{activeTab:tab,templateView:'workshop'}),tab);
       c.ensure(after.busy||after.entries.find(item=>item.key===entry.key)?.level>current.level);return {...c.changed('התחיל שדרוג בית מלאכה: '+entry.label),cycle:true};
     }
     return c.result('complete','תור שדרוגי בית המלאכה הושלם');
   }
   if(rule.kind==='research'&&rule.autopilot==='research') {
     // Research on demand: what blocks recruitment for an attack ("נדרש מחקר: אבקת שריפה") is
     // researched when it is offered; until then its branch (military, for units) moves on.
     const rules=(await chrome.storage.local.get('game-automations-v1'))['game-automations-v1']?.rules??[];
     const needed=[...new Set(rules.filter(item=>item.accountKey===rule.accountKey&&item.enabled&&!item.deleted&&/נדרש מחקר/.test(item.status??''))
       .map(item=>String(item.status).replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').split(/נדרש מחקר:?/)[1]?.split(/ ומבנה| ·|;|$/)[0]?.trim()).filter(Boolean))];
     p.needed=needed;
     // Nothing blocks: research by plan (switch "מחקר לפי תוכנית") — economy, then science, seafaring, military.
     const plan=(await chrome.storage.local.get('full-auto-v1'))['full-auto-v1']?.features?.research!==false;
     if(!needed.length&&!plan) return {...c.wait('אין כרגע מחקר שחוסם תקיפה או גיוס'),idle:true,delayMs:3600000};
     const source=await c.request({...c.base,view:'researchAdvisor',templateView:'researchAdvisor',oldView:'updateGlobalData'});
     const available=researchData(source);
     const direct=available.find(item=>needed.some(name=>String(item.label).includes(name)||name.includes(String(item.label))));
     const order=[/econom/i,/knowledge|scien/i,/sea/i,/militar|army|war/i];
     const pick=direct??(needed.length?available.find(item=>/military|army|war/i.test(item.key)):order.map(pattern=>available.find(item=>pattern.test(item.key))).find(Boolean)??available[0]);
     if(!pick) return {...c.wait(needed.length?'המחקר הנדרש ('+needed.join(', ')+') אינו זמין עדיין ולא זוהה ענף הצבא':'אין מחקר זמין כרגע'),delayMs:3600000};
     const answer=await c.request({action:'Advisor',function:'doResearch',type:pick.key,backgroundView:'city',currentCityId:rule.cityId,templateView:'researchAdvisor',ajax:1},true,{allowRejected:true});
     const after=researchData(await c.request({...c.base,view:'researchAdvisor',templateView:'researchAdvisor',oldView:'updateGlobalData'}));
     if(after.some(item=>item.key===pick.key&&item.label===pick.label)) {
       let reason='';try {reason=commands(answer).filter(entry=>entry[0]==='provideFeedback').flatMap(entry=>Array.isArray(entry[1])?entry[1]:[entry[1]]).map(item=>String(item?.text??'').replace(/<[^>]*>/g,'').trim()).filter(Boolean).join(' · ');} catch { /* No feedback. */ }
       return {...c.wait('ממתינה לנקודות מחקר ל'+pick.label+(reason?' ('+reason.slice(0,100)+')':'')+(direct||!needed.length?'':' — בדרך אל '+needed.join(', '))),delayMs:3600000};
     }
     return {...c.changed('נחקר '+pick.label+(direct?' — פותח את הגיוס לתקיפה':needed.length?' — בדרך אל '+needed.join(', '):' (לפי התוכנית)')),cycle:true};
   }
   if(rule.kind==='research') {
     const index=p.index??0;if(index>=rule.entries.length) return c.result('complete','תור המחקר הושלם');
     const entry=rule.entries[index],source=await c.request({...c.base,view:'researchAdvisor',templateView:'researchAdvisor',oldView:'updateGlobalData'});
     const available=researchData(source),current=available.find(item=>item.key===entry.key);
     if(!current||current.label!==entry.label) throw new Error('המחקר שנבחר השתנה; יש לעדכן את התור לפני ההפעלה');
     await c.request({action:'Advisor',function:'doResearch',type:entry.key,backgroundView:'city',currentCityId:rule.cityId,templateView:'researchAdvisor',ajax:1},true);
     const after=await c.request({...c.base,view:'researchAdvisor',templateView:'researchAdvisor',oldView:'updateGlobalData'});
     let remaining;try {remaining=researchData(after);} catch {remaining=null;}
     c.ensure(remaining && !remaining.some(item=>item.key===entry.key&&item.label===current.label));p.index=index+1;
     return {...c.changed('המחקר בוצע: '+entry.label),cycle:true};
   }
   if(rule.kind==='experiment') {
     if(c.stock.crystal<300000 || c.stock.crystal-300000<c.reserve) return c.wait('ממתינה ל־300,000 קריסטל מעל המלאי השמור');
     const source=await c.view('academy');if(source.includes('experimentCooldown')) return c.wait('ממתינה לסיום זמן ההמתנה לניסוי');
     await c.request({...c.base,action:'CityScreen',function:'buyResearch',position:c.building('academy').position,templateView:'academy'},true);
     const after=await c.view('academy');c.ensure(after.includes('experimentCooldown'));
     return {...c.changed('ניסוי באקדמיה בוצע'),cycle:true,delayMs:241*60000};
   }
   if(rule.kind==='miracle') {
     const source=await c.view('temple'),data=template(source);
     if(!data.js_WonderViewButton) throw new Error('מצב הפלא לא פוענח');
     if(data.js_WonderViewButton.buttonState!=='enabled') return c.wait('ממתינה לכך שהפלא יהיה זמין להפעלה');
     await c.request({...c.base,action:'CityScreen',function:'activateWonder',position:c.building('temple').position,templateView:'temple'},true);
     const after=template(await c.view('temple'));c.ensure(after.js_WonderViewButton?.buttonState==='disabled' || Object.values(after).some(item=>item?.countdown));
     return {...c.changed('הפלא הופעל'),cycle:true};
   }
   if(rule.kind==='attacks') {
     const response=commands(await c.request({...c.base,view:'militaryAdvisor',oldView:'city',oldBackgroundView:'city'}));
     const movements=bridge.advisorMovements(response);p.seen??=[];
     const hostile=movements.filter(movement=>[true,1,'1','true'].includes(movement.isHostile));
     const fresh=hostile.filter(movement=>!p.seen.includes(String(movement.event?.id)));
     const alerts=fresh.map(movement=>'התראת תקיפה: '+String(movement.event.missionText??'תנועה עוינת')+' · '+String(movement.origin?.name??'מקור לא זמין')+' ← '+String(movement.target?.name??'יעד לא זמין')+' · זמן אירוע: '+(N(movement.eventTime)!==null?new Date(Number(movement.eventTime)*1000).toLocaleString('he-IL',{timeZone:'Asia/Jerusalem'}):'לא זמין'));
     p.seen=hostile.map(movement=>String(movement.event?.id)).slice(0,200);
     // Rescue (user decision, 2026-10-14): an attack heading to one of this account's cities, more
     // than ten minutes away, gets that city's resources shipped to another of its cities — goods
     // on ships cannot be pillaged. One shipment per check, the largest resource first, up to five
     // per attack; the balancing brings them back afterwards. Switch: "הצלת משאבים מתקיפה".
     // Only a pillage takes resources (user decision, 2026-10-18): occupying a town or a port and
     // pirate missions sent at the city leave the warehouses alone, so they alert without shipping.
     const rescueOn=(await chrome.storage.local.get('full-auto-v1'))['full-auto-v1']?.features?.rescue!==false;
     const pillage=movement=>{const text=bridge.decodeUnicodeEscape(String(movement.event?.missionText??''));
       if(/פיראט|pira|pirate/i.test(text)) return false;
       return /ביזה|בזיזה|pillag|plunder/i.test(text)||(!text&&Number(movement.event?.mission)===13);};
     if(rescueOn&&hostile.some(pillage)) {
       p.rescued??={};
       const arrival=movement=>{const value=N(movement.eventTime);return value===null?null:value>1e12?value:value*1000;};
       const threats=hostile.filter(pillage).filter(movement=>{const at=arrival(movement);return at!==null&&at-Date.now()>10*60000&&(p.rescued[String(movement.event?.id)]??0)<5;});
       if(threats.length) {
         const snapshot=await bridge.collectAccountSnapshot(false);
         const own=new Map(snapshot.cities.map(city=>[String(city.id),city]));
         const attacked=new Set(hostile.map(movement=>String(movement.target?.cityId??movement.target?.id)));
         const threat=threats.find(movement=>own.has(String(movement.target?.cityId??movement.target?.id)));
         if(threat) {
           const victim=own.get(String(threat.target?.cityId??threat.target?.id));
           const resource=['wood','wine','marble','crystal','sulfur'].map(key=>[key,Math.floor(victim.resources?.[key]??0)]).sort((a,b)=>b[1]-a[1]).find(([,amount])=>amount>=1000)?.[0];
           const free=city=>{const cap=city.resourceCapacities?.[resource]??city.storageCapacity??0;return cap-(city.resources?.[resource]??0);};
           const haven=snapshot.cities.filter(city=>String(city.id)!==String(victim.id)&&!attacked.has(String(city.id))).sort((a,b)=>free(b)-free(a))[0];
           if(resource&&haven) {
             c.markExternalSubmitted();
             const amount=Math.floor(victim.resources[resource]);
             const result=await bridge.executeAutomationTransport({originCityId:String(victim.id),destinationCityId:String(haven.id),resource,sendMode:'reserve',quantity:0,remaining:amount,intervalMinutes:2,maxCycles:1,accountKey:rule.accountKey,gameAutomationId:rule.id,gameOperationId:rule.inFlight});
             p.rescued[String(threat.event?.id)]=(p.rescued[String(threat.event?.id)]??0)+1;
             const names={wood:'עץ',wine:'יין',marble:'שיש',crystal:'קריסטל',sulfur:'גופרית'};
             const note='🛡️ הצלת משאבים: תקיפה בדרך ל'+victim.name+' — '+(result.status==='sent'?'נשלח '+names[resource]+' ל'+haven.name:'המשלוח לא יצא ('+result.message+')');
             return c.result(result.status==='sent'?'changed':'alert',[...alerts,note].join('\n'),{alerts:[...alerts,note],cycle:false});
           }
         }
       }
     }
     return c.result(alerts.length?'alert':'waiting',alerts.join('\n')||'לא זוהו תנועות עוינות חדשות',{alerts});
   }
   if(rule.kind==='wine') {
     const header=await c.rawHeader(),consumption=N(header.wineSpendings),production=Number(header.producedTradegood)===1?N(header.tradegoodProduction):0;
     if(consumption===null||production===null) throw new Error('קצב צריכת היין או ייצורו אינו זמין');
     const deficit=consumption-production*3600;
     if(deficit<=0||c.stock.wine/deficit>=rule.hours) return c.wait('אספקת היין בעיר תקינה');
     const alerts=[];if(!p.lastAlertAt||Date.now()-p.lastAlertAt>=12*3600000) {alerts.push('מחסור ביין בעיר '+bridge.decodeUnicodeEscape(c.city.name)+' · נותרו כ־'+Math.floor(c.stock.wine/deficit)+' שעות אספקה');p.lastAlertAt=Date.now();}
     if(!rule.autoTransfer) return c.result(alerts.length?'alert':'waiting',alerts[0]??'מחסור ביין — ההתראה כבר נשלחה',{alerts});
     if(c.policy) return c.result(alerts.length?'alert':'waiting','מחסור ביין — איזון 48,000 פעיל ומטפל בהשלמה; לא נשלח משלוח מתחרה',{alerts});
     const rawMovements=bridge.advisorMovements(commands(await c.request({...c.base,view:'militaryAdvisor',oldView:'city',oldBackgroundView:'city'})));
     const movements=rawMovements.map(m=>({...m,origin:m.origin?{...m.origin,name:bridge.decodeUnicodeEscape(m.origin.name),avatarName:bridge.decodeUnicodeEscape(m.origin.avatarName)}:m.origin,target:m.target?{...m.target,name:bridge.decodeUnicodeEscape(m.target.name),avatarName:bridge.decodeUnicodeEscape(m.target.avatarName)}:m.target}));
     const snapshot=await bridge.collectAccountSnapshot(false);
     if(snapshot.ownerName!==c.initial.ownerName) throw new Error('החשבון השתנה במהלך סריקת היין');
     const reservations=globalThis.IkariamAccountPolicy.cargoReservations(snapshot.cities,movements,c.initial.ownerName);
     if(reservations.incoming[rule.cityId]?.wine>0) return c.result('waiting','כבר יש משלוח יין בדרך לעיר',{alerts});
     const donor=snapshot.cities.filter(city=>city.id!==rule.cityId && city.resources.wine-(reservations.outgoing[city.id]?.wine??0)>=c.reserve+rule.transferAmount).sort((a,b)=>b.resources.wine-a.resources.wine)[0];
     if(!donor) return c.result(alerts.length?'alert':'waiting','לא נמצאה עיר תורמת עם מספיק יין מעל המלאי השמור',{alerts});
     // Shared shipping adapter performs its own fresh preflight and preserves reserve.
     if(rule.reviewMode==='manual') {
       const fields={function:'loadTransportersWithFreight',originName:donor.name,destinationName:bridge.decodeUnicodeEscape(c.city.name),resource:'wine',amount:rule.transferAmount};
       const key=JSON.stringify(fields);
       if(rule.skippedPlans?.includes(key)||rule.approval?.key!==key||Date.now()-rule.approval.approvedAt>180000) {
         const error=new Error('מחסור ביין — משלוח השלמה ממתין לאישור');error.mutationSubmitted=false;
         error.proposal={key,fields,cityName:bridge.decodeUnicodeEscape(c.city.name),createdAt:Date.now()};error.skipped=rule.skippedPlans?.includes(key);throw error;
       }
     }
     c.markExternalSubmitted();
     const result=await bridge.executeAutomationTransport({originCityId:donor.id,destinationCityId:rule.cityId,resource:'wine',sendMode:'reserve',quantity:c.reserve,remaining:rule.transferAmount,intervalMinutes:2,maxCycles:1,accountKey:rule.accountKey,gameAutomationId:rule.id,gameOperationId:rule.inFlight});
     return c.result(result.status==='sent'?'changed':'waiting',result.message,{alerts,cycle:result.status==='sent'});
   }
   if(rule.kind==='daily') return await daily(c);
   if(rule.kind==='barbarians') return await barbarians(c);
   if(rule.kind==='reinforce') return await reinforce(c);
   if(isExtra(rule.kind)) return await extras.step(c);
   throw new Error('סוג אוטומציה אינו נתמך');
  } catch(error) {
    if(error.proposal && c && !c.submitted) {
      const progress=structuredClone(c.progress??{});
      if(error.skipped && ['building','workshop','research'].includes(rule.kind)) progress.index=(progress.index??0)+1;
      if(error.skipped && rule.kind==='recruit') {
        progress.remaining??=Object.fromEntries(rule.entries.map(entry=>[entry.key,entry.target]));
        for(const entry of rule.entries) if(error.proposal.fields[entry.key.replace(/^ship:/,'')]!=null) progress.remaining[entry.key]=0;
      }
      if(error.skipped && rule.kind==='daily') {
        const fn=error.proposal.fields.function;
        progress.day=new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Jerusalem'});
        if(fn==='giveDailyActivityBonus') {progress.wineClaimed=true;progress.lastWineAttemptAt=Date.now();}
        if(fn==='collect') progress.fountainClaimed=true;
        if(fn==='CollectDailyTasksFavor') progress.claimedTasks=[...(progress.claimedTasks??[]),String(error.proposal.fields.taskId)];
        if(fn==='requestBonus'||fn==='watchVideo') {
          progress.skippedVideos=[...(progress.skippedVideos??[]),Number(error.proposal.fields.bonusId??progress.video?.bonusId)];progress.video=null;
        }
      }
      return {status:error.alerts?.length?'alert':'waiting',message:error.skipped?'הפעולה דולגה; ממתינה לבדיקה הבאה':error.message,progress,proposal:error.skipped?null:error.proposal,alerts:error.alerts??[]};
    }
    error.mutationSubmitted=error.mutationSubmitted??c?.submitted??false;throw error;
  }
  finally {if(c) {try {await c.restore();} catch(error) {error.mutationSubmitted=c.submitted;throw error;}}}
 }
 // constructionList.sendResourcesNeeded: fetch missing upgrade materials from
 // other own cities, one shipment per check, through the shared transport adapter.
 async function procure(c,missing,label) {
   const rule=c.rule,movements=bridge.advisorMovements(commands(await c.request({...c.base,view:'militaryAdvisor',oldView:'city',oldBackgroundView:'city'}))).map(m=>({...m,origin:m.origin?{...m.origin,name:bridge.decodeUnicodeEscape(m.origin.name),avatarName:bridge.decodeUnicodeEscape(m.origin.avatarName)}:m.origin,target:m.target?{...m.target,name:bridge.decodeUnicodeEscape(m.target.name),avatarName:bridge.decodeUnicodeEscape(m.target.avatarName)}:m.target}));
   const snapshot=await bridge.collectAccountSnapshot(false);
   if(snapshot.ownerName!==c.initial.ownerName) throw new Error('החשבון השתנה במהלך תכנון אספקת המשאבים');
   const reservations=globalThis.IkariamAccountPolicy.cargoReservations(snapshot.cities,movements,c.initial.ownerName);
   for(const [resource,amount] of missing) {
     const needed=amount-(reservations.incoming[rule.cityId]?.[resource]??0);
     if(needed<=0) continue;
     const donor=snapshot.cities.filter(city=>city.id!==rule.cityId).map(city=>({city,free:city.resources[resource]-(reservations.outgoing[city.id]?.[resource]??0)-c.reserve})).filter(item=>item.free>0).sort((a,b)=>b.free-a.free)[0];
     if(!donor) continue;
     const send=Math.min(needed,donor.free);
     if(rule.reviewMode==='manual') {
       const fields={function:'loadTransportersWithFreight',originName:donor.city.name,destinationName:bridge.decodeUnicodeEscape(c.city.name),resource,amount:send};
       const key=JSON.stringify(fields);
       if(rule.skippedPlans?.includes(key)||rule.approval?.key!==key||Date.now()-rule.approval.approvedAt>180000) {
         const error=new Error('חסרים משאבים לשדרוג — משלוח אספקה ממתין לאישור');error.mutationSubmitted=false;
         error.proposal={key,fields,cityName:bridge.decodeUnicodeEscape(c.city.name),createdAt:Date.now()};error.skipped=rule.skippedPlans?.includes(key);throw error;
       }
     }
     c.markExternalSubmitted();
     const result=await bridge.executeAutomationTransport({originCityId:donor.city.id,destinationCityId:rule.cityId,resource,sendMode:'reserve',quantity:c.reserve,remaining:send,intervalMinutes:2,maxCycles:1,accountKey:rule.accountKey,gameAutomationId:rule.id,gameOperationId:rule.inFlight});
     return c.result(result.status==='sent'?'changed':'waiting',result.status==='sent'?'אספקה לשדרוג '+label+': '+result.message:result.message);
   }
   return c.wait('ממתינה למשאבים לשדרוג; משלוחי אספקה בדרך או שאין עודפים בערים אחרות');
 }
 // All-day cinema, exactly as Ikabot loginDaily: read the cinema, request a show for each
 // available bonus, wait 55 seconds, then watch it. The game's answer is checked on the cinema
 // page afterwards; an unconfirmed bonus is simply tried again, never left 'unknown'.
 async function allDayCinema(c) {
   // All four shows, ambrosia included (user decision, 2026-10-12).
   const count=4;
   const p=c.progress,keys=['Resource','Tradegood','Favour','Ambrosia'],labels=['ייצור חומרי בנייה','משאב יוקרה','תגמול','אמברוסיה'];
   const view=()=>c.request({...c.base,view:'cinema',visit:1,templateView:'cinema'});
   if(p.video) {
     const elapsed=Date.now()-p.video.requestedAt;
     if(elapsed<55000) return {...c.wait('מוצג תוכן קולנוע; ממתין 55 שניות לסיומו'),delayMs:55000-elapsed};
     const video=p.video;p.video=null;
     await c.request({...c.base,view:'noViewChange',action:'AdVideoRewardAction',function:'watchVideo',videoId:video.videoId,templateView:'cinema'},true,{allowRejected:true});
     const label=labels[video.bonusId-51]??'בונוס';
     if(html(await view()).includes('js_nextPossible'+keys[video.bonusId-51])) return {...c.changed('נאסף בונוס קולנוע: '+label),cycle:true,delayMs:60000};
     return {...c.wait('בונוס הקולנוע ('+label+') לא אושר במשחק; ינסה שוב בבדיקה הבאה'),delayMs:60000};
   }
   const source=await view(),container=doc(source).querySelector('#VideoRewards');
   // Each offer: its show id (when available) or a cooldown timer. Read from the page, and if
   // that finds nothing, exactly as Ikabot does: split the raw response on the reward items.
   // Each show is recognised by its own type in the page (its timer id or bonus id), not by its
   // place in the list: a slot with "no feature available" shifted the places, so the favour
   // show was looked for in the wrong slot and never collected (user report, 2026-10-15).
   const kindOf=(htmlText,position)=>{
     const named=htmlText.match(/js_nextPossible(Resource|Tradegood|Favour|Ambrosia)/)?.[1];if(named) return keys.indexOf(named);
     const bonus=Number(htmlText.match(/bonusId["'\s:=]+(5[1-4])/i)?.[1]);if(bonus>=51&&bonus<=54) return bonus-51;
     return position;
   };
   let offers=container?Array.from(container.querySelectorAll('li')).map((node,position)=>({node,position})).filter(({node})=>node.querySelector('form')||/js_nextPossible/.test(node.innerHTML))
     .map(({node,position})=>{
       const videoId=node.querySelector('input[name=videoId]')?.getAttribute('value')??node.innerHTML.match(/videoId["'\s:=]+(\d+)/i)?.[1]??null;
       // An available offer may still carry an empty, hidden timer element: an offer with a
       // show id is available; only one without it is cooling down.
       return {cooling:!videoId&&/js_nextPossible/.test(node.innerHTML),videoId,kind:kindOf(node.innerHTML,position)};
     }):[];
   if(!offers.some(offer=>offer.cooling||offer.videoId)) {
     const raw=String(source).replace(/\\"/g,'"').replace(/\\\//g,'/');
     const part=raw.split('id="VideoRewards"')[1]?.split('ul>')[0]??'';
     offers=part.split('li>').map((item,position)=>({item,position})).filter(({item})=>item.includes('form')||item.includes('js_nextPossible'))
       .map(({item,position})=>{const videoId=item.match(/name="videoId"\s*value="(\d+)"/)?.[1]??null;return {cooling:!videoId&&item.includes('js_nextPossible'),videoId,kind:kindOf(item,Math.floor(position/2))};});
     if(!offers.some(offer=>offer.cooling||offer.videoId)) {
       // Kept so the real page structure can be checked; tokens are removed.
       p.cinemaDebug={at:Date.now(),found:!!container,snippet:(part||html(source)).replace(/actionRequest[^,&<]{0,80}/gi,'actionRequest=…').slice(0,3000)};
       return {...c.wait('לא זוהו אפשרויות בקולנוע; נשמר קטע מהעמוד לבדיקה · ינסה שוב בעוד 10 דקות'),delayMs:600000};
     }
   }
   p.cinemaDebug=null;
   let favourHeld=null;
   p.cinemaOffers={at:Date.now(),offers:offers.map(offer=>({kind:keys[offer.kind]??offer.kind,available:!!offer.videoId&&!offer.cooling}))};
   for(const offer of offers) {
     const index=offer.kind,videoId=offer.videoId;
     if(!(index>=0&&index<count)||offer.cooling||!/^\d+$/.test(videoId??'')) continue;
     // The favour show (50) is not collected when it could take the account over the favour
     // cap (2,500): Telegram is told instead and the user decides (user decision, 2026-10-12).
     // Unknown favour counts as over the cap, as for daily-task rewards.
     if(index===2) {
       const tasks=await c.request({...c.base,view:'dailyTasks',templateView:'dailyTasks'});
       const favour=N(html(tasks).match(/currentFavor[\s\S]*?(\d[\d,.]*)\s*</)?.[1]?.replace(/[,.]/g,''));
       const cap=c.rule.favourCap??2500,reward=50;
       if(favour===null||favour+reward>cap) {
         favourHeld={favour,cap};
         const alert=!p.favourHeldAlertAt||Date.now()-p.favourHeldAlertAt>=6*3600000;
         if(alert) p.favourHeldAlertAt=Date.now();
         favourHeld.alert=alert;
         continue;
       }
       p.favourHeldAlertAt=null;
     }
     await c.request({...c.base,view:'noViewChange',action:'AdVideoRewardAction',function:'requestBonus',bonusId:51+index,videoId,templateView:'cinema'},true,{allowRejected:true});
     p.video={videoId,bonusId:51+index,requestedAt:Date.now()};
     return {...c.changed('הוצג תוכן קולנוע ('+labels[index]+'); ממתין 55 שניות לאיסוף'),delayMs:55000};
   }
   const now=Date.now();
   const times=globalThis.IkariamReadInsights.parseDailyBonuses(source,now).slice(0,count).map(bonus=>bonus.nextAvailableAt).filter(at=>Number.isFinite(at)&&at>now);
   const next=times.length?Math.min(...times):null;
   const at=next?new Date(next).toLocaleTimeString('he-IL',{timeZone:'Asia/Jerusalem',hour:'2-digit',minute:'2-digit'}):null;
   let delayMs=next?Math.min(3*3600000,Math.max(60000,next-now+60000)):1800000;
   let message=next?'כל בונוסי הקולנוע נאספו; הבא זמין ב־'+at+' וייאסף אז':'כל בונוסי הקולנוע נאספו; בדיקה חוזרת בעוד 30 דקות';
   const alerts=[];
   if(favourHeld) {
     // Checked again every hour: once favour is spent below the cap the show is collected.
     delayMs=Math.min(delayMs,3600000);
     const level=favourHeld.favour===null?'לא ידוע':favourHeld.favour.toLocaleString('he-IL');
     message='בונוס התגמול בקולנוע (50) ממתין: התגמול '+level+' — איסוף יעבור את '+favourHeld.cap.toLocaleString('he-IL')+' · '+message;
     if(favourHeld.alert) alerts.push('🎬 '+String(c.rule.accountKey).split('|')[0]+': בונוס התגמול בקולנוע (50) לא נאסף — התגמול כעת '+level+', והאיסוף יעבור את '+favourHeld.cap.toLocaleString('he-IL')+'. נצל תגמול (למשל במקדש) והבונוס ייאסף לבד בבדיקה הבאה.');
   }
   return {...c.wait(message),idle:true,delayMs,...(alerts.length?{alerts}:{})};
 }
 // The rewards window of the daily tasks (view dailyTasksRewards): each row holds the reward's name, its favour
 // cost and the game's own redeem link (action ChangeFavorIntoReward with its rewardId). The first reward in the
 // user's order that is offered and affordable is redeemed through that link; the favour read afterwards must
 // be lower. Returns the reward's name, or null when none can be redeemed.
 const FAVOUR_ORDER=[/פאן/,/טיצ/,/הפי?סטוס/,/זהב מוגבר/],FAVOUR_LABELS=['פאן','טיצ׳ה','הפיסטוס','זהב מוגבר'];
 async function spendFavour(c,favour) {
   let source;try {source=await c.request({...c.base,view:'dailyTasksRewards',templateView:'dailyTasksRewards'});} catch {return null;}
   const offers=Array.from(doc(source).querySelectorAll('tr')).map(row=>{
     const link=row.querySelector('a.button[href*="ChangeFavorIntoReward"]');if(!link) return null;
     const name=(row.querySelector('td.left')?.textContent??row.textContent).replace(/\s+/g,' ').trim();
     const grey=(link.getAttribute('onclick')??'').match(/makeGrey\([^,]+,\s*(\d+)\s*,\s*(\d+)\s*\)/);
     const cost=grey?Number(grey[2]):N(row.querySelector('td.smallright')?.textContent?.replace(/[^\d]/g,''));
     return {name,link,cost,disabled:/disabled|inactive|grey/i.test(link.getAttribute('class')??'')};
   }).filter(Boolean);
   // What the window offered, kept for the alert (user report, 2026-10-28: "none available" with no reason).
   c.progress.favourOffers=FAVOUR_ORDER.map((pattern,index)=>{const offer=offers.find(item=>pattern.test(item.name));const label=FAVOUR_LABELS[index];
     return !offer?label+': לא מופיע בחלון':offer.disabled?label+': לא זמין כרגע':offer.cost>favour?label+': עולה '+offer.cost+' (יש '+favour+')':label+(offer.cost>0?': '+offer.cost:': עלות לא נקראה');});
   for(const pattern of FAVOUR_ORDER) {
     const offer=offers.find(item=>pattern.test(item.name));
     // A cost that could not be read is still tried: the favour must drop after it, or nothing counts.
     if(!offer||offer.disabled||offer.cost>0&&offer.cost>favour) continue;
     const params=Object.fromEntries(new URLSearchParams((offer.link.getAttribute('href')??'').replace(/&amp;/g,'&').replace(/^[^?]*\?/,'')));delete params.actionRequest;
     if(params.action!=='ChangeFavorIntoReward'||!/^\d+$/.test(params.rewardId??'')) continue;
     // A reward the game refused today is not tried again today (user report, 2026-10-28: the same refusal
     // stopped the daily bonuses of Orakel1 and Orakel2 several times a day); the next one in order is tried.
     if((c.progress.favourTried??[]).includes(params.rewardId)) continue;
     let left=null;
     try {
       await c.request({...c.base,...params,templateView:'dailyTasksRewards'},true);
       const after=await c.request({...c.base,view:'dailyTasks',templateView:'dailyTasks'});
       left=N(html(after).match(/currentFavor[\s\S]*?(\d[\d,.]*)\s*</)?.[1]?.replace(/[,.]/g,''));
     } catch { /* Refused: noted below. */ }
     if(left!==null&&left<favour) return offer.name;
     // One game action per check: the check ends here, calmly, and the next one goes on without this reward.
     c.progress.favourTried=[...(c.progress.favourTried??[]),params.rewardId];
     c.progress.favourOffers=c.progress.favourOffers.map((text,index)=>pattern===FAVOUR_ORDER[index]?FAVOUR_LABELS[index]+': המשחק סירב היום':text);
     return {refused:offer.name};
   }
   return null;
 }
 async function daily(c) {
   const p=c.progress,day=new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Jerusalem'});
   if(p.day!==day) {p.day=day;p.claimedTasks=[];p.skippedVideos=[];p.favourTried=[];p.wineClaimed=!!p.lastWineAttemptAt&&Date.now()-p.lastWineAttemptAt<86400000;p.fountainClaimed=false;}
   if(p.lastWineAttemptAt&&Date.now()-p.lastWineAttemptAt>=86400000) p.wineClaimed=false;
   if(c.rule.allDayVideos) return await allDayCinema(c);
   if(!p.wineClaimed) {
     const source=await c.request({...c.base,action:'AvatarAction',function:'giveDailyActivityBonus',dailyActivityBonusCitySelect:c.rule.cityId,startPageShown:1,detectedDevice:1,autoLogin:'on',activeTab:'multiTab2'},true,{allowRejected:true});
     const feedback=commands(source).filter(item=>item[0]==='provideFeedback').flatMap(item=>item[1]??[]);
     // Persist an attempted daily claim even when the server indicates that
     // today's bonus was already claimed; never spam the same claim.
     p.wineClaimed=true;p.lastWineAttemptAt=Date.now();
     if(feedback.some(item=>Number(item?.type)===11)) return c.wait('בונוס היין אינו זמין לאיסוף כעת; בקשת האיסוף נדחתה במשחק');
     c.ensure(feedback.some(item=>Number(item?.type)===10));
     return {...c.changed('נאסף בונוס היין היומי'),cycle:true};
   }
   if(c.rule.collectTasks) {
     let source=await c.request({...c.base,view:'dailyTasks',templateView:'dailyTasks'});
     const collectable=row=>!row.querySelector('.textLineThrough') && !row.classList.contains('textLineThrough') && row.querySelector('.smallright.progress.details') && row.querySelector('.smallright.progress.details').textContent.trim()===row.querySelector('.left.small.progress.details')?.textContent.trim();
     const taskId=row=>row.innerHTML.match(/taskId=(\d+)/)?.[1]??row.innerHTML.match(/task_amount_(\d+)/)?.[1];
     // loginDaily.look: the highscore, inventory and shop tasks complete by opening those views.
     if(c.rule.performTasks) {
       const views={26:{view:'highscore',showMe:1},27:{view:'inventory',templateView:'dailyTasks'},28:{view:'premium',linkType:2,templateView:'dailyTasks'}};
       p.visited??=[];let visited=false;
       for(const row of doc(source).querySelectorAll('tr')) {
         const id=Object.keys(views).find(key=>row.innerHTML.includes('task_amount_'+key));
         if(id && !collectable(row) && !row.innerHTML.includes('textLineThrough') && !p.visited.includes(id)) {await c.request({...c.base,...views[id]});p.visited.push(id);visited=true;}
       }
       if(visited) source=await c.request({...c.base,view:'dailyTasks',templateView:'dailyTasks'});
     }
     const rows=Array.from(doc(source).querySelectorAll('tr'));
     const row=rows.find(row=>collectable(row) && /taskId=\d+/.test(row.innerHTML) && !p.claimedTasks.includes(taskId(row)));
     if(row) {
       const id=taskId(row);
       // A reward that would cross the favour cap requires a warning and explicit approval.
       const favour=N(html(source).match(/currentFavor[\s\S]*?(\d[\d,.]*)\s*</)?.[1]?.replace(/[,.]/g,''));
       const rewardNode=row.querySelector('[class*="favour"],[class*="favor"],[class*="Favour"],[class*="Favor"]');
       // The task's favour reward: its favour element, or a "+N" in the row's own text (user report,
       // 2026-10-22: an unread reward made the guard stop at 2,000 instead of the real 2,500 cap).
       const rewardText=rewardNode?.textContent??row.textContent.match(/\+\s*(\d[\d,.]*)/)?.[1]??null;
       const reward=rewardText!=null?globalThis.IkariamReadInsights.numeric(String(rewardText)):null;
       const cap=c.rule.favourCap??2500;
       // Only a reward that really takes the account over the cap waits for approval; an unknown reward
       // keeps the old safety margin.
       const risky=favour===null || (reward!==null?favour+reward>cap:favour>=cap-(c.rule.favourMargin??500));
       // Before the cap, favour is spent in the game's rewards window in the user's order (user decision,
       // 2026-10-25): Pan's blessing, Tyche's, Hephaestus's, then boosted gold income. Only when none of them
       // can be redeemed the reward waits for the user, who presses "handled, check again".
       if(c.rule.favourGuard!==false && risky && favour!==null && c.rule.favourSpend!==false) {
         const spent=await spendFavour(c,favour);
         if(spent?.refused) return c.wait('המשחק סירב לתגמול החסד '+spent.refused+'; הוא ידולג עד מחר והבונוסים ממשיכים');
         if(spent) return {...c.changed('נפדה חסד לפני התקרה: '+spent),cycle:true};
       }
       if(c.rule.favourGuard!==false && risky) {
         const fields={function:'CollectDailyTasksFavor',taskId:id,currentFavour:favour??'לא זמין',reward:reward??'לא זמין',cap};
         const key=JSON.stringify(fields);
         if(!(c.rule.approval?.key===key && Date.now()-c.rule.approval.approvedAt<=180000)) {
           const error=new Error('איסוף התגמול עלול לחצות '+cap+' נקודות חסד — ממתין לאישור שלך');error.mutationSubmitted=false;error.forced=true;
           error.proposal={key,fields,cityName:bridge.decodeUnicodeEscape(c.city.name),createdAt:Date.now(),forced:true};error.skipped=c.rule.skippedPlans?.includes(key);
           error.alerts=p.favourAlerted===key?[]:['חסד ב־'+String(c.rule.accountKey).split('|')[0]+': איסוף משימה '+id+' יעבור את '+cap+' (כעת '+(favour??'לא זמין')+', תגמול '+(reward??'לא זמין')+'), ואף ברכה מהרשימה (פאן, טיצ׳ה, הפיסטוס, זהב מוגבר) אינה זמינה לפדיון'+(p.favourOffers?.length?' ('+p.favourOffers.join(' · ')+')':'')+'. טפל במשחק ולחץ בחלונית "טופל, בדוק שוב".'];
           p.favourAlerted=key;throw error;
         }
       }
       if(!p.claimedTasks.includes(id)) {
         await c.request({...c.base,action:'CollectDailyTasksFavor',taskId:id,templateView:'dailyTasks'},true);
         const after=await c.request({...c.base,view:'dailyTasks',templateView:'dailyTasks'});
         const updated=Array.from(doc(after).querySelectorAll('tr')).find(row=>new RegExp('taskId='+id+'(?:\\D|$)').test(row.innerHTML));
         c.ensure(!updated||!!updated.querySelector('.textLineThrough')||updated.classList.contains('textLineThrough'));p.claimedTasks.push(id);return {...c.changed('נאסף תגמול משימה יומית '+id),cycle:true};
       }
     }
   }
   if(!p.fountainClaimed&&/class="fountain_active/.test(c.home)) {
     await c.request({...c.base,action:'AmbrosiaFountainActions',function:'collect',templateView:'ambrosiaFountain'},true);
     await c.cityRead();c.ensure(!/class="fountain_active/.test(c.home));p.fountainClaimed=true;return {...c.changed('נאסף בונוס המזרקה'),cycle:true};
   }
   let cinemaSource=null;
   if(c.rule.collectVideos) {
     const cinema=await c.request({...c.base,view:'cinema',visit:1,templateView:'cinema'});cinemaSource=cinema;
     if(p.video) {
       if(Date.now()-p.video.requestedAt<55000) return c.wait('ממתינה 55 שניות לסיום שלב בונוס הסרטון');
       await c.request({...c.base,view:'noViewChange',action:'AdVideoRewardAction',function:'watchVideo',videoId:p.video.videoId,templateView:'cinema'},true);
       const after=await c.request({...c.base,view:'cinema',visit:1,templateView:'cinema'});
       c.ensure(html(after).includes('js_nextPossible'+({51:'Resource',52:'Tradegood',53:'Favour',54:'Ambrosia'}[p.video.bonusId])));
       p.video=null;return {...c.changed('נאסף בונוס הסרטון'),cycle:true};
     }
     const container=doc(cinema).querySelector('#VideoRewards');
     if(!container) throw new Error('אפשרויות בונוס הסרטונים לא פוענחו');
     const features=Array.from(container.querySelectorAll('li')).filter(node=>node.querySelector('form')||/js_nextPossible/.test(node.innerHTML));
     for(let index=0;index<Math.min(c.rule.collectAmbrosia?4:3,features.length);index++) {
       const node=features[index],videoId=node.querySelector('input[name=videoId]')?.getAttribute('value');
       if(!/^\d+$/.test(videoId??'') || /js_nextPossible/.test(node.innerHTML)) continue;
       const bonusId=51+index;
       if(p.skippedVideos?.includes(bonusId)) continue;
       const source=await c.request({...c.base,view:'noViewChange',action:'AdVideoRewardAction',function:'requestBonus',bonusId,videoId,templateView:'cinema'},true);
       c.ensure(commands(source).some(item=>item[0]==='provideFeedback'&&(item[1]??[]).some(feedback=>Number(feedback.type)===10)));
       p.video={videoId,bonusId,requestedAt:Date.now()};return c.changed('התחיל שלב איסוף בונוס הסרטון; ממתינה לאישור סיום');
     }
   }
   // All-day mode: come back right after the earliest cinema bonus becomes available again.
   if(c.rule.allDayVideos&&cinemaSource) {
     const now=Date.now();
     const times=globalThis.IkariamReadInsights.parseDailyBonuses(cinemaSource,now).slice(0,c.rule.collectAmbrosia?4:3)
       .filter(bonus=>!p.skippedVideos?.includes(bonus.id)).map(bonus=>bonus.nextAvailableAt).filter(at=>Number.isFinite(at)&&at>now);
     const next=times.length?Math.min(...times):null;
     const at=next?new Date(next).toLocaleTimeString('he-IL',{timeZone:'Asia/Jerusalem',hour:'2-digit',minute:'2-digit'}):null;
     return {...c.wait(next?'כל בונוסי הקולנוע הזמינים נאספו; הבונוס הבא זמין ב־'+at+' וייאסף אז':'כל בונוסי הקולנוע הזמינים נאספו; בדיקה חוזרת בעוד 30 דקות'),
       idle:true,delayMs:next?Math.min(3*3600000,Math.max(60000,next-now+20000)):1800000};
   }
   return {...c.wait('הבונוסים הזמינים נאספו; ממתינה למשימות שהושלמו או ליום הבא'),idle:true};
 }
 async function unitData(c,id) {
   const source=html(await c.request({...c.base,view:'unitdescription',unitId:id,helpId:9,subHelpId:0,templateView:'unitdescription'}));
   const speed=N(source.match(/<span class="textLabel">.*?<\/span>\s*(\d+)\s*<br\s*\/?\s*>/)?.[1]);
   const weight=N(source.match(/<li class="weight[^"]*"[^>]*>[\s\S]*?<\/span>\s*(\d+)\s*<\/li>/)?.[1]);
   if(!speed||speed<=0) throw new Error('מהירות הכוח אינה זמינה לתכנון בטוח');
   return {speed,weight};
 }
 async function barbarians(c) {
   const main=(()=>{try{return /\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name??'');}catch{return false;}})();
   const round=main?c.progress.mainBarbarianRound:null;
   const markerKey='main-barbarian-operation-'+c.rule.id;
   if(round){const saved=(await chrome.storage.local.get(markerKey))[markerKey];if(saved?.id===round.id)Object.assign(round,saved);}
   const saveRound=async()=>{if(round)await chrome.storage.local.set({[markerKey]:{...round}});};
   const finish=(status,reason)=>{c.progress.mainRecruitNeed=null;c.progress.mainBarbarianDone={roundId:round.id,status,reason};return c.result('complete',reason);};


   const ownIsland=String(c.city.islandId??'');if(!/^\d+$/.test(ownIsland)) throw new Error('לא זוהה אי העיר');
   const islandId=String(round?ownIsland:c.rule.targetIslandId||ownIsland);if(!/^\d+$/.test(islandId)) throw new Error('אי היעד אינו תקין');
   const remote=islandId!==ownIsland;
   const islandSource=await c.request({view:'island',islandId});
   const island=commands(islandSource).find(item=>item[0]==='updateBackgroundData')?.[1];
   if(String(island?.id)!==islandId || !island.barbarians) throw new Error('מצב כפר הברברים אינו זמין');
   const response=await c.request({view:'barbarianVillage',destinationIslandId:islandId,oldBackgroundView:'city',cityWorldviewScale:1,islandId,backgroundView:'island',currentIslandId:islandId,ajax:1});
   const data=template(response),level=N(data.js_islandBarbarianLevel?.text);
   if(level===null) throw new Error('רמת הברברים אינה זמינה');
   if(main) {
     const observation={islandId,level,underAttack:Number(island.barbarians.underAttack)===1,destroyed:Number(island.barbarians.destroyed)===1,at:Date.now(),cityId:c.rule.cityId};
     const key='main-barbarian-islands-'+c.rule.accountKey,all=(await chrome.storage.local.get(key))[key]??{};
     await chrome.storage.local.set({[key]:{...all,[islandId]:observation}});c.progress.mainBarbarianObservation=observation;
     if(round?.scanOnly)return finish('done','רמת כפר הברברים נקראה מהמשחק');
   }
   const custom=c.rule.customUnits&&Object.keys(c.rule.customUnits.units??{}).length?c.rule.customUnits:null;
   const preset=custom?{units:custom.units,loot:Object.keys(custom.loot??{}).length?custom.loot:custom.units}:presets.find(item=>level>=item.min&&level<=item.max);
   if(round&&(!preset||level>c.rule.maxBarbarianLevel))return finish('skipped','רמת הברברים '+level+' מעל ההרכב או התקרה המותרת; לא נשלחה תקיפה');
   if(!preset||level>c.rule.maxBarbarianLevel) return c.result('complete','הברברים עברו את רמת התקיפה המותרת; האוטומציה נעצרה');
   const movements=bridge.advisorMovements(commands(await c.request({...c.base,view:'militaryAdvisor',oldView:'city',oldBackgroundView:'city'})));
   // Coordinate several cities: never launch while any own mission 13 targets this island.
   const travelling=movements.some(movement=>Number(movement.event?.mission)===13 && String(movement.target?.islandId)===islandId);
   const ownRoundMovement=!!round&&movements.some(movement=>Number(movement.event?.mission)===13&&[movement.origin?.cityId??movement.origin?.id,movement.target?.cityId??movement.target?.id].some(id=>String(id)===String(c.rule.cityId)));
   if(round&&ownRoundMovement&&round.phase!=='preparing'){round.observed=true;await saveRound();}
   if(travelling || ownRoundMovement || Number(island.barbarians.underAttack)===1) return c.wait('ממתינה לתקיפה, לבזיזה ולחזרת הכוחות');
   if(![0,1].includes(Number(island.barbarians.destroyed))||![0,1].includes(Number(island.barbarians.underAttack))) throw new Error('מצב הקרב אינו תואם');
   const destroyed=Number(island.barbarians.destroyed)===1;
   if(round&&round.phase!=='preparing') {
     if(!round.accepted&&!round.observed)return c.wait('ממתין לאימות תוצאת התקיפה במשחק; לא תישלח פעולה נוספת ללא ראיות');
     const old=Date.now()-(round.sentAt??Date.now())>=120000;
     if(round.phase==='loot-submitted'&&old&&(round.accepted||round.observed))return finish('done','הבזיזה הסתיימה והכוחות חזרו; העיר סיימה את הסבב');
     if(round.phase==='attack-submitted'&&!destroyed&&old&&(round.accepted||round.observed))return finish('skipped','התקיפה הסתיימה בלי כפר מוכרע; לא תישלח תקיפה נוספת בסבב זה');
     if(round.phase==='loot-submitted'||!destroyed)return c.wait('ממתין לאימות תוצאת התקיפה וחזרת הכוחות; אין שליחה חוזרת');
   }
   const requirements=destroyed?preset.loot:preset.units;
   c.progress.battlePlan={at:Date.now(),level,islandId,phase:destroyed?'בזיזה':'תקיפה',requirements,available:null,missing:null};
   const available=await troops(c);
   if(available===null) {
     // Troops that cannot be read are never a fault: while the barracks trains, the attack
     // waits for it; otherwise the next round reads again (nothing is recruited blind).
     let training=false;try {training=/['"]buildProgress['"]\s*,\s*\d+/.test(html(await c.view('barracks')));} catch { /* No barracks view. */ }
     return c.wait(training?'מגייסת כוחות לתקיפת הברברים; ממתינה לסיום הגיוס':'בודקת את הכוחות בעיר; תנסה שוב בסבב הבא');
   }
   const missing=Object.entries(requirements).filter(([id,quantity])=>(available[id]??0)<quantity).map(([id,quantity])=>({key:id,target:quantity-(available[id]??0),label:id}));
   c.progress.battlePlan.available=available;
   c.progress.battlePlan.missing=Object.fromEntries(missing.map(entry=>[entry.key,entry.target]));
   if(missing.length) {
     if(!c.rule.autoRecruit) return c.wait('חסרים כוחות להרכב התקיפה; הפעל השלמת גיוס או גייס ידנית');
     if(!c.city.position.some(item=>item.building==='barracks')) {
       if(c.city.position.some(item=>item.isBusy))return c.wait('ממתינה לסיום הבנייה לפני הקמת מגורי חיילים');
       return uniformStep(c,{...c.rule,entries:[{key:'new:barracks',position:0,target:1,label:'מגורי חיילים'}]});
     }

     // Recruiting is part of the attack: troops already ordered are waited for, never ordered again.
     const p=c.progress,pending=p.recruitPending;
     if(pending&&Date.now()-pending.at<(pending.orders?6:2)*3600000) {
       const arrived=pending.orders&&pending.baseline?Object.entries(pending.orders).every(([id,quantity])=>(available[id]??0)>=(pending.baseline[id]??0)+quantity):false;
       if(!arrived) return {...c.wait('מגייסת כוחות לתקיפת הברברים; ממתינה לסיום הגיוס שהוזמן ב־'+new Date(pending.at).toLocaleTimeString('he-IL',{timeZone:'Asia/Jerusalem',hour:'2-digit',minute:'2-digit'})),delayMs:15*60000};
     }
     p.recruitPending=null;
     const ordered=await recruit(c,missing);
     if(ordered.orders) p.recruitPending={at:Date.now(),orders:Object.fromEntries(ordered.orders.map(order=>[String(order.id),order.quantity])),baseline:{...available}};
     p.recruitWaits=ordered.status==='waiting'?(p.recruitWaits??0)+1:0;
     return {...ordered,progress:p,idle:p.recruitWaits>=3};
   }
   let home=island;
   if(remote) {
     home=commands(await c.request({view:'island',islandId:ownIsland})).find(item=>item[0]==='updateBackgroundData')?.[1];
     if(String(home?.id)!==ownIsland) throw new Error('נתוני אי העיר אינם זמינים');
   }
   // Hephaestus (wonder 5) on the attacking city's island: activate it first when available.
   if(!destroyed && c.rule.hephaestus && Number(home.wonder)===5 && c.city.position.some(item=>item.building==='temple')) {
     const temple=template(await c.view('temple'));
     if(temple.js_WonderViewButton?.buttonState==='enabled') {
       await c.request({...c.base,action:'CityScreen',function:'activateWonder',position:c.building('temple').position,templateView:'temple'},true);
       const after=template(await c.view('temple'));c.ensure(after.js_WonderViewButton?.buttonState==='disabled' || Object.values(after).some(item=>item?.countdown));
       return c.changed('הופעל הנס של Hephaestus לפני התקיפה');
     }
   }
   const resourceFields=['resource','tradegood1','tradegood2','tradegood3','tradegood4'];
   const resources=resourceFields.map(key=>globalThis.IkariamReadInsights.numeric(data['js_islandBarbarianResource'+key]?.text));
   if(resources.some(value=>value===null)) throw new Error('מטען הבזיזה אינו זמין');
   const loot=resources.reduce((sum,value)=>sum+value,0);
   if(round&&destroyed&&loot===0)return finish(round.phase==='attack-submitted'?'done':'skipped',round.phase==='attack-submitted'?'התקיפה הסתיימה ואין מטען נוסף לבזיזה':'הכפר כבר נבזז; העיר דולגה ללא שליחה');
   if(destroyed&&loot===0) return {...c.wait('הכפר נבזז; ממתינה להתחדשות הברברים'),idle:true};
   let speed=Infinity,weight=0;
   if(destroyed||remote) for(const [id,quantity] of Object.entries(requirements)) {
     const unit=await unitData(c,id);speed=Math.min(speed,unit.speed);
     if(remote) {if(unit.weight===null) throw new Error('משקל הכוח אינו זמין להפלגה לאי אחר');weight+=unit.weight*quantity;}
   }
   // attackBarbarians.calc_travel_time
   const travel=remote?Math.ceil(1200*Math.hypot(N(home.xCoord)-N(island.xCoord),N(home.yCoord)-N(island.yCoord))):Math.ceil(36000/speed);
   if((destroyed||remote)&&!Number.isFinite(travel)) throw new Error('זמן ההגעה לאי היעד אינו זמין');
   if(destroyed) {
     const timer=data.barbarianCityCooldownTimer?.countdown;
     if(N(timer?.enddate)===null || N(timer?.currentdate)===null) throw new Error('זמן התחדשות הברברים אינו זמין לבזיזה בטוחה');
     if(travel+5>=Number(timer.enddate)-Number(timer.currentdate)) return c.wait('אין מספיק זמן להגיע לבזיזה לפני התחדשות הברברים');
   }
   const navy=commands(await c.request({view:'merchantNavy'}));
   const capacity=N(navy.find(item=>item[1]?.singleTransporterCapacity!==undefined)?.[1]?.singleTransporterCapacity);
   const header=await c.rawHeader(),ships=N(header.freeTransporters);
   if(capacity===null||capacity<=0||ships===null) throw new Error('קיבולת או מספר ספינות המסחר אינם זמינים');
   const troopShips=Math.ceil(weight/capacity);
   if(ships<=0 || ships<troopShips) return c.wait(remote?'ממתינה לספינות מסחר להובלת הכוחות לאי היעד':'ממתינה לספינות מסחר לבזיזה');
   // A full plunder (Firefox, user decision 2026-10-22: the high villages are worth every merchant ship,
   // even all of them): while the barbarians have time before they recover, the loot waits for the ships
   // it needs (90% of them at least) instead of leaving with the few that are free. The supply to the main
   // account keeps its priority on the ships (barbarian-ships-v1 only reports the wait). Close to the
   // recovery it leaves with what there is.
   const firefoxPlunder=globalThis.chrome?.runtime?.getManifest&&!/\bmain\b/.test(chrome.runtime.getManifest()?.version_name??'');
   if(firefoxPlunder&&destroyed&&loot>0) {
     const needed=troopShips+Math.ceil(loot/capacity),timer=data.barbarianCityCooldownTimer?.countdown,left=Number(timer?.enddate)-Number(timer?.currentdate);
     const holds=(await chrome.storage.local.get('barbarian-ships-v1'))['barbarian-ships-v1']??{};
     if(ships<Math.ceil(needed*0.9)&&Number.isFinite(left)&&left>travel+1800) {
       await chrome.storage.local.set({'barbarian-ships-v1':{...holds,[c.rule.accountKey]:{needed,free:ships,cityId:String(c.rule.cityId),at:Date.now()}}});
       return c.wait('ממתינה לספינות לבזיזה מלאה: '+ships+' מתוך '+needed+' פנויות (האספקה לחשבון הראשי קודמת)');
     }
     if(holds[c.rule.accountKey]) {const next={...holds};delete next[c.rule.accountKey];await chrome.storage.local.set({'barbarian-ships-v1':next});}
   }
   const payload={action:'transportOperations',function:'attackBarbarianVillage',islandId,destinationCityId:0,transporter:Math.min(ships,troopShips+Math.ceil(loot/capacity)),barbarianVillage:1,backgroundView:'island',currentIslandId:islandId,templateView:'plunder',ajax:1};
   const upkeep={304:3,315:1,302:4,303:3,312:15,309:45,307:15,306:25,305:30,311:20,310:10};
   for(const [id,cost] of Object.entries(upkeep)){payload['cargo_army_'+id+'_upkeep']=cost;payload['cargo_army_'+id]=0;}
   for(const [id,quantity] of Object.entries(requirements)) payload['cargo_army_'+id]=quantity;
   if(round) {round.phase=destroyed?'loot-submitted':'attack-submitted';round.sentAt=Date.now();round.accepted=false;round.observed=false;await saveRound();}
   try {await c.request(payload,true);}catch(error){if(round&&error.mutationSubmitted===false){round.phase='preparing';await saveRound();}throw error;}
   const after=bridge.advisorMovements(commands(await c.request({...c.base,view:'militaryAdvisor',oldView:'city',oldBackgroundView:'city'})));
   c.ensure(after.some(movement=>Number(movement.event?.mission)===13 && String(movement.target?.islandId)===islandId && !movements.some(old=>String(old.event?.id)===String(movement.event?.id)) && String(movement.origin?.cityId??movement.origin?.id)===c.rule.cityId));
   const eta=destroyed||remote?' · הגעה משוערת בעוד '+Math.round(travel/60)+' דקות':'';
   const gold={stock:N(header.gold),net:globalThis.IkariamGameAutomationExtras?.netGold(header)??null,at:Date.now()};
   if(round){round.accepted=true;await saveRound();}
   return {gold,...c.changed((destroyed?'נשלחה בזיזה לכפר הברברים':'נשלחה תקיפה '+(custom?'בהרכב מותאם':'בהרכב Ikabot')+' לרמת ברברים '+level)+(remote?' באי אחר':'')+eta),cycle:!destroyed};
 }
 // Battle reinforcement (see battle-reinforce.js). One rule per battle; every check does at most
 // one game action: a send of units that are ready, else one recruitment order. The round is read
 // again every 16 minutes. Plan per city in progress.plan: {toTrain, ordered, sent}.
 async function reinforce(c) {
   const B=globalThis.IkariamBattle,rule=c.rule,p=c.progress,unit=String(rule.battleUnit),now=Date.now();
   if(!B) throw new Error('מודול הקרב אינו זמין');
   p.plan??={};p.sent=(p.sent??[]).filter(item=>item.arrival>now-3600000);
   const snapshot=(await chrome.storage.local.get('account-snapshot-'+rule.accountKey))['account-snapshot-'+rule.accountKey]?.snapshot;
   const cities=(snapshot?.cities??[]).filter(city=>(city.buildings??[]).some(item=>item.building==='barracks')&&(!rule.battleCities?.length||rule.battleCities.includes(String(city.id))));
   if(!cities.length) return c.wait('אין בחשבון ערים עם מגורי חיילים');
   const at=(city,extra)=>({cityId:String(city.id),currentCityId:String(city.id),backgroundView:'city',ajax:1,...extra});
   const coords=city=>{const [x,y]=String(city.coordinates??'').match(/\d+/g)??[];return {x:Number(x),y:Number(y)};};
   // 1. Every 16 minutes: the latest round of the battle at the target city.
   if(now-(p.readAt??0)>=16*60000||!p.battle) {
     p.readAt=now;
     const list=B.parseCombatList(html(await c.request({...c.base,view:'militaryAdvisorCombatList'})));
     let found=null;
     for(const battle of list.filter(item=>item.running).slice(0,6)) {
       const report=B.parseReport(html(await c.request({...c.base,view:'militaryAdvisorReportView',combatId:battle.combatId})));
       if(report.running&&report.round&&(!rule.battleCityName||report.place.includes(rule.battleCityName))) {found={...battle,...report};break;}
     }
     if(!found) {
       const had=!!p.battle;p.battle=null;for(const entry of Object.values(p.plan)) entry.toTrain=0;
       if(!list.length&&!p.listDebug) p.listDebug={at:now,snippet:'no battles parsed'};
       return {...c.wait(had?'הקרב ב'+(rule.battleCityName||'יעד')+' הסתיים; הגיוס נעצר (יחידות שכבר גויסו נשארות בעיר)':'ממתינה לקרב שרץ ב'+(rule.battleCityName||'יעד')),delayMs:16*60000};
     }
     let round=B.parseRound(html(await c.request({...c.base,view:'militaryAdvisorDetailedReportView',combatRound:found.round.round,detailedCombatId:found.round.detailedCombatId})));
     if(round.total&&round.round!==round.total) round=B.parseRound(html(await c.request({...c.base,view:'militaryAdvisorDetailedReportView',combatRound:round.total,detailedCombatId:found.round.detailedCombatId})));
     const side=B.ourSide(round,c.initial.ownerName,rule.battleMission),mine=round.sides[side]?.[unit];
     if(!mine&&!Object.keys(round.sides.attacker).length&&!Object.keys(round.sides.defender).length) {
       p.roundDebug={at:now,snippet:html(await c.request({...c.base,view:'militaryAdvisorDetailedReportView',combatRound:found.round.round,detailedCombatId:found.round.detailedCombatId})).replace(/actionRequest[^,&<]{0,80}/gi,'actionRequest=…').slice(0,4000)};
       return c.wait('דוח הסיבוב לא פוענח; נשמרה דוגמה לתיקון — לא גויס ולא נשלח דבר');
     }
     // Not one unit of ours in the first round read: the side or the unit was not recognised —
     // never train a whole army on that; a later zero (all lost) after units were seen is real.
     if(!mine&&!(p.battle?.present>0)) {p.roundDebug={at:now,side,units:{attacker:Object.keys(round.sides.attacker),defender:Object.keys(round.sides.defender)}};return {...c.wait('יחידות '+unit+' של החשבון לא נמצאו בקרב; לא גויס דבר — בדוק את סוג היחידה ואת עיר היעד'),delayMs:16*60000};}
     const present=(mine?.field??0)+(mine?.reserve??0),enRoute=p.sent.filter(item=>item.arrival>now).reduce((sum,item)=>sum+item.amount,0);
     const pending=Object.values(p.plan).reduce((sum,entry)=>sum+(entry.toTrain??0)+(entry.ordered??0),0);
     const gap=Math.max(0,rule.battleTarget-present-enRoute-pending);
     p.battle={at:now,combatId:found.combatId,place:found.place,round:round.round,total:round.total,side,present,lost:mine?.lost??0,enRoute,pending,gap};
     if(gap>0) {
       const speed=(await unitData(c,unit)).speed,target=rule.battleCoords;
       const options=cities.map(city=>({cityId:String(city.id),unitSeconds:p.unitSeconds?.[city.id]??rule.battleUnitSeconds??300,queueSeconds:0,travelSeconds:target?B.travelSeconds(coords(city),target,speed):0}));
       const {plan}=B.allocate(gap,options,{chunk:10,now});
       for(const item of plan) {(p.plan[item.cityId]??={toTrain:0,ordered:0,sent:0}).toTrain+=item.amount;p.plan[item.cityId].arrival=item.arrival;}
     }
   }
   if(!p.battle) return c.wait('ממתינה לקרב שרץ');
   const name=city=>bridge.decodeUnicodeEscape(city.name);
   // 2. Units that are ready go to the battle first (the game's own mission form).
   for(const city of cities) {
     const entry=p.plan[String(city.id)];if(!entry?.ordered) continue;
     const counts=armyCounts(await c.request(at(city,{view:'cityMilitary',activeTab:'tabUnits',currentTab:'tabUnits',templateView:'cityMilitary'})));
     const ready=Math.min(entry.ordered,counts?.[unit]??0);if(ready<=0) continue;
     const view={station:{view:'deployment',deploymentType:'army'},pillage:{view:'plunder'},defend:{view:'defendCity'}}[rule.battleMission];
     const source=html(await c.request(at(city,{...view,destinationCityId:rule.battleCityId})));
     const fields=B.parseMissionForm(source);
     if(!fields) {p.formDebug={at:now,mission:rule.battleMission,snippet:source.replace(/actionRequest[^,&<]{0,80}/gi,'actionRequest=…').slice(0,4000)};return c.wait('טופס המשימה לא זוהה; נשמרה דוגמה לתיקון — לא נשלח דבר');}
     delete fields.actionRequest;
     for(const key of Object.keys(fields)) if(/^cargo_army_\d+$/.test(key)) fields[key]=0;
     fields['cargo_army_'+unit]=ready;
     if('transporter' in fields&&String(city.islandId)!==String(rule.battleIslandId??city.islandId)) {
       const capacity=N(commands(await c.request({view:'merchantNavy'})).find(item=>item[1]?.singleTransporterCapacity!==undefined)?.[1]?.singleTransporterCapacity);
       const weight=(await unitData(c,unit)).weight;
       if(!capacity||weight===null) throw new Error('קיבולת הספינות או משקל היחידה אינם זמינים');
       fields.transporter=Math.ceil(ready*weight/capacity);
     }
     const before=bridge.advisorMovements(commands(await c.request({...c.base,view:'militaryAdvisor',oldView:'city',oldBackgroundView:'city'})));
     await c.request({...fields,currentCityId:String(city.id),backgroundView:'city',ajax:1},true);
     const after=bridge.advisorMovements(commands(await c.request({...c.base,view:'militaryAdvisor',oldView:'city',oldBackgroundView:'city'})));
     c.ensure(after.some(movement=>!before.some(old=>String(old.event?.id)===String(movement.event?.id))&&String(movement.origin?.cityId??movement.origin?.id)===String(city.id)));
     const speed=(await unitData(c,unit)).speed,arrival=now+(rule.battleCoords?B.travelSeconds(coords(city),rule.battleCoords,speed):0)*1000;
     entry.ordered-=ready;entry.sent+=ready;p.sent.push({cityId:String(city.id),amount:ready,at:now,arrival});
     return {...c.changed('נשלחו '+ready+' יחידות מ'+name(city)+' לקרב ב'+(p.battle.place||rule.battleCityName)+' · הגעה '+new Date(arrival).toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'})),cycle:false};
   }
   // 3. Otherwise one recruitment order, nearest arrival first — not while the gold balance is
   // negative and the gold in stock would not last 12 hours (the army's upkeep only adds to it).
   const globalHeader=commands(await c.request({view:'updateGlobalData',ajax:1}))[0]?.[1]?.headerData,net=netGold(globalHeader),gold=N(globalHeader?.gold);
   if(net!==null&&net<0&&!(gold!==null&&gold>-net*12)) return {...c.wait('מאזן הזהב שלילי ('+Math.round(net)+' לשעה) והזהב במלאי לא יחזיק 12 שעות — הגיוס לתגבורת ממתין; הסוכן מחזיר מדענים ופועלים לאזרחים'),delayMs:10*60000};
   for(const city of cities.filter(city=>p.plan[String(city.id)]?.toTrain>0).sort((a,b)=>(p.plan[String(a.id)].arrival??0)-(p.plan[String(b.id)].arrival??0))) {
     const entry=p.plan[String(city.id)],barracks=city.buildings.find(item=>item.building==='barracks');
     const source=await c.request(at(city,{view:'barracks',position:barracks.position}));
     if(/['"]buildProgress['"]\s*,\s*\d+/.test(html(source))) continue;
     const home=await c.request({view:'city',cityId:String(city.id)});
     const stock=bridge.parseAvailableResources(home),citizens=N(home.match(/\\?"citizens\\?":\s*\\?"?(\d+)/)?.[1]);
     if(!stock||citizens===null) continue;
     const orders=globalThis.IkariamAutomationRules.trainingPlan([{key:unit,target:entry.toTrain}],recipeData(source),stock,citizens,0);
     if(!orders.length) continue;
     await c.request(at(city,{action:'CityScreen',function:'buildUnits',position:barracks.position,templateView:'barracks',[unit]:orders[0].quantity}),true);
     c.ensure(/['"]buildProgress['"]\s*,\s*\d+/.test(html(await c.request(at(city,{view:'barracks',position:barracks.position})))));
     entry.toTrain-=orders[0].quantity;entry.ordered+=orders[0].quantity;
     return {...c.changed('גויסו '+orders[0].quantity+' '+orders[0].label+' ב'+name(city)+' לתגבור הקרב · נשארו לגייס '+Object.values(p.plan).reduce((sum,item)=>sum+item.toTrain,0)),cycle:false};
   }
   const b=p.battle;
   return {...c.wait('קרב ב'+(b.place||rule.battleCityName)+' · סיבוב '+(b.round??'?')+(b.total?'/'+b.total:'')+' · בשדה ובעתודה '+b.present+' מתוך '+rule.battleTarget+' · בדרך '+b.enRoute+' · אבדו בסיבוב '+b.lost),delayMs:Math.max(60000,(p.readAt??now)+16*60000-now)};
 }
 async function checkPiracy(rule) {
   const c=await context(rule);
   try {
     const match=c.home.replace(/\\"/g,'"').match(/"showPirateFortressShip"\s*:\s*([01])/);
     if(!match)throw new Error('מצב משימת הפיראטים לא פוענח');
     return {active:match[1]==='0',checkedAt:Date.now()};
   } finally {await c.restore();}
 }
 // The raids table's live target check (reads only; see extras.raidProbe).
 async function raidProbe(rule,playerName,cities) {
  let c;try {c=await context(rule);c.building('pirateFortress');return await extras.raidProbe(c,playerName,cities);}
  catch(error) {error.mutationSubmitted=false;throw error;} finally {if(c) await c.restore();}
 }
 return {catalog,step,checkPiracy,raidProbe,vacation:accountKey=>extras.vacation(accountKey)};
}
globalThis.IkariamGameAutomationActions={commands,template,recipeData,workshopData,researchData,armyCounts,presets,createActions};
})();

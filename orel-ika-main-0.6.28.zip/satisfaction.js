// Satisfaction guard (Firefox edition, user decision 2026-10-20 — the first of all tasks): a city
// whose citizens are unhappy loses citizens, and fewer citizens mean less gold and fewer resources.
// Every city of every account is read from its town hall (satisfaction, population growth per
// hour, taken by the account read); a city with negative satisfaction or a shrinking population
// gets wine first (its tavern serves the most wine), its governor's residence first when the
// colony is corrupt (it needs the number of cities − 1, Ikariam's government rule) and its tavern
// next in the building queue. A city whose values were not read is reported, never assumed happy.
(() => {
const level=(city,building)=>Number((city?.buildings??[]).find(item=>item?.building===building)?.level)||0;
const has=(city,building)=>(city?.buildings??[]).some(item=>item?.building===building);
const position=(city,building)=>{const found=(city?.buildings??[]).find(item=>item?.building===building);return Number.isInteger(Number(found?.position))?Number(found.position):null;};
const number=value=>value===null||value===undefined||value===''?null:Number.isFinite(Number(value))?Number(value):null;
// What the user is offered for an unhappy city (user decision, 2026-10-20): the governor's
// residence up to the level that ends corruption; without corruption, the tavern by one level
// for every 12 points of missing satisfaction (an estimate, 1 to 5 levels). Approved, it becomes
// a building queue for the city that brings its materials from the account's other cities.
// A missing building is offered too (user decision, 2026-10-20): built on a free plot, level 1; the
// next offer raises it once the city is read again.
function proposal({satisfaction,unhappy,corrupt,governor,needed,city}) {
  if(!unhappy) return [];
  if(corrupt) return has(city,'palaceColony')?[{building:'palaceColony',label:'מגורי מושל',position:position(city,'palaceColony'),from:governor,to:needed}]:[{building:'palaceColony',label:'מגורי מושל',position:null,from:0,to:1,build:true}];
  if(!has(city,'tavern')) return [{building:'tavern',label:'בית מרזח',position:null,from:0,to:1,build:true}];
  const from=level(city,'tavern'),steps=Math.max(1,Math.min(5,Math.ceil(Math.max(0,-(satisfaction??0))/12)||1));
  return [{building:'tavern',label:'בית מרזח',position:position(city,'tavern'),from,to:from+steps}];
}
function assess(cities) {
  const list=Array.isArray(cities)?cities:[];
  const capitalOf=city=>city?.isCapital===true||has(city,'palace');
  const hasCapital=list.some(capitalOf);
  return list.map(city=>{
    const satisfaction=number(city?.population?.satisfaction),growth=number(city?.populationGrowthPerHour);
    const capital=capitalOf(city),governor=level(city,'palaceColony'),needed=Math.max(0,list.length-1);
    const corrupt=hasCapital&&!capital&&governor<needed;
    const unhappy=satisfaction!==null&&satisfaction<0||growth!==null&&growth<0;
    const unknown=satisfaction===null&&growth===null;
    const reasons=[];
    if(satisfaction!==null&&satisfaction<0) reasons.push('שביעות רצון '+satisfaction);
    if(growth!==null&&growth<0) reasons.push('האוכלוסייה יורדת ('+growth+' לשעה)');
    if(corrupt) reasons.push('שחיתות: מגורי מושל '+(has(city,'palaceColony')?'ברמה '+governor:'לא בנויים')+' — נדרשת רמה '+needed);
    if(unhappy&&!has(city,'tavern')) reasons.push('אין בית מרזח בעיר');
    if(unhappy&&number(city?.resources?.wine)===0) reasons.push('אין יין בעיר');
    return {cityId:String(city?.id),name:city?.name??String(city?.id),satisfaction,growth,unhappy,unknown,corrupt,governor,needed,
      tavern:has(city,'tavern')?level(city,'tavern'):null,reasons,positions:{palaceColony:position(city,'palaceColony'),tavern:position(city,'tavern')},proposal:proposal({satisfaction,unhappy,corrupt,governor,needed,city})};
  });
}
globalThis.IkariamSatisfaction={assess};
})();

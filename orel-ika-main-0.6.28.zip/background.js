// Mode A background service worker (docs/ARCHITECTURE.md §1, §5). Pure
// relay: the side panel asks "is there a real connection", this finds an
// open Ikariam tab and asks ITS content script to read its own page. No
// game credentials or login requests. Optional Telegram delivery is handled
// separately by game-automation-runtime.js with session-only bot credentials.
//
// Logs every step with an [ikariam-agent] prefix — check this file's own
// console via chrome://extensions -> "עוזר איקריאם" card -> "service worker"
// link ("Inspect views") when diagnosing a connection that isn't working.

import { createTransportRuntime } from "./transport-automation.js";
import { createGameAutomationRuntime } from "./game-automation-runtime.js";
import { createTabRefresh, reloadGameTab } from "./tab-refresh.js";
import { createTabWatchdog } from "./tab-watchdog.js";
import { createHealthReport } from "./health-report.js";
import { createAutopilot } from "./autopilot.js";
import { createWarMode } from "./war-mode.js";
import { createRaidPlayers } from "./raid-players.js";
import { createUpdateCheck } from "./update-check.js";
import { createMainSupplyBridge } from "./main-supply-bridge.js";
import { createMainCaptureRanking } from "./main-capture-ranking.js";
import { createFirefoxCapturePoints } from "./firefox-capture-points.js";
const LOG_PREFIX = "[ikariam-agent:background]";
// Firefox-only modules are loaded only in Firefox (user report, 2026-10-25): Opera runs this file as a
// module service worker, where a dynamic import() is refused by the HTML specification; Firefox's build
// bundles these imports into the file. In Opera both modules would do nothing anyway.
const FIREFOX_EDITION=!/\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name??'');
// Firefox reads the main account's shortages from the local bridge (observation only, no shipment).
if(FIREFOX_EDITION) void import('./firefox-supply-bridge.js').then(module=>{module.startFirefoxSupplyBridge(chrome);console.log(LOG_PREFIX,'firefox-supply-bridge loaded');}).catch(error=>console.warn('[firefox-bridge]',error.message));
else console.log(LOG_PREFIX,'firefox-supply-bridge skipped: Opera main edition');

chrome.runtime.onInstalled.addListener((details) => {
  console.log(LOG_PREFIX, "installed/updated");
  void configurePanelBehavior();
  // Firefox and Opera: after an update or a reload of the extension the open game tabs lose the agent until
  // they are reloaded (user reports, 2026-10-25: every account "not connected" after each Firefox update;
  // Opera's scans stopped until its game tab was refreshed). They are reloaded one by one, five seconds
  // apart, starting ten seconds after the update; their runs were already cut by the update.
  if(details?.reason==="update"&&typeof setTimeout==="function") setTimeout(async()=>{
    const tabs=(await chrome.tabs.query({})).filter(tab=>/^https:\/\/s\d+-\w+\.ikariam\.gameforge\.com\//.test(tab.url??""));
    for(const [index,tab] of tabs.entries()) setTimeout(()=>{void chrome.tabs.reload(tab.id).catch(()=>{});},index*5000);
  },10000);
});

async function configurePanelBehavior() {
  try {
    await chrome.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: false });
  } catch (error) {
    console.warn(LOG_PREFIX, "side panel configuration unavailable", error);
  }
}
void configurePanelBehavior();

// Opera may expose no Chromium sidePanel API. Use the identical extension
// application in a normal tab, without additional permissions or game requests.
let openingApplication = null;
async function openApplicationTab() {
  if (openingApplication) return openingApplication;
  openingApplication = (async () => {
    const url = chrome.runtime.getURL("sidepanel.html");
    const existing = (await chrome.tabs.query({})).find(tab => tab.url === url);
    if (existing) {
      await chrome.tabs.update(existing.id, { active: true });
      if (chrome.windows?.update && existing.windowId !== undefined)
        await chrome.windows.update(existing.windowId, { focused: true });
    } else {
      await chrome.tabs.create({ url, active: true });
    }
  })();
  try { await openingApplication; } finally { openingApplication = null; }
}

// The toolbar button opens the full-window application (preferred for many
// accounts). The side panel / Firefox sidebar stays available from the browser menu.
chrome.action?.onClicked.addListener(() => {
  void openApplicationTab().catch(error => console.error(LOG_PREFIX, "application opening failed", error));
});

let boundTabId = null;
let boundAccountKey = null;
const readerFiles = ["page-fetch.js","transport-plan.js","account-policy.js","read-insights.js","automation-rules.js","game-automation-extra.js","game-automation-actions.js","content-script.js"];
// Opera recovery must load the same construction dependency as manifest injection.
const MAIN_SUPPLY_EDITION=/\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name??'');
if(MAIN_SUPPLY_EDITION)readerFiles.splice(readerFiles.indexOf('game-automation-actions.js'),0,'build-forecast.js');
// The agent's build list in the game's sidebar (Opera only, 2026-10-28) is restored with the readers.
if(MAIN_SUPPLY_EDITION)readerFiles.push('agent-build-queue.js');
// No bridge listeners, alarms or requests are created in Firefox.
if(MAIN_SUPPLY_EDITION)createMainSupplyBridge(chrome);
// Opera (unpacked) reloads itself after a new build, once nothing is in flight (user decision,
// 2026-10-22: no manual reload after an update).
if(MAIN_SUPPLY_EDITION&&typeof setInterval==='function'&&typeof fetch==='function'&&chrome.runtime?.reload){
  const stamp=async()=>{try{return (await (await fetch(chrome.runtime.getURL('build-stamp.json'),{cache:'no-store'})).json()).at??null;}catch{return null;}};
  let first=null;void stamp().then(value=>{first=value;});
  setInterval(async()=>{
    const current=await stamp();if(!first||!current||current===first)return;
    const values=await chrome.storage.local.get(['game-automations-v1','transport-automation-v1']);
    const busy=[...(values['game-automations-v1']?.rules??[]),...(values['transport-automation-v1']?.rules??[])].some(rule=>rule.inFlight&&!rule.deleted);
    if(!busy)chrome.runtime.reload();
  },300000);
}
// Opera: after the computer slept (or the browser was closed) the game tab no longer sends its scans
// until it is refreshed (user report, 2026-10-26: no scan from 16:32 until a manual refresh at 23:35).
// A one-minute heartbeat notices the gap; after more than five minutes without one, the game tabs are
// reloaded at the next beat (a minute later, so the network is back), one by one, two seconds apart.
// The marks are stored, so a service worker that was stopped in between still does it.
if(MAIN_SUPPLY_EDITION&&chrome.alarms&&chrome.tabs?.reload&&typeof setTimeout==='function') {
  const BEAT='main-wake-beat-v1',PENDING='main-wake-reload-v1';
  chrome.alarms.create('main-wake-check',{periodInMinutes:1});
  chrome.alarms.onAlarm.addListener(async alarm=>{
    if(alarm.name!=='main-wake-check') return;
    const now=Date.now(),stored=await chrome.storage.local.get([BEAT,PENDING]),last=stored[BEAT]??now;
    await chrome.storage.local.set({[BEAT]:now});
    if(now-last>300000) {console.log(LOG_PREFIX,'woke after',Math.round((now-last)/60000),'minutes; the game tabs reload at the next beat');await chrome.storage.local.set({[PENDING]:now});return;}
    if(!stored[PENDING]) return;
    await chrome.storage.local.remove(PENDING);
    const tabs=(await chrome.tabs.query({})).filter(tab=>GAME_TAB.test(tab.url??''));
    for(const [index,tab] of tabs.entries()) setTimeout(()=>{void chrome.tabs.reload(tab.id).catch(()=>{});},index*2000);
  });
}
const mainSupplyModulesReady=new Set();
if(MAIN_SUPPLY_EDITION)chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type!=='IKARIAM_AGENT_MAIN_SUPPLY_REVISION')return false;
  sendResponse({ok:true,revision:'2026-10-20-city-supply-v1'});return false;
});
async function ensureMainSupplyModules(tabId){
  if(!MAIN_SUPPLY_EDITION||mainSupplyModulesReady.has(tabId))return;
  // These files only define pure helpers. Never reinject the content listener
  // or replay an action just because an already-open tab lacks a dependency.
  await chrome.scripting.executeScript({target:{tabId},files:['account-policy.js','build-forecast.js']});
  mainSupplyModulesReady.add(tabId);
}
const pageIdentity = page => page?.found && page.ownerName && page.mundo && page.servidor
  ? [page.ownerName,page.mundo,page.servidor].join("|") : null;
async function sendReadMessage(tabId,message){
  // Only short, read-only identity/ack messages are bounded here. Never retry mutations.
  const pending=chrome.tabs.sendMessage(tabId,message);
  if(!MAIN_SUPPLY_EDITION||!['IKARIAM_AGENT_PARSE_PAGE','IKARIAM_AGENT_READ_ACCOUNT_JOB'].includes(message.type))return pending;
  let timer;
  try{return await Promise.race([pending,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('לשונית המשחק לא אישרה את בקשת הקריאה בזמן')),8000);})]);}
  finally{clearTimeout(timer);}
}
async function recoverRead(tab, message) {
  // This function is only used for the explicitly allowlisted read messages.
  // Never resend transport or other mutation commands here.
  for (let attempt = 0; attempt < 8; attempt++) {
    if (attempt) await new Promise(resolve => setTimeout(resolve, 1500));
    try {
      const page = await sendReadMessage(tab.id, {type:"IKARIAM_AGENT_PARSE_PAGE"});
      const key = pageIdentity(page);
      if (!key) continue;
      // A read for a specific account must reach that account's tab, never another one.
      const expected=message.accountKey??boundAccountKey;
      if (expected && key !== expected)
        return {ok:false,reason:"החשבון בלשונית המשחק השתנה. יש להתחבר מחדש לפני המשך העבודה."};
      if(!message.accountKey) boundAccountKey = key;
      const response=await sendReadMessage(tab.id, message);
      if(response) return response;
    } catch {
      if (attempt === 0) {
        try { await chrome.scripting.executeScript({target:{tabId:tab.id},files:readerFiles}); }
        catch { /* Navigation can temporarily prevent injection. */ }
      }
    }
  }
  return {ok:false,reason:"לשונית המשחק עדיין נטענת או אינה מגיבה. הקריאה תיבדק שוב; לא נשלחה פעולה נוספת."};
}
// The tab the user selected in the account picker survives a worker restart.
const boundRestored=chrome.storage.session?.get?.("bound-tab").then(stored=>{
  if(boundTabId===null && stored?.["bound-tab"]) ({tabId:boundTabId,accountKey:boundAccountKey}=stored["bound-tab"]);
}).catch(()=>{});
const GAME_TAB=/^https:\/\/s\d+-\w+\.ikariam\.gameforge\.com\//;
const within=(promise,ms)=>Promise.race([promise,new Promise(resolve=>setTimeout(()=>resolve(null),ms))]);
async function describeTab(tab) {
  let page=null;
  // An unloaded (discarded) tab has no running page; it is listed and reloaded on selection.
  if(!tab.discarded) {
    try {page=await within(chrome.tabs.sendMessage(tab.id,{type:"IKARIAM_AGENT_PARSE_PAGE"}),6000);}
    catch {
      try {await chrome.scripting.executeScript({target:{tabId:tab.id},files:readerFiles});page=await within(chrome.tabs.sendMessage(tab.id,{type:"IKARIAM_AGENT_PARSE_PAGE"}),6000);}
      catch { /* Still loading; listed as unidentified. */ }
    }
  }
  try {if(tab.autoDiscardable!==false) await chrome.tabs.update(tab.id,{autoDiscardable:false});} catch { /* Not supported by every browser. */ }
  let container=null;
  // Firefox Multi-Account Containers: show the container name next to the account.
  try {if(tab.cookieStoreId && tab.cookieStoreId!=="firefox-default" && globalThis.browser?.contextualIdentities) container=(await browser.contextualIdentities.get(tab.cookieStoreId))?.name??null;} catch { /* Permission or containers unavailable. */ }
  return {tabId:tab.id,accountKey:pageIdentity(page),ownerName:page?.ownerName??null,world:page?.mundo??null,server:page?.servidor??null,cityName:page?.cityName??null,container,selected:tab.id===boundTabId,
    discarded:tab.discarded===true,title:tab.title??null};
}
// Fix offered next to read errors: reload one account's tab, never during a submitted action.
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type!=="IKARIAM_AGENT_RELOAD_ACCOUNT_TAB") return false;
  (async()=>{
    const tab=typeof message.accountKey==="string"?await findAccountTab(message.accountKey):(await chrome.tabs.query({})).find(item=>item.id===message.tabId&&GAME_TAB.test(item.url??""));
    if(!tab?.id) {sendResponse({ok:false,reason:"לשונית החשבון לא נמצאה"});return;}
    const stored=await chrome.storage.local.get(["game-automations-v1","transport-automation-v1"]);
    // Only this account's own running action blocks the reload; a tab that is not signed in runs nothing.
    const own=rule=>typeof message.accountKey==="string"&&rule.accountKey===message.accountKey;
    const busy=(stored["game-automations-v1"]?.rules??[]).some(rule=>own(rule)&&rule.inFlight&&!rule.uncertain)||(stored["transport-automation-v1"]?.rules??[]).some(rule=>own(rule)&&rule.inFlight);
    if(busy) {sendResponse({ok:false,reason:"אוטומציה באמצע שליחת פעולה; נסה שוב בעוד דקה"});return;}
    tabAccounts.delete(tab.id);await reloadGameTab(chrome,tab);sendResponse({ok:true});
  })().catch(error=>sendResponse({ok:false,reason:error.message}));
  return true;
});
// The game tab's queue of one account, for the raids panel: what runs, what waits, and taking a
// waiting job out of it.
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type!=="IKARIAM_AGENT_TAB_QUEUE") return false;
  (async()=>{
    const tab=typeof message.accountKey==="string"?await findAccountTab(message.accountKey):null;
    if(!tab?.id) {sendResponse({ok:false,reason:"לשונית החשבון לא נמצאה"});return;}
    const type={cancel:"IKARIAM_AGENT_QUEUE_CANCEL",stop:"IKARIAM_AGENT_QUEUE_STOP",crew:"IKARIAM_AGENT_PIRATE_LIVE"}[message.operation]??"IKARIAM_AGENT_QUEUE_LIST";
    sendResponse(await chrome.tabs.sendMessage(tab.id,{type,index:message.index,label:message.label,operationId:message.operationId,since:message.since,cityId:message.cityId}));
  })().catch(error=>sendResponse({ok:false,reason:error.message}));
  return true;
});
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(!["IKARIAM_AGENT_LIST_ACCOUNTS","IKARIAM_AGENT_SELECT_ACCOUNT"].includes(message?.type)) return false;
  (async()=>{
    await boundRestored;
    const tabs=(await chrome.tabs.query({})).filter(tab=>GAME_TAB.test(tab.url??""));
    if(message.type==="IKARIAM_AGENT_LIST_ACCOUNTS") {sendResponse({ok:true,accounts:await Promise.all(tabs.map(describeTab))});return;}
    const tab=tabs.find(item=>item.id===message.tabId);
    if(!tab) {sendResponse({ok:false,reason:"לשונית החשבון נסגרה"});return;}
    let account=await describeTab(tab);
    if(!account.accountKey) {
      // Reload an unloaded or unresponsive account tab and wait for the game to identify it.
      try {await reloadGameTab(chrome,tab);} catch { /* The tab may still be loading. */ }
      for(let attempt=0;attempt<16&&!account.accountKey;attempt++) {
        await new Promise(resolve=>setTimeout(resolve,1500));
        account=await describeTab(await chrome.tabs.get(tab.id));
      }
    }
    if(!account.accountKey) {sendResponse({ok:false,reason:"החשבון בלשונית לא זוהה גם אחרי טעינה מחדש. ודא שהמשחק מחובר בלשונית."});return;}
    boundTabId=tab.id;boundAccountKey=account.accountKey;
    try {await chrome.storage.session?.set?.({"bound-tab":{tabId:boundTabId,accountKey:boundAccountKey}});} catch { /* Kept in memory only. */ }
    sendResponse({ok:true,account:{...account,selected:true}});
  })().catch(error=>sendResponse({ok:false,reason:error.message}));
  return true;
});
async function findIkariamTab() {
  await boundRestored;
  const allTabs = await chrome.tabs.query({});

  const candidates = allTabs.filter((t) => /^https:\/\/s\d+-\w+\.ikariam\.gameforge\.com\//.test(t.url ?? ""));
  candidates.sort((a,b)=>Number(b.id===boundTabId)-Number(a.id===boundTabId) || Number(b.active)-Number(a.active) || (b.lastAccessed??0)-(a.lastAccessed??0));
  const match = candidates[0];
  console.log(LOG_PREFIX, match ? `found Ikariam tab: ${match.url}` : "no Ikariam tab found among open tabs");
  return match ?? null;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!["IKARIAM_AGENT_GET_REAL_CONNECTION", "IKARIAM_AGENT_READ_ACCOUNT", "IKARIAM_AGENT_READ_ACCOUNT_JOB", "IKARIAM_AGENT_READ_SECTION", "IKARIAM_AGENT_READ_CITY_VIEW", "IKARIAM_AGENT_MILITARY_DIAGNOSTICS"].includes(message?.type)) {
    return false;
  }

  console.log(LOG_PREFIX, "received IKARIAM_AGENT_GET_REAL_CONNECTION from side panel");

  (async () => {
    let tab;
    if (message.type !== "IKARIAM_AGENT_GET_REAL_CONNECTION" && typeof message.accountKey === "string") {
      // Reads for one of several open accounts (the "all accounts" views).
      tab = await findAccountTab(message.accountKey);
      if (!tab?.id) {sendResponse({ok:false,reason:"לשונית החשבון "+message.accountKey.split("|")[0]+" אינה פתוחה או לא זוהתה"}); return;}
    } else if (message.type !== "IKARIAM_AGENT_GET_REAL_CONNECTION" && boundTabId !== null) {
      try {tab = await chrome.tabs.get(boundTabId);} catch {sendResponse({ok:false,reason:"לשונית המשחק נסגרה. יש להתחבר מחדש."}); return;}
      if (!/^https:\/\/s\d+-\w+\.ikariam\.gameforge\.com\//.test(tab.url ?? "")) {
        sendResponse({ok:false,reason:"לשונית המשחק אינה זמינה."}); return;
      }
    } else {tab = await findIkariamTab();}
    if (!tab?.id) {
      console.log(LOG_PREFIX, "responding: no_tab");
      sendResponse({ ok: true, reason: "no_tab" });
      return;
    }
    if(message.type==='IKARIAM_AGENT_READ_ACCOUNT_JOB') {
      // Prevent Chromium's ordinary memory discard while the account is read.
      // Restore an already discarded document without changing tab focus.
      try {
        if(tab.autoDiscardable===true) await chrome.tabs.update(tab.id,{autoDiscardable:false});
        if(tab.discarded && chrome.tabs.reload) await chrome.tabs.reload(tab.id);
      } catch { /* Browser-specific tab policies may reject this hint. */ }
    }

    try {
      console.log(LOG_PREFIX, `sending IKARIAM_AGENT_PARSE_PAGE to tab ${tab.id}`);
      if (message.type !== "IKARIAM_AGENT_GET_REAL_CONNECTION") {
        try {
          const response=await sendReadMessage(tab.id, message);
          sendResponse(response??await recoverRead(tab,message));
        }
        catch { sendResponse(await recoverRead(tab, message)); }
        return;
      }
      let parsed;
      const deadline=Date.now()+45000;
      // A single click waits for a loading game page instead of requiring repeated clicks.
      const candidates=(await chrome.tabs.query({})).filter(t=>t.id!==tab.id && /^https:\/\/s\d+-\w+\.ikariam\.gameforge\.com\//.test(t.url??"")).slice(0,4);
      for (const candidate of [tab,...candidates]) {
        let injected=false;
        for(let attempt=0;attempt<4;attempt++) {
          if(Date.now()>=deadline) break;
          try { parsed=await chrome.tabs.sendMessage(candidate.id,{type:"IKARIAM_AGENT_PARSE_PAGE"}); }
          catch {
            parsed=null;
            if(!injected) {
              injected=true;
              try {await chrome.scripting.executeScript({target:{tabId:candidate.id},files:readerFiles});}
              catch { /* Loading pages are retried within the bound below. */ }
            }
          }
          if(parsed?.found) {tab=candidate;break;}
          if(attempt<3) await new Promise(resolve=>setTimeout(resolve,750));
        }
        if(parsed?.found) break;
        if(Date.now()>=deadline) break;
      }
      if (!parsed) {
        sendResponse({ ok: true, reason: "no_response" });
        return;
      }
      if (parsed.found) {
        boundTabId = tab.id; boundAccountKey = pageIdentity(parsed);
        try {await chrome.storage.session?.set?.({"bound-tab":{tabId:boundTabId,accountKey:boundAccountKey}});} catch { /* Kept in memory only. */ }
      }
      sendResponse({ ok: true, parsed });
    } catch (err) {
      // Most commonly: the tab was open before the extension was loaded (or
      // reloaded), so its content script was never injected. A page refresh
      // (F5) on the Ikariam tab fixes this.
      console.error(LOG_PREFIX, "chrome.tabs.sendMessage to content script failed:", err);
      sendResponse({ ok: true, reason: "no_response" });
    }
  })();

  return true; // keep the message channel open for the async response above
});

// Account-aware tab lookup for engines that serve every open account.
const tabAccounts=new Map();
// Firefox: a game tab that stopped answering (its page left behind by an extension update, or put to
// sleep by the browser) is reloaded after three missed reads, at most every ten minutes (user report,
// 2026-10-22: account tabs stayed open but "not open" for an hour and their shipments waited).
// Old run records are removed so the storage never fills (user report, 2026-10-25: Opera's storage passed
// its 10 MB and every save failed from Saturday evening). A record of a run still in flight is always kept;
// others go a day after they were written, and only the last hundred scan receipts stay.
async function pruneRunRecords() {
  const all=await chrome.storage.local.get(null),now=Date.now(),remove=[];
  const live=new Set([...(all['transport-automation-v1']?.rules??[]),...(all['game-automations-v1']?.rules??[])].map(rule=>rule.inFlight).filter(Boolean).map(String));
  for(const [key,value] of Object.entries(all)) {
    const id=key.match(/^(?:transport|game)-(?:result|progress)-(.+)$/)?.[1];
    if(!id||live.has(id)) continue;
    const at=value?.createdAt??value?.updatedAt??value?.at??null;
    if(at===null||now-at>86400000) remove.push(key);
  }
  const receipts=Object.keys(all).filter(key=>/^main-supply-scan-receipt-v2-.+-\d+$/.test(key)).sort((a,b)=>Number(b.match(/-(\d+)$/)[1])-Number(a.match(/-(\d+)$/)[1]));
  remove.push(...receipts.slice(100));
  for(let index=0;index<remove.length;index+=200) await chrome.storage.local.remove(remove.slice(index,index+200));
}
if(typeof setTimeout==='function'&&typeof setInterval==='function') {setTimeout(()=>{void pruneRunRecords().catch(()=>{});},60000);setInterval(()=>{void pruneRunRecords().catch(()=>{});},1800000);}
const tabMisses=new Map(),tabReloads=new Map();
async function reviveGameTabs(tabs) {
  for(const tab of tabs) {
    if(!(tab.discarded||(tabMisses.get(tab.id)??0)>=3)||Date.now()-(tabReloads.get(tab.id)??0)<600000) continue;
    tabReloads.set(tab.id,Date.now());tabMisses.delete(tab.id);
    try {await chrome.tabs.reload(tab.id);} catch { /* Closed meanwhile. */ }
  }
}
async function findAccountTab(accountKey) {
  if(!accountKey) return findIkariamTab();
  const tabs=(await chrome.tabs.query({})).filter(tab=>GAME_TAB.test(tab.url??""));
  const cached=tabs.find(tab=>tabAccounts.get(tab.id)===accountKey);
  for(const tab of cached?[cached,...tabs.filter(item=>item!==cached)]:tabs) {
    const key=pageIdentity(await within(chrome.tabs.sendMessage(tab.id,{type:"IKARIAM_AGENT_PARSE_PAGE"}).catch(()=>null),6000));
    if(key) {tabAccounts.set(tab.id,key);tabMisses.delete(tab.id);} else {tabAccounts.delete(tab.id);tabMisses.set(tab.id,(tabMisses.get(tab.id)??0)+1);}
    if(key===accountKey) {if(MAIN_SUPPLY_EDITION)await ensureMainSupplyModules(tab.id);return tab;}
  }
  if(!MAIN_SUPPLY_EDITION&&chrome.tabs.reload) await reviveGameTabs(tabs);
  return null;
}
// Firefox: a tab that still answers but whose game requests keep failing (user report, 2026-10-23: Orakel1
// and Orakel5 answered all night while every game read timed out, until a manual refresh) is reloaded once
// its account went unread for twenty minutes while its automations kept failing, at most every half hour.
const stuckReloads=new Map();
async function reviveStuckAccounts() {
  const values=await chrome.storage.local.get(null),rules=values['game-automations-v1']?.rules??[],now=Date.now();
  const failing=/קריאת המשחק נכשלה|timed out|חרגה מזמן ההמתנה|Failed to fetch|NetworkError/i;
  for(const key of Object.keys(values).filter(item=>item.startsWith('account-snapshot-'))) {
    const accountKey=key.slice('account-snapshot-'.length),readAt=values[key]?.at??0;
    // A tab whose game requests only time out (three or more in five minutes and none answered) is
    // reloaded at once, before the whole account freezes (user decision, 2026-10-27), at most every
    // fifteen minutes; otherwise as before, after twenty minutes unread with failing automations.
    const diag=values['diag-v1-'+accountKey],recent=now-(diag?.at??0)<180000?(diag?.buckets??[]).filter(b=>now-(b.t??0)<=300000):[];
    const timedOut=recent.reduce((sum,b)=>sum+(b.timeout??0),0),answered=recent.reduce((sum,b)=>sum+(b.req??0)-(b.timeout??0)-(b.fail??0),0);
    const freezing=timedOut>=3&&answered<=0;
    if(now-(stuckReloads.get(accountKey)??0)<(freezing?900000:1800000)) continue;
    if(!freezing&&(now-readAt<1200000||!rules.some(rule=>rule.accountKey===accountKey&&!rule.deleted&&failing.test(rule.status??'')&&now-(rule.lastRunAt??0)<900000))) continue;
    // Never while a shipment of the account was dispatched in the last five minutes (no ambiguous cargo).
    if((values['transport-automation-v1']?.rules??[]).some(rule=>rule.accountKey===accountKey&&!rule.deleted&&rule.inFlight&&now-(rule.lastRunAt??0)<300000)) continue;
    const tab=await findAccountTab(accountKey);if(!tab?.id) continue;
    stuckReloads.set(accountKey,now);
    try {await chrome.tabs.reload(tab.id);} catch { /* Closed meanwhile. */ }
  }
}
// A game tab left on the browser's load-error page ("problem loading page") is reloaded every five minutes.
const errorReloads=new Map();
async function reviveErrorTabs() {
  for(const tab of await chrome.tabs.query({})) {
    if(!GAME_TAB.test(tab.url??'')||tab.status==='loading'||/איקרים|Ikariam/i.test(tab.title??'')||Date.now()-(errorReloads.get(tab.id)??0)<300000) continue;
    errorReloads.set(tab.id,Date.now());
    try {await chrome.tabs.reload(tab.id);} catch { /* Closed meanwhile. */ }
  }
}
if(!MAIN_SUPPLY_EDITION&&typeof setInterval==='function'&&chrome.tabs?.reload) setInterval(()=>{void reviveErrorTabs().catch(()=>{});void reviveStuckAccounts().catch(()=>{});},300000);
// The AI agent was removed: delete any Anthropic API key saved by an earlier version
// and drop the optional API permission so nothing can call it.
void chrome.storage?.local?.remove?.("agent-anthropic-key")?.catch?.(()=>{});
void chrome.permissions?.remove?.({origins:["https://api.anthropic.com/*"]})?.catch?.(()=>{});
// No happiness rules from the policy report (user decision, 2026-10-15): every tavern serves the most wine.
const transportRuntime=createTransportRuntime(chrome,findAccountTab);
const gameRuntime=createGameAutomationRuntime(chrome,findAccountTab);
// Every open account collects each cinema bonus as soon as it is available, without a click.
// It always runs: a stopped rule is re-enabled (after 30 minutes when errors stopped it), and
// an older cinema-only daily rule, which it replaces, is switched off so the two never compete.
async function ensureAllDayBonuses() {
  const tabs=(await chrome.tabs.query({})).filter(tab=>GAME_TAB.test(tab.url??"")&&!tab.discarded);
  for(const tab of tabs) {
    let page=null;try {page=await within(chrome.tabs.sendMessage(tab.id,{type:"IKARIAM_AGENT_PARSE_PAGE"}),6000);} catch {continue;}
    const accountKey=pageIdentity(page);
    if(!accountKey||!/^\d+$/.test(String(page?.cityId??""))) continue;
    try {
      const state=await gameRuntime.handle({operation:"list",accountKey});
      let rule=state.rules.find(item=>item.kind==="daily"&&item.allDayVideos);
      // The "daily bonuses" switch wins (user report, 2026-10-16: it was switched back on every
      // minute): off for every account, or off in this one from its card, keeps the cinema off.
      const switches=await chrome.storage.local.get(["autopilot-v1","autopilot-off-v1"]);
      if(switches["autopilot-v1"]?.daily===false||(switches["autopilot-off-v1"]?.daily??[]).includes(accountKey)) {
        if(rule?.enabled&&!rule.inFlight) await gameRuntime.handle({operation:"toggle",accountKey,id:rule.id,enabled:false});
        continue;
      }
      // A repeated cinema request is simply refused by the game, so a stuck rule is replaced.
      if(rule?.uncertain&&!rule.inFlight) {await gameRuntime.handle({operation:"delete",accountKey,id:rule.id});rule=null;}
      if(rule&&(rule.enabled||rule.inFlight||rule.uncertain||rule.failures&&Date.now()-(rule.lastRunAt??0)<1800000)) continue;
      for(const other of state.rules.filter(item=>item.kind==="daily"&&!item.allDayVideos&&item.enabled&&item.collectVideos&&!item.collectTasks&&!item.inFlight))
        await gameRuntime.handle({operation:"toggle",accountKey,id:other.id,enabled:false});
      if(!rule) {
        const before=new Set(state.rules.map(item=>item.id));
        const saved=await gameRuntime.handle({operation:"save",accountKey,rule:{kind:"daily",cityId:String(page.cityId),intervalMinutes:2,maxCycles:10000,reserve:0,entries:[],collectVideos:true,collectTasks:false,allDayVideos:true,collectAmbrosia:true}});
        rule=saved.rules.find(item=>!before.has(item.id));
      }
      if(rule) await gameRuntime.handle({operation:"toggle",accountKey,id:rule.id,enabled:true});
    } catch(error) {console.warn("[automation] all-day bonuses for",accountKey,":",error.message);}
  }
}
// The morning routine was removed (user decision, 2026-10-15): everything it did runs all day in
// full autonomy; the report is sent at 07:00 and on demand. Its old state is removed once.
void chrome.storage?.local?.remove?.(["morning-routine-v1"])?.catch?.(()=>{});
// Cost tables read with every value doubled (v1) are dropped; v2 is read again from the game.
void chrome.storage?.local?.get?.(null)?.then?.(all=>chrome.storage.local.remove(Object.keys(all??{}).filter(key=>key.startsWith("cost-tables-v1-"))))?.catch?.(()=>{});
const tabRefresh=createTabRefresh(chrome,findIkariamTab);
// No VPN guard (user decision, 2026-10-13: a fixed computer); its old state is removed once.
void chrome.storage?.local?.remove?.(["ip-guard-v1"])?.catch?.(()=>{});
const autopilot=createAutopilot(chrome,{game:gameRuntime,transport:{handle:transportRuntime.command},identify:async tab=>{const key=(await describeTab(tab)).accountKey;if(!key) throw new Error("account not identified");return key;}});
// A switch flipped in the panel applies within seconds, not at the next five-minute round.
chrome.storage.onChanged?.addListener((changes,area)=>{if(area==="local"&&(changes[autopilot.key]||changes['autopilot-run-v1']||changes['autopilot-off-v1']||changes[autopilot.fullKey]||changes[autopilot.uniformKey]||changes['telegram:all']||changes['tavern-auto-v1'])) void autopilot.tick(true).catch(()=>{});});
// First round shortly after the extension starts, not five minutes later.
globalThis.setTimeout?.(()=>{void autopilot.tick(true)?.catch?.(()=>{});},20000);
const healthReport=createHealthReport(chrome,{notify:gameRuntime.notify});
const raidPlayers=createRaidPlayers(chrome);
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type!=='IKARIAM_AGENT_RAID_PLAYERS') return false;
  raidPlayers.handle(message.command??{}).then(data=>sendResponse({ok:true,data}),error=>sendResponse({ok:false,reason:error.message}));
  return true;
});
const warMode=createWarMode(chrome,{transport:{handle:transportRuntime.command},identify:async tab=>{const key=(await describeTab(tab)).accountKey;if(!key) throw new Error("account not identified");return key;}});
// The allocation pilot (Firefox; idle unless the local bridge itself is in pilot mode — see firefox-supply-claims.js).
if(!FIREFOX_EDITION) console.log(LOG_PREFIX,'firefox-supply-claims skipped: Opera main edition');
else void import('./firefox-supply-claims.js').then(module=>{
  const claims=module.createFirefoxSupplyClaims(chrome,{transport:{handle:transportRuntime.command}});
  if(!claims)return;
  console.log(LOG_PREFIX,'firefox-supply-claims loaded');
  chrome.alarms.create('firefox-supply-claims',{periodInMinutes:0.5});
  chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='firefox-supply-claims')void claims.tick().catch(()=>{});});
  chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
    if(message?.type!=='IKARIAM_AGENT_SUPPLY_CLAIM_DECIDE')return false;
    claims.decide(String(message.claimId),message.approve===true).then(entry=>sendResponse({ok:true,entry}),error=>sendResponse({ok:false,reason:error.message}));return true;
  });
}).catch(error=>console.warn('[firefox-claims]',error.message));
// Capture points for Opera's raid order (user decision, 2026-10-28): Firefox reads them daily at 18:01 and on
// Opera's request; Opera reads the ranking from the local service every minute.
const capturePoints=FIREFOX_EDITION?createFirefoxCapturePoints(chrome,{findTab:findAccountTab}):createMainCaptureRanking(chrome);
if(capturePoints) {
  chrome.alarms.create('capture-points',{periodInMinutes:FIREFOX_EDITION?0.5:1});
  chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='capture-points')void capturePoints.tick().catch(()=>{});});
}
// The raids table's live target check (Opera): handed to the account's game tab.
if(MAIN_SUPPLY_EDITION)chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type!=='IKARIAM_AGENT_RAID_PROBE') return false;
  (async()=>{
    const tab=typeof message.accountKey==='string'?await findAccountTab(message.accountKey):null;
    if(!tab?.id) return {ok:false,reason:'לשונית החשבון סגורה'};
    // The city of the account's raids automation (its fortress) reads the screens, as a raid would.
    const rule=((await chrome.storage.local.get('game-automations-v1'))['game-automations-v1']?.rules??[]).find(item=>item.accountKey===message.accountKey&&item.kind==='pirates'&&!item.deleted);
    if(!rule) return {ok:false,reason:'אין אוטומציית פשיטות בחשבון'};
    return await chrome.tabs.sendMessage(tab.id,{type:'IKARIAM_AGENT_RAID_PROBE',accountKey:message.accountKey,cityId:String(rule.cityId),playerName:message.playerName,cities:message.cities});
  })().then(sendResponse,error=>sendResponse({ok:false,reason:error.message}));return true;
});
// The raids table's "רענן נקודות לכידה" (Opera).
if(capturePoints?.refresh)chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type!=='IKARIAM_AGENT_CAPTURE_REFRESH') return false;
  void capturePoints.refresh(message.names).then(result=>sendResponse({ok:true,...result}),error=>sendResponse({ok:false,reason:error.message}));return true;
});
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type!=='IKARIAM_AGENT_WAR_COMMAND') return false;
  // A started or resumed request ships at once, not at the next shipping alarm.
  warMode.handle(message.command).then(data=>{sendResponse({ok:true,data});if(['start','resume-target'].includes(message.command?.operation)) void transportRuntime.tick().catch(()=>{});},error=>sendResponse({ok:false,reason:error.message}));
  return true;
});
const tabWatchdog=createTabWatchdog(chrome,{notify:gameRuntime.notify,identify:async tab=>{
  const key=(await describeTab(tab)).accountKey;
  if(!key) throw new Error("account not identified");return key;
}});
chrome.tabs.onUpdated?.addListener((tabId, change, tab) => {
  if(MAIN_SUPPLY_EDITION&&change.status==="loading")mainSupplyModulesReady.delete(tabId);
  if (change.status !== "complete" || !/^https:\/\/s\d+-\w+\.ikariam\.gameforge\.com\//.test(tab.url ?? "")) return;
  // Repair the reader after navigation without submitting any game action.
  void chrome.tabs.sendMessage(tabId,{type:"IKARIAM_AGENT_PARSE_PAGE"})
    .catch(() => chrome.scripting.executeScript({target:{tabId},files:readerFiles}))
    .catch(() => console.warn(LOG_PREFIX,"reader recovery deferred until the next read"));
});
void gameRuntime.start();
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type!=='IKARIAM_AGENT_VERIFY_PIRACY')return false;
  gameRuntime.handle({operation:'verify-piracy'}).then(result=>sendResponse(result),error=>sendResponse({ok:false,reason:error.message}));return true;
});
void gameRuntime.telegramHealth?.().catch(()=>{});
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(!["IKARIAM_AGENT_UNIFORM_SYNC","IKARIAM_AGENT_AUTOPILOT_SYNC"].includes(message?.type)) return false;
  if(message.type==="IKARIAM_AGENT_AUTOPILOT_SYNC") {
    sendResponse({ok:true});
    void autopilot.tick(true).then(()=>gameRuntime.tick()).catch(error=>console.error('[automation] setup failed',error.message));
    return false;
  }
  autopilot.tick(true).then(()=>gameRuntime.tick()).then(()=>sendResponse({ok:true}),error=>sendResponse({ok:false,reason:error.message}));
  return true;
});
chrome.storage.onChanged?.addListener((changes,area)=>{
  if(area==='local' && (changes['pirate-raids-v1'] || Object.entries(changes).some(([key,value])=>key.startsWith('game-result-')&&value.newValue?.status==='complete')))
    void gameRuntime.tick().catch(()=>console.error('[automation] game automation result processing failed'));
});
// The main edition (Opera, loaded unpacked) checks GitHub for a newer version itself.
const updateCheck=(()=>{try {return /\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name??'')?createUpdateCheck(chrome):null;} catch {return null;}})();
// Every minute: each job on its own, so one that throws can never stop the others (an undefined
// job once stopped the tab watchdog, the daily report and the autopilot for days).
chrome.alarms.onAlarm.addListener(alarm=>{
  if(alarm.name!==gameRuntime.alarmName) return;
  for(const [name,job] of [['telegram health',()=>gameRuntime.telegramHealth?.()],['game automation tick',()=>gameRuntime.tick()],['all-day bonuses check',()=>ensureAllDayBonuses()],
    ['tab refresh',()=>tabRefresh.tick()],['tab watchdog',()=>tabWatchdog.tick()],['health report',()=>healthReport.tick()],['autopilot',()=>autopilot.tick()],['update check',()=>updateCheck?.tick()]])
    try {void Promise.resolve(job()).catch(()=>console.error('[automation] '+name+' failed'));} catch {console.error('[automation] '+name+' failed');}
});
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type!=='IKARIAM_AGENT_REFRESH_COMMAND') return false;
  tabRefresh.handle(message.command).then(data=>sendResponse({ok:true,data}),error=>sendResponse({ok:false,reason:error.message}));
  return true;
});
// "Send the report to Telegram now": the daily report (failures and what did not happen), on demand.
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type==='IKARIAM_AGENT_UPDATE_CHECK') {Promise.resolve(updateCheck?.tick(true)??null).then(data=>sendResponse({ok:true,data}),error=>sendResponse({ok:false,reason:error.message}));return true;}
  if(message?.type!=='IKARIAM_AGENT_HEALTH_REPORT') return false;
  healthReport.sendNow().then(data=>sendResponse({ok:true,data}),error=>sendResponse({ok:false,reason:error.message}));
  return true;
});
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type!=='IKARIAM_AGENT_GAME_AUTOMATION_COMMAND') return false;
  gameRuntime.handle(message.command).then(data=>{
    sendResponse({ok:true,data});
    if((/\bmain\b/.test(chrome.runtime.getManifest().version_name??'')&&['start-barbarian-round','scan-barbarian-levels','stop-barbarian-round'].includes(message.command.operation))||['decision','captcha','execute-building','start-raids','retry-raids'].includes(message.command.operation)||message.command.operation==='toggle'&&message.command.enabled) void gameRuntime.tick().catch(()=>console.error('[automation] game automation tick failed'));
  },error=>sendResponse({ok:false,reason:error.message}));
  return true;
});
void transportRuntime.start();
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name===transportRuntime.alarmName) {void transportRuntime.tick().catch(error=>console.error("[automation]",error.message));void warMode.tick().catch(error=>console.error("[war]",error.message));}});
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type!=="IKARIAM_AGENT_TRANSPORT_AUTOMATION") return false;
  transportRuntime.command(message.command).then(data=>{
    sendResponse({ok:true,data});
    const ids=transportRuntime.immediateIds(message.command,data);
    if(ids.length||['policy-decision','decision'].includes(message.command.operation)) void transportRuntime.tick(ids).catch(error=>console.error("[automation]",error.message));
  },error=>sendResponse({ok:false,reason:error.message}));
  return true;
});




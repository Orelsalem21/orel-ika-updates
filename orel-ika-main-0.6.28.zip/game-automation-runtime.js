import { createMainBarbarianRounds } from './main-barbarian-rounds.js';
import './automation-rules.js';
export function createGameAutomationRuntime(chrome,findTab,{now=()=>Date.now(),uuid=()=>crypto.randomUUID(),telegramFetch=fetch,discordFetch=fetch}={}) {
  const key='game-automations-v1',alarmName='game-automations-tick';
  let queue=Promise.resolve();
  const serial=job=>{const next=queue.then(job,job);queue=next.catch(()=>{});return next;};
  const read=async()=>((await chrome.storage.local.get(key))[key]??{rules:[],events:[]});
  const write=state=>chrome.storage.local.set({[key]:state});
  const mainEdition=()=>{try {return /\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name??'');} catch {return false;}};
  // Firefox pirates (user decision, 2026-10-28): only mission 1, back to back, in each account's capital; their
  // captchas and stops go to their own Telegram bot, never the main one.
  const firefoxPirate=rule=>!mainEdition()&&rule?.kind==='pirates'&&Number(rule.pirateMission)===1&&rule.pirateStrategy!=='auto';
  const pirateBot=async()=>(await chrome.storage.local.get('telegram-pirates:all'))['telegram-pirates:all']??null;
  // A Firefox raid never stops over a lost connection or an unknown result (user decision, 2026-10-28: the
  // internet or the VPN drops now and then and the raids must always go on): every run reads the fortress from the
  // game first — a crew already out is waited for, never sent twice — so it simply tries again in a minute.
  function pirateRecover(state,rule,why) {
    rule.uncertain=false;rule.inFlight=null;rule.enabled=true;rule.nextRunAt=now()+60000;
    rule.status=(why?why+' — ':'')+'מנסה שוב בעוד דקה (המצב נקרא מחדש מהמשחק)';log(state,rule,'waiting',rule.status);
  }
  const mainBarbarians=createMainBarbarianRounds(chrome,{now,uuid,write,log});
  let healthFlight=null;
  async function telegramHealth(force=false) {
    if(healthFlight)return healthFlight;
    const cached=(await chrome.storage.local.get('telegram-health-v1'))['telegram-health-v1'];
    if(!force&&cached&&now()-cached.checkedAt<300000)return cached;
    healthFlight=(async()=>{
      const config=await setting('telegram','all');
      let result={configured:!!config,working:false,checkedAt:now(),reason:'לא נמצא חיבור טלגרם שמור'};
      if(config)try {
        if(!await chrome.permissions.contains({origins:['https://api.telegram.org/*']}))throw new Error('לא ניתנה הרשאה לטלגרם');
        for(const method of ['getMe','getChat','getWebhookInfo']) {
          const suffix=method==='getChat'?'?'+new URLSearchParams({chat_id:config.chatId}):'';
          const response=await telegramFetch('https://api.telegram.org/bot'+config.token+'/'+method+suffix,{signal:AbortSignal.timeout(15000)});
          const data=await response.json();
          if(!response.ok||!data.ok)throw new Error('בדיקת חיבור טלגרם נכשלה ('+method+')');
          if(method==='getWebhookInfo'&&data.result?.url)throw new Error('הבוט מחובר לשירות אחר דרך Webhook; תשובות הקפצ׳ה אינן זמינות לתוסף');
        }
        result={configured:true,working:true,checkedAt:now()};
      }catch(error){result.reason=error.message;}
      await chrome.storage.local.set({'telegram-health-v1':result});return result;
    })().finally(()=>{healthFlight=null;});
    return healthFlight;
  }
  // At most every ten minutes (user report, 2026-10-25: Firefox froze; reading the whole storage for every
  // account every minute ran on the browser's main process).
  let cleanedAt=0;
  async function cleanup(state) {
    if(now()-cleanedAt<600000) return;cleanedAt=now();
    const values=await chrome.storage.local.get(null),retained=new Set(state.rules.filter(rule=>rule.inFlight).map(rule=>'game-result-'+rule.inFlight));
    const completed=Object.keys(values).filter(key=>key.startsWith('game-result-')&&values[key]?.status==='complete'&&!retained.has(key)).sort((a,b)=>(values[b].createdAt??0)-(values[a].createdAt??0));
    if(completed.length>200) await chrome.storage.local.remove(completed.slice(200));
    const plans=Object.keys(values).filter(key=>key.startsWith('game-progress-')&&!retained.has(key.replace('game-progress-','game-result-'))).sort((a,b)=>(values[b].createdAt??0)-(values[a].createdAt??0));
    if(plans.length>200) await chrome.storage.local.remove(plans.slice(200));
  }
  const visible=async(state,accountKey)=>{
    // Firefox has no pirates (user decision, 2026-10-28): its pirate automations are neither shown nor run.
    const rules=state.rules.filter(rule=>rule.accountKey===accountKey&&!rule.deleted&&(mainEdition()||rule.kind!=='pirates'||firefoxPirate(rule)));
    for(const rule of rules) if(rule.inFlight) rule.executionPlan=(await chrome.storage.local.get('game-progress-'+rule.inFlight))['game-progress-'+rule.inFlight]??null;
    return {rules,events:state.events.filter(event=>event.accountKey===accountKey)};
  };
  const transient=status=>/קריאת המשחק נכשלה|העיר אינה שייכת לחשבון המחובר|אינה פתוחה|חרגה מזמן ההמתנה|timed out|Failed to fetch|NetworkError|\(50[234]\)/i.test(status??'');
  function log(state,rule,status,message) {
    state.events.unshift({id:uuid(),accountKey:rule.accountKey,ruleId:rule.id,time:now(),status,message});state.events=state.events.slice(0,3000);
  }
  async function identity(tab) {
    let timer;
    const page=await Promise.race([chrome.tabs.sendMessage(tab.id,{type:'IKARIAM_AGENT_PARSE_PAGE'}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('לשונית המשחק אינה מגיבה לבדיקת החשבון')),10000);})]).finally(()=>clearTimeout(timer));
    if(!page?.found||!page.ownerName||!page.mundo||!page.servidor) throw new Error('לא זוהה חשבון מחובר');
    return [page.ownerName,page.mundo,page.servidor].join('|');
  }
  // One Telegram/Discord setting for every account, kept in local extension storage so it
  // survives closing Firefox (user decision, 2026-10-12). An older per-account session
  // settings are migrated to the shared persistent setting on first use.
  async function setting(kind,accountKey) {
    const sharedKey=kind+':all';
    const saved=(await chrome.storage.local.get(sharedKey))[sharedKey];
    if(saved) return saved;
    const legacy=await chrome.storage.session?.get(null)??{};
    const own=legacy[kind+':'+accountKey];
    const candidate=own??Object.entries(legacy).find(([key,value])=>key.startsWith(kind+':')&&value)?.[1];
    if(!candidate) return null;
    await chrome.storage.local.set({[sharedKey]:candidate});
    for(const key of Object.keys(legacy).filter(key=>key.startsWith(kind+':'))) await chrome.storage.session.remove(key);
    return candidate;
  }
  async function sendTelegram(accountKey,text,config) {
    const settings=config??await setting('telegram',accountKey);
    if(!settings) throw new Error('לא נמצא חיבור טלגרם שמור. הגדר אותו פעם אחת בהגדרות ההתראות');
    if(!await chrome.permissions.contains({origins:['https://api.telegram.org/*']})) throw new Error('לא ניתנה הרשאה לטלגרם');
    let response;
    try {response=await telegramFetch('https://api.telegram.org/bot'+settings.token+'/sendMessage',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:settings.chatId,text:String(text).slice(0,4000)}),signal:AbortSignal.timeout(15000)});} catch {throw new Error('שליחת ההתראה לטלגרם לא הושלמה');}
    if(!response.ok || !(await response.json()).ok) throw new Error('טלגרם דחה את ההתראה; בדוק את הבוט ומזהה השיחה');
  }
  // botComm.sendToDiscord: optional webhook, session storage only.
  async function sendDiscord(accountKey,text,config) {
    const settings=config??await setting('discord',accountKey);
    if(!settings) throw new Error('דיסקורד אינו מוגדר לסשן הדפדפן הנוכחי');
    if(!await chrome.permissions.contains({origins:['https://discord.com/*']})) throw new Error('לא ניתנה הרשאה לדיסקורד');
    let response;
    try {response=await discordFetch(settings.webhook,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content:String(text).slice(0,1900)}),signal:AbortSignal.timeout(15000)});} catch {throw new Error('שליחת ההתראה לדיסקורד לא הושלמה');}
    if(!response.ok) throw new Error('דיסקורד דחה את ההתראה; בדוק את כתובת ה־Webhook');
  }
  async function channels(accountKey) {
    return {telegram:!!await setting('telegram',accountKey),discord:!!await setting('discord',accountKey)};
  }
  async function notify(accountKey,text) {
    const configured=await channels(accountKey),errors=[];let delivered=0;
    if(configured.telegram) try {await sendTelegram(accountKey,text);delivered++;} catch(error) {errors.push(error.message);}
    if(configured.discord) try {await sendDiscord(accountKey,text);delivered++;} catch(error) {errors.push(error.message);}
    if(!delivered) throw new Error(errors[0]??'לא הוגדר ערוץ התראות');
  }
  // alertAttacks.respondToAttack: a matching Telegram reply activates vacation mode.
  async function telegramReplies(state,accountKey,rule,tab) {
    const settings=await setting('telegram',accountKey);
    if(!settings || !await chrome.permissions.contains({origins:['https://api.telegram.org/*']})) return;
    let data;
    try {
      const response=await telegramFetch('https://api.telegram.org/bot'+settings.token+'/getUpdates?'+new URLSearchParams({offset:String(rule.telegramOffset??0),timeout:'0'}),{signal:AbortSignal.timeout(15000)});
      data=await response.json();
    } catch {return;}
    if(!data?.ok || !Array.isArray(data.result)) return;
    for(const update of data.result) {
      rule.telegramOffset=Math.max(rule.telegramOffset??0,Number(update.update_id)+1);
      const message=update.message;
      if(String(message?.chat?.id)!==String(settings.chatId) || Number(message.date)*1000<rule.vacationCodeAt-60000) continue;
      if(new RegExp('^\\s*(?:/vacation|חופשה)\\s+'+rule.vacationCode+'\\s*$').test(String(message.text??''))) {
        rule.vacationCode=null;
        try {
          const result=await chrome.tabs.sendMessage(tab.id,{type:'IKARIAM_AGENT_VACATION',accountKey});
          log(state,rule,result?.ok?'changed':'error',result?.ok?'בקשת מצב חופשה נשלחה לפי תשובה בטלגרם':'הפעלת מצב חופשה נכשלה: '+(result?.reason??''));
        } catch {log(state,rule,'unknown','בקשת מצב חופשה נשלחה ללא אישור; בדוק במשחק');}
        rule.outbox=(rule.outbox??[]).concat([{message:'בקשת מצב חופשה נשלחה למשחק לפי התשובה שלך.',attempts:0}]);
        return;
      }
    }
  }
  // Approvals through Telegram (user decision, 2026-10-14): an action waiting for approval is sent
  // as a message; a reply to it — "כן"/"אשר"/"1" approves, "לא"/"דלג"/"0" skips. Only a reply that
  // quotes the message counts, so it can never be mistaken for a captcha code or another approval.
  const describe=fields=>Object.entries(fields??{}).filter(([key])=>!['cityId','position','actionRequest'].includes(key)).slice(0,6).map(([key,value])=>key+': '+value).join(' · ');
  async function telegramApprovals(state) {
    const waiting=state.rules.filter(rule=>!rule.deleted&&rule.enabled&&rule.proposal?.key&&!rule.inFlight);
    if(!waiting.length) return;
    const settings=await setting('telegram','all');
    if(!settings || !await chrome.permissions.contains({origins:['https://api.telegram.org/*']})) return;
    const api=method=>'https://api.telegram.org/bot'+settings.token+'/'+method;
    // A changing plan is not re-sent more than once every half hour.
    for(const rule of waiting.filter(rule=>rule.proposalMessageKey!==rule.proposal.key&&now()-(rule.proposalMessageAt??0)>=1800000)) {
      const text='🟠 פעולה ממתינה לאישור בחשבון "'+rule.accountKey.split('|')[0]+'"'+(rule.proposal.cityName?' · עיר '+rule.proposal.cityName:'')+'\n'+describe(rule.proposal.fields)+'\nהשב להודעה הזו "כן" לאישור או "לא" לדילוג.';
      try {
        const data=await (await telegramFetch(api('sendMessage'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:settings.chatId,text}),signal:AbortSignal.timeout(15000)})).json();
        if(data?.ok) {rule.proposalMessageKey=rule.proposal.key;rule.proposalMessageAt=now();rule.proposalMessageId=data.result?.message_id??null;log(state,rule,'telegram','בקשת האישור נשלחה לטלגרם');}
      } catch { /* Next round. */ }
    }
    let result=[];
    try {const data=await (await telegramFetch(api('getUpdates')+'?'+new URLSearchParams({offset:String(state.telegramOffset??0),timeout:'0'}),{signal:AbortSignal.timeout(15000)})).json();result=data?.ok&&Array.isArray(data.result)?data.result:[];} catch {return;}
    const inbox=new Map((state.telegramCaptchaInbox??[]).map(update=>[update.update_id,update]));
    for(const update of result) {state.telegramOffset=Math.max(state.telegramOffset??0,Number(update.update_id)+1);if(String(update.message?.chat?.id)===String(settings.chatId)) inbox.set(update.update_id,update);}
    state.telegramCaptchaInbox=[...inbox.values()].filter(update=>Number(update.message?.date)*1000>now()-3600000).slice(-100);
    for(const update of [...state.telegramCaptchaInbox]) {
      const quoted=update.message?.reply_to_message?.message_id,text=String(update.message?.text??'').trim();
      const rule=waiting.find(item=>item.proposalMessageId!=null&&item.proposalMessageId===quoted);
      if(!rule) continue;
      const yes=/^(כן|אשר|מאשר|1|✅)$/.test(text),no=/^(לא|דלג|0|❌)$/.test(text);
      if(!yes&&!no) continue;
      state.telegramCaptchaInbox=state.telegramCaptchaInbox.filter(item=>item.update_id!==update.update_id);
      if(yes) {rule.approval={key:rule.proposal.key,approvedAt:now()};log(state,rule,'approved','אושר בטלגרם; יבוצע עכשיו אחרי בדיקה מחדש');}
      else {rule.skippedPlans=[...(rule.skippedPlans??[]),rule.proposal.key].slice(-100);log(state,rule,'skipped','דולג לפי תשובה בטלגרם');}
      rule.proposal=null;rule.nextRunAt=now();
    }
  }
  // Pirate captcha through Telegram: the image goes to the saved chat and the user's reply
  // (the code) is entered into the waiting mission. The user solves it; nothing is sent to a
  // captcha-solving service. With several captchas pending, a reply must quote its image.
  async function telegramCaptcha(state,accountKey,rule) {
    const captcha=rule.progress?.captcha;
    if(!/^data:image\/png;base64,/.test(captcha?.image??'')) return;
    const own=!mainEdition()&&rule.kind==='pirates',offsetKey=own?'pirateTelegramOffset':'telegramOffset',inboxKey=own?'pirateTelegramCaptchaInbox':'telegramCaptchaInbox';
    const settings=own?await pirateBot():await setting('telegram',accountKey);
    if(!settings || !await chrome.permissions.contains({origins:['https://api.telegram.org/*']})) return;
    const api=method=>'https://api.telegram.org/bot'+settings.token+'/'+method;
    const updates=async offset=>{
      const response=await telegramFetch(api('getUpdates')+'?'+new URLSearchParams({offset:String(offset),timeout:'0'}),{signal:AbortSignal.timeout(15000)});
      const data=await response.json();return data?.ok&&Array.isArray(data.result)?data.result:[];
    };
    if(rule.captchaSentAt!==captcha.at||now()-(rule.captchaPhotoSentAt??rule.captchaSentAt??0)>=1800000) {
      // Date and quoted image identify replies; never discard other accounts' replies here.
      const bytes=Uint8Array.from(atob(captcha.image.split(',')[1]),char=>char.charCodeAt(0));
      const form=new FormData();
      form.append('chat_id',String(settings.chatId));
      const account='"'+accountKey.split('|')[0]+'"';
      form.append('caption',(captcha.wrong?'❌ שחזור הקוד בחשבון '+account+' נכשל — יש להזין קוד חדש':'☠️ משימת פיראטים בחשבון '+account+' ממתינה לפתרון קפצ׳ה')+'\nהשב להודעה הזו עם הקוד שבתמונה');
      form.append('photo',new Blob([bytes],{type:'image/png'}),'captcha.png');
      try {
        const data=await (await telegramFetch(api('sendPhoto'),{method:'POST',body:form,signal:AbortSignal.timeout(20000)})).json();
        if(data?.ok) {
          if(rule.captchaSentAt!==captcha.at)rule.captchaMessageIds=[];
          rule.captchaSentAt=captcha.at;rule.captchaPhotoSentAt=now();rule.captchaMessageId=data.result?.message_id??null;
          if(rule.captchaMessageId!=null)rule.captchaMessageIds=[...(rule.captchaMessageIds??[]),rule.captchaMessageId].slice(-10);
          log(state,rule,'telegram','תמונת הקפצ׳ה נשלחה לטלגרם; ממתינה לתשובה שלך');
        }
      } catch { /* Retried on the next check. */ }
      return;
    }
    // Firefox pirates: their bot's replies are read at once by the fast loop below, never here (two readers of
    // one bot would take each other's messages).
    if(own) return;
    let result;try {result=await updates(state[offsetKey]??0);} catch {return;}
    const inbox=new Map((state[inboxKey]??[]).map(update=>[update.update_id,update]));
    for(const update of result) {
      state[offsetKey]=Math.max(state[offsetKey]??0,Number(update.update_id)+1);
      if(String(update.message?.chat?.id)===String(settings.chatId)) inbox.set(update.update_id,update);
    }
    state[inboxKey]=[...inbox.values()].filter(update=>Number(update.message?.date)*1000>now()-3600000).slice(-100);
    const pending=state.rules.filter(item=>item.kind==='pirates'&&!item.deleted&&item.progress?.captcha&&!(item.captchaAnswer?.at>=item.progress.captcha.at)).length;
    for(const update of state[inboxKey]) {
      const message=update.message,text=String(message?.text??'').trim();
      if(String(message?.chat?.id)!==String(settings.chatId) || Number(message.date)*1000<captcha.at-60000 || !/^[A-Za-z0-9]{3,12}$/.test(text)) continue;
      const quoted=message.reply_to_message?.message_id;
      if(quoted!=null?quoted!==rule.captchaMessageId&&!(rule.captchaMessageIds??[]).includes(quoted):pending>1) continue;
      rule.captchaAnswer={value:text,at:now()};rule.nextRunAt=now();
      rule.status='התקבל קוד קפצ׳ה מטלגרם — ממתין לשליחה למשחק';
      state[inboxKey]=state[inboxKey].filter(item=>item.update_id!==update.update_id);
      log(state,rule,'approved','התקבל קוד קפצ׳ה מטלגרם; יישלח בבדיקה הבאה');
      // The user's wording (2026-10-13): the code reached the agent and is being checked.
      rule.outbox=(rule.outbox??[]).concat([{message:'🔎 שחזור הקוד בחשבון "'+accountKey.split('|')[0]+'" נבדק',attempts:0}]);
      return;
    }
  }
  // Firefox pirates (user decision, 2026-10-28): a captcha code is acted on at once. A long poll on the pirate
  // bot hears the reply within a second; the image is marked 👀, the run goes to the game right away (ahead of
  // the account's other work), its result is read as it lands: ✅ on the image when the code was right, ❌ and a
  // new image when it was not. A reply that is not English letters and digits is answered "not valid" at once.
  // unref: in tests a waiting timer never holds the process; in the browser it is a plain timer.
  const sleep=ms=>new Promise(done=>{const timer=setTimeout(done,ms);timer?.unref?.();});
  async function react(bot,messageId,emoji) {
    if(messageId==null) return;
    try {await telegramFetch('https://api.telegram.org/bot'+bot.token+'/setMessageReaction',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:bot.chatId,message_id:messageId,reaction:[{type:'emoji',emoji}]}),signal:AbortSignal.timeout(10000)});} catch { /* A mark only. */ }
  }
  // Telegram lets a bot react only with its own set (no ✅ or ❌), so the verdict is written on the image itself:
  // the 👀 mark is taken off and the caption starts with ✅ or ❌ (user decision, 2026-10-28).
  async function verdict(bot,messageId,caption) {
    if(messageId==null) return;
    try {await telegramFetch('https://api.telegram.org/bot'+bot.token+'/setMessageReaction',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:bot.chatId,message_id:messageId,reaction:[]}),signal:AbortSignal.timeout(10000)});} catch { /* A mark only. */ }
    try {await telegramFetch('https://api.telegram.org/bot'+bot.token+'/editMessageCaption',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:bot.chatId,message_id:messageId,caption}),signal:AbortSignal.timeout(10000)});} catch { /* A mark only. */ }
  }
  async function replyTo(bot,messageId,text) {
    try {await telegramFetch('https://api.telegram.org/bot'+bot.token+'/sendMessage',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:bot.chatId,text,reply_to_message_id:messageId}),signal:AbortSignal.timeout(10000)});} catch { /* A note only. */ }
  }
  const waitingCaptcha=rule=>firefoxPirate(rule)&&!rule.deleted&&rule.progress?.captcha&&!(rule.captchaAnswer?.at>=rule.progress.captcha.at);
  async function pirateReplies(updates,bot) {
    const state=await read(),answered=[];
    for(const update of updates) {
      state.pirateTelegramOffset=Math.max(state.pirateTelegramOffset??0,Number(update.update_id)+1);
      const message=update.message,text=String(message?.text??'').trim();
      if(!message||String(message.chat?.id)!==String(bot.chatId)||!text||text.startsWith('/')) continue;
      const pending=state.rules.filter(waitingCaptcha),quoted=message.reply_to_message?.message_id;
      const rule=quoted!=null?pending.find(item=>item.captchaMessageId===quoted||(item.captchaMessageIds??[]).includes(quoted)):pending.length===1?pending[0]:null;
      // A code that fits no waiting image (no Reply while several wait, or a Reply to an old image) is never
      // dropped silently (user report, 2026-10-28): the user is told at once and the waiting images come again.
      if(!rule) {
        if(!pending.length) {await replyTo(bot,message.message_id,'ℹ️ אין כרגע קפצ׳ה שממתינה לקוד');continue;}
        await replyTo(bot,message.message_id,'❓ לא ברור לאיזה חשבון הקוד — יש להשיב (Reply) על התמונה עצמה. ממתינות: '+pending.map(item=>item.accountKey.split('|')[0]).join(', ')+'. התמונות נשלחות שוב עכשיו');
        for(const item of pending) {item.captchaPhotoSentAt=0;await telegramCaptcha(state,item.accountKey,item);}
        continue;
      }
      if(!/^[A-Za-z0-9]{3,12}$/.test(text)) {await replyTo(bot,message.message_id,'❌ לא תקין — הקוד רק באותיות אנגליות ומספרים. השב שוב לתמונה');continue;}
      rule.captchaAnswer={value:text,at:now()};rule.nextRunAt=now();rule.captchaReactMessageId=quoted??rule.captchaMessageId??null;
      rule.status='התקבל קוד קפצ׳ה מטלגרם — נשלח עכשיו למשחק';log(state,rule,'approved','התקבל קוד קפצ׳ה מטלגרם; נשלח מיד');
      await react(bot,rule.captchaReactMessageId,'👀');
      answered.push({id:rule.id,accountKey:rule.accountKey});
    }
    await write(state);return answered;
  }
  async function runAnswered({id,accountKey},bot) {
    const tab=await findTab(accountKey);if(!tab?.id) return;
    try {if(await identity(tab)!==accountKey) return;} catch {return;}
    await serial(()=>tickAccount(tab,accountKey,id));
    const run=(await read()).rules.find(rule=>rule.id===id)?.inFlight;if(!run) return;
    let result=null;
    for(let i=0;i<180&&result?.status!=='complete';i++) {await sleep(i<20?250:1000);result=(await chrome.storage.local.get('game-result-'+run))['game-result-'+run];}
    await serial(()=>tickAccount(tab,accountKey,id));
    await serial(async()=>{
      const state=await read(),rule=state.rules.find(item=>item.id===id);if(!rule) return;
      const wrong=rule.progress?.captcha&&rule.progress.captcha.at>(rule.captchaAnswer?.at??0);
      const account='"'+accountKey.split('|')[0]+'"';
      if(wrong) {await verdict(bot,rule.captchaReactMessageId,'❌ הקוד '+rule.captchaAnswer?.value+' שגוי בחשבון '+account+' — נשלחה תמונה חדשה');await telegramCaptcha(state,accountKey,rule);}
      else if(result?.ok) await verdict(bot,rule.captchaReactMessageId,'✅ הקוד '+rule.captchaAnswer?.value+' תקין — משימת הפיראטים בחשבון '+account+' יצאה');
      rule.captchaReactMessageId=null;await write(state);
    });
    drivePirates(await read());
  }
  // Firefox pirates run back to back, 24/7 (user decision, 2026-10-28): fifteen seconds after a mission ends the next
  // capture goes out, ahead of the account's other work, and every result is read as it lands — never left for
  // the minute round. A raid waiting for its captcha hands over to the fast loop above.
  const drivers=new Map();
  function drivePirates(state) {
    if(mainEdition()) return;
    for(const rule of state.rules.filter(item=>firefoxPirate(item)&&item.enabled&&!item.deleted&&!item.uncertain&&!drivers.has(item.id))) {
      const id=rule.id,accountKey=rule.accountKey;
      drivers.set(id,(async()=>{
        for(let lap=0;lap<500;lap++) {
          let current=(await read()).rules.find(item=>item.id===id);
          if(!current||!current.enabled||current.deleted||current.uncertain||waitingCaptcha(current)) return;
          if(!current.inFlight) {
            const wait=(current.nextRunAt??0)-now();
            if(wait>120000) return;
            if(wait>0) {await sleep(wait);continue;}
            const tab=await findTab(accountKey);if(!tab?.id) return;
            try {if(await identity(tab)!==accountKey) return;} catch {return;}
            await serial(()=>tickAccount(tab,accountKey,id));
            current=(await read()).rules.find(item=>item.id===id);
            // Already sent and settled within that call (a quick result): wait for the next mission.
            if(!current?.inFlight) {if(current&&current.nextRunAt>now()) continue;return;}
          }
          const run=current.inFlight;let result=null;
          for(let i=0;i<300&&result?.status!=='complete';i++) {await sleep(i<40?250:1000);result=(await chrome.storage.local.get('game-result-'+run))['game-result-'+run];}
          if(result?.status!=='complete') return;
          const tab=await findTab(accountKey);if(!tab?.id) return;
          await serial(()=>tickAccount(tab,accountKey,id));
          const after=(await read()).rules.find(item=>item.id===id);
          if(after&&waitingCaptcha(after)) {
            await serial(async()=>{const fresh=await read(),own=fresh.rules.find(item=>item.id===id);if(own) {await telegramCaptcha(fresh,accountKey,own);await write(fresh);}});
            void fastCaptcha().catch(()=>{});return;
          }
        }
      })().catch(()=>{}).finally(()=>drivers.delete(id)));
    }
  }
  let fastFlight=null;
  function fastCaptcha() {
    if(mainEdition()) return Promise.resolve();
    if(fastFlight) return fastFlight;
    const runs=[];
    fastFlight=(async()=>{
      for(let round=0;round<40;round++) {
        const state=await read(),bot=await pirateBot();
        if(!bot||!state.rules.some(waitingCaptcha)||!await chrome.permissions.contains({origins:['https://api.telegram.org/*']})) return;
        const started=now();let updates=[];
        try {
          const response=await telegramFetch('https://api.telegram.org/bot'+bot.token+'/getUpdates?'+new URLSearchParams({offset:String(state.pirateTelegramOffset??0),timeout:'20'}),{signal:AbortSignal.timeout(30000)});
          const data=await response.json();updates=data?.ok&&Array.isArray(data.result)?data.result:[];
        } catch {await sleep(3000);continue;}
        if(!updates.length) {if(now()-started<1000) await sleep(1000);continue;}
        const answered=await serial(()=>pirateReplies(updates,bot));
        for(const item of answered) runs.push(runAnswered(item,bot).catch(()=>{}));
      }
    })().finally(async()=>{await Promise.allSettled(runs);fastFlight=null;});
    return fastFlight;
  }
  async function handle(command) {
    if(command?.operation==='verify-piracy') {
      const state=await read();
      for(const rule of state.rules.filter(rule=>rule.kind==='pirates'&&!rule.deleted&&rule.progress?.captcha)) {
        const tab=await findTab(rule.accountKey);if(!tab?.id)continue;
        try {
          const response=await chrome.tabs.sendMessage(tab.id,{type:'IKARIAM_AGENT_PIRACY_CHECK',rule});
          if(!response?.ok)continue;
          rule.progress.piracyCheckedAt=response.result.checkedAt;
          if(response.result.active){rule.progress.captcha=null;rule.captchaAnswer=null;rule.status='משימת פיראטים פעילה — אומת במשחק';}
        }catch { /* Keep unverified data hidden until a successful read. */ }
      }
      await write(state);return {ok:true};
    }
    if(command?.operation==='telegram-status') return {configured:!!await setting('telegram','all')};
    if(command?.operation==='telegram-health-status') return telegramHealth();
    if(command?.operation==='telegram-check') {
      if(!await setting('telegram','all')) return {configured:false,working:false,reason:'לא נמצא חיבור טלגרם שמור'};
      try {
        await sendTelegram('all','Orel Ika: בדיקת שומר טלגרם הצליחה.');
        return {configured:true,working:true,checkedAt:now()};
      } catch(error) {return {configured:true,working:false,checkedAt:now(),reason:error.message};}
    }
    // Every account's automations and recent events, without needing their tabs.
    if(command?.operation==='overview') {
      const state=await read(),keys=[...new Set(state.rules.filter(rule=>!rule.deleted).map(rule=>rule.accountKey))];
      return {accounts:await Promise.all(keys.map(async key=>({accountKey:key,...(await visible(state,key))})))};
    }
    // command.accountKey targets one of several open accounts; otherwise the selected tab.
    const tab=await findTab(command?.accountKey);if(!tab?.id) throw new Error(command?.accountKey?'לשונית החשבון '+command.accountKey.split('|')[0]+' אינה פתוחה':'יש להשאיר לשונית משחק מחוברת פתוחה');
    const accountKey=await identity(tab),state=await read();
    if(command?.accountKey && accountKey!==command.accountKey) throw new Error('לשונית החשבון שייכת לחשבון אחר; רענן אותה ונסה שוב');
    if(!command || typeof command.operation!=='string') throw new Error('בקשת ניהול אינה תקינה');
    if(['start-barbarian-round','scan-barbarian-levels','stop-barbarian-round'].includes(command.operation)) {
      if(!mainEdition())throw new Error('סבבי ברברים זמינים באופרה בלבד');
      if(command.operation==='stop-barbarian-round')await mainBarbarians.stop(accountKey);
      else await mainBarbarians.start(state,accountKey,command.cityId??null,command.operation==='scan-barbarian-levels');
      await write(state);return visible(state,accountKey);
    }
    if(command.operation==='telegram-status') return {configured:!!await setting('telegram',accountKey)};
    if(command.operation==='telegram-save') {
      if(!/^\d{5,15}:[\w-]{20,100}$/.test(command.token??'') || !/^-?\d{1,25}$/.test(command.chatId??'')) throw new Error('פרטי טלגרם אינם תקינים');
      const config={token:command.token,chatId:command.chatId};
      await sendTelegram(accountKey,'Orel Ika: חיבור ההתראות לטלגרם נבדק בהצלחה.',config);
      await chrome.storage.session.remove('telegram:'+accountKey);await chrome.storage.local.set({'telegram:all':config});return {configured:true};
    }
    if(command.operation==='telegram-delete') {await chrome.storage.session.remove('telegram:'+accountKey);await chrome.storage.local.remove('telegram:all');return {configured:false};}
    if(command.operation==='telegram-pirates-status') return {configured:!!await pirateBot()};
    if(command.operation==='telegram-pirates-save') {
      if(mainEdition()) throw new Error('בוט הפיראטים מוגדר בגרסת Firefox בלבד');
      if(!/^\d{5,15}:[\w-]{20,100}$/.test(command.token??'') || !/^-?\d{1,25}$/.test(command.chatId??'')) throw new Error('פרטי טלגרם אינם תקינים');
      if(command.token===(await setting('telegram',accountKey))?.token) throw new Error('זה הבוט הראשי — לפיראטים צריך בוט נפרד');
      const config={token:command.token,chatId:command.chatId};
      await sendTelegram(accountKey,'Orel Ika: בוט הפיראטים מחובר. כאן יגיעו רק קפצ׳ות ותקלות של פשיטות הפיראטים.',config);
      await chrome.storage.local.set({'telegram-pirates:all':config});return {configured:true};
    }
    if(command.operation==='telegram-pirates-delete') {await chrome.storage.local.remove('telegram-pirates:all');return {configured:false};}
    if(command.operation==='discord-status') return {configured:(await channels(accountKey)).discord};
    if(command.operation==='discord-save') {
      if(!/^https:\/\/(?:discord\.com|discordapp\.com)\/api\/webhooks\/\d{5,25}\/[\w-]{20,120}$/.test(command.webhook??'')) throw new Error('כתובת Webhook של דיסקורד אינה תקינה');
      const config={webhook:command.webhook.replace('discordapp.com','discord.com')};
      await sendDiscord(accountKey,'Orel Ika: חיבור ההתראות לדיסקורד נבדק בהצלחה.',config);
      await chrome.storage.session.remove('discord:'+accountKey);await chrome.storage.local.set({'discord:all':config});return {configured:true};
    }
    if(command.operation==='discord-delete') {await chrome.storage.session.remove('discord:'+accountKey);await chrome.storage.local.remove('discord:all');return {configured:false};}
    if(command.operation==='vacation') {
      if(command.confirm!=='חופשה') throw new Error('יש להקליד "חופשה" לאישור');
      const response=await chrome.tabs.sendMessage(tab.id,{type:'IKARIAM_AGENT_VACATION',accountKey});
      if(!response?.ok) throw new Error(response?.reason??'בקשת מצב חופשה נכשלה');
      return response.result;
    }
    if(command.operation==='catalog') {
      const response=await chrome.tabs.sendMessage(tab.id,{type:'IKARIAM_AGENT_AUTOMATION_CATALOG',kind:command.kind,cityId:command.cityId,accountKey});
      if(!response?.ok) throw new Error(response?.reason??'קריאת האפשרויות נכשלה');return response.catalog;
    }
    if(command.operation==='list') return visible(state,accountKey);
    if(command.operation==='delete-raids') {
      const raids=(await chrome.storage.local.get('pirate-raids-v1'))['pirate-raids-v1']??{};
      if(raids[accountKey]?.running) throw new Error('יש לעצור את הסבב לפני המחיקה');
      delete raids[accountKey];
      await chrome.storage.local.set({'pirate-raids-v1':raids});
      return visible(state,accountKey);
    }
    // Stopping a round only switches it off; the round's progress is never rewritten from a panel's
    // older copy (that could mark a raid already sent as waiting, and a retry would send it twice).
    if(command.operation==='stop-raids') {
      const raids=(await chrome.storage.local.get('pirate-raids-v1'))['pirate-raids-v1']??{},live=raids[accountKey];
      if(live?.running) await chrome.storage.local.set({'pirate-raids-v1':{...raids,[accountKey]:{...live,running:false,stoppedByUser:true,updatedAt:now(),message:'נעצר על ידך · הפשיטה שכבר בדרך תחזור כרגיל'}}});
      return visible(state,accountKey);
    }
    if(command.operation==='start-raids'||command.operation==='retry-raids'||command.operation==='execute-raids-now') {
      const immediate=command.operation==='execute-raids-now';
      // Captures switched off by the user do not block a round (user decision, 2026-10-18): the
      // stopped pirate automation runs the round alone and switches off again when it ends.
      const pirates=state.rules.filter(r=>r.accountKey===accountKey&&r.kind==='pirates'&&!r.deleted&&!r.uncertain);
      const rule=pirates.find(r=>r.enabled)??pirates.filter(r=>!r.inFlight).sort((a,b)=>(b.lastRunAt??0)-(a.lastRunAt??0))[0];
      if(!rule) throw new Error('יש להגדיר אוטומציית פיראטים בחשבון (אפשר גם כבויה) לפני התחלת סבב');
      if(!rule.enabled) {rule.enabled=true;rule.progress={...rule.progress,raidOnly:true};rule.status='סבב פשיטות בלבד; הלכידות כבויות';log(state,rule,'enabled',rule.status);}
      else if(!immediate) rule.progress={...rule.progress,raidOnly:false};
      const raids=(await chrome.storage.local.get('pirate-raids-v1'))['pirate-raids-v1']??{};
      if(raids[accountKey]?.running&&!immediate) throw new Error('סבב פשיטות כבר פעיל בחשבון');
      if(raids[accountKey]?.running&&immediate) {
        if(!rule.inFlight) {rule.nextRunAt=now();await write(state);}
        await tickAccount(tab,accountKey,rule.id);return visible(await read(),accountKey);
      }
      const previous=raids[accountKey],retry=command.operation==='retry-raids'||immediate&&!command.targets;
      if(retry&&(!previous||!Number.isInteger(previous.index)||previous.index<0||previous.index>=previous.targets?.length)) throw new Error('אין יעד ממתין לניסיון חוזר');
      const targets=retry?previous.targets:command.targets;
      // A target is a verified city, or a player whose nearest city the raid picks (raids panel).
      const valid=t=>/^\d+$/.test(String(t.cityId??''))&&/^\d+$/.test(String(t.islandId??''))||!t.cityId&&typeof t.playerName==='string'&&!!t.playerName.trim();
      // Up to 20 players (user decision, 2026-10-27: the raids list holds 20).
      if(!Array.isArray(targets)||!targets.length) throw new Error('אין יעדים לסבב הפשיטות');
      if(targets.length>20) throw new Error('אפשר לצאת לסבב על עד 20 יעדים');
      if(targets.some(t=>!valid(t))) throw new Error('רשימת יעדי הפשיטות אינה מאומתת');
      const next=retry?{...previous,targets:previous.targets.map((t,i)=>i===previous.index&&t.status==='error'?{...t,status:undefined,message:undefined,sentAt:undefined}:{...t})}:{index:0,targets:targets.map(t=>({...t,status:undefined,message:undefined,sentAt:undefined}))};
      await chrome.storage.local.set({'pirate-raids-v1':{...raids,[accountKey]:{...next,running:true,startedAt:now(),ruleId:rule.id,finishedAt:undefined,updatedAt:undefined,debug:undefined,auto:undefined,stoppedByUser:undefined,message:retry?'ניסיון חוזר התקבל · ממתין לבדיקת הצוות':'הסבב התקבל · ממתין לבדיקת הצוות'}}});
      // Preserve any outstanding operation and its receipt; never submit it a second time.
      if(!rule.inFlight) {rule.nextRunAt=now();await write(state);}
      await tickAccount(tab,accountKey,rule.id);return visible(await read(),accountKey);
    }
    // Dashboard fixes, chosen by the user: release a stuck run (the next check reads the game
    // again before acting) and run an automation now. A confirmed result is never discarded.
    if(command.operation==='release'||command.operation==='run-now') {
      const rule=state.rules.find(rule=>rule.id===command.id&&rule.accountKey===accountKey&&!rule.deleted);
      if(!rule) throw new Error('האוטומציה לא נמצאה');
      if(rule.inFlight) {
        const receipt=(await chrome.storage.local.get('game-result-'+rule.inFlight))['game-result-'+rule.inFlight];
        if(receipt?.status==='complete'&&receipt.ok) throw new Error('התקבלה תוצאה מאושרת; היא תיושם בבדיקה הקרובה');
        if(command.operation==='run-now') throw new Error('האוטומציה באמצע ריצה; המתן לסיומה');
      }
      if(command.operation==='release') {rule.inFlight=null;rule.uncertain=false;rule.failures=0;if(rule.progress) {rule.progress.video=null;rule.progress.needsIntervention=null;}}
      rule.enabled=true;rule.nextRunAt=now();rule.status=command.operation==='release'?'שוחררה לבקשתך; המצב ייקרא מחדש מהמשחק':'הופעלה עכשיו לבקשתך';
      log(state,rule,'enabled',rule.status);await write(state);return visible(state,accountKey);
    }
    if(command.operation==='execute-building') {
      const rule=state.rules.find(r=>r.id===command.id&&r.accountKey===accountKey&&!r.deleted&&r.kind==='building');
      if(!rule||rule.inFlight||rule.uncertain)throw new Error('תוצאת שדרוג קודם אינה ידועה; יש לבדוק אותו במשחק לפני חידוש');
      Object.assign(rule,{reserve:0,procure:true,enabled:true,reviewMode:'auto',approval:null,proposal:null,nextRunAt:now(),status:'תור הבנייה הופעל עם שימוש במשאבים הזמינים'});
      log(state,rule,'enabled',rule.status);await write(state);return visible(state,accountKey);
    }

    if(command.operation==='verify-building') {
      const rule=state.rules.find(r=>r.id===command.id&&r.accountKey===accountKey&&!r.deleted&&r.kind==='building');
      if(!rule)throw new Error('משימת הבנייה לא נמצאה');
      const response=await chrome.tabs.sendMessage(tab.id,{type:'IKARIAM_AGENT_AUTOMATION_CATALOG',kind:'building',cityId:rule.cityId,accountKey});
      if(!response?.ok||!Array.isArray(response.catalog?.entries))throw new Error(response?.reason??'בדיקת הבניין במשחק לא הושלמה');
      if(await identity(tab)!==accountKey)throw new Error('החשבון השתנה במהלך הבדיקה');
      const remaining=rule.entries.slice(Number(rule.progress?.index??0));
      const completed=remaining.length>0&&remaining.every(entry=>response.catalog.entries.some(actual=>actual.key===entry.key&&actual.position===entry.position&&Number.isFinite(actual.level)&&actual.level>=entry.target));
      if(completed) {
        rule.enabled=false;rule.uncertain=false;rule.inFlight=null;rule.progress={...rule.progress,index:rule.entries.length};rule.status='אומת במשחק: יעדי שדרוג המבנים הושלמו';log(state,rule,'complete',rule.status);
      } else {rule.status='נבדק במשחק: יעד השדרוג טרם הושלם; תוצאת הבקשה עדיין אינה ידועה';log(state,rule,'verified',rule.status);}
      await write(state);return visible(state,accountKey);
    }

    if(command.operation==='review-mode'||command.operation==='decision') {
      const rule=state.rules.find(rule=>rule.id===command.id&&rule.accountKey===accountKey&&!rule.deleted);
      if(!rule||rule.inFlight||rule.uncertain) throw new Error('יש להמתין לסיום ההרצה לפני שינוי התכנון');
      if(command.operation==='review-mode') {
        if(!['auto','manual'].includes(command.mode)) throw new Error('מצב ביצוע אינו תקין');
        rule.reviewMode=command.mode;rule.approval=null;rule.proposal=null;rule.skippedPlans=[];
        log(state,rule,'mode',command.mode==='manual'?'נבחר אישור ידני':'נבחר ביצוע אוטומטי');
      } else {
        if(rule.reviewMode!=='manual'&&!rule.proposal?.forced||rule.proposal?.key!==command.key||now()-rule.proposal.createdAt>(rule.proposal.forced?3600000:180000)) throw new Error('ההצעה אינה זמינה או פגה; יש להמתין לבדיקה עדכנית');
        if(command.approved===true) {rule.approval={key:command.key,approvedAt:now()};log(state,rule,'approved','הפעולה אושרה; התנאים ייבדקו שוב לפני ביצוע');}
        else {rule.skippedPlans=[...(rule.skippedPlans??[]),command.key].slice(-100);log(state,rule,'skipped','הפעולה דולגה על ידי המשתמש');}
        rule.proposal=null;
      }
      rule.nextRunAt=now();await write(state);return visible(state,accountKey);
    }
    if(command.operation==='captcha') {
      const rule=state.rules.find(rule=>rule.id===command.id&&rule.accountKey===accountKey&&!rule.deleted&&rule.kind==='pirates');
      // Accepted even while a check runs: the code is kept and sent by the next run.
      if(!rule) throw new Error('אוטומציית הפיראטים לא נמצאה בחשבון הזה');
      if(!/^[A-Za-z0-9]{3,12}$/.test(command.value??'')) throw new Error('יש להקליד את התווים שבתמונה');
      rule.captchaAnswer={value:command.value,at:now()};rule.nextRunAt=now();log(state,rule,'approved','התקבל קוד קפצ׳ה; יישלח בבדיקה הבאה');
      rule.outbox=(rule.outbox??[]).concat([{message:'🔎 שחזור הקוד בחשבון "'+accountKey.split('|')[0]+'" נבדק',attempts:0}]);
      await write(state);return visible(state,accountKey);
    }
    // Building uniformity: the autopilot refreshes a city's queue from the latest plan.
    if(command.operation==='set-entries') {
      // Firefox: satisfaction care raises the governor's residence target of its own queue too.
      const rule=state.rules.find(rule=>rule.id===command.id&&rule.accountKey===accountKey&&!rule.deleted&&rule.kind==='building'&&(rule.autopilot==='uniform'||!mainEdition()&&rule.autopilot==='satisfaction'));
      if(!rule) throw new Error('תור האחידות לא נמצא');
      if(rule.inFlight) return visible(state,accountKey);
      rule.entries=globalThis.IkariamAutomationRules.validateRule({...rule,startAt:null,entries:command.entries}).entries;
      await write(state);return visible(state,accountKey);
    }
    if(command.operation==='clear-log') {state.events=state.events.filter(event=>event.accountKey!==accountKey);}
    else if(command.operation==='save'||command.operation==='save-batch') {
      const inputs=command.operation==='save-batch'?command.rules:[command.rule];
      if(!Array.isArray(inputs)||inputs.length<1||inputs.length>60) throw new Error('יש לבחור בין עיר אחת ל־60 ערים');
      const configs=inputs.map(globalThis.IkariamAutomationRules.validateRule);
      if(!mainEdition()&&configs.some(config=>config.kind==='pirates'&&!firefoxPirate(config))) throw new Error('בגרסת Firefox מותרת רק משימת פיראטים 1 ברצף');
      // Up to 100 automations of the user; the autopilot's own (one per city) come on top.
      const live=state.rules.filter(rule=>!rule.deleted);
      if(live.filter(rule=>!rule.autopilot).length+configs.filter(config=>!config.autopilot).length>100||live.length+configs.length>400) throw new Error('ניתן לשמור עד 100 אוטומציות');
      for(const config of configs) if(state.rules.some(rule=>rule.accountKey===accountKey && rule.cityId===config.cityId && rule.inFlight)) throw new Error('בעיר זו קיימת פעולה שטרם התקבלה תוצאתה');
      for(const config of configs) {
        const rule={...config,id:uuid(),accountKey,enabled:false,status:'נשמרה — ממתינה להפעלה',cycles:0,progress:{},nextRunAt:config.startAt??now()};
        state.rules.push(rule);log(state,rule,'saved',rule.status);
      }
    } else if(['toggle','delete'].includes(command.operation)) {
      const rule=state.rules.find(rule=>rule.id===command.id&&rule.accountKey===accountKey&&!rule.deleted);
      if(!rule) throw new Error('האוטומציה לא נמצאה');
      if(command.operation==='delete') {rule.deleted=true;rule.enabled=false;log(state,rule,'deleted','האוטומציה הוסרה; פעולות שכבר התחילו ממשיכות במשחק');}
      else {
        if(command.enabled && (rule.inFlight || rule.uncertain)) throw new Error('תוצאת פעולה אינה ידועה; אין להפעיל שוב לפני בדיקה במשחק');
        if(command.enabled && rule.cycles>=rule.maxCycles) throw new Error('מגבלת המחזורים הושלמה');
        const clash=other=>other.id!==rule.id && other.enabled && other.accountKey===accountKey && other.cityId===rule.cityId && other.kind===rule.kind && !(rule.kind==='daily'&&!!rule.allDayVideos!==!!other.allDayVideos&&!(rule.collectVideos&&other.collectVideos));
        // What the user (or the morning routine) switches on wins over the agent's own automation
        // in that city: the agent's one steps aside and comes back when the user's one is gone.
        if(command.enabled && !rule.autopilot) for(const other of state.rules.filter(other=>clash(other)&&other.autopilot&&!other.inFlight)) {other.enabled=false;other.status='מושבתת';log(state,other,'paused','הושבתה כי הופעלה אוטומציה ידנית מאותו סוג בעיר');}
        // An upgrade the user approved for satisfaction (Firefox) is the user's own decision: the
        // agent's building uniformity in that city steps aside for it, like for a manual queue.
        if(command.enabled && !mainEdition() && rule.autopilot==='satisfaction' && rule.kind==='building') for(const other of state.rules.filter(other=>clash(other)&&other.autopilot==='uniform'&&!other.inFlight)) {other.enabled=false;other.status='מושבתת';log(state,other,'paused','הושבתה לטובת שדרוג שביעות רצון שאושר');}
        if(command.enabled && state.rules.some(clash)) throw new Error('אוטומציה מאותו סוג כבר פעילה בעיר זו');
        // The main edition has no Telegram (user decision, 2026-10-16): its alerts stay in the panel.
        if(command.enabled && !mainEdition() && rule.kind==='pirates' && !await pirateBot()) throw new Error('יש להגדיר בוט טלגרם לפיראטים (הגדרות ← טלגרם לפיראטים) לפני ההפעלה');
        if(command.enabled && rule.telegram && !mainEdition() && rule.kind!=='pirates' && !Object.values(await channels(accountKey)).some(Boolean)) throw new Error('יש להגדיר חיבור טלגרם לפני הפעלת ההתראות');
        rule.enabled=command.enabled===true;rule.status=rule.enabled?'ממתינה לבדיקה':'מושבתת';rule.nextRunAt=Math.max(now(),rule.startAt??0);rule.failures=0;
        log(state,rule,rule.enabled?'enabled':'paused',rule.status);
      }
    } else throw new Error('פעולת ניהול אינה נתמכת');
    state.rules=state.rules.filter(rule=>!rule.deleted||rule.inFlight);await write(state);return visible(state,accountKey);
  }
  // Every account with work runs in its own tab; accounts without an open tab wait.
  async function tick() {
    const stored=await read();
    // Telegram replies must be collected even while a game tab is loading or unavailable.
    for(const rule of stored.rules.filter(rule=>rule.kind==='pirates'&&(mainEdition()||firefoxPirate(rule))&&!rule.deleted&&rule.progress?.captcha&&!(rule.captchaAnswer?.at>=rule.progress.captcha.at))) {
      await telegramCaptcha(stored,rule.accountKey,rule);
    }
    try {await telegramApprovals(stored);} catch { /* Approvals retry on the next round. */ }
    await write(stored);
    void fastCaptcha().catch(()=>{});
    drivePirates(stored);
    // An account with a running raid round is checked even when its pirate automation is switched off.
    const rounds=(await chrome.storage.local.get('pirate-raids-v1'))['pirate-raids-v1']??{};
    // Firefox: a hidden account keeps its settings but runs nothing (user decision, 2026-10-25: Orakel8 set aside).
    const hidden=new Set(mainEdition()?[]:((await chrome.storage.local.get('hidden-accounts-v1'))['hidden-accounts-v1']??['Orakel8|42|il','Orelkaful8|42|il']));
    const keys=[...new Set(stored.rules.filter(rule=>!rule.deleted&&!hidden.has(rule.accountKey)&&(rule.enabled||rule.inFlight||rule.uncertain||(rule.failures??0)>=3&&transient(rule.status)||rule.outbox?.length||rule.vacationCode||rule.kind==='pirates'&&rounds[rule.accountKey]?.running)).map(rule=>rule.accountKey))];
    // A fair queue (user request, 2026-10-15): every round starts from the next account, so the
    // accounts listed first do not take every free place.
    rotation=(rotation+1)%Math.max(1,keys.length);
    for(const key of [...keys.slice(rotation),...keys.slice(0,rotation)]) {
      const tab=await findTab(key);if(!tab?.id) continue;
      let owner;try {owner=await identity(tab);} catch {continue;}
      if(owner===key) await tickAccount(tab,key);
    }
  }
  const lastDispatch=new Map();let rotation=0;
  async function tickAccount(tab,accountKey,preferredRule=null) {
    const state=await read();
    const activeRaids=((await chrome.storage.local.get('pirate-raids-v1'))['pirate-raids-v1']??{})[accountKey];
    // The shipping runtime shares the same content-script serial queue. Do not
    // queue behind a known outstanding shipping operation on this account.
    const transport=(await chrome.storage.local.get('transport-automation-v1'))['transport-automation-v1'];
    // One-time: waits scheduled by the earlier offer detection (which missed available offers
    // carrying an empty timer) are dropped, so every account checks the cinema right away.
    for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&rule.kind==='daily'&&rule.allDayVideos&&!rule.deleted&&!rule.inFlight&&(rule.cinemaVersion??0)<2)) {rule.cinemaVersion=2;rule.nextRunAt=now();}
    // One-time: barbarian rules stopped by the old troop reader ("cannot verify the troops") run again.
    for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&rule.kind==='barbarians'&&!rule.deleted&&!rule.inFlight&&(rule.armyReader??0)<3&&/לא ניתן לאמת את כמות הכוחות/.test(rule.status??''))) {
      rule.armyReader=3;rule.enabled=true;rule.uncertain=false;rule.failures=0;rule.nextRunAt=now();rule.status='קריאת הצבא עודכנה לפי Ikabot; בודקת שוב';log(state,rule,'waiting',rule.status);
    }
    // The agent's own pirate raids choose their mission by the measured captcha statistics.
    for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&rule.kind==='pirates'&&rule.autopilot==='pirates'&&!rule.pirateStrategy)) rule.pirateStrategy='auto';
    // Firefox runs only mission 1 back to back in the capital (user decision, 2026-10-28): any older pirate raid is switched off.
    // A Firefox raid left uncertain by an older version (before the automatic recovery) goes on as well.
    if(!mainEdition()) for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&firefoxPirate(rule)&&!rule.deleted&&rule.uncertain)) pirateRecover(state,rule,'נמצאה ריצה עם תוצאה לא ידועה');
    if(!mainEdition()) for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&rule.kind==='pirates'&&!rule.deleted&&rule.enabled&&!firefoxPirate(rule)&&!rule.inFlight)) {rule.enabled=false;rule.status='הוחלפה בפשיטה ברצף של משימה 1 בעיר הבירה';log(state,rule,'stopped',rule.status);}
    // Daily bonuses stopped by a favour reward the game refused (fixed 2026-10-28: a refused reward is skipped for
    // the day) run again once.
    for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&rule.kind==='daily'&&!rule.deleted&&!rule.enabled&&!rule.inFlight&&(rule.favourRefusalFix??0)<1&&/המשחק דחה את הפעולה/.test(rule.status??''))) {
      rule.favourRefusalFix=1;rule.enabled=true;rule.uncertain=false;rule.failures=0;rule.nextRunAt=now();rule.status='הופעלה מחדש: תגמול חסד שהמשחק סירב לו מדולג עד מחר';log(state,rule,'enabled',rule.status);
    }
    // Taverns stopped by asking for a level the tavern had not unlocked (fixed 2026-10-15) run again once.
    for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&rule.kind==='tavern'&&!rule.deleted&&!rule.enabled&&!rule.inFlight&&(rule.tavernLevelFix??0)<1&&/המשחק דחה את הפעולה/.test(rule.status??''))) {
      rule.tavernLevelFix=1;rule.enabled=true;rule.uncertain=false;rule.failures=0;rule.nextRunAt=now();rule.status='ממתינה לבדיקה';log(state,rule,'enabled','חודשה: הטברנה מגישה עכשיו את הרמה המרבית שהיא מאפשרת');
    }
    // One pirate automation per city: an agent's own one that stays off beside an active one of the
    // user's (a restored backup) is removed.
    for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&rule.kind==='pirates'&&rule.autopilot==='pirates'&&!rule.deleted&&!rule.enabled&&!rule.inFlight&&
      state.rules.some(other=>other!==rule&&other.accountKey===accountKey&&other.kind==='pirates'&&!other.deleted&&other.enabled&&String(other.cityId)===String(rule.cityId)))) {
      rule.deleted=true;log(state,rule,'deleted','הוסרה כפילות: אוטומציית פיראטים אחרת פעילה באותה עיר');
    }
    // Building queues already stopped that way (before the rule above) are released too.
    for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&rule.kind==='building'&&!rule.deleted&&rule.uncertain&&transient(rule.status))) {
      rule.uncertain=false;rule.inFlight=null;rule.enabled=true;rule.failures=0;rule.nextRunAt=now();rule.status='הפעולה נשלחה והקריאה שאחריה נכשלה; העיר תיקרא שוב לפני כל פעולה';log(state,rule,'waiting',rule.status);
    }
    // One-time: barbarian runs stopped after ordering troops (the training was not recognised)
    // run again; the order is treated as training, so nothing is ordered twice.
    for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&rule.kind==='barbarians'&&!rule.deleted&&rule.uncertain&&(rule.recruitVerify??0)<1&&/לא ניתן לאמת את השינוי/.test(rule.status??''))) {
      rule.recruitVerify=1;rule.inFlight=null;rule.uncertain=false;rule.failures=0;rule.enabled=true;rule.nextRunAt=now();
      rule.progress={...rule.progress,recruitPending:{at:now(),orders:null,baseline:null}};
      rule.status='הגיוס שהוזמן נחשב לגיוס פעיל; התקיפה תצא כשהכוחות יגיעו';log(state,rule,'waiting',rule.status);
    }
    // A run cut off by a tab reload never reports back. For actions the game refuses to repeat
    // harmlessly — cinema bonuses, starting an upgrade that already started, setting the tavern
    // wine level or the workers — the run is released after ten minutes (fifteen for
    // upgrades) and the next check reads the game again before acting.
    // Pirates: the next run reads the fortress first and waits while a mission is active.
    // A pirate run carrying a captcha code is released after five minutes, so the code is sent again.
    const releasable=rule=>rule.kind==='daily'&&rule.allDayVideos?600000:rule.kind==='pirates'&&rule.captchaAnswer?300000:['building','pirates','barbarians','reinforce'].includes(rule.kind)?900000:['tavern','workers'].includes(rule.kind)?600000:['attacks','islands'].includes(rule.kind)?300000:null;
    // A run lost with a tab refresh (the tab's queue is empty, the result still pending) is released
    // after 90 seconds instead of ten to fifteen minutes; nothing was running it any more.
    const safelyLost=new Set();
    // Recover only after the tab proves its queue is empty and a fresh game read succeeds.
    // New receipts record raid intent before POST; an unconfirmed intent is never replayed.
    if(activeRaids?.running) for(const rule of state.rules.filter(r=>r.accountKey===accountKey&&r.kind==='pirates'&&!r.deleted&&r.inFlight&&now()-(r.dispatchedAt??now())>90000)) {
      if(now()-(rule.raidRecoveryAt??0)<60000) continue;
      rule.raidRecoveryAt=now();
      try {
        const bounded=async message=>{let timer;try {return await Promise.race([chrome.tabs.sendMessage(tab.id,message),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('recovery check timed out')),10000);})]);} finally {clearTimeout(timer);}};
        const health=await bounded({type:'IKARIAM_AGENT_QUEUE_HEALTH'});
        if(!health?.ok||health.runningSince||health.waiting) continue;
        const receipt=(await chrome.storage.local.get('game-result-'+rule.inFlight))['game-result-'+rule.inFlight];
        if(receipt?.status==='complete') continue;
        const current=activeRaids.targets?.[activeRaids.index];
        const safe=receipt?.phase==='queued'||receipt?.raidTracking===1&&!receipt.raidSubmission||current?.status==='sent'&&String(receipt?.raidSubmission?.cityId)===String(current.cityId);
        if(!safe) {rule.status='התאוששות אוטומטית: תוצאת שליחה קודמת אינה ידועה; נמנעת שליחה כפולה';continue;}
        const check=await bounded({type:'IKARIAM_AGENT_PIRACY_CHECK',rule});
        if(!check?.ok||typeof check.result?.active!=='boolean') continue;
        // Re-read the receipt after the game check: a completed result always takes precedence.
        const latest=(await chrome.storage.local.get('game-result-'+rule.inFlight))['game-result-'+rule.inFlight];
        if(latest?.status==='complete') continue;
        rule.inFlight=null;rule.uncertain=false;rule.enabled=true;rule.failures=0;rule.nextRunAt=now();
        rule.status=check.result.active?'התאוששות אוטומטית: הצוות במשימה; הסבב ימתין לחזרתו':'התאוששות אוטומטית: ההרצה שנקטעה שוחררה; הסבב ממשיך';
        log(state,rule,'waiting',rule.status);
      } catch { /* A failed health/game read is retried next minute without submitting anything. */ }
    }
    const lost=state.rules.filter(rule=>rule.accountKey===accountKey&&!rule.deleted&&rule.inFlight&&!rule.uncertain&&releasable(rule)!==null&&now()-(rule.dispatchedAt??0)>90000);
    if(lost.length) {
      let health=null;try {health=await Promise.race([chrome.tabs.sendMessage(tab.id,{type:'IKARIAM_AGENT_QUEUE_HEALTH'}),new Promise(resolve=>setTimeout(()=>resolve(null),3000))]);} catch { /* No answer: keep waiting. */ }
      if(health?.ok&&!health.runningSince&&!health.waiting) for(const rule of lost) {
        const receipt=(await chrome.storage.local.get('game-result-'+rule.inFlight))['game-result-'+rule.inFlight];
        if(receipt&&receipt.status!=='pending') continue;
        if(activeRaids?.running&&rule.kind==='pirates') continue;
        if(receipt?.phase==='queued') safelyLost.add(rule.id);
        rule.dispatchedAt=0;
      }
    }
    for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&!rule.deleted&&releasable(rule)!==null&&(rule.inFlight||rule.uncertain)&&now()-(rule.dispatchedAt??0)>releasable(rule))) {
      const receipt=rule.inFlight?(await chrome.storage.local.get('game-result-'+rule.inFlight))['game-result-'+rule.inFlight]:null;
      // A confirmed success is applied by the normal path below; anything else is released.
      if(receipt?.status==='complete'&&receipt.ok) continue;
      if(activeRaids?.running&&rule.kind==='pirates'&&!safelyLost.has(rule.id)) continue;
      rule.inFlight=null;rule.uncertain=false;rule.enabled=true;rule.failures=0;rule.nextRunAt=now();if(rule.progress) rule.progress.video=null;
      rule.status=rule.kind==='daily'?'הריצה הקודמת נקטעה; איסוף הבונוסים ממשיך':'הריצה הקודמת נקטעה; המצב ייקרא מחדש מהמשחק לפני כל פעולה';log(state,rule,'waiting',rule.status);
    }
    // Firefox: a wine refill whose result stayed unknown for six hours is settled long ago in the game; it
    // is switched off (never sent again) so its city is not held — satisfaction care supplies the wine now
    // (user report, 2026-10-22: two such refills held Polis3 and Polis5 since the day before).
    if(!mainEdition()) for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&rule.kind==='wine'&&!rule.deleted&&rule.uncertain&&now()-(rule.dispatchedAt??rule.lastRunAt??0)>6*3600000)) {
      rule.uncertain=false;rule.inFlight=null;rule.enabled=false;rule.status='הושבתה: תוצאת העברת יין ישנה לא ידועה ולא תישלח שוב; היין מסופק דרך טיפול בשביעות רצון';log(state,rule,'paused',rule.status);
    }
    // A run that stayed without a result for 30 minutes no longer holds the tab or its city (user report,
    // 2026-10-22: a stuck wine run stopped Opera's supply scans until a click). Kinds that read the game
    // again before acting are released the way the "release" button does — nothing is sent from memory.
    for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&!rule.deleted&&rule.uncertain&&['wine','tavern','building','daily','research','workers'].includes(rule.kind)&&now()-(rule.dispatchedAt??rule.lastRunAt??0)>1800000)) {
      if(rule.kind==='wine'&&!mainEdition()) continue; // Firefox: settled below without a resend.
      rule.inFlight=null;rule.uncertain=false;rule.failures=0;if(rule.progress) {rule.progress.video=null;rule.progress.needsIntervention=null;}
      rule.enabled=true;rule.nextRunAt=now();rule.status='שוחררה אוטומטית אחרי 30 דקות בלי תוצאה; המצב ייקרא מחדש מהמשחק לפני כל פעולה';log(state,rule,'waiting',rule.status);
    }
    // An automation stopped only by temporary read failures (a slow game or network) resumes.
    for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&!rule.deleted&&!rule.enabled&&!rule.uncertain&&!rule.inFlight&&(rule.failures??0)>=3&&transient(rule.status)&&now()-(rule.lastFailureAt??0)>=1800000)) {
      rule.enabled=true;rule.nextRunAt=now();log(state,rule,'waiting','חודשה אחרי כשלי קריאה זמניים');
    }
    for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey)) {
      if(rule.inFlight) {
        const receipt=(await chrome.storage.local.get('game-result-'+rule.inFlight))['game-result-'+rule.inFlight];
        if(receipt?.status==='complete'&&(!rule.uncertain||receipt.ok||receipt.mutationSubmitted===false)) {
          if(receipt.ok) {
            const result=receipt.result;
            if(!result || !['waiting','changed','complete','alert'].includes(result.status)) {if(firefoxPirate(rule)) {pirateRecover(state,rule,'תוצאת הריצה לא זוהתה');continue;}rule.enabled=false;rule.uncertain=true;rule.status='תוצאת פעולה אינה תואמת';log(state,rule,'error',rule.status);continue;}
            rule.uncertain=false;rule.progress=result.progress??rule.progress;rule.status=result.message;rule.lastRunAt=now();rule.failures=0;
            rule.proposal=result.proposal??null;rule.executionPlan=result.executedPlan??null;rule.approval=null;
            // A code is cleared only once a run that started after it has used it.
            if(rule.kind==='pirates'&&!result.keepCaptchaAnswer&&(rule.captchaAnswer?.at??0)<=(rule.dispatchedAt??0)) rule.captchaAnswer=null;
            rule.idle=result.idle===true;if(result.gold) rule.lastGold=result.gold;
            if(result.cycle) rule.cycles++;
            // The daily cap counts per account (7 accounts share one browser): [time, account].
            if(result.status==='changed') {state.actions??=[];state.actions.push([now(),rule.accountKey]);}
            if(result.status==='complete'||!(rule.kind==='pirates'&&(rule.continuous||rule.progress.captureConversionPending||rule.progress.raidOnly))&&rule.cycles>=rule.maxCycles) rule.enabled=false;
            rule.nextRunAt=now()+Math.max(rule.kind==='pirates'?1000:rule.allDayVideos?30000:120000,rule.kind==='pirates'&&result.cycle&&rule.progress.captureConversionPending?1000:rule.kind==='pirates'&&Number.isFinite(rule.progress.missionEndsAt)?rule.progress.missionEndsAt+15000-now():result.delayMs??rule.intervalMinutes*60000);
            // A capture timer from before the round must not postpone raid-return checks.
            // Polling is read-only until the page verifies both crew and movements again.
            if(mainEdition()&&rule.kind==='pirates'&&activeRaids?.running)rule.nextRunAt=Math.min(rule.nextRunAt,now()+30000);
            // A code that arrived during that run is sent right away.
            if(rule.kind==='pirates'&&!result.keepCaptchaAnswer&&rule.captchaAnswer&&rule.progress?.captcha&&rule.captchaAnswer.at>=(rule.progress.captcha.at??0)) rule.nextRunAt=now();
            const changedStatus=rule.lastLoggedStatus!==result.message;
            if(result.status!=='waiting'||changedStatus) {log(state,rule,result.status,result.message);rule.lastLoggedStatus=result.message;}
            if(result.alerts?.length && rule.kind==='attacks' && rule.vacationReply && rule.telegram) {
              rule.vacationCode=String(1000+Math.floor(Math.random()*9000));rule.vacationCodeAt=now();
              result.alerts=result.alerts.map(message=>message+'\nלהפעלת מצב חופשה השב תוך שעתיים: חופשה '+rule.vacationCode);
            }
            // All-day cinema and pirate captcha messages always go to the shared Telegram channel.
            if(result.alerts?.length && (rule.telegram||rule.allDayVideos||rule.kind==='pirates')) {
              // Retain an outbox before sending; Telegram failures cannot cause
              // game mutations to be replayed.
              // Firefox pirates report only captchas and stops (user decision, 2026-10-28), not every launch.
              const alerts=result.alerts.filter(message=>!(!mainEdition()&&rule.kind==='pirates')&&!(rule.kind==='pirates'&&rule.progress?.captcha&&/ממתינה לפתרון קפצ/.test(message)));
              rule.outbox=(rule.outbox??[]).concat(alerts.map(message=>({message,attempts:0}))).slice(-100);
            }
            rule.inFlight=null;
          } else {
            rule.status=receipt.reason??'ההרצה נכשלה';rule.failures=(rule.failures??0)+1;rule.lastFailureAt=now();
            // A building queue whose post-action read failed is checked again in ten minutes: the
            // run reads the city first, and the game never starts the same upgrade twice.
            if(receipt.mutationSubmitted!==false&&rule.kind==='building'&&transient(rule.status)) {rule.uncertain=false;rule.inFlight=null;rule.nextRunAt=now()+600000;rule.status='הפעולה נשלחה והקריאה שאחריה נכשלה; העיר תיקרא שוב לפני כל פעולה';log(state,rule,'waiting',rule.status);}
            else if(receipt.mutationSubmitted!==false&&firefoxPirate(rule)) pirateRecover(state,rule,rule.status);
            else if(receipt.mutationSubmitted!==false) {rule.enabled=false;rule.uncertain=true;log(state,rule,'unknown','תוצאת פעולה אינה ידועה — ההרצה נעצרה; יש לבדוק במשחק');}
            // Temporary read failures keep retrying (up to an hour apart) instead of stopping.
            else {rule.uncertain=false;rule.inFlight=null;rule.nextRunAt=now()+(firefoxPirate(rule)?(rule.failures<10?30000:60000):Math.min(3600000,120000*2**rule.failures));if(!firefoxPirate(rule)&&rule.failures>=3&&!transient(rule.status)) rule.enabled=false;log(state,rule,'error',rule.status);}
          }
        } else if(now()-(rule.dispatchedAt??now())>600000) {if(firefoxPirate(rule)) pirateRecover(state,rule,'לא התקבלה תוצאה');else if(!rule.uncertain){rule.enabled=false;rule.uncertain=true;rule.status='לא התקבלה תוצאה; יש לבדוק במשחק';log(state,rule,'unknown',rule.status);}}
      }
      // Firefox pirates: a raid stopped by failures (or left with an unknown result) is reported once to the pirate bot.
      if(!mainEdition()&&rule.kind==='pirates') {
        const stopped=rule.uncertain||rule.enabled===false&&(rule.failures??0)>0;
        if(stopped&&rule.pirateStopNoted!==rule.status) {rule.pirateStopNoted=rule.status;rule.outbox=(rule.outbox??[]).concat([{message:'⚠️ פשיטת הפיראטים בחשבון "'+accountKey.split('|')[0]+'" נעצרה: '+(rule.status??'סיבה לא ידועה'),attempts:0}]).slice(-100);}
        else if(!stopped) rule.pirateStopNoted=null;
      }
      if(rule.outbox?.length) {
        await write(state);
        const pending=rule.outbox[0];
        try {if(!mainEdition()&&rule.kind==='pirates') {const bot=await pirateBot();if(!bot) throw new Error('לא הוגדר בוט טלגרם לפיראטים');await sendTelegram(accountKey,pending.message,bot);} else await notify(accountKey,pending.message);rule.outbox.shift();log(state,rule,'telegram','התראה נשלחה');}
        catch(error) {pending.attempts++;log(state,rule,'error',error.message);if(pending.attempts>=3) rule.outbox.shift();}
      }
    }
    for(const rule of state.rules.filter(rule=>rule.accountKey===accountKey&&rule.vacationCode)) {
      if(now()-rule.vacationCodeAt>2*3600000) rule.vacationCode=null;else await telegramReplies(state,accountKey,rule,tab);
    }
    await write(state);
    await cleanup(state);
    const barbarianRound=mainEdition()?await mainBarbarians.prepare(state,accountKey):null;
    if(mainEdition()&&barbarianRound)await write(state);
    // All-day cinema bonuses are small account-level requests: they may queue in the tab behind a
    // running shipment, ignore an uncertain rule elsewhere in the city and the shared daily cap,
    // and go first, so a bonus is collected as soon as it is available.
    const cinema=rule=>rule.kind==='daily'&&rule.allDayVideos===true;
    // A captcha the user already answered goes first too, even beside a running shipment scan:
    // otherwise an account whose balancing scans every few minutes kept the answer waiting for hours.
    const answered=rule=>rule.kind==='pirates'&&!!rule.captchaAnswer;
    const first=rule=>cinema(rule)||answered(rule);
    // A pirate raid that is due (no captcha waiting for the user) goes before routine checks.
    const raid=rule=>rule.kind==='pirates'&&!rule.progress?.captcha;
    // Opera: a building automation whose city has its builder free goes before the routine checks (user report,
    // 2026-10-29: Yayin 2's builder stood free for half an hour behind tavern and wine checks that were fine anyway).
    const idleBuilders=new Set();
    if(mainEdition()) for(const city of ((await chrome.storage.local.get('account-snapshot-'+accountKey))['account-snapshot-'+accountKey]?.snapshot?.cities??[])) if(!(city.buildings??[]).some(item=>item?.isBusy&&!(Number(item.completed)>0&&Number(item.completed)*1000<now()))) idleBuilders.add(String(city.id));
    const builderFree=rule=>rule.kind==='building'&&idleBuilders.has(String(rule.cityId));
    // Wine-only mode in this account (user decision, 2026-10-16): no building (the uniformity
    // queue still runs, for the workers only), no regular temple, nothing that moves resources,
    // and wine supply only between 00:00 and 07:00 Israel time. Switches are not changed.
    const wineOnly=!!(await chrome.storage.local.get('wine-only-v1'))['wine-only-v1']?.accounts?.[accountKey];
    const night=Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jerusalem',hour:'2-digit',hourCycle:'h23'}).format(new Date(now())))<7;
    // War mode (user decision, 2026-10-16): everything goes to the alliance; no manual building
    // queue, gathering, donating or market buying uses the resources meanwhile. Wine control goes on.
    const war=!!(await chrome.storage.local.get('war-mode-v1'))['war-mode-v1']?.active;
    const held=rule=>!mainEdition()&&rule.kind==='pirates'&&!firefoxPirate(rule)||war&&(rule.kind==='building'&&rule.autopilot!=='uniform'&&rule.autopilot!=='satisfaction'||['consolidate','donate','market'].includes(rule.kind))||
      // Satisfaction comes first of all (Firefox, user decision 2026-10-20): the governor's residences
      // of satisfaction care are built in wine-only accounts too (user report, 2026-10-22: Orakel1–4
      // had their residence queues held there since they were opened).
      wineOnly&&(rule.kind==='building'&&rule.autopilot!=='uniform'&&!(!mainEdition()&&rule.autopilot==='satisfaction')||['miracle','consolidate','donate'].includes(rule.kind)||rule.kind==='wine'&&!night);
    // Only automations that ship resources themselves wait for a running shipment scan; building,
    // research, the tavern and the rest run beside it (the scan re-reads stock before each send),
    // so a busy balancing no longer leaves the builders idle (user report, 2026-10-15).
    const ships=rule=>['wine','market','consolidate','donate'].includes(rule.kind);
    const pendingRuns=state.rules.filter(rule=>rule.accountKey===accountKey&&rule.inFlight&&!rule.uncertain);
    if(activeRaids?.running) {
      const pendingPirate=pendingRuns.find(rule=>rule.kind==='pirates');
      // Opera: a raid round keeps a raid pending nearly all the time (a check every half minute), which held every
      // other automation for hours (user report, 2026-10-29: a builder stood idle from 12:01; Kristal 12's building
      // had not run since the evening before). One other run goes out beside it; the tab still runs the raid first.
      if(pendingPirate) {try {await chrome.tabs.sendMessage(tab.id,{type:'IKARIAM_AGENT_PRIORITIZE_RAID',operationId:pendingPirate.inFlight});} catch {}if(!mainEdition()||pendingRuns.some(rule=>rule.kind!=='pirates')) return;}
    }
    // Tab execution remains serial; a manual raid may queue ahead of other pending jobs.
    // A Firefox raid that is due (or holds its captcha code) goes out beside the account's other pending work.
    const captchaReady=!mainEdition()&&state.rules.some(rule=>rule.accountKey===accountKey&&firefoxPirate(rule)&&rule.enabled&&!rule.inFlight&&(rule.progress?.captcha?rule.captchaAnswer?.at>=rule.progress.captcha.at:rule.nextRunAt<=now()));
    const alongside=(mainEdition()||captchaReady)&&pendingRuns.length&&!pendingRuns.some(rule=>rule.kind==='pirates');
    if(pendingRuns.length&&!activeRaids?.running&&!alongside) return;
    const shipping=transport?.rules?.some(rule=>rule.accountKey===accountKey&&rule.inFlight);
    const uncertainCities=new Set(state.rules.filter(rule=>rule.accountKey===accountKey&&rule.uncertain).map(rule=>rule.cityId));
    const raidState=((await chrome.storage.local.get('pirate-raids-v1'))['pirate-raids-v1']??{})[accountKey];
    // A newly requested round wakes the existing pirate rule once; later checks keep their delay.
    const newRound=rule=>rule.kind==='pirates'&&raidState?.running&&raidState.startedAt>(rule.dispatchedAt??0);
    // The round belongs to one pirate automation; a deleted owner hands it to the account's other
    // pirate automation, and an owner the user switched off still drives the round to its end
    // (the captures stay off) — a round never waits for an automation that will not run.
    const owner=raidState?.running&&raidState.ruleId?state.rules.find(rule=>rule.id===raidState.ruleId&&rule.accountKey===accountKey&&rule.kind==='pirates'&&!rule.deleted):null;
    if(mainEdition()&&raidState?.running) for(const item of state.rules.filter(item=>item.accountKey===accountKey&&item.kind==='pirates'&&!item.deleted&&!item.inFlight&&!item.uncertain&&(!owner||item.id===owner.id))) item.nextRunAt=Math.min(item.nextRunAt,Math.max(now(),(item.dispatchedAt??0)+30000));
    const roundRule=rule=>!raidState?.running||!owner||rule.kind!=='pirates'||rule.id===owner.id;
    const drives=rule=>!!owner&&rule.id===owner.id&&!rule.uncertain;
    const rule=state.rules.filter(rule=>rule.accountKey===accountKey && (!mainEdition()||mainBarbarians.allows(rule,barbarianRound)) && (!alongside||rule.kind==='pirates') && (!preferredRule||rule.id===preferredRule) && roundRule(rule) && (rule.enabled||drives(rule))&&!rule.inFlight&&!rule.deleted&&(rule.nextRunAt<=now()||newRound(rule)) && !held(rule) && (!shipping||first(rule)||!ships(rule)) && (!uncertainCities.has(rule.cityId)||['attacks','islands'].includes(rule.kind)||first(rule))).sort((a,b)=>Number(raidState?.running&&b.kind==='pirates')-Number(raidState?.running&&a.kind==='pirates')||Number(answered(b))-Number(answered(a))||Number(cinema(b))-Number(cinema(a))||Number(raid(b))-Number(raid(a))||Number(builderFree(b))-Number(builderFree(a))||a.nextRunAt-b.nextRunAt)[0];
    if(!rule) return;
    const date=now(),windowStart=date-86400000;
    state.actions=(state.actions??[]).filter(entry=>(Array.isArray(entry)?entry[0]:entry)>=windowStart);
    const accepted=state.actions.filter(entry=>!Array.isArray(entry)||entry[1]===accountKey).length;
    if(accepted>=500 && !cinema(rule) && !(rule.kind==='pirates'&&rule.continuous) && !['attacks','islands'].includes(rule.kind) && !(rule.kind==='wine'&&!rule.autoTransfer)) {rule.nextRunAt=date+3600000;rule.status='מגבלת 500 פעולות ליממה — ממתינה';await write(state);return;}
    // At least 15 seconds between two automations of one account: the game is not flooded and
    // what the user opens on screen gets through. Cinema bonuses and pirate captchas are not held.
    if(!cinema(rule)&&rule.kind!=='pirates'&&now()-(lastDispatch.get(accountKey)??0)<15000) return;
    // At most three automations run at once across every account (two were too few for nine
    // accounts, user report 2026-10-15): Firefox keeps only six connections
    // to the game server, shared with the pages themselves, so the tabs keep loading. A run lost
    // more than five minutes ago (e.g. by a reload) does not hold a place.
    const running=state.rules.filter(item=>item.inFlight&&!item.uncertain&&now()-(item.dispatchedAt??0)<300000).length;
    if(running>=3&&!cinema(rule)&&!(rule.kind==='pirates'&&(rule.captchaAnswer||raidState?.running))) return;
    lastDispatch.set(accountKey,now());
    rule.inFlight=uuid();rule.dispatchedAt=now();await write(state);
    try {
      const response=await chrome.tabs.sendMessage(tab.id,{type:'IKARIAM_AGENT_GAME_AUTOMATION',rule});
      if(!response?.accepted) throw new Error('לא התקבל אישור התחלת הרצה');
    } catch {if(firefoxPirate(rule)) pirateRecover(state,rule,'הלשונית לא הגיבה');else {rule.enabled=false;rule.uncertain=true;rule.status='התקשורת נותקה בעת ההפעלה; ההרצה נעצרה לבדיקה';log(state,rule,'unknown',rule.status);}await write(state);}
  }
  async function currentAccount() {const tab=await findTab();if(!tab?.id) throw new Error('יש להשאיר לשונית משחק מחוברת פתוחה');return identity(tab);}
  let tickFlight=null;
  const scheduledTick=()=>{
    if(tickFlight)return tickFlight;
    tickFlight=serial(tick).finally(()=>{tickFlight=null;});return tickFlight;
  };
  return {alarmName,handle:command=>command?.operation==='telegram-status'?setting('telegram','all').then(config=>({configured:!!config})):command?.operation==='telegram-health-status'?telegramHealth():command?.operation==='overview'?handle(command):serial(()=>handle(command)),telegramHealth,tick:scheduledTick,fastCaptcha,start:async()=>chrome.alarms.create(alarmName,{periodInMinutes:1}),
    currentAccount,notify,channels};
}

// War mode (user decision, 2026-10-14): when the alliance is attacked, the user lists cities of the
// alliance's main player and how much of which resource each needs ("crystal 9: 200,000 crystal").
// Each amount is split equally between the accounts (an account that lacks it gives what it has and
// the others cover the rest), and every account sends its share from its cities holding the most,
// as one-off shipments through the shipping runtime (which verifies the target before each send).
// Stopping removes what has not been sent yet. State: war-mode-v1.
// Per request (user decision, 2026-10-18): shipments go without pauses until the amount is met or the
// accounts run out (a request for 8M with 7M in the accounts sends the 7M and reports it). Each
// request shows what was sent and what is left, and can be stopped (cancelled) or paused; a request
// still paused after 24 hours is cancelled.
const KEY = 'war-mode-v1', MIN = 500, PAUSE_LIMIT = 24 * 3600000, ROUNDS = 3, RESOURCES = ['wood', 'wine', 'marble', 'crystal', 'sulfur'];
const NAMES = { wood: 'עץ', wine: 'יין', marble: 'שיש', crystal: 'קריסטל', sulfur: 'גופרית' };

// Equal shares, capped by what each account has; what one cannot give is spread over the others.
export function warShares(amount, available) {
  const shares = Object.fromEntries(Object.keys(available).map(key => [key, 0]));
  let left = Math.max(0, Math.floor(amount)), open = Object.keys(available).filter(key => available[key] > 0);
  while (left > 0 && open.length) {
    const each = Math.ceil(left / open.length);let given = 0;
    for (const key of open) { const take = Math.min(each, available[key] - shares[key], left - given); shares[key] += take; given += take; }
    left -= given;open = open.filter(key => available[key] - shares[key] > 0);
    if (!given) break;
  }
  return { shares, missing: left };
}
// An account's share over its cities, most first; pieces under one ship-load chunk are skipped.
export function cityPlan(share, cities, resource) {
  const plan = [];let left = share;
  for (const city of [...cities].sort((a, b) => (b.resources?.[resource] ?? 0) - (a.resources?.[resource] ?? 0))) {
    if (left < MIN) break;
    const take = Math.min(left, Math.floor(city.resources?.[resource] ?? 0));
    if (take >= MIN) { plan.push({ cityId: String(city.id), amount: take }); left -= take; }
  }
  return plan;
}

export function createWarMode(chrome, { transport, identify, now = () => Date.now() }) {
  const firefox = () => { try { return !/\bmain\b/.test(chrome.runtime?.getManifest?.()?.version_name ?? ''); } catch { return true; } };
  const read = async () => ({ active: false, targets: [], plan: {}, log: [], ...((await chrome.storage.local.get(KEY))[KEY] ?? {}) });
  const write = state => chrome.storage.local.set({ [KEY]: state });
  const note = (state, message) => { state.log = [{ time: now(), message }, ...(state.log ?? [])].slice(0, 100); };
  const fmt = value => Math.round(value).toLocaleString('he-IL');
  async function accounts() {
    const tabs = (await chrome.tabs.query({})).filter(tab => /^https:\/\/s\d+-\w+\.ikariam\.gameforge\.com\//.test(tab.url ?? ''));
    const keys = new Set();
    for (const tab of tabs) { const key = await identify(tab).catch(() => null); if (key) keys.add(key); }
    return [...keys];
  }
  // The cities the extension last read, less what war shipments created after that read have taken or
  // still hold for this resource (otherwise a second request or the next round counts it twice).
  // Satisfaction comes before war (Firefox, user decision 2026-10-20): a city with an approved
  // satisfaction upgrade gives nothing, and what its current step still lacks (read from the game's
  // quote for that step) stays in the account's other cities, the richest keeping it.
  const kept = async (key, resource) => {
    if (!firefox()) return { cities: new Set(), amount: 0 };
    const rules = ((await chrome.storage.local.get('game-automations-v1'))['game-automations-v1']?.rules ?? [])
      .filter(rule => rule.accountKey === key && rule.kind === 'building' && rule.autopilot === 'satisfaction' && rule.enabled && !rule.deleted);
    const lack = rule => { const quote = rule.progress?.quote; return Math.max(0, Math.ceil(Number(quote?.missing ? quote.missing[resource] ?? 0 : quote?.costs?.[resource] ?? 0) || 0)); };
    return { cities: new Set(rules.map(rule => String(rule.cityId))), amount: rules.reduce((sum, rule) => sum + lack(rule), 0) };
  };
  const cities = async (state, key, resource) => {
    const entry = (await chrome.storage.local.get('account-snapshot-' + key))['account-snapshot-' + key], at = entry?.at ?? 0, taken = {};
    for (const target of state.targets) if (target.resource === resource) for (const rule of state.plan?.[target.id]?.[key]?.rules ?? [])
      if ((rule.createdAt ?? 0) > at) taken[rule.cityId] = (taken[rule.cityId] ?? 0) + (rule.done ? rule.sent ?? 0 : Math.max(rule.amount, rule.sent ?? 0));
    const list = (entry?.snapshot?.cities ?? []).map(city => taken[String(city.id)] ? { ...city, resources: { ...city.resources, [resource]: Math.max(0, (city.resources?.[resource] ?? 0) - taken[String(city.id)]) } } : city);
    const hold = await kept(key, resource);
    if (!hold.cities.size) return list;
    let left = hold.amount;
    return list.map(city => hold.cities.has(String(city.id)) ? { ...city, resources: { ...city.resources, [resource]: 0 } } : city)
      .sort((a, b) => (b.resources?.[resource] ?? 0) - (a.resources?.[resource] ?? 0))
      .map(city => { const take = Math.min(left, city.resources?.[resource] ?? 0);left -= take;return take ? { ...city, resources: { ...city.resources, [resource]: (city.resources?.[resource] ?? 0) - take } } : city; });
  };
  // What the account holds of the resource right now for the war, and when the account was read.
  const holding = async (state, key, resource) => ({ stock: Math.floor((await cities(state, key, resource)).reduce((sum, city) => sum + (city.resources?.[resource] ?? 0), 0)),
    readAt: (await chrome.storage.local.get('account-snapshot-' + key))['account-snapshot-' + key]?.at ?? null });
  // The split of an amount for one target, from the cities the extension last read (no game request).
  async function split(state, target, amount) {
    const keys = await accounts();
    const givers = keys.filter(key => key.split('|')[0] !== target.playerName && !(state.exclude ?? []).includes(key.split('|')[0]));
    const stock = {}, read = {};
    for (const key of givers) { const held = await holding(state, key, target.resource);stock[key] = held.stock;read[key] = held.readAt; }
    const { shares, missing } = warShares(amount, stock);
    return { targetId: target.id, missing, accounts: Object.fromEntries(givers.map(key => [key, { stock: stock[key], share: shares[key], ...(firefox() ? { readAt: read[key] } : {}) }])) };
  }
  async function plan(state) {
    const result = [];
    for (const target of state.targets) result.push(await split(state, target, target.amount));
    return result;
  }
  // One round of one-off shipments for a target: every account's share from its cities holding the most.
  async function launch(state, target, amount) {
    const item = await split(state, target, amount), entries = state.plan[target.id] ??= {};
    let planned = 0;
    for (const [key, entry] of Object.entries(item.accounts)) {
      const slot = entries[key] ??= { share: 0, rules: [] };slot.share += entry.share;
      for (const piece of cityPlan(entry.share, await cities(state, key, target.resource), target.resource)) {
        try {
          const before = new Set(((await transport.handle({ operation: 'list', accountKey: key })).rules ?? []).map(rule => rule.id));
          const saved = await transport.handle({ operation: 'save', accountKey: key, rule: { originCityId: piece.cityId, destinationCityId: '0', resource: target.resource, sendMode: 'amount', quantity: piece.amount,
            intervalMinutes: 2, maxCycles: 1, startImmediately: true, oneOff: true, war: true, externalTarget: { x: target.x, y: target.y, playerName: target.playerName, islandName: target.islandName, cityName: target.cityName } } });
          const rule = (saved.rules ?? []).find(item => !before.has(item.id));
          if (rule) {
            // Recorded before it is switched on and saved at once, so a shipment is never unknown to the state.
            slot.rules.push({ id: rule.id, amount: piece.amount, cityId: piece.cityId, sent: 0, createdAt: now() });planned += piece.amount;await write(state);
            await transport.handle({ operation: 'toggle', accountKey: key, id: rule.id, enabled: true });
          }
        } catch (error) { note(state, key.split('|')[0] + ' → ' + target.cityName + ': ' + error.message);if (firefox()) target.lastError = error.message; }
      }
    }
    return { planned, missing: item.missing };
  }
  const rulesOf = (state, target) => Object.values(state.plan?.[target.id] ?? {}).flatMap(entry => entry.rules ?? []);
  const sentOf = (state, target) => rulesOf(state, target).reduce((sum, rule) => sum + (rule.sent ?? 0), 0);
  // Reads every shipment of the target from the shipping runtime: what was sent and whether any is still going.
  async function refresh(state, target) {
    let open = false, failed = 0;
    for (const [key, entry] of Object.entries(state.plan?.[target.id] ?? {})) {
      let list;try { list = (await transport.handle({ operation: 'list', accountKey: key })).rules ?? []; } catch { open = true;continue; }
      for (const rule of entry.rules ?? []) {
        const live = list.find(item => item.id === rule.id);
        if (!live) { rule.done = true;rule.paused = false;continue; }
        // Shipments made before the sent counter existed (0.5.19): a completed one sent its amount,
        // one stopped on the way sent what it no longer had to send.
        const legacy = live.sentTotal == null && !live.enabled ? (live.cycles >= live.maxCycles ? rule.amount : Number.isFinite(live.remaining) ? Math.max(0, rule.amount - live.remaining) : 0) : 0;
        rule.sent = Math.max(rule.sent ?? 0, Number(live.sentTotal) || 0, legacy);
        // A stopped shipment, also one whose last result is unknown (it waits for a check in the game
        // and is never sent again), no longer holds the request: the rest is planned without it.
        const stopped = /^נעצר|^נדרשת בדיקה/.test(live.status ?? '');
        rule.done = !live.enabled && (live.cycles >= live.maxCycles || stopped) && (!live.inFlight || stopped);
        if (rule.done && stopped) failed++;
        rule.paused = !live.enabled && !rule.done;
        if (!rule.done) open = true;
      }
    }
    return { open, failed, sent: sentOf(state, target) };
  }
  const each = async (state, target, fn) => { for (const [key, entry] of Object.entries(state.plan?.[target.id] ?? {})) for (const rule of entry.rules ?? []) await fn(key, rule); };
  const enable = (state, target) => each(state, target, (key, rule) => rule.paused ? transport.handle({ operation: 'toggle', accountKey: key, id: rule.id, enabled: true }).then(() => { rule.paused = false; }).catch(() => {}) : null);
  // Finished war shipments are history: what they sent is kept in this state, so they are removed
  // from the accounts' routes (they filled the 100-route limit — user report, 2026-10-19).
  const clear = (state, target) => each(state, target, (key, rule) => rule.done ? transport.handle({ operation: 'delete', accountKey: key, id: rule.id }).catch(() => {}) : null);
  async function sweep() {
    let removed = 0;
    for (const key of await accounts()) {
      let list = [];try { list = (await transport.handle({ operation: 'list', accountKey: key })).rules ?? []; } catch { continue; }
      for (const rule of list.filter(item => item.war && !item.enabled && !item.inFlight)) { try { await transport.handle({ operation: 'delete', accountKey: key, id: rule.id });removed++; } catch { /* Kept. */ } }
    }
    return removed;
  }
  // Wine balancing between each account's cities runs for certain during a war (user decision,
  // 2026-10-20): every account's balancing is switched on at the start (the shipping runtime moves
  // only wine while a war is on) and each account gets back its own switches when the war ends.
  async function wineOn(state) {
    state.policyBefore = {};
    for (const key of await accounts()) {
      let policy = null;try { policy = (await transport.handle({ operation: 'list', accountKey: key })).policy ?? null; } catch { continue; }
      state.policyBefore[key] = policy ? { balanceEnabled: !!policy.balanceEnabled, exportEnabled: !!policy.exportEnabled } : null;
      if (policy?.balanceEnabled && policy.enabled) continue;
      try { await transport.handle({ operation: 'configure-policy', accountKey: key, policy: { balanceEnabled: true, exportEnabled: !!policy?.exportEnabled } }); }
      catch (error) { note(state, key.split('|')[0] + ': איזון היין לא הופעל (' + error.message + ')'); }
    }
  }
  async function wineBack(state) {
    for (const [key, before] of Object.entries(state.policyBefore ?? {})) {
      if (before?.balanceEnabled) continue;
      try { await transport.handle({ operation: 'configure-policy', accountKey: key, policy: { balanceEnabled: false, exportEnabled: !!before?.exportEnabled } }); } catch { /* The switch stays as the war left it. */ }
    }
    state.policyBefore = null;
  }
  async function cancel(state, target, why) {
    await refresh(state, target);
    await each(state, target, (key, rule) => transport.handle({ operation: 'delete', accountKey: key, id: rule.id }).catch(() => {}));
    target.status = 'cancelled';target.endedAt = now();target.sent = sentOf(state, target);
    note(state, target.cityName + ': ' + why + ' — הועברו ' + fmt(target.sent) + ' מתוך ' + fmt(target.amount) + ' ' + (NAMES[target.resource] ?? ''));
  }
  // Brings every request up to date: completion, the next round, paused requests, the end of the war.
  async function update(state) {
    if (!state.active) return state;
    // A war started before this version gets its wine balancing on the next check.
    if (state.policyBefore == null) await wineOn(state);
    for (const target of state.targets) {
      target.status ??= 'running';
      if (target.status === 'done' || target.status === 'cancelled') continue;
      if (target.status === 'paused' && now() - (target.pausedAt ?? now()) >= PAUSE_LIMIT) { await cancel(state, target, 'הבקשה בוטלה אחרי 24 שעות בהשהיה');continue; }
      const { open, failed, sent } = await refresh(state, target);
      target.sent = sent;
      if (target.status === 'paused') continue;
      // A shipment paused while it was in flight is switched on again once it settles.
      await enable(state, target);
      if (open) continue;
      // Everything planned has settled. Resources found since the start (the stored stock was older)
      // go in another round, until the amount is met, a round sends nothing, or three rounds ran.
      const left = target.amount - sent;
      if (left >= MIN && (target.rounds ?? 1) < ROUNDS && sent > (target.lastRoundSent ?? -1)) {
        target.lastRoundSent = sent;target.rounds = (target.rounds ?? 1) + 1;
        const { planned } = await launch(state, target, left);
        if (planned > 0) continue;
      }
      target.status = 'done';target.endedAt = now();await clear(state, target);
      // "Nothing left" only when the accounts really hold less than one load (user report,
      // 2026-10-20: shipments refused by the game read as empty accounts); otherwise what is
      // still there and why it was not sent.
      let ending = 'בחשבונות לא נשאר יותר';
      if (firefox() && sent < target.amount) {
        const rest = (await split(state, target, left)).accounts;
        target.remaining = Object.values(rest).reduce((sum, entry) => sum + entry.stock, 0);
        target.reason = target.lastError ? 'המשלוחים נדחו: ' + target.lastError : failed ? failed + ' משלוחים נעצרו בשגיאה' : 'שלושה סבבי משלוח הסתיימו';
        if (target.remaining >= MIN) ending = 'בחשבונות נותרו עוד ' + fmt(target.remaining) + ' ' + (NAMES[target.resource] ?? '') + ' שלא נשלחו — ' + target.reason;
      }
      note(state, target.cityName + ': ' + (sent >= target.amount ? 'הושלם — הועברו ' + fmt(sent) + ' ' + (NAMES[target.resource] ?? '')
        : 'הסתיים — הועברו ' + fmt(sent) + ' מתוך ' + fmt(target.amount) + ' ' + (NAMES[target.resource] ?? '') + '; ' + ending) + (failed ? ' (' + failed + ' משלוחים נעצרו בשגיאה)' : ''));
    }
    if (state.targets.every(target => target.status === 'done' || target.status === 'cancelled')) {
      await wineBack(state);
      state.active = false;state.stoppedAt = now();note(state, 'כל הבקשות הסתיימו — מצב המלחמה כבוי והבנייה חוזרת');
    }
    return state;
  }
  // Each request with what every account holds now (Firefox: from its latest read, user report
  // 2026-10-20 — the panel must match the accounts).
  async function summary(state) {
    const result = [];
    for (const target of state.targets.filter(target => state.plan?.[target.id])) {
      const entries = state.plan[target.id], sent = target.sent ?? sentOf(state, target), accounts = [];
      for (const [key, entry] of Object.entries(entries)) accounts.push({ accountKey: key, share: entry.share, sent: (entry.rules ?? []).reduce((sum, rule) => sum + (rule.sent ?? 0), 0), ...(firefox() ? await holding(state, key, target.resource) : {}) });
      result.push({ targetId: target.id, status: target.status ?? 'running', amount: target.amount, sent, left: Math.max(0, target.amount - sent),
        percent: target.amount ? Math.min(100, Math.round(sent / target.amount * 100)) : 0, pausedAt: target.pausedAt ?? null, endedAt: target.endedAt ?? null,
        ...(firefox() ? { remaining: target.remaining ?? null, reason: target.reason ?? null } : {}), accounts });
    }
    return result;
  }
  async function handle(command) {
    const state = await read();
    if (command.operation === 'get') return { ...state, preview: state.active ? null : await plan(state), requests: await summary(state) };
    if (command.operation === 'configure') {
      if (state.active) throw new Error('יש לעצור את מצב המלחמה לפני שינוי היעדים');
      const targets = (command.targets ?? []).map((target, index) => ({ id: target.id ?? 't' + now() + index, x: Number(target.x), y: Number(target.y),
        playerName: String(target.playerName ?? '').trim(), islandName: String(target.islandName ?? '').trim(), cityName: String(target.cityName ?? '').trim(),
        resource: target.resource, amount: Math.floor(Number(target.amount)) }));
      // Never between the user's own accounts (one IP, network-sharing agreement): a target that
      // belongs to one of them is refused.
      const own = new Set((await accounts()).map(key => key.split('|')[0]));
      for (const target of targets) {
        if (own.has(target.playerName)) throw new Error('אסור לשלוח בין החשבונות שלך — ' + target.playerName + ' הוא אחד מהם');
        globalThis.IkariamTransportPlan?.validateExternalTarget?.(target);
        if (!RESOURCES.includes(target.resource) || !(target.amount >= MIN)) throw new Error('יש לבחור משאב וכמות של לפחות 500 לכל יעד');
      }
      Object.assign(state, { targets, plan: {}, exclude: Array.isArray(command.exclude) ? command.exclude : state.exclude ?? [] });
      await write(state);return { ...state, preview: await plan(state), requests: [] };
    }
    if (command.operation === 'start') {
      if (state.active) throw new Error('מצב המלחמה כבר פעיל');
      if (!state.targets.length) throw new Error('יש להגדיר לפחות יעד אחד');
      const removed = await sweep();if (removed) note(state, 'נוקו ' + removed + ' משלוחי מלחמה ישנים שהסתיימו');
      state.plan = {};state.active = true;state.startedAt = now();
      await wineOn(state);
      for (const target of state.targets) {
        Object.assign(target, { status: 'running', sent: 0, rounds: 1, pausedAt: null, endedAt: null, lastRoundSent: null, lastError: null, remaining: null, reason: null });
        const { missing } = await launch(state, target, target.amount);
        if (missing > 0) note(state, target.cityName + ': בכל החשבונות יחד חסרים ' + fmt(missing) + ' — נשלח כל מה שיש');
      }
      note(state, 'מצב מלחמה הופעל');await write(state);return { ...state, requests: await summary(state) };
    }
    if (command.operation === 'stop') {
      for (const target of state.targets) if (target.status !== 'done' && target.status !== 'cancelled') await cancel(state, target, 'נעצר');
      // Every war shipment still waiting in the accounts goes too, also one a round left unrecorded
      // (user report 2026-10-18: a round launched twice at once left shipments the state did not know).
      let swept = 0;
      for (const key of await accounts()) {
        let list = [];try { list = (await transport.handle({ operation: 'list', accountKey: key })).rules ?? []; } catch { continue; }
        for (const rule of list.filter(item => item.war && item.enabled && !item.inFlight)) { try { await transport.handle({ operation: 'delete', accountKey: key, id: rule.id });swept++; } catch { /* Kept; it ends by itself. */ } }
      }
      await wineBack(state);
      state.active = false;state.stoppedAt = now();note(state, 'מצב מלחמה נעצר; משלוחים שכבר יצאו ממשיכים ליעדם' + (swept ? ' · הוסרו ' + swept + ' משלוחים שעוד לא יצאו' : ''));await write(state);return { ...state, requests: await summary(state) };
    }
    if (['stop-target', 'pause-target', 'resume-target'].includes(command.operation)) {
      const target = state.targets.find(item => item.id === command.targetId);
      if (!state.active || !target) throw new Error('הבקשה לא נמצאה במצב מלחמה פעיל');
      if (target.status === 'done' || target.status === 'cancelled') throw new Error('הבקשה כבר הסתיימה');
      if (command.operation === 'stop-target') await cancel(state, target, 'בוטל לבקשתך');
      if (command.operation === 'pause-target' && target.status !== 'paused') {
        await each(state, target, (key, rule) => rule.done ? null : transport.handle({ operation: 'toggle', accountKey: key, id: rule.id, enabled: false }).catch(() => {}));
        target.status = 'paused';target.pausedAt = now();note(state, target.cityName + ': הושהה; בלי חידוש תוך 24 שעות הבקשה תבוטל');
      }
      if (command.operation === 'resume-target' && target.status === 'paused') {
        target.status = 'running';target.pausedAt = null;note(state, target.cityName + ': חודש');
      }
      await update(state);await write(state);return { ...state, requests: await summary(state) };
    }
    if (command.operation === 'progress') {
      await update(state);await write(state);
      return { ...state, requests: await summary(state) };
    }
    throw new Error('פעולת מצב מלחמה אינה נתמכת');
  }
  // One operation at a time (user report, 2026-10-18): the minute check and the panel both ran a
  // round's planning at once and each saved its own shipments. While a round is being planned the
  // panel gets the saved state at once ("מכין סבב"), and the minute check waits for the next minute.
  let queue = Promise.resolve(), busy = 0;
  const serial = job => { busy++;const next = queue.then(job, job).finally(() => { busy--; });queue = next.catch(() => {});return next; };
  async function entry(command) {
    if (command?.operation === 'get') return handle(command);
    if (command?.operation === 'progress' && busy) { const state = await read();return { ...state, requests: await summary(state), preparing: true }; }
    return serial(() => handle(command));
  }
  // Runs with the shipping alarm: completion, next rounds and the 24-hour pause limit need no open panel.
  async function tick() { if (busy) return;return serial(async () => { const state = await read();if (!state.active) return;await update(state);await write(state); }); }
  return { handle: entry, tick, key: KEY };
}

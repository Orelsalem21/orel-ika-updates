// Firefox side of the allocation pilot (docs/SUPPLY_ALLOCATION_PROTOCOL_DRAFT.md, contract
// allocation-v2.1 by Codex). Nothing here runs unless the local bridge itself says it is in pilot
// mode with that contract — the user sets that in the service's config by hand, never through the API.
// In the pilot:
// - one claim at a time, for the configured city and resource, from the configured supplier,
//   chosen by supply-donors.js (satisfaction, war and the city's own building step come first), and
//   one external shipment intent per pilotId;
// - Opera must accept, the user approves in the panel, then everything is checked again (war,
//   pilot parameters, the supplier's spare stock, the target city verified in the game) before the
//   intent is recorded here and in the bridge, and only then the game is asked;
// - every request is journaled with its exact payload and operationKey before it is sent and is
//   repeated unchanged after a lost answer; the receipt says sent or unknown and the state the bridge
//   returns is the one kept (a failure needs positive evidence, which this client does not claim);
// - an intent without a bound route, or an unknown result, is never sent again: it waits for review.
import { cityAvailable, pickDonor } from './supply-donors.js';
import { orderDemands, inventory, chooseSupplier, demandDue } from './supply-schedule.js';
const SMALL_LOAD = 1500, SMALL_WAIT_MS = 6 * 3600000;
import { BRIDGE_URL, FF_BRIDGE_CONFIG, parseDemands } from './firefox-supply-bridge.js';
export const CLAIMS_KEY = 'firefox-supply-claims-v1', CLAIMS_STATUS = 'firefox-supply-claims-status-v1', CONTRACT = 'allocation-v2.1';
// Steady work (proposed to Codex, docs/SUPPLY_ALLOCATION_PROTOCOL_DRAFT.md): the service itself must say
// mode 'dispatch' with this contract and limits; until then only the pilot above can run.
export const DISPATCH_CONTRACT = 'allocation-v3-proposed';
const validDispatch = d => d && Number.isSafeInteger(d.maxOpenClaims) && d.maxOpenClaims > 0 && d.maxOpenClaims <= 100 && Number.isSafeInteger(d.maxClaimAmount) && d.maxClaimAmount > 0 && d.maxClaimAmount % 500 === 0
  && (d.suppliers === null || Array.isArray(d.suppliers) && d.suppliers.every(item => typeof item === 'string')) && ['auto', 'manual'].includes(d.approval);
const CAPABILITIES = ['claims', 'shared-reservations', 'durable-intent', 'per-scan-incoming'];
const MAX_WAIT = 2 * 3600000; // A claim's route may wait for ships this long (the loading cap).
const STALE_INTENT = 6 * 3600000; // After this an open intent without a finished route is reported unknown.
const OPEN = ['new', 'requested', 'accepted', 'intenting', 'intent', 'sent', 'unknown', 'in-transit'];
const uuid = () => globalThis.crypto.randomUUID();
const validPilot = pilot => pilot && typeof pilot.pilotId === 'string' && /^\d{1,12}$/.test(String(pilot.cityId ?? '')) && typeof pilot.resource === 'string'
  && typeof pilot.supplierAccountKey === 'string' && Number.isSafeInteger(pilot.cap) && pilot.cap > 0 && pilot.cap % 500 === 0;

export function createFirefoxSupplyClaims(api, { transport, fetcher = (...args) => fetch(...args), now = () => Date.now() } = {}) {
  if (/\bmain\b/.test(api.runtime?.getManifest?.()?.version_name ?? '')) return null;
  // A round whose game call never answers is superseded after ten minutes (user report, 2026-10-22: one
  // hung call stopped every supply round for half an hour); the superseded round can no longer save.
  let busy = false, busySince = 0, generation = 0;
  const get = async key => (await api.storage.local.get(key))[key];
  const call = async (key, path, body) => {
    const response = await fetcher(BRIDGE_URL + path, { method: body ? 'POST' : 'GET', cache: 'no-store', signal: AbortSignal.timeout(5000),
      headers: { Authorization: 'Bearer ' + key, ...(body ? { 'Content-Type': 'application/json' } : {}) }, ...(body ? { body: JSON.stringify(body) } : {}) });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw Object.assign(new Error(data.error ?? ('השירות החזיר ' + response.status)), { status: response.status });
    return data;
  };
  async function accounts() {
    const all = await api.storage.local.get(null), rules = all['game-automations-v1']?.rules ?? [];
    return Object.keys(all).filter(key => key.startsWith('account-snapshot-')).map(key => key.slice('account-snapshot-'.length))
      .map(accountKey => ({ accountKey, readAt: all['account-snapshot-' + accountKey]?.at ?? null, cities: all['account-snapshot-' + accountKey]?.snapshot?.cities ?? [], rules: rules.filter(rule => rule.accountKey === accountKey) }));
  }
  async function routes(accountKey) { return (await transport.handle({ operation: 'list', accountKey })).rules ?? []; }
  // The receipt of a bound route, once the shipping runtime has an outcome (never "failed").
  function outcome(route) {
    if (!route) return null;
    if (route.uncertain || /נדרשת בדיקה/.test(route.status ?? '')) return { result: 'unknown', sentAmount: Number(route.sentTotal) || 0 };
    const sent = Number(route.sentTotal) || 0;
    // Sent only when the route is finished: every load left and nothing waits for ships. The arrival is
    // the latest of the loads' arrivals (each read from the game's transport form as it left), never the
    // quote taken before the claim; a load without a known arrival leaves it out rather than guessing.
    if (!route.enabled && !route.inFlight && route.cycles >= route.maxCycles && sent > 0) {
      const parts = Array.isArray(route.parts) ? route.parts : [], arrivals = parts.map(part => part.arrivalAt).filter(Number.isSafeInteger);
      const lastArrival = parts.length ? (arrivals.length === parts.length ? Math.max(...arrivals) : null) : Number.isSafeInteger(route.lastShipment?.timing?.arrivalAt) ? route.lastShipment.timing.arrivalAt : null;
      return { result: 'sent', sentAmount: sent, ...(lastArrival ? { arrivalAt: lastArrival } : {}), loads: parts.length || null };
    }
    // Stopped, or switched off before it finished (not by its own last cycle): the result is not known.
    if (!route.enabled && !route.inFlight && (/^נעצר/.test(route.status ?? '') || (route.cycles ?? 0) < (route.maxCycles ?? 1))) return { result: 'unknown', sentAmount: sent };
    return null;
  }
  // Fresh read-only travel quotes (supplier city to verified target), cached for 30 minutes; a failure
  // leaves the arrival unknown, never guessed.
  // Travel quotes per port and target (the voyage does not depend on the amount; the port's loading rate is
  // amount / loading seconds): kept six hours and across restarts, and every port is quoted over the rounds,
  // eight new game reads a round at most (user decision, 2026-10-28: only the three biggest ports were quoted).
  const targets = new Map(), quotes = new Map(), QUOTES_KEY = 'firefox-supply-quotes-v1', FLEET_KEY = 'firefox-supply-fleet-v1';
  let quoteBudget = Infinity, quotesLoaded = false;const fleetFailedAt = new Map();
  // A quote waits at most twenty seconds (user report, 2026-10-23: quotes queued behind long account scans
  // held every supply round, so no claim was made for seven hours); without one the claim goes unquoted.
  const timed = work => { let timer;return Promise.race([work, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('quote timeout')), 20000); })]).finally(() => clearTimeout(timer)); };
  async function quote(observation, demand, candidates, { force = false, amount: fixed = null } = {}) {
    const result = {}, place = observation.cities?.[demand.cityId];let changed = false;
    if (!place?.name || !place?.playerName || !Number.isSafeInteger(place.x) || !Number.isSafeInteger(place.y)) return result;
    for (const candidate of candidates) {
      const amount = fixed ?? Math.min(candidate.available, demand.claimable ?? demand.amount), key = candidate.accountKey + ':' + candidate.cityId + '>' + demand.cityId;
      const cached = quotes.get(key);
      if (cached && now() - cached.at < (force ? 120000 : cached.timing ? 21600000 : 1800000)) { if (cached.timing) result[candidate.accountKey + ':' + candidate.cityId] = cached.timing;continue; }
      if (!force && quoteBudget <= 0) continue;
      if (!force) quoteBudget--;
      changed = true;
      try {
        const targetKey = candidate.accountKey + '>' + demand.cityId;
        let target = targets.get(targetKey);
        if (!target || now() - target.at > 3600000) {
          const verified = (await timed(transport.handle({ operation: 'verify-target', accountKey: candidate.accountKey, allowMissingIslandName: true, target: { x: place.x, y: place.y, playerName: place.playerName, cityName: place.name, islandName: place.islandName ?? '' } }))).target;
          target = { at: now(), value: verified };targets.set(targetKey, target);
        }
        const timing = (await timed(transport.handle({ operation: 'quote', accountKey: candidate.accountKey, originCityId: candidate.cityId, target: target.value, amount }))).timing;
        quotes.set(key, { at: now(), timing: timing ? { ...timing, quotedAt: now(), quotedAmount: amount } : null });
        if (timing) result[candidate.accountKey + ':' + candidate.cityId] = { ...timing, quotedAt: now(), quotedAmount: amount };
      } catch { quotes.set(key, { at: now(), timing: null }); }
    }
    if (changed) await api.storage.local.set({ [QUOTES_KEY]: Object.fromEntries([...quotes].filter(([, item]) => item.timing && now() - item.at < 21600000)) });
    return result;
  }
  // The trade ships of every supplier account at sea, read from the game's fleet movements every ten minutes.
  async function refreshFleets(pool) {
    const fleets = (await get(FLEET_KEY)) ?? {};
    // An account whose read failed (tab closed or busy) is asked again five minutes later, not every round.
    await Promise.allSettled(pool.filter(account => !(now() - (fleets[account.accountKey]?.at ?? 0) < 600000) && !(now() - (fleetFailedAt.get(account.accountKey) ?? 0) < 300000)).map(async account => {
      try { const fleet = (await timed(transport.handle({ operation: 'fleet', accountKey: account.accountKey }))).fleet;if (fleet) fleets[account.accountKey] = fleet; }
      catch (error) { fleetFailedAt.set(account.accountKey, now());throw error; }
    }));
    await api.storage.local.set({ [FLEET_KEY]: fleets });
    return fleets;
  }
  async function tick() {
    if (busy && now() - busySince < 600000) return;busy = true;busySince = now();const mine = ++generation;
    const status = { at: now(), active: false };
    const journal = (await get(CLAIMS_KEY)) ?? { entries: [] };
    quoteBudget = 8;
    if (!quotesLoaded) { quotesLoaded = true;for (const [key, item] of Object.entries((await get(QUOTES_KEY)) ?? {})) if (!quotes.has(key)) quotes.set(key, item); }
    // An open claim is never dropped from the journal (user report, 2026-10-22: repeated refusals pushed
    // every open claim out of a 50-entry journal, so their receipts were never sent); only closed ones are trimmed.
    const save = async () => { if (mine !== generation) throw new Error('סבב קודם הוחלף');const closed = journal.entries.filter(item => !OPEN.includes(item.state) && item.state !== 'intenting');journal.entries = journal.entries.filter(item => OPEN.includes(item.state) || item.state === 'intenting' || closed.slice(-50).includes(item));await api.storage.local.set({ [CLAIMS_KEY]: journal }); };
    try {
      const config = await get(FF_BRIDGE_CONFIG);
      if (!config?.enabled || !config.key) { status.message = 'ערוץ האספקה כבוי';return; }
      const health = await call(config.key, '/v1/health');
      const capable = extra => [...CAPABILITIES, ...extra].every(item => (health.capabilities ?? []).includes(item));
      const isPilot = health.schema === 2 && health.mode === 'pilot' && health.contractRevision === CONTRACT && capable([]) && validPilot(health.pilot);
      const isDispatch = health.schema === 2 && health.mode === 'dispatch' && health.contractRevision === DISPATCH_CONTRACT && capable(['multi-claim']) && validDispatch(health.dispatch);
      if (!isPilot && !isDispatch) { status.message = 'פיילוט ההקצאות אינו פעיל בשירות (מצב ' + (health.mode ?? '?') + ') — אין הקצאות ואין משלוחים';return; }
      const pilot = isPilot ? health.pilot : null, dispatch = isDispatch ? health.dispatch : null;
      // The limits this client works within: the pilot is one city, one resource, one supplier, one claim.
      const scope = pilot ? { kind: 'pilot', id: pilot.pilotId, cap: pilot.cap, suppliers: [pilot.supplierAccountKey], maxOpen: 1, approval: 'manual', allows: item => item.cityId === String(pilot.cityId) && item.resource === pilot.resource }
        : { kind: 'dispatch', id: 'dispatch', cap: dispatch.maxClaimAmount, suppliers: dispatch.suppliers, maxOpen: dispatch.maxOpenClaims, approval: dispatch.approval, allows: () => true };
      status.active = true;status.mode = scope.kind;if (pilot) status.pilot = pilot;else status.dispatch = dispatch;
      // One external one-off shipment for an intent; routePending is saved before the route is asked
      // for, so a crash in between is never taken for "no shipment". A war after the intent holds it.
      const ship = async entry => {
        if ((await get('war-mode-v1'))?.active === true) { status.message = 'מצב מלחמה פעיל — המשלוח שאושר ממתין';return; }
        entry.routePending = true;await save();
        const before = new Set((await routes(entry.supplier.accountKey)).map(item => item.id));
        const saved = await transport.handle({ operation: 'save', accountKey: entry.supplier.accountKey, rule: { originCityId: entry.supplier.cityId, destinationCityId: '0', resource: entry.resource,
          sendMode: 'amount', quantity: entry.acceptedAmount, intervalMinutes: 2, maxCycles: 1, startImmediately: true, oneOff: true, externalTarget: entry.target } });
        const route = (saved.rules ?? []).find(item => !before.has(item.id));
        if (route) { entry.routeId = route.id;await save();await transport.handle({ operation: 'toggle', accountKey: entry.supplier.accountKey, id: route.id, enabled: true }); }
      };
      // The intent is recorded once; a refusal (the shortage changed, Opera cancelled) is settled from the
      // bridge and an accepted claim the bridge will not take an intent for is cancelled before any route.
      const recordIntent = async entry => {
        try { settle(entry, await call(config.key, '/v1/claims/' + entry.claimId + '/intent', entry.intentBody));entry.intentAt ??= now(); }
        catch (error) {
          if (![400, 403, 409].includes(error.status)) { entry.lastError = error.message;await save();return; }
          const claim = ((await call(config.key, '/v1/claims')).claims ?? []).find(item => item.claimId === entry.claimId);
          if (claim?.state === 'intent') { settle(entry, claim);entry.intentAt ??= now(); }
          else if (claim?.state === 'accepted') { entry.cancelKey ??= uuid();await save();settle(entry, await call(config.key, '/v1/claims/' + entry.claimId + '/cancel', { operationKey: entry.cancelKey }));entry.why = 'השירות לא קיבל את הכוונה: ' + error.message; }
          else if (claim) { settle(entry, claim);entry.why = error.message; }
          else Object.assign(entry, { state: 'abandoned', why: error.message });
        }
        await save();
      };
      const settle = (entry, claim) => { if (claim?.state) Object.assign(entry, { state: claim.state, ...(claim.acceptedAmount != null ? { acceptedAmount: claim.acceptedAmount } : {}), updatedAt: now() }); };
      // 1. Requests whose answer was lost are repeated exactly (same claimId, operationKey and payload).
      for (const entry of journal.entries.filter(item => item.state === 'new')) {
        try { settle(entry, await call(config.key, '/v1/claims', entry.claimBody)); }
        catch (error) { if (error.status === 409 || error.status === 400 || error.status === 403) Object.assign(entry, { state: 'abandoned', why: error.message, updatedAt: now() }); else throw error; }
        await save();
      }
      for (const entry of journal.entries.filter(item => item.state === 'intenting')) await recordIntent(entry);
      // 2. Intents: a saved receipt is repeated unchanged; a bound route reports its outcome; a route
      //    that may exist without being bound is never created again — it waits for review.
      for (const entry of journal.entries.filter(item => item.state === 'intent')) try {
        if (!entry.receiptBody) {
          const list = await routes(entry.supplier.accountKey);
          // Nothing holds a shortage for ever (user report, 2026-10-25: five claims stayed "sending" for up to
          // 60 hours): six hours after the intent, a claim whose route is gone, still in flight or never bound
          // is reported unknown with what its route sent — Opera closes it three hours later, nothing is resent.
          const stale = list.find(route => route.id === entry.routeId);
          if (now() - (entry.intentAt ?? entry.createdAt ?? now()) > STALE_INTENT && (!stale || stale.inFlight || !entry.routeId)) {
            entry.receiptBody = { operationKey: uuid(), result: 'unknown', sentAmount: Math.min(entry.acceptedAmount ?? 0, Number(stale?.sentTotal) || 0) };entry.stale = now();await save();
          }
          if (!entry.receiptBody) {
          if (!entry.routeId && entry.routePending) {
            const match = list.filter(route => route.oneOff && String(route.originCityId) === entry.supplier.cityId && route.resource === entry.resource && route.quantity === entry.acceptedAmount && route.externalTarget?.cityName === entry.target?.cityName);
            if (match.length === 1) entry.routeId = match[0].id;
            else { entry.review = 'לא ידוע אם נוצר משלוח לכוונה הזו — נדרשת בדיקה במשחק; לא תישלח שוב';await save();continue; }
          }
          // The intent was recorded but the route was never asked for (routePending is set first): ship now.
          if (!entry.routeId && !entry.routePending) { await ship(entry);continue; }
          const bound = list.find(route => route.id === entry.routeId);
          // A route still waiting for ships two hours after its intent holds the shortage from free ships
          // elsewhere (user report, 2026-10-22: Orakel5 queued loads for 13 hours while 330 ships idled).
          // It is stopped first; a round later, with no run in flight and nothing more sent, it is removed
          // and only what already left is reported — the rest is planned anew for a supplier with ships.
          if (bound && entry.stopAt && !bound.inFlight && (Number(bound.sentTotal) || 0) === entry.stopSent && now() - entry.stopAt >= 60000) {
            await transport.handle({ operation: 'delete', accountKey: entry.supplier.accountKey, id: bound.id });entry.routeRemoved = true;
            const parts = Array.isArray(bound.parts) ? bound.parts : [], arrivals = parts.map(part => part.arrivalAt).filter(Number.isSafeInteger);
            entry.receiptBody = entry.stopSent > 0 ? { operationKey: uuid(), result: 'sent', sentAmount: entry.stopSent, ...(arrivals.length && arrivals.length === parts.length ? { arrivalAt: Math.max(...arrivals) } : {}) }
              : { operationKey: uuid(), result: 'failed', sentAmount: 0, evidence: { kind: 'pre-submit-failure', observedAt: now() } };
            await save();
          } else if (bound && entry.stopAt) {
            if (!bound.inFlight) entry.stopSent = Number(bound.sentTotal) || 0;
            entry.stopAt = now();await save();continue;
          } else if (bound && !outcome(bound) && bound.enabled && !bound.inFlight && now() - (entry.intentAt ?? now()) > MAX_WAIT) {
            await transport.handle({ operation: 'toggle', accountKey: entry.supplier.accountKey, id: bound.id, enabled: false });
            entry.stopAt = now();entry.stopSent = Number(bound.sentTotal) || 0;await save();continue;
          }
          const result = entry.receiptBody ? null : outcome(bound);
          if (!result && !entry.receiptBody) continue;
          if (result) {
            const { loads, ...body } = result;entry.loads = loads;
            entry.receiptBody = { operationKey: uuid(), ...body };await save();
          }
          }
        }
        settle(entry, await call(config.key, '/v1/claims/' + entry.claimId + '/receipt', entry.receiptBody));entry.lastError = null;await save();
      } catch (error) {
        // One claim's failure never holds the others (user report, 2026-10-22: a refused intent stopped
        // every round, so finished shipments were never reported). The saved receipt is repeated later.
        entry.lastError = error.message;await save();
      }
      // 3. The bridge decides every other move (Opera's accept or reject, cancellation, delivery, review).
      const remote = (await call(config.key, '/v1/claims')).claims ?? [];
      for (const entry of journal.entries.filter(item => !['new', 'intenting', 'abandoned'].includes(item.state))) settle(entry, remote.find(item => item.claimId === entry.claimId));
      // A claim the service holds for a Firefox supplier but the journal lost is taken back: before any
      // shipment it is cancelled; with an intent it is bound to its one route (same port, resource, amount
      // and target city) and reported as usual, or — no such route — reported unknown, never sent again.
      for (const claim of remote.filter(item => item.owner === 'consumer' && item.pilotId === scope.id && ['requested', 'accepted', 'intent'].includes(item.state) && !journal.entries.some(entry => entry.claimId === item.claimId))) {
        try {
          if (claim.state !== 'intent') { settle(claim, await call(config.key, '/v1/claims/' + claim.claimId + '/cancel', { operationKey: uuid() }));continue; }
          const amount = claim.acceptedAmount ?? claim.amount, list = await routes(claim.supplierAccountKey);
          const match = list.filter(route => route.oneOff && String(route.originCityId) === String(claim.originCityId) && route.resource === claim.resource && route.quantity === amount && String(route.externalTarget?.cityId ?? '') === String(claim.cityId)
            && !journal.entries.some(entry => entry.routeId === route.id));
          const entry = { claimId: claim.claimId, pilotId: scope.id, demandId: claim.demandId, cityId: claim.cityId, resource: claim.resource, amount: claim.amount, acceptedAmount: amount,
            supplier: { accountKey: claim.supplierAccountKey, cityId: String(claim.originCityId) }, state: 'intent', approved: true, createdAt: claim.createdAt ?? now(), intentAt: claim.intentAt ?? now(), routePending: true, recovered: now() };
          if (match.length === 1) entry.routeId = match[0].id;
          else entry.receiptBody = { operationKey: uuid(), result: 'unknown', sentAmount: 0 };
          journal.entries.push(entry);await save();
        } catch (error) { status.message = 'שחזור הקצאה: ' + error.message; }
      }
      // Leftovers never pile up (user decision, 2026-10-22): the route of a closed claim is removed (a load
      // already at sea goes on); the shortage, if still there, is planned anew.
      for (const entry of journal.entries.filter(item => ['reconciled-current-state', 'delivered', 'failed', 'cancelled', 'rejected'].includes(item.state) && item.routeId && !item.routeRemoved)) {
        try {
          const route = (await routes(entry.supplier.accountKey)).find(item => item.id === entry.routeId);
          if (!route) entry.routeRemoved = true;
          else if (!route.inFlight) { await transport.handle({ operation: 'delete', accountKey: entry.supplier.accountKey, id: route.id });entry.routeRemoved = true; }
        } catch { /* Removed next round. */ }
      }
      // Steady work with automatic approval: an accepted claim needs no click (the checks below still apply).
      if (scope.approval === 'auto') for (const entry of journal.entries.filter(item => item.state === 'accepted' && !item.approved && item.pilotId === scope.id)) entry.approved = true;
      await save();
      // 4. Accepted claims the user approved: everything checked again, then intent, then one shipment each.
      //    One claim per supplier account at a time, the accounts in parallel (user decision, 2026-10-28:
      //    one shipment per round for all seven accounts left their ships idle).
      const readyAll = journal.entries.filter(item => item.state === 'accepted' && item.approved && !item.routePending);
      const handle = async ready => {
        if ((await get('war-mode-v1'))?.active === true) { status.message = 'מצב מלחמה פעיל — ההקצאה שאושרה ממתינה';return; }
        const cancel = async why => { ready.cancelKey ??= uuid();await save();settle(ready, await call(config.key, '/v1/claims/' + ready.claimId + '/cancel', { operationKey: ready.cancelKey }));ready.why = why;await save(); };
        if (ready.pilotId !== scope.id || !scope.allows(ready) || scope.suppliers && !scope.suppliers.includes(ready.supplier.accountKey) || !(ready.acceptedAmount <= scope.cap)) return await cancel('פרטי הפיילוט או מגבלות האספקה השתנו');
        const supplier = (await accounts()).find(account => account.accountKey === ready.supplier.accountKey), city = supplier?.cities.find(item => String(item.id) === ready.supplier.cityId);
        if (!city || cityAvailable(city, ready.resource, supplier.rules).available < ready.acceptedAmount) return await cancel('לעיר הספק כבר אין עודף מספיק');
        const observation = await parseDemands(await call(config.key, '/v1/demands'), now()), place = observation?.cities?.[ready.cityId];
        if (!place?.name || !place?.playerName || !Number.isSafeInteger(place.x) || !Number.isSafeInteger(place.y)) throw new Error('פרטי עיר היעד חסרים בתצפית — אין שליחה');
        // The game confirms the target (player, city, coordinates; the island's name is read from it).
        const verified = (await transport.handle({ operation: 'verify-target', accountKey: ready.supplier.accountKey, allowMissingIslandName: true,
          target: { x: place.x, y: place.y, playerName: place.playerName, cityName: place.name, islandName: place.islandName ?? '' } })).target;
        if (!verified?.islandName) throw new Error('עיר היעד לא אומתה במשחק — אין שליחה');
        ready.target = { x: verified.x ?? place.x, y: verified.y ?? place.y, playerName: verified.playerName ?? place.playerName, cityName: verified.cityName ?? place.name, islandName: verified.islandName };
        // Steady work: the arrival shown for this claim comes from a fresh quote (at most two minutes old)
        // for the accepted amount; without one it is unknown — the shipment is still the same one.
        if (dispatch) {
          const offer = (await quote(observation, { cityId: ready.cityId, claimable: ready.acceptedAmount, amount: ready.acceptedAmount }, [{ accountKey: ready.supplier.accountKey, cityId: ready.supplier.cityId, available: ready.acceptedAmount }], { force: true, amount: ready.acceptedAmount }))[ready.supplier.accountKey + ':' + ready.supplier.cityId];
          ready.plan = { ...(ready.plan ?? {}), arrivalAt: offer?.arrivalAt ?? null, quotedAt: offer?.quotedAt ?? null, quoteAmount: ready.acceptedAmount, quoteSource: offer ? 'game-transport-form' : null };await save();
        }
        ready.intentBody = { operationKey: uuid(), amount: ready.acceptedAmount };ready.state = 'intenting';await save();
        await recordIntent(ready);
        if (ready.state === 'intent') await ship(ready);
      };
      if (readyAll.length) {
        const seen = new Set(), batch = readyAll.filter(item => !seen.has(item.supplier.accountKey) && seen.add(item.supplier.accountKey));
        const failed = (await Promise.allSettled(batch.map(handle))).find(result => result.status === 'rejected');
        if (failed) throw failed.reason;
        return;
      }
      // 5. Steady work: new claims up to the limit, the most urgent shortage first, each from the supplier
      //    that arrives in time with the most (or the fastest), never with stock already committed.
      if (dispatch) {
        const open = journal.entries.filter(item => OPEN.includes(item.state));
        if (open.length >= scope.maxOpen) return;
        if ((await get('war-mode-v1'))?.active === true) { status.message = 'מצב מלחמה פעיל — אין הקצאות';return; }
        const observation = await parseDemands(await call(config.key, '/v1/demands'), now());
        if (!observation) { status.message = 'אין תצפית תקפה מאופרה';return; }
        // claimable already excludes every hold; another supplier may cover the rest of a shortage, but a
        // supplier never holds the same shortage twice (the service enforces it too).
        const pending = orderDemands(observation.demands.filter(item => (item.claimable ?? 0) >= 500), now());
        // Supply to the main account comes before the barbarian plunders (user decision, 2026-10-22): a
        // plunder waits for its ships, it does not hold them from the supply.
        const pool = (await accounts()).filter(account => account.accountKey !== observation.accountKey && (!scope.suppliers || scope.suppliers.includes(account.accountKey)));
        const fleets = await refreshFleets(pool);
        for (const account of pool) account.fleet = fleets[account.accountKey] ?? null;
        const all = [];
        for (const account of pool) { try { all.push(...(await routes(account.accountKey)).map(route => ({ ...route, accountKey: route.accountKey ?? account.accountKey }))); } catch { /* The routes of an account whose tab is closed stay unknown. */ } }
        // Every port works in parallel and keeps working (user decision, 2026-10-22): each supplier city
        // loads its own claim of up to two hours, and a city whose load is out takes the next shortage in
        // the order of the build lists' times; several claims are made in one round.
        const port = entry => entry.supplier.accountKey + ':' + entry.supplier.cityId;
        let made = 0;
        for (const demand of pending) {
          // Ten claims a round, then up to ten more only for accounts whose ships would otherwise sit idle
          // (user decision, 2026-10-28: 58 free ships waited while routine wine was never reached).
          if (open.length >= scope.maxOpen || made >= 20) break;
          if ((demand.claimable ?? 0) < 500) continue;
          // The service's own list counts too, so a port the journal does not know of is never asked twice.
          const holders = new Set([...open.filter(entry => entry.demandId === demand.id).map(port), ...remote.filter(item => item.demandId === demand.id && OPEN.includes(item.state)).map(item => item.supplierAccountKey + ':' + item.originCityId)]);
          // A port still loading an earlier claim is chosen only when no idle port can supply.
          const busy = new Set(journal.entries.filter(entry => ['requested', 'accepted', 'intenting'].includes(entry.state) || entry.state === 'intent' && !entry.receiptBody).map(port));
          const cap = Math.min(scope.cap, Number.isSafeInteger(demand.capacityAvailable) ? demand.capacityAvailable : Infinity);
          const every = inventory(pool, demand.resource, { routes: all, claims: journal.entries }).filter(item => !holders.has(item.accountKey + ':' + item.cityId) && (made < 10 || item.ships >= 10));
          let pick = null, offers = {};
          for (const candidates of [every.filter(item => !busy.has(item.accountKey + ':' + item.cityId)), every]) {
            // Always quoted (cached 30 minutes): the arrival orders suppliers and the port's loading time bounds the load.
            offers = await quote(observation, demand, candidates);
            pick = chooseSupplier(demand, candidates, { quotes: offers, now: now(), cap });
            if (pick) break;
          }
          if (!pick) continue;
          // A small load (one or two ships) waits to grow while its build is far off (user decision, 2026-10-30:
          // single ships carried 500 a long way): it goes once the build is within six hours, or the shortage has
          // waited six hours (its time unknown).
          const dueAt = demandDue(demand), seenAt = Number.isSafeInteger(demand.firstSeenAt) ? demand.firstSeenAt : now();
          if (pick.amount < SMALL_LOAD && !(dueAt !== null ? dueAt - now() <= SMALL_WAIT_MS : now() - seenAt >= SMALL_WAIT_MS)) continue;
          const claimId = uuid(), entry = { claimId, pilotId: scope.id, demandId: demand.id, cityId: demand.cityId, resource: demand.resource, amount: pick.amount,
            supplier: { accountKey: pick.accountKey, cityId: pick.cityId, cityName: pick.cityName }, plan: { reason: pick.reason, arrivalAt: pick.arrivalAt, quotedAt: offers[pick.accountKey + ':' + pick.cityId]?.quotedAt ?? null, dueAt: demandDue(demand), firstSeenAt: demand.firstSeenAt ?? null },
            state: 'new', approved: false, createdAt: now(),
            claimBody: { operationKey: uuid(), claimId, demandId: demand.id, revision: observation.revision, supplierAccountKey: pick.accountKey, originCityId: pick.cityId, amount: pick.amount } };
          journal.entries.push(entry);await save();
          try { settle(entry, await call(config.key, '/v1/claims', entry.claimBody)); }
          catch (error) { if (error.status === 409 || error.status === 400 || error.status === 403) Object.assign(entry, { state: 'abandoned', why: error.message }); else throw error; }
          // A refused claim is not abandoned again and again: the refusal ends this round's claims.
          await save();if (entry.state === 'abandoned') break;made++;if (OPEN.includes(entry.state)) open.push(entry);
          // Every claim moves the service to a new revision: the next claim of this round uses the fresh one
          // (user report, 2026-10-22: the second claim of a round was refused as an older revision).
          const fresh = await parseDemands(await call(config.key, '/v1/demands'), now());
          if (!fresh) break;
          observation.revision = fresh.revision;
          for (const item of pending) { const latest = fresh.demands.find(other => other.id === item.id);item.claimable = latest?.claimable ?? 0; }
        }
        status.message = pending.length ? 'אין ספק עם עודף וספינות פנויות לחוסרים הפתוחים' : 'אין חוסרים פתוחים לכיסוי';return;
      }
      // 5. Pilot: a new claim only when none is open, and once per pilot for an external shipment.
      if (journal.entries.some(item => OPEN.includes(item.state))) return;
      if (journal.entries.some(item => item.pilotId === pilot.pilotId && item.intentAt)) { status.message = 'המשלוח של הפיילוט הזה כבר בוצע — פיילוט נוסף דורש אישור חדש';return; }
      if ((await get('war-mode-v1'))?.active === true) { status.message = 'מצב מלחמה פעיל — אין הקצאות';return; }
      const observation = await parseDemands(await call(config.key, '/v1/demands'), now());
      const demand = observation?.demands?.find(item => item.cityId === String(pilot.cityId) && item.resource === pilot.resource);
      if (!demand) { status.message = 'אין כרגע חוסר בעיר ובמשאב של הפיילוט';return; }
      const donor = pickDonor((await accounts()).filter(account => account.accountKey === pilot.supplierAccountKey), demand, { cap: pilot.cap });
      if (!donor) { status.message = 'אין בחשבון הספק עיר עם עודף מספיק';return; }
      const claimId = uuid(), entry = { claimId, pilotId: pilot.pilotId, demandId: demand.id, cityId: demand.cityId, resource: demand.resource, amount: donor.amount,
        supplier: { accountKey: donor.accountKey, cityId: donor.cityId, cityName: donor.cityName }, state: 'new', approved: false, createdAt: now(),
        claimBody: { operationKey: uuid(), claimId, demandId: demand.id, revision: observation.revision, supplierAccountKey: donor.accountKey, originCityId: donor.cityId, amount: donor.amount } };
      journal.entries.push(entry);await save();
      try { settle(entry, await call(config.key, '/v1/claims', entry.claimBody)); }
      catch (error) { if (error.status === 409 || error.status === 400 || error.status === 403) Object.assign(entry, { state: 'abandoned', why: error.message }); else throw error; }
      await save();
    } catch (error) {
      status.error = /[א-ת]/.test(error.message ?? '') ? error.message : 'פעולת הפיילוט נכשלה (' + (error.status ?? error.message) + ')';
    } finally {
      if (mine === generation) { await api.storage.local.set({ [CLAIMS_STATUS]: status });busy = false; }
    }
  }
  // The user's click in the panel: approves an accepted claim for sending, or withdraws it before the intent.
  async function decide(claimId, approve) {
    const journal = (await get(CLAIMS_KEY)) ?? { entries: [] }, entry = journal.entries.find(item => item.claimId === claimId);
    if (!entry || !['requested', 'accepted'].includes(entry.state)) throw new Error('ההקצאה אינה ממתינה להחלטה');
    // Approval is the user's part only: nothing is sent before the bridge also says Opera accepted.
    if (approve) entry.approved = true;
    else {
      const config = await get(FF_BRIDGE_CONFIG);entry.cancelKey ??= uuid();await api.storage.local.set({ [CLAIMS_KEY]: journal });
      const claim = await call(config.key, '/v1/claims/' + claimId + '/cancel', { operationKey: entry.cancelKey });entry.state = claim.state ?? 'cancelled';
    }
    await api.storage.local.set({ [CLAIMS_KEY]: journal });
    return entry;
  }
  return { tick, decide };
}

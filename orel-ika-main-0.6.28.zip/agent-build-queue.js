// The agent's build list in the game's own sidebar (Opera, user decision 2026-10-28): it looks and works like
// the game's "רשימת מבנים בבניה" — the same markup and classes — but without its limit and without ambrosia.
// "שדרג" in a building's "הרחב" box adds that building's next level when the game cannot build it now; ✖ removes a row (and the later
// levels of the same building); the agent builds the rows in order once the game's own list is through (see
// agentQueue in game-automation-actions.js). Rows are kept per city in main-build-queue-v1: {position,
// building, level}. Costs and times come from the game's cost tables the agent already reads.
(() => {
  const main = () => { try { return /\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name ?? ''); } catch { return false; } };
  if (!main() || globalThis.IkariamAgentBuildQueue) return;
  globalThis.IkariamAgentBuildQueue = true;
  const QUEUE = 'main-build-queue-v1', ID = 'agentConstructionItem';
  const ICONS = { wood: '//gf2.geo.gfsrv.net/cdnd2/99bb4eda859ecc63edd36b32b768f0.png', marble: '//gf1.geo.gfsrv.net/cdn6d/579a48faf17c3f87225154449d55b1.png', wine: '//gf1.geo.gfsrv.net/cdnc6/94ddfda045a8f5ced3397d791fd064.png', crystal: '//gf2.geo.gfsrv.net/cdn1e/417b4059940b2ae2680c070a197d8c.png', sulfur: '//gf1.geo.gfsrv.net/cdn9b/5578a7dfa3e98124439cca4a387a61.png' };
  const REDUCER = { wood: 'carpentering', wine: 'vineyard', marble: 'architect', crystal: 'optician', sulfur: 'fireworker' };
  const esc = text => String(text ?? '').replace(/[&<>"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[char]);
  const number = value => Number(value).toLocaleString('en-US');
  // Days, hours and minutes as the game writes long times (user request, 2026-10-29): "1י 20ש 5ד".
  const clock = seconds => { const days = Math.floor(seconds / 86400), hours = Math.floor(seconds % 86400 / 3600), minutes = Math.floor(seconds % 3600 / 60); return [days ? days + 'י' : '', days || hours ? hours + 'ש' : '', minutes + 'ד'].filter(Boolean).join(' '); };
  const positionOf = text => Number(String(text ?? '').match(/[?&](?:amp;)?position=(\d+)/)?.[1]);
  const CLASS = { wood: 'wood', wine: 'wine', marble: 'marble', crystal: 'glass', sulfur: 'sulfur' }, NAME = { wood: 'עצים', wine: 'יין', marble: 'שיש', crystal: 'גבישי קריסטל', sulfur: 'גופרית' };
  let accounts = null, open = true;
  // Cities with a building under construction (from the latest read), for the click on the game's own "שדרג".
  const busyCities = new Set();
  // The game's own "הרחב" box of the open building (not the agent's copy of it).
  const gameBox = () => document.querySelector('#buildingUpgrade:not(.agentCopy)');
  // The highest level the building reaches after everything listed: its level, the game's list, the agent's list.
  const topLevel = (position, shown, game, rows) => Math.max(0, ...[shown, ...game.rows.filter(row => row.position === position).map(row => row.level), ...(game.current?.position === position ? [game.current.level] : []), ...rows.filter(row => row.position === position).map(row => row.level)].filter(Number.isFinite));
  // The city of the sidebar: from the game's own links in it, else the city selector.
  const cityId = () => document.querySelector('#sidebar [href*="cityId="]')?.getAttribute('href')?.match(/cityId=(\d+)/)?.[1] ?? document.querySelector('#citySelect')?.value ?? null;
  async function cityOf(id) {
    accounts ??= Object.keys(await chrome.storage.local.get(null)).filter(key => key.startsWith('account-snapshot-')).map(key => key.slice('account-snapshot-'.length));
    for (const accountKey of accounts) {
      const city = (await chrome.storage.local.get('account-snapshot-' + accountKey))['account-snapshot-' + accountKey]?.snapshot?.cities?.find(item => String(item.id) === String(id));
      if (city) return { accountKey, city };
    }
    return null;
  }
  // The game's own list on the page: its rows (position, level, end) and the building under construction.
  function gameList() {
    const list = document.querySelector('#constructionList:not(.agentList)');
    const rows = [...(list?.querySelectorAll(':scope > li') ?? [])].map(item => ({ position: positionOf(item.innerHTML), level: Number((item.querySelector('.amount')?.textContent.match(/\d+/g) ?? []).at(-1)), endAt: Number(item.innerHTML.match(/enddate:\s*'(\d+)'/)?.[1]) * 1000 || 0 }));
    const unit = list?.querySelector('.currentUnit');
    const current = unit ? { position: positionOf(unit.innerHTML), level: Number(unit.querySelector('.amount')?.textContent.match(/\d+/)?.[0]) } : null;
    return { rows, current, count: rows.length + (current ? 1 : 0), endAt: Math.max(0, ...rows.map(row => row.endAt)) };
  }
  // The last level of a building in its cost table (the game's Ikipedia lists every level it has): no row beyond it.
  const lastLevel = table => table?.levels ? Math.max(0, ...Object.keys(table.levels).map(Number).filter(Number.isFinite)) : Infinity;
  const read = async () => (await chrome.storage.local.get(QUEUE))[QUEUE] ?? {};
  // A building whose cost table the agent has not read yet: the panel reads it from the game's Ikipedia itself (a
  // read only, the same table the building engine keeps for a week), at most one building every half minute.
  const tried = new Map();let reading = false;
  async function readTable(accountKey, building, id) {
    if (reading || Date.now() - (tried.get(building) ?? 0) < 30 * 60000) return;
    reading = true;tried.set(building, Date.now());
    try {
      const get = async params => { const response = await (globalThis.IkariamPageFetch ?? fetch)('/index.php?' + new URLSearchParams(params), { credentials: 'same-origin', redirect: 'error', signal: AbortSignal.timeout(15000) });if (!response.ok) throw new Error('read failed');return globalThis.IkariamReadInsights.viewHtml(await response.text()); };
      const index = await get({ view: 'buildingDetail', buildingId: 0, helpId: 1, backgroundView: 'city', currentCityId: id, templateView: 'ikipedia', ajax: 1 });
      const link = index.match(new RegExp('button_building '+building+'"[^>]*?onclick="ajaxHandlerCall\\(\'\\?([^\']*)\''))?.[1]?.replace(/&amp;/g, '&');
      if (!link) return;
      const params = Object.fromEntries(new URLSearchParams(link));delete params.actionRequest;
      const table = globalThis.IkariamBuildForecast.parseCostTable(await get({ ...params, backgroundView: 'city', currentCityId: id, templateView: 'buildingDetail', ajax: 1 }));
      if (!Object.keys(table.levels).length) return;
      const key = 'cost-tables-v3-' + accountKey, tables = (await chrome.storage.local.get(key))[key] ?? {};
      await chrome.storage.local.set({ [key]: { ...tables, [building]: { at: Date.now(), ...table } } });
      document.getElementById(ID)?.removeAttribute('data-key');schedule();
    } catch { /* Tried again in half an hour. */ } finally { reading = false; }
  }
  async function render() {
    const widget = document.querySelector('#sidebarWidget'), id = cityId();
    if (!widget || !id) return;
    const found = await cityOf(id), rows = (await read())[id] ?? [], game = gameList();
    const tables = found ? (await chrome.storage.local.get('cost-tables-v3-' + found.accountKey))['cost-tables-v3-' + found.accountKey] ?? {} : {};
    const buildings = found?.city?.buildings ?? [], stock = found?.city?.resources ?? {};
    const reducers = Object.fromEntries(Object.entries(REDUCER).map(([resource, building]) => [resource, Number(buildings.find(item => item?.building === building)?.level) || 0]));
    const building = buildings.find(item => item?.isBusy);
    if (building) busyCities.add(String(id)); else if (found) busyCities.delete(String(id));
    let end = Math.max(game.endAt, building && Number(building.completed) > 0 ? Number(building.completed) * 1000 : 0, Date.now());
    // A row already built, under construction or held by the game's own list is the game's: it is not shown (the
    // building engine drops it once built). The game's list: the marks on the city's buildings, and for the open
    // building its own box, whose "הכרחי לשלב N" tells that the game already holds every level below N.
    const box = gameBox(), boxLevel = box?.querySelector('.buildingLevel');
    const position = boxLevel ? positionOf(boxLevel.querySelector('[href*="position="]')?.getAttribute('href') ?? document.querySelector('#sidebar [href*="position="]')?.getAttribute('href')) : NaN;
    const boxNext = Number(box?.querySelector('h4')?.textContent.match(/\d+/)?.[0]);
    const held = pos => { const at = buildings[pos], marks = String(at?.inConstructionList ?? '').split(',').filter(mark => /\d/.test(mark)).length;
      return Math.max(at ? (Number(at.level) || 0) + (at.isBusy ? 1 : 0) + marks : 0, pos === position && Number.isFinite(boxNext) ? boxNext - 1 : 0); };
    const pending = (row, at = buildings[row.position]) => !at || at.building !== row.building || held(row.position) < row.level;
    // The game's own list when the page does not show it (user report, 2026-10-29: the shipyard stood at 25 while the
    // panel spoke of 31): the city's buildings carry its slots ("2, 3, 4, 5, 6"), one level each in slot order, so the
    // levels the game already holds are shown with their times and the agent's rows start after them.
    const reached = {};
    const gameRows = game.count ? [] : buildings.flatMap((at, pos) => String(at?.inConstructionList ?? '').split(',').map(Number).filter(slot => slot > 0).map(slot => ({ slot, pos }))).sort((a, b) => a.slot - b.slot).map(({ pos }) => {
      const at = buildings[pos];reached[pos] = (reached[pos] ?? (Number(at.level) || 0) + (at.isBusy ? 1 : 0)) + 1;
      const step = globalThis.IkariamBuildForecast?.levelCost(tables[at.building], reached[pos], reducers, null);
      if (step?.seconds) end += step.seconds * 1000;
      return { position: pos, building: at.building, level: reached[pos], costs: step?.costs ?? null, endAt: step?.seconds ? end : null, name: at.name ?? at.building };
    });
    const items = rows.map((row, index) => ({ row, index })).filter(({ row }) => pending(row)).map(({ row, index }) => {
      const step = globalThis.IkariamBuildForecast?.levelCost(tables[row.building], row.level, reducers, null);
      if (step?.seconds) end += step.seconds * 1000;
      return { ...row, index, costs: step?.costs ?? null, endAt: step?.seconds ? end : null, name: buildings[row.position]?.name ?? row.building };
    });
    // The game's "הרחב" box, copied one to one into the agent's list (user decision, 2026-10-28: like a premium
    // account): its up arrow adds the next level to the agent's list, the level shows where the building ends
    // after everything listed, "הכרחי לשלב" shows that next level's cost (missing in red); "הרוס" is the game's own.
    const opened = Number.isInteger(position) && buildings[position]?.building && buildings[position].building !== 'empty' ? buildings[position] : null;
    let upgrade = '', top = null;
    if (opened) {
      top = Math.max(held(position), topLevel(position, Number(boxLevel.querySelector('.showLevel')?.textContent.match(/\d+/)?.[0]), game, rows));
      const next = top + 1, step = globalThis.IkariamBuildForecast?.levelCost(tables[opened.building], next, reducers, null);
      // A building listed up to its last level (user report, 2026-10-29: the carpentry asked for level 51): no further level.
      const ended = next > lastLevel(tables[opened.building]);
      const copy = box.cloneNode(true);copy.classList.add('agentCopy');
      copy.querySelectorAll('[id]').forEach(node => node.removeAttribute('id'));copy.id = 'buildingUpgrade';
      const up = copy.querySelector('li.upgrade a');
      if (up && ended) { up.removeAttribute('onclick');up.setAttribute('href', '#');up.classList.add('disabled');up.setAttribute('title', 'שלב ' + top + ' הוא השלב האחרון של המבנה');const text = up.querySelector('.textLabel');if (text) text.textContent = 'שלב מרבי'; }
      else if (up) { up.removeAttribute('onclick');up.setAttribute('href', '#');up.classList.remove('disabled');up.setAttribute('title', 'הוסף את שלב ' + next + ' לרשימת הסוכן');up.dataset.agentAdd = '1';const text = up.querySelector('.textLabel');if (text) text.textContent = 'לרשימה'; }
      // The level is the building's level in the game right now, as in the game's own box; the next level counts everything listed.
      const live = Number(boxLevel.querySelector('.showLevel')?.textContent.match(/\d+/)?.[0]);
      const level = copy.querySelector('li.showLevel');if (level) level.innerHTML = '<div class="textLabel">שלב </div>' + (Number.isFinite(live) ? live : Number(opened.level) || 0);
      const title = copy.querySelector('h4');if (title) title.textContent = ended ? 'השלב האחרון (' + top + ') כבר ברשימה' : 'הכרחי לשלב ' + next + ':';
      const costs = copy.querySelector('ul.resources');
      if (costs && ended) costs.innerHTML = '';
      else if (costs) costs.innerHTML = step ? Object.entries(step.costs).map(([resource, value]) => `<li class="${CLASS[resource]} ${(Number(stock[resource]) || 0) < value ? ' red bold' : ''}" title="${NAME[resource]}: ${number(value)}"><span class="accesshint">${NAME[resource]}: </span>${number(value)}</li>`).join('')
        + (step.seconds ? `<li class="time"><span class="accesshint">זמן בנייה: </span>${clock(step.seconds)}</li>` : '') : '<li class="agentWait">העלויות נקראות מהמשחק…</li>';
      upgrade = copy.outerHTML;
    }
    const missing = [...new Set([...[...gameRows, ...items].filter(item => !item.costs).map(item => item.building), ...(opened && !tables[opened.building] ? [opened.building] : [])])];
    if (found && missing.length) void readTable(found.accountKey, missing[0], id);
    const key = JSON.stringify([id, gameRows.map(item => [item.position, item.level, item.endAt && Math.floor(item.endAt / 60000)]), items.map(item => [item.position, item.level, item.endAt && Math.floor(item.endAt / 60000)]), game.count, open, stock, position, top, building && [building.position, building.completed]]);
    let entry = document.getElementById(ID);
    if (entry && entry.dataset.key === key && entry.parentElement === widget) return;
    const row = (item, place) => `<li><div class="buildingImg ${esc(item.building)}"></div>${item.index == null ? '' : `<div class="abortdiv"><a class="abort" title="בטל" href="#" data-remove="${item.index}"></a></div>`}`
      + `<div class="amount bold">${place}. שלב&nbsp;${item.level}</div><div class="time">${item.endAt ? clock(Math.max(0, (item.endAt - Date.now()) / 1000)) + ' עד הסיום' : 'הזמן נקרא מהמשחק…'}</div>`
      + `<div class="tooltip"><div class="bold">${esc(item.name)}</div><div>הכרחי לשלב ${item.level}:</div>`
      + (item.costs ? Object.entries(item.costs).map(([resource, value]) => `<div class="${(Number(stock[resource]) || 0) < value ? 'red bold' : ''}"><img src="${ICONS[resource]}">&nbsp;<span>${number(value)}</span></div>`).join('') : '<div>העלויות נקראות מהמשחק…</div>')
      + '</div></li>';
    // The building under construction, as the game's own list shows it ("בבנייה:"), when the game shows no list of
    // its own here: the first row starts when it ends (user report, 2026-10-29: the first time looked too long).
    // Its progress bar as the game draws it (user request, 2026-10-29), from the level's build time and its end.
    const total = building ? globalThis.IkariamBuildForecast?.levelCost(tables[building.building], (Number(building.level) || 0) + 1, reducers, null)?.seconds : 0;
    const done = total && Number(building.completed) > 0 ? Math.round(Math.min(100, Math.max(0, 100 - (Number(building.completed) - Date.now() / 1000) / total * 100))) : null;
    const current = !game.count && building ? `<h4>בבנייה:</h4><div class="currentUnit"><div class="buildingImg ${esc(building.building)}"></div><div class="amount"><span class="textLabel">${esc(building.name ?? building.building)} (שלב&nbsp;${(Number(building.level) || 0) + 1})</span></div>`
      + (done == null ? '' : `<div class="progressbar short"><div class="bar" title="${done}%" style="width: ${done}%;"></div></div>`)
      + `<div class="countdown">${Number(building.completed) > 0 ? clock(Math.max(0, Number(building.completed) - Date.now() / 1000)) : ''}</div></div>` : '';
    const before = game.count || (current ? 1 : 0), offset = before + gameRows.length;
    const theGame = gameRows.length ? '<h4>ברשימת המשחק:</h4>' + gameRows.map((item, place) => row(item, before + 1 + place)).join('') : '';
    if (!entry) { entry = document.createElement('li');entry.id = ID;entry.className = 'accordionItem'; }
    entry.dataset.key = key;
    entry.innerHTML = `<a class="accordionTitle${open ? ' active' : ''}">רשימת מבנים בבנייה : <span class="indicator"></span></a>`
      + `<div class="accordionContent sidebar_warehouse" style="display: ${open ? 'block' : 'none'};">${upgrade}<div class="agentClear"></div><div class="dynamic"><ul id="constructionList" class="agentList">${current}${theGame}<h4>ברשימה:</h4>`
      + (items.length ? items.map((item, place) => row(item, offset + 1 + place)).join('') : '<li class="agentEmpty">הרשימה ריקה — פתח מבנה ולחץ על החץ למעלה כדי להוסיף שלב</li>')
      + '</ul></div></div>';
    const after = document.querySelector('#constructionList:not(.agentList)')?.closest('.accordionItem');
    if (entry.parentElement !== widget) after?.parentElement === widget ? after.after(entry) : widget.appendChild(entry);
  }
  // "שדרג" / "בתור לבניה!" of the building's box (user decision, 2026-10-28): when the game cannot build now (another
  // building under construction, missing resources, or its own list full) the click adds the building's next level
  // to the agent's list instead of opening the game's ambrosia window; when the game can build, it builds as usual.
  async function addNext(button) {
    const box = gameBox()?.querySelector('.buildingLevel'), label = button.querySelector('.textLabel'), before = label?.textContent;
    const say = text => { if (!label) return;label.textContent = text;setTimeout(() => { label.textContent = before; }, 2500); };
    const position = positionOf(box?.querySelector('[href*="position="]')?.getAttribute('href') ?? document.querySelector('#sidebar [href*="position="]')?.getAttribute('href'));
    const id = cityId(), found = id ? await cityOf(id) : null, building = Number.isInteger(position) ? found?.city?.buildings?.[position]?.building : null;
    if (!building || building === 'empty') { say('המבנה לא זוהה — רענן');return; }
    const boxNext = Number(gameBox()?.querySelector('h4')?.textContent.match(/\d+/)?.[0]);
    const all = await read(), rows = all[id] ?? [], level = Math.max(Number.isFinite(boxNext) ? boxNext - 1 : 0, topLevel(position, Number(box?.querySelector('.showLevel')?.textContent.match(/\d+/)?.[0]), gameList(), rows)) + 1;
    const table = found ? ((await chrome.storage.local.get('cost-tables-v3-' + found.accountKey))['cost-tables-v3-' + found.accountKey] ?? {})[building] : null;
    if (level > lastLevel(table)) { say('שלב מרבי');return; }
    await chrome.storage.local.set({ [QUEUE]: { ...(await read()), [id]: [...rows, { position, building, level }] } });
    say(button.closest('#' + ID) ? '✓ שלב ' + level : '✓ נוסף לרשימת הסוכן (שלב ' + level + ')');
  }
  // The game can build now only with its builder free: while another building is under construction its "שדרג"
  // goes to the game's premium list, which a non-premium account is refused (user report, 2026-10-29: "נדרש חשבון
  // פרימיום על מנת להשתמש ברשימת מבנים בבנייה") — the click goes to the agent's list instead.
  const gameCanBuild = button => !button.classList.contains('disabled') && !busyCities.has(String(cityId())) && !document.querySelector('#constructionList:not(.agentList) .currentUnit') && /UpgradeExistingBuilding/.test((button.getAttribute('href') ?? '') + ' ' + (button.getAttribute('onclick') ?? ''));
  // ✖ and the title (the game's own accordion script does not know this item). A long list scrolls inside the panel
  // (user request, 2026-10-29), in the game's colours.
  document.addEventListener('click', async event => {
    const target = event.target instanceof Element ? event.target : null;
    const add = target?.closest(`#${ID} [data-agent-add]`);
    if (add) { event.preventDefault();event.stopImmediatePropagation();await addNext(add);return; }
    const upgrade = target?.closest('#buildingUpgrade:not(.agentCopy) #js_buildingUpgradeButton');
    if (upgrade && !gameCanBuild(upgrade)) { event.preventDefault();event.stopImmediatePropagation();await addNext(upgrade);return; }
    if (target?.closest(`#${ID} .accordionTitle`)) { event.preventDefault();open = !open;document.getElementById(ID)?.removeAttribute('data-key');schedule();return; }
    const remove = target?.closest(`#${ID} [data-remove]`);
    if (!remove) return;
    event.preventDefault();
    const id = cityId(), all = await read(), rows = all[id] ?? [], index = Number(remove.dataset.remove), gone = rows[index];
    if (!gone) return;
    await chrome.storage.local.set({ [QUEUE]: { ...all, [id]: rows.filter((row, place) => place !== index && !(place > index && row.position === gone.position && row.level > gone.level)) } });
  }, true);
  const style = document.createElement('style');
  style.textContent = `#${ID} li{position:relative}#${ID} li .tooltip{display:none;position:fixed;z-index:65200;background:#fdf7dd;border:1px solid #c9a36b;padding:4px 6px;white-space:nowrap}#${ID} li:hover .tooltip{display:block}#${ID} .red{color:#c00}#${ID} li.agentWait{float:none;width:auto;background:none;padding:2px 0}#${ID} .agentCopy{overflow:hidden}#${ID} .agentCopy ul.resources li.agentWait{width:100%;text-align:center}#${ID} #constructionList.agentList > h4,#${ID} #constructionList.agentList > li,#${ID} #constructionList.agentList > .currentUnit,#${ID} .agentClear{clear:both}#${ID} #constructionList.agentList > .currentUnit{overflow:hidden}#${ID} #constructionList.agentList > li.agentEmpty{float:none;width:auto;padding:4px 6px;background:none}#${ID} #constructionList.agentList{max-height:330px;overflow-y:auto;overflow-x:hidden;scrollbar-width:thin;scrollbar-color:#c9a36b #f4e9ce}`;
  (document.head ?? document.documentElement).appendChild(style);
  // A row's costs open beside the panel even when the list scrolls (a scrolling box would cut them off).
  document.addEventListener('mouseover', event => {
    const item = event.target instanceof Element ? event.target.closest(`#${ID} li`) : null, tip = item?.querySelector(':scope > .tooltip');
    if (!tip) return;
    const box = item.getBoundingClientRect();tip.style.top = Math.max(4, box.top) + 'px';tip.style.left = Math.max(4, box.left - (tip.offsetWidth || 180) - 6) + 'px';
  });
  let timer = null, last = 0;
  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(() => { last = Date.now();void render().catch(() => {}); }, Math.max(300, 1500 - (Date.now() - last)));
  }
  new MutationObserver(mutations => { if (mutations.some(change => !(change.target instanceof Element && change.target.closest(`#${ID}`)))) schedule(); }).observe(document.body, { childList: true, subtree: true });
  chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes[QUEUE]) { document.getElementById(ID)?.removeAttribute('data-key');schedule(); } });
  setInterval(() => { document.getElementById(ID)?.removeAttribute('data-key');schedule(); }, 60000);
  schedule();
})();

// Which Firefox account and city can cover one shortage of the main account (allocation protocol
// draft, docs/SUPPLY_ALLOCATION_PROTOCOL_DRAFT.md — not wired to any shipment yet). A city gives only
// what it holds above its own keeps, so covering the main account never undoes the other tasks:
// - satisfaction first: a city with an approved or automatic satisfaction upgrade gives nothing, and
//   wine keeps 48 hours of the city's own tavern consumption (at least 5,000);
// - every other resource keeps the per-city floor (20,000, the marble kept by satisfaction care);
// - what the city's enabled building queues still need for their current step (the game's quote);
// - nothing at all while war mode is on (the war requests come first).
export const DONOR_DEFAULTS = { keep: 20000, wineHours: 48, wineFloor: 5000, step: 500 };
const RESOURCES = ['wood', 'wine', 'marble', 'crystal', 'sulfur'];

// What one city can give of one resource, and why it keeps the rest.
export function cityAvailable(city, resource, rules = [], options = {}) {
  const o = { ...DONOR_DEFAULTS, ...options }, id = String(city?.id);
  const mine = rules.filter(rule => String(rule.cityId) === id && rule.enabled && !rule.deleted);
  // A satisfaction upgrade keeps what its next step costs (the game's own quote, subtracted below with
  // the other building rules); only one whose cost is not yet read holds the whole city (user report,
  // 2026-10-22: over five million marble and wood stood still behind governor upgrades of 10–130 thousand).
  if (mine.some(rule => rule.kind === 'building' && rule.autopilot === 'satisfaction' && !Object.keys(rule.progress?.quote?.costs ?? {}).length)) return { available: 0, reason: 'שדרוג שביעות רצון פעיל בעיר' };
  const stock = Math.max(0, Math.floor(Number(city?.resources?.[resource]) || 0));
  const use = Number.isFinite(city?.wineConsumptionPerHour) && city.wineConsumptionPerHour > 0 ? city.wineConsumptionPerHour : 0;
  const keep = resource === 'wine' ? Math.max(o.wineFloor, Math.ceil(use * o.wineHours)) : o.keep;
  const building = mine.filter(rule => rule.kind === 'building').reduce((sum, rule) => sum + Math.max(0, Math.ceil(Number(rule.progress?.quote?.costs?.[resource]) || 0)), 0);
  return { available: Math.max(0, stock - keep - building), stock, keep, building };
}

// Every city of every account that can give the resource, most first.
export function donorCandidates(accounts, resource, options = {}) {
  if (!RESOURCES.includes(resource)) throw new Error('משאב לא מוכר');
  if (options.war) return [];
  const result = [];
  for (const account of accounts ?? []) for (const city of account.cities ?? []) {
    const entry = cityAvailable(city, resource, account.rules ?? [], options);
    if (entry.available > 0) result.push({ accountKey: account.accountKey, cityId: String(city.id), cityName: city.name ?? String(city.id), ...entry });
  }
  return result.sort((a, b) => b.available - a.available);
}

// One supplier for one shortage (the pilot: a single supplier and city per claim). The amount is
// whole loads of 500, never more than the shortage, the city's spare stock or the pilot cap.
export function pickDonor(accounts, demand, options = {}) {
  const o = { ...DONOR_DEFAULTS, ...options };
  const wanted = Math.min(demand?.claimable ?? demand?.amount ?? 0, o.cap ?? Infinity);
  if (!(wanted >= o.step)) return null;
  for (const candidate of donorCandidates(accounts, demand.resource, o)) {
    const amount = Math.floor(Math.min(wanted, candidate.available) / o.step) * o.step;
    if (amount >= o.step) return { ...candidate, amount };
  }
  return null;
}

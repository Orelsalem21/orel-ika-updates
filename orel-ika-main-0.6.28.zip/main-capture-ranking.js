// Opera raids by capture points (user decision, 2026-10-28): the capture points Firefox hands the local service
// are read every minute and kept as main-capture-ranking-v1 ({fetchedAt, points: {name: {value, at}}, cycle});
// players added to the raid list during a round are asked of Firefox at once (main-capture-requests-v1).
import { BRIDGE_URL } from './main-supply-bridge.js';

export const CAPTURE_RANKING = 'main-capture-ranking-v1', CAPTURE_REQUESTS = 'main-capture-requests-v1';
const CONFIG = 'main-supply-bridge-v1';
export function createMainCaptureRanking(api, { fetcher = fetch, now = Date.now } = {}) {
  if (!/\bmain\b/.test(api.runtime?.getManifest?.()?.version_name ?? '')) return null;
  let busy = false;
  const call = async (key, path, body) => {
    const response = await fetcher(BRIDGE_URL + path, { method: body ? 'POST' : 'GET', headers: { Authorization: 'Bearer ' + key, ...(body ? { 'Content-Type': 'application/json' } : {}) }, ...(body ? { body: JSON.stringify(body) } : {}), cache: 'no-store', signal: AbortSignal.timeout(5000) });
    if (!response.ok) throw new Error('שירות התיאום החזיר ' + response.status);
    return response.json();
  };
  async function tick() {
    if (busy) return;busy = true;
    try {
      const values = await api.storage.local.get([CONFIG, CAPTURE_REQUESTS, CAPTURE_RANKING]);
      const config = values[CONFIG];
      if (!config?.enabled || !/^[a-f0-9]{64}$/.test(config.key ?? '')) return;
      const asked = values[CAPTURE_REQUESTS] ?? [];
      if (asked.length) { await call(config.key, '/v1/capture-requests', { names: asked.slice(0, 50) });await api.storage.local.set({ [CAPTURE_REQUESTS]: [] }); }
      const data = await call(config.key, '/v1/capture-points');
      const refresh = (await api.storage.local.get(CAPTURE_RANKING))[CAPTURE_RANKING]?.refresh ?? null;
      await api.storage.local.set({ [CAPTURE_RANKING]: { fetchedAt: now(), points: data.points ?? {}, cycle: data.cycle ?? null, requests: data.requests ?? {}, refresh } });
    } catch (error) {
      const last = (await api.storage.local.get(CAPTURE_RANKING))[CAPTURE_RANKING] ?? {};
      await api.storage.local.set({ [CAPTURE_RANKING]: { ...last, error: /[א-ת]/.test(error.message ?? '') ? error.message : 'הקריאה מהשירות נכשלה', errorAt: now() } });
    } finally { busy = false; }
  }
  // "רענן נקודות לכידה" in the raids table (user request, 2026-10-29: show the real number now): the names are
  // asked of Firefox at once, which reads them on its next half-minute check; the ranking is read again meanwhile.
  async function refresh(names) {
    const list = [...new Set((Array.isArray(names) ? names : []).filter(name => typeof name === 'string' && name.trim() && name.length <= 64))].slice(0, 50);
    if (!list.length) throw new Error('אין חשבונות Firefox לרענון');
    const values = await api.storage.local.get([CAPTURE_REQUESTS, CAPTURE_RANKING]);
    await api.storage.local.set({ [CAPTURE_REQUESTS]: [...new Set([...(values[CAPTURE_REQUESTS] ?? []), ...list])].slice(-50), [CAPTURE_RANKING]: { ...(values[CAPTURE_RANKING] ?? {}), refresh: { at: now(), names: list } } });
    await tick();
    for (const delay of [20000, 40000, 70000, 110000]) setTimeout(() => { void tick().catch(() => {}); }, delay)?.unref?.();
    return { names: list.length };
  }
  return { tick, refresh };
}

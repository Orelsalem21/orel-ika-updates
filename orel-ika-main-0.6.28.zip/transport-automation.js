import "./transport-plan.js";
export const {RESOURCE_KEYS,validateTransportRule,planTransport}=globalThis.IkariamTransportPlan;

// findTab(accountKey) returns the open game tab of that account (any container);
// without an account it returns the tab selected in the panel.
// Main-account edition: nothing leaves the account (no export, no route to another player).
const MAIN_EDITION=()=>{try {return /\bmain\b/.test(globalThis.chrome?.runtime?.getManifest?.()?.version_name??'');} catch {return false;}};
const SCAN_ONLY='האיזון הפנימי כבוי — הסריקה ממשיכה לדווח חוסרים לספקי פיירפוקס';
export function createTransportRuntime(chrome, findTab, {onPolicyReport=async()=>{}}={}) {
  const KEY="transport-automation-v1",ALARM="transport-automation-tick";
  let queue=Promise.resolve();
  const serial=job=>{const next=queue.then(job,job);queue=next.catch(()=>{});return next;};
  const read=async()=> {
    const state=(await chrome.storage.local.get(KEY))[KEY]??{rules:[],events:[]};
    for(const rule of state.rules) rule.intervalMinutes??=rule.intervalHours*60;
    for(const item of state.events) item.accountKey??=state.rules.find(rule=>rule.id===item.ruleId)?.accountKey;
    return state;
  };
  // The 100-route limit counts routes that can still run; a finished one-off shipment (war mode,
  // a single send) is history and no longer holds a place (user report, 2026-10-19: old war
  // shipments filled the limit and a new war round could not create any).
  // Firefox edition only (war mode lives there); the main edition (Opera) counts as before.
  const counted=state=>state.rules.filter(item=>!item.deleted&&!(!MAIN_EDITION()&&item.oneOff&&!item.enabled&&!item.inFlight)).length;
  const visible=async(state,accountKey)=>{
    const policy=state.rules.find(rule=>rule.accountKey===accountKey&&rule.policyMode&&!rule.deleted);
    if(policy)policy.receipts=((await chrome.storage.local.get('account-policy-receipts-'+policy.id))['account-policy-receipts-'+policy.id]??[]).map(({id,status,originCityId,destinationCityId,resource,amount,ships,timing,createdAt,externalTarget})=>({id,status,originCityId,destinationCityId,resource,amount,ships,timing,createdAt,externalTarget}));
    if(policy){policy.stopRequested=!!(await chrome.storage.local.get('transport-stop-'+policy.id))['transport-stop-'+policy.id];if(policy.stopRequested&&!policy.inFlight){policy.enabled=false;policy.status='נעצר לבקשתך; משימות אחרות יכולות להמשיך';}}
    if(policy?.inFlight) policy.scanProgress=(await chrome.storage.local.get('transport-progress-'+policy.inFlight))['transport-progress-'+policy.inFlight]??null;
    return {rules:state.rules.filter(rule=>rule.accountKey===accountKey&&!rule.deleted&&!rule.policyMode),policy,events:state.events.filter(item=>item.accountKey===accountKey)};
  };
  const write=state=>chrome.storage.local.set({[KEY]:state});
  // At most every ten minutes: it reads the whole storage (see game-automation-runtime.js, 2026-10-25).
  let cleanedAt=0;
  async function cleanupResults(state) {
    if(Date.now()-cleanedAt<600000) return;cleanedAt=Date.now();
    const stored=await chrome.storage.local.get(null);
    const retained=new Set(state.rules.filter(rule=>rule.inFlight).map(rule=>"transport-result-"+rule.inFlight));
    const completed=Object.keys(stored).filter(key=>key.startsWith("transport-result-") && !retained.has(key) && stored[key]?.status==="complete")
      .sort((a,b)=>(stored[b].createdAt??0)-(stored[a].createdAt??0));
    // Fifty: an Opera scan result carries its whole report (about 20 KB each; 2026-10-25 the storage filled).
    if(completed.length>50) await chrome.storage.local.remove(completed.slice(50));
    const progressKeys=Object.keys(stored).filter(key=>key.startsWith('transport-progress-')&&!retained.has(key.replace('transport-progress-','transport-result-'))).sort((a,b)=>(stored[b].updatedAt??0)-(stored[a].updatedAt??0));
    if(progressKeys.length>200) await chrome.storage.local.remove(progressKeys.slice(200));
  }
  // A full policy scan of a large account (up to four rescans plus sends, queued behind
  // other reads) can exceed five minutes. Wait while the tab keeps reporting progress.
  const progressAge=async operationId=>{
    const progress=(await chrome.storage.local.get("transport-progress-"+operationId))["transport-progress-"+operationId];
    const saved=(await chrome.storage.local.get("transport-result-"+operationId))["transport-result-"+operationId];
    return Date.now()-Math.max(progress?.updatedAt??0,saved?.createdAt??0);
  };
  async function awaitOperation(operationId,tabId=null) {
    const key="transport-result-"+operationId,started=Date.now();
    for(;;) {
      const saved=(await chrome.storage.local.get(key))[key];
      if(saved?.status==="complete") return saved;
      // A run the tab accepted but never started (no progress after two minutes while the tab's
      // queue is idle) is released at once instead of after ten minutes (user report, 2026-10-16).
      // Nothing was sent: the first progress record comes before any request.
      if(tabId!==null&&Date.now()-started>=120000&&!(await chrome.storage.local.get("transport-progress-"+operationId))["transport-progress-"+operationId]) {
        let health=null;try {health=await Promise.race([chrome.tabs.sendMessage(tabId,{type:'IKARIAM_AGENT_QUEUE_HEALTH'}),new Promise(resolve=>setTimeout(()=>resolve(null),3000))]);} catch { /* No answer. */ }
        if(health?.ok&&!health.runningSince&&!health.waiting) {
          await chrome.storage.local.set({[key]:{status:"complete",ok:false,reason:"הלשונית קיבלה את הסריקה אך לא התחילה אותה; תישלח שוב",mutationSubmitted:false,createdAt:Date.now()}});
          continue;
        }
      }
      if(Date.now()-started>=300000 && (await progressAge(operationId)>=300000 || Date.now()-started>=2400000))
        throw new Error("לא התקבלה תוצאת משלוח והלשונית הפסיקה לדווח התקדמות. יש לבדוק תנועות במשחק");
      await new Promise(resolve=>setTimeout(resolve,2000));
    }
  }
  // Settle a policy run whose result arrived after this worker stopped waiting. The policy
  // never replays a request: its receipt ledger and the in-transit movements read on the
  // next scan account for anything already sent. Returns "cleared", "running" or "unknown".
  async function settlePolicy(state,rule) {
    if(!rule.inFlight) return "cleared";
    const saved=(await chrome.storage.local.get("transport-result-"+rule.inFlight))["transport-result-"+rule.inFlight];
    if(saved?.status==="complete") {
      if(saved.ok) {try {finish(state,rule,saved);} catch { rule.inFlight=null; }}
      else {rule.inFlight=null;rule.status="הריצה הקודמת הסתיימה בשגיאה: "+(saved.reason??"לא ידוע")+"; התנאים ייבדקו מחדש";}
      event(state,rule,"verified","התקבלה תוצאת הריצה הקודמת; הסריקה הבאה מתחשבת במטענים שבדרך ואינה שולחת שוב");
      return "cleared";
    }
    if(await progressAge(rule.inFlight)<300000) return "running";
    if(saved?.status==="pending" || !saved) {
      rule.inFlight=null;rule.status="הריצה הקודמת לא הושלמה (הלשונית רועננה או נסגרה); התנועות ייבדקו בסריקה הבאה";
      event(state,rule,"verified",rule.status);return "cleared";
    }
    return "unknown";
  }
  function finish(state,rule,response) {
    if(!response?.ok) {
      const error=new Error(response?.reason??"לא התקבלה תוצאה מאומתת");
      error.safeToRetry=response?.status==="complete" && response.mutationSubmitted===false;
      throw error;
    }
    const result=response.result;
    rule.proposal=result?.proposal??null;rule.approval=null;
    if(!result || !["sent","waiting","empty"].includes(result.status)) throw new Error("תוצאת משלוח אינה תואמת");
    if(rule.policyMode) {
      // A full scan costs ~200 requests: rescan soon after sending, otherwise every 10 minutes
      // ("נצל ספינות עכשיו" still runs at once).
      rule.inFlight=null;rule.lastRunAt=Date.now();rule.status=result.message;rule.nextRunAt=Date.now()+(MAIN_EDITION()?(result.shipments?.length||result.noShips?120000:180000):
        // Firefox (user report, 2026-10-23: game pages failed to load under the requests of seven accounts):
        // supply goes through the service, so an account's own full scan runs every 30 minutes, 10 after sending.
        result.shipments?.length||result.noShips?600000:1800000);
      // "All ships at sea" did not scan: keep the last scan report (plans, shortages).
      if(!result.noShips) rule.report=result.report;rule.approval=null;rule.checks=0;rule.cycles+=(result.shipments?.length??0);
      rule.scanProgress=null;
      rule.windowShipments=(rule.windowShipments??0)+(result.shipments?.length??0);
      for(const shipment of result.shipments??[]) {
        rule.lastShipment={...shipment,submittedAt:shipment.submittedAt??Date.now()};
        const resource={wood:"עץ",wine:"יין",marble:"שיש",crystal:"קריסטל",sulfur:"גופרית"}[shipment.resource]??"משאב";
        event(state,rule,"sent",(shipment.kind==="balance"?"איזון משאבים":"העברה לחשבון הראשי")+" · "+resource+" · "+shipment.message+(shipment.reason?' · '+shipment.reason:''));
      }
      // A repeated identical scan result ("all ships at sea") is logged once, not every 2 minutes.
      if(!result.shipments?.length&&rule.lastScanMessage!==result.message) event(state,rule,"scan",result.message);
      rule.lastScanMessage=result.shipments?.length?null:result.message;
      return;
    }
    rule.inFlight=null;rule.lastRunAt=Date.now();rule.status=result.message;
    rule.remaining=result.remaining??rule.remaining;
    if(result.status==="sent") {rule.lastShipment={submittedAt:Date.now(),amount:result.amount,ships:result.ships,timing:result.timing??null};rule.sentTotal=(rule.sentTotal??0)+(Number(result.amount)||0);
      // Firefox one-off routes keep every load (a supply claim is closed only when all its loads left;
      // the last arrival is the latest of them, read from the game's transport form when each load left).
      if(!MAIN_EDITION()&&rule.oneOff) rule.parts=[...(rule.parts??[]),{at:Date.now(),amount:Number(result.amount)||0,ships:result.ships??null,departureAt:result.timing?.departureAt??null,arrivalAt:result.timing?.arrivalAt??null}].slice(-60);}
    if(result.status==="empty" || result.status==="sent" && rule.remaining===0) {
      rule.checks=0;rule.cycles++;rule.remaining=null;
    }
    // War shipments (user decision, 2026-10-18) never pause between loads: the next one goes at once,
    // and while every ship is at sea the free ships are checked again every minute.
    rule.nextRunAt=Date.now()+(rule.war?(result.status==="sent"?0:60000):rule.intervalMinutes*60000);
    if(rule.cycles>=rule.maxCycles) {rule.enabled=false;rule.status="הושלם — הגעה למגבלת המחזורים";}
    event(state,rule,result.status,result.message);
  }
  const event=(state,rule,status,message)=>{
    state.events.unshift({id:crypto.randomUUID(),time:Date.now(),ruleId:rule.id,accountKey:rule.accountKey,status,message,shipment:status==="sent"?rule.lastShipment:undefined});
    // A full day of shipments for the daily health report.
    state.events=state.events.slice(0,1500);
  };
  async function identity(tab) {
    const page=await chrome.tabs.sendMessage(tab.id,{type:"IKARIAM_AGENT_PARSE_PAGE"});
    if(!page?.found || !page.ownerName || !page.mundo || !page.servidor) throw new Error("לא זוהה חשבון מחובר להרצת האוטומציה");
    return [page.ownerName,page.mundo,page.servidor].join("|");
  }
  // All accounts at once, without needing their tabs: policy, next plan and recent events.
  async function overview() {
    const state=await read(),accounts=[...new Set(state.rules.filter(rule=>rule.policyMode&&!rule.deleted).map(rule=>rule.accountKey))];
    return {accounts:await Promise.all(accounts.map(async accountKey=>{
      const view=await visible(state,accountKey);
      return {accountKey,policy:view.policy??null,events:view.events.slice(0,30)};
    }))};
  }
  async function handle(command) {
    if(command.operation==="overview") return overview();
    // "Pause in this account": nothing leaves this account for the main account until the user
    // resumes it; balancing between its own cities continues. Nothing else lifts it — not "use
    // free ships now", the morning routine or the balancing hours. Works with the tab closed.
    if(command.operation==="pause-account"||command.operation==="resume-account") {
      const state=await read();
      const rule=state.rules.find(item=>item.policyMode&&!item.deleted&&item.accountKey===command.accountKey);
      if(!rule) throw new Error("לחשבון הזה אין אוטומציית משלוחים");
      const paused=command.operation==="pause-account";
      rule.paused=paused;rule.pausedAt=paused?Date.now():null;
      await chrome.storage.local.set({['transport-pause-'+rule.id]:paused?{at:Date.now()}:null});
      if(!paused) rule.nextRunAt=Date.now();
      rule.status=paused?"העברה החוצה מושהית לבקשתך — האיזון בין ערי החשבון ממשיך":"ההעברה לראשי חודשה לבקשתך";
      event(state,rule,paused?"paused":"enabled",rule.status);
      await write(state);return visible(state,command.accountKey);
    }
    const state=await read(),tab=await findTab(command.accountKey);
    if(!tab?.id) throw new Error(command.accountKey?"לשונית החשבון "+command.accountKey.split("|")[0]+" אינה פתוחה":"יש להשאיר לשונית משחק מחוברת פתוחה");
    const accountKey=await identity(tab);
    if(command.accountKey && accountKey!==command.accountKey) throw new Error("לשונית החשבון שייכת לחשבון אחר; רענן את הלשונית ונסה שוב");
    async function verify(target) {
      const response=await chrome.tabs.sendMessage(tab.id,{type:"IKARIAM_AGENT_VERIFY_EXTERNAL_TARGET",target,allowMissingIslandName:command.operation==='verify-target'&&command.allowMissingIslandName===true});
      if(!response?.ok || !response.target) throw new Error(response?.reason??"לא ניתן לאמת את עיר היעד");
      if(await identity(tab)!==accountKey) throw new Error("החשבון השתנה במהלך האימות");
      return response.target;
    }
    if(command.operation==="verify-target") return {...visible(state,accountKey),target:await verify(command.target)};
    // Firefox steady supply: a fresh read-only travel quote from one of this account's cities to a verified target.
    if(command.operation==="quote") {
      if(MAIN_EDITION()) throw new Error("הצעת זמן הובלה זמינה בפיירפוקס בלבד");
      const response=await chrome.tabs.sendMessage(tab.id,{type:"IKARIAM_AGENT_TRANSPORT_QUOTE",originCityId:command.originCityId,target:command.target,amount:command.amount});
      if(!response?.ok) throw new Error(response?.reason??"זמן ההובלה אינו זמין");
      return {timing:response.timing??null};
    }
    // Firefox steady supply: this account's trade ships at sea and when each group ends its stage.
    if(command.operation==="fleet") {
      if(MAIN_EDITION()) throw new Error("יומן הספינות זמין בפיירפוקס בלבד");
      const response=await chrome.tabs.sendMessage(tab.id,{type:"IKARIAM_AGENT_FLEET_TIMELINE"});
      if(!response?.ok) throw new Error(response?.reason??"יומן הספינות אינו זמין");
      return {fleet:response.fleet??null};
    }
    if(command.operation==="list") return visible(state,accountKey);
    // Dashboard fix: resume a 48,000 policy stopped by an error. A late result is applied first;
    // the receipt ledger and the movements read on the next scan prevent any resend.
    if(command.operation==="resume-policy") {
      const rule=state.rules.find(r=>r.accountKey===accountKey&&r.policyMode&&!r.deleted);
      if(!rule) throw new Error("לחשבון הזה אין אוטומציית משלוחים");
      if(rule.inFlight&&await settlePolicy(state,rule)==="running") throw new Error("ריצה עדיין מתבצעת בחשבון הזה; התוצאה תופיע בסיומה");
      rule.inFlight=null;rule.enabled=true;rule.nextRunAt=Date.now();rule.status="חודש לבקשתך";
      await chrome.storage.local.set({['transport-stop-'+rule.id]:null});
      event(state,rule,"enabled",rule.status);await write(state);return visible(state,accountKey);
    }
    if(command.operation==="verify-receipt") {
      const rule=state.rules.find(r=>r.accountKey===accountKey&&r.policyMode&&!r.deleted);
      if(!rule?.inFlight) return visible(state,accountKey);
      const result=(await chrome.storage.local.get('transport-result-'+rule.inFlight))['transport-result-'+rule.inFlight];
      if(result?.status!=='complete'||!result.ok&&result.mutationSubmitted!==false)throw new Error('עדיין אין תוצאה מאומתת למשימה; יש לבדוק את התנועות במשחק');
      if(result.ok)finish(state,rule,result);else {rule.inFlight=null;rule.status='אומת שהפעולה נעצרה לפני השליחה; התנאים ייבדקו מחדש';}
      rule.enabled=!(await chrome.storage.local.get('transport-stop-'+rule.id))['transport-stop-'+rule.id];rule.nextRunAt=Date.now();
      event(state,rule,'verified','התקבלה תוצאה מאומתת באיחור; אין שליחה חוזרת של אותה בקשה');await write(state);return visible(state,accountKey);
    }

    if(command.operation==="stop-after-current") {
      const rule=state.rules.find(r=>r.accountKey===accountKey&&!r.deleted&&(command.id?r.id===command.id:r.policyMode));
      if(!rule) return visible(state,accountKey);
      await chrome.storage.local.set({['transport-stop-'+rule.id]:{requestedAt:Date.now()}});
      return visible(state,accountKey);
    }

    // Which resources go to the main account (user decision, 2026-10-15): null = all of them;
    // otherwise only those listed. Balancing between the account's cities always covers all five.
    if(command.operation==="policy-export-resources") {
      const rule=state.rules.find(item=>item.policyMode&&item.accountKey===accountKey&&!item.deleted);
      if(!rule) throw new Error("אין עדיין מדיניות איזון בחשבון הזה");
      const list=command.resources;
      if(list!==null&&!(Array.isArray(list)&&list.length&&list.every(key=>["wood","wine","marble","crystal","sulfur"].includes(key)))) throw new Error("יש לבחור לפחות משאב אחד, או את כל המשאבים");
      rule.exportResources=list===null?null:[...new Set(list)];
      event(state,rule,"enabled",list===null?"העברה לראשי: כל המשאבים":"העברה לראשי רק של: "+rule.exportResources.join(", "));
      await write(state);return visible(state,accountKey);
    }
    if(['policy-review-mode','policy-decision','review-mode','decision'].includes(command.operation)) {
      const policyCommand=command.operation.startsWith('policy-');
      const rule=state.rules.find(item=>(policyCommand?item.policyMode:item.id===command.id)&&item.accountKey===accountKey&&!item.deleted);
      if(!rule||rule.inFlight) throw new Error('יש להמתין לסיום הסריקה או ההרצה לפני שינוי התכנון');
      if(command.operation.endsWith('review-mode')) {
        if(!['auto','manual'].includes(command.mode)) throw new Error('מצב ביצוע לא תקין');
        rule.reviewMode=command.mode;rule.approval=null;rule.skippedPlans=[];
        event(state,rule,'mode',command.mode==='manual'?'נבחר אישור ידני לכל משלוח':'נבחר ביצוע אוטומטי');
      } else {
        if(rule.approval) throw new Error('פעולה שאושרה כבר ממתינה לביצוע; יש להמתין לתוצאה');
        if(rule.reviewMode!=='manual') throw new Error('אישור פעולות זמין במצב ידני בלבד');
        const plan=policyCommand?rule.report?.plans?.find(item=>item.key===command.key):rule.proposal;
        if(!plan || plan.key!==command.key || Date.now()-(policyCommand?rule.report.scannedAt:plan.createdAt)>180000) throw new Error('ההצעה פגה; יש להמתין לסריקה עדכנית');
        if(command.approved===true) {rule.approval={key:plan.key,approvedAt:Date.now()};rule.status='המשלוח אושר — ממתין לבדיקה חוזרת וביצוע';if(policyCommand) rule.report.plans=[];else rule.proposal=null;event(state,rule,'approved','אושר משלוח: '+(plan.originName??plan.fields?.originName)+' אל '+(plan.destinationName??plan.fields?.destinationName)+' · '+(plan.resource??plan.fields?.resource)+' · '+(plan.amount??plan.fields?.amount));}
        else {rule.skippedPlans=[...(rule.skippedPlans??[]),plan.key].slice(-100);if(policyCommand) rule.report.plans=rule.report.plans.filter(item=>item.key!==plan.key);else rule.proposal=null;event(state,rule,'skipped','המשלוח דולג על ידי המשתמש');}
      }
      rule.nextRunAt=Date.now();await write(state);return visible(state,accountKey);
    }
    if(command.operation==="configure-policy") {
      const config=command.policy;
      if(!config || typeof config.balanceEnabled!=="boolean" || typeof config.exportEnabled!=="boolean") throw new Error("הגדרת אוטומציות אינה תקינה");
      if(MAIN_EDITION()&&config.exportEnabled) throw new Error("בחשבון הראשי אין העברה החוצה; האיזון נשאר בין הערים שלו");
      if(config.reviewMode!==undefined&&!['auto','manual'].includes(config.reviewMode))throw new Error("מצב ביצוע לא תקין");
      let rule=state.rules.find(item=>item.policyMode && item.accountKey===accountKey);
      if(rule?.inFlight) {
        const settled=await settlePolicy(state,rule);
        // A switch is never refused while a scan runs (user report, 2026-10-16: the scans run
        // almost all the time, so switching off was impossible). The change is kept and applied
        // when the run ends; switching the export off holds it from the next step of the running
        // scan, and switching everything off stops the run.
        if(settled==="running") {
          rule.pendingPolicy={balanceEnabled:config.balanceEnabled,exportEnabled:config.exportEnabled,...(config.externalTarget?{externalTarget:config.externalTarget}:{}),at:Date.now()};
          if(!config.exportEnabled) await chrome.storage.local.set({['transport-pause-'+rule.id]:{at:Date.now(),pending:true}});
          if(!config.balanceEnabled&&!config.exportEnabled) await chrome.storage.local.set({['transport-stop-'+rule.id]:{requestedAt:Date.now(),pending:true}});
          event(state,rule,'paused','השינוי נשמר ויחול בסיום הסריקה הנוכחית');
          await write(state);return visible(state,accountKey);
        }
        if(settled!=="cleared") throw new Error("יש משלוח שתוצאתו אינה ידועה; בדוק תנועות לפני חידוש");
      }
      // The target saved on this policy was verified when it was set; re-verifying it on every
      // "use free ships now" queued the click behind the tab's running scan.
      const same=rule?.externalTarget&&config.externalTarget&&["cityId","playerName","cityName"].every(field=>config.externalTarget[field]==null||String(config.externalTarget[field])===String(rule.externalTarget[field]));
      const externalTarget=config.externalTarget&&!same?await verify(config.externalTarget):rule?.externalTarget;
      if(config.exportEnabled && !externalTarget) throw new Error("יש לאמת יעד קבוע בחשבון הראשי לפני ההפעלה");
      if(!rule) {rule={id:crypto.randomUUID(),accountKey,policyMode:true,cycles:0,intervalMinutes:2,remaining:null};state.rules.push(rule);}
      await chrome.storage.local.set({['transport-stop-'+rule.id]:null});
      // Firefox: wine-only balancing between the account's own cities (user decision, 2026-10-22).
      if(!MAIN_EDITION()&&typeof config.wineBalanceOnly==='boolean') rule.wineBalanceOnly=config.wineBalanceOnly;
      Object.assign(rule,{balanceEnabled:config.balanceEnabled,exportEnabled:config.exportEnabled,externalTarget,
        ...(config.reviewMode!==undefined?{reviewMode:config.reviewMode,approval:null,skippedPlans:[]}:{}),continuousExportV1:true,enabled:MAIN_EDITION()||config.balanceEnabled || config.exportEnabled,status:"ממתין לסריקה",nextRunAt:Date.now()});
      if(!rule.enabled) rule.status="אוטומציות החשבון מושבתות";
      // Opera keeps scanning and reporting its shortages to the Firefox suppliers with the internal
      // balancing off (user decision, 2026-10-22); nothing moves between its own cities then.
      else if(MAIN_EDITION()&&!config.balanceEnabled) rule.status=SCAN_ONLY;
      // Settings may change while paused (e.g. by the morning routine); the pause stays.
      if(rule.paused) rule.status="העברה החוצה מושהית לבקשתך — האיזון בין ערי החשבון ממשיך";
      if(rule.enabled) for(const other of state.rules.filter(item=>!item.policyMode&&item.accountKey===accountKey&&!item.deleted&&item.status==="מושבת למניעת התנגשות עם אוטומציות 48,000")) {
        other.enabled=true;other.status="ממתין לבדיקה";other.nextRunAt=Date.now();
      }
      event(state,rule,rule.enabled?"enabled":"paused",rule.enabled?"אוטומציות 48,000 הופעלו; איזון מקבל קדימות":"אוטומציות 48,000 נעצרו");
      await write(state);return visible(state,accountKey);
    }
    // A one-off send (a single shipment the user asked for) may run alongside the 48,000 policy;
    // the policy reserves cargo already in transit on its next scan.
    const oneOff=command.operation==="toggle" && state.rules.find(item=>item.id===command.id&&item.accountKey===accountKey)?.oneOff===true;

    if(command.operation==="clear-log") {
      state.events=state.events.filter(item=>item.accountKey!==accountKey);
      await write(state);return visible(state,accountKey);
    }
    if(command.operation==="delete") {
      const rule=state.rules.find(item=>item.id===command.id && item.accountKey===accountKey && !item.deleted);
      if(!rule) throw new Error("המסלול לא נמצא בחשבון הנוכחי");
      rule.enabled=false;rule.deleted=true;
      event(state,rule,"deleted","המסלול הוסר; משלוחים שכבר נשלחו ממשיכים במשחק");
      // Preserve unknown operation IDs; never turn deletion into permission to replay.
      state.rules=state.rules.filter(item=>!item.deleted || item.inFlight);
      await write(state);return visible(state,accountKey);
    }
    if(command.operation==="save-batch") {
      if(MAIN_EDITION()&&(command.rules??[]).some(rule=>rule?.externalTarget)) throw new Error("בחשבון הראשי מסלולים רק בין הערים שלו");
      if(!Array.isArray(command.rules) || command.rules.length<1 || command.rules.length>100) throw new Error("יש לבחור בין מסלול אחד ל־100 מסלולים");
      if(counted(state)+command.rules.length>100) throw new Error("ניתן להגדיר עד 100 מסלולים");
      const verifiedTargets=new Map(),prepared=[];
      for(const input of command.rules) {
        let config={...input};
        if(config.externalTarget) {
          const key=JSON.stringify(config.externalTarget);
          if(!verifiedTargets.has(key)) verifiedTargets.set(key,await verify(config.externalTarget));
          const target=verifiedTargets.get(key);config={...config,externalTarget:target,destinationCityId:target.cityId};
        }
        validateTransportRule(config);
        if(config.startAt!=null && config.startAt<Date.now()) throw new Error("מועד ההתחלה חייב להיות עתידי");
        const key=[config.originCityId,config.destinationCityId,config.resource].join("|");
        if(prepared.some(item=>item.key===key)) throw new Error("הבקשה כוללת מסלול כפול");
        prepared.push({key,config});
      }
      const groupId=crypto.randomUUID();
      for(const {config} of prepared) {
        const rule={originCityId:config.originCityId,destinationCityId:config.destinationCityId,resource:config.resource,
          sendMode:config.sendMode,quantity:config.quantity,intervalMinutes:config.intervalMinutes??config.intervalHours*60,
          maxCycles:config.maxCycles,startAt:config.startAt??null,startImmediately:config.startImmediately===true,...(config.externalTarget?{externalTarget:config.externalTarget}:{}),
          id:crypto.randomUUID(),groupId,accountKey,enabled:false,cycles:0,nextRunAt:config.startAt??Date.now(),status:"מושבת",remaining:null};
        state.rules.push(rule);event(state,rule,"saved","מסלול מלאי שמור נשמר במצב מושבת");
      }
      await write(state);return visible(state,accountKey);
    }
    if(command.operation==="toggle-group") {
      const rules=state.rules.filter(item=>item.groupId===command.id && item.accountKey===accountKey && !item.deleted);
      if(!rules.length) throw new Error("קבוצת המסלולים לא נמצאה");
      if(command.enabled && rules.some(item=>item.inFlight || item.cycles>=item.maxCycles)) throw new Error("יש מסלול שהגיע למגבלה או שתוצאת המשלוח שלו לא ידועה");
      for(const rule of rules) {
        rule.enabled=command.enabled===true;rule.status=rule.enabled?"ממתין לבדיקה":"מושבת";
        if(rule.enabled) rule.nextRunAt=rule.startImmediately?Date.now():Math.max(Date.now(),rule.startAt??0,rule.nextRunAt??0);
        event(state,rule,rule.enabled?"enabled":"paused",rule.status);
      }
      await write(state);return visible(state,accountKey);
    }
    if(command.operation==="save") {
      if(MAIN_EDITION()&&command.rule?.externalTarget) throw new Error("בחשבון הראשי מסלולים רק בין הערים שלו");
      if(command.rule?.externalTarget) {
        const target=await verify(command.rule.externalTarget);
        command={...command,rule:{...command.rule,externalTarget:target,destinationCityId:target.cityId}};
      }
      validateTransportRule(command.rule);
      if(command.rule.startAt!=null && command.rule.startAt<Date.now()) throw new Error("יש לבחור מועד התחלה עתידי או להשאיר את השדה ריק להתחלה בהפעלה");
      if(counted(state)>=100) throw new Error("ניתן להגדיר עד 100 מסלולים");
      const rule={originCityId:command.rule.originCityId,destinationCityId:command.rule.destinationCityId,resource:command.rule.resource,
        sendMode:command.rule.sendMode,quantity:command.rule.quantity,intervalMinutes:command.rule.intervalMinutes??command.rule.intervalHours*60,maxCycles:command.rule.maxCycles,
        startAt:command.rule.startAt??null,
        startImmediately:command.rule.startImmediately===true,
        ...(command.rule.oneOff===true&&command.rule.maxCycles===1?{oneOff:true}:{}),
        ...(command.rule.oneOff===true&&command.rule.war===true?{war:true}:{}),
        ...(command.rule.externalTarget?{externalTarget:command.rule.externalTarget}:{}),
        id:crypto.randomUUID(),accountKey,enabled:false,cycles:0,nextRunAt:command.rule.startAt??Date.now(),status:"מושבת",remaining:null};
      state.rules.push(rule);event(state,rule,"saved","המסלול נשמר במצב מושבת");
    } else if(command.operation==="toggle") {
      const rule=state.rules.find(item=>item.id===command.id && item.accountKey===accountKey && !item.deleted);
      if(!rule) throw new Error("המסלול אינו שייך לחשבון הנוכחי");
      if(command.enabled && rule.inFlight) throw new Error("תוצאת משלוח קודם אינה ידועה. בדוק תנועות במשחק וצור מסלול חדש לאחר הבדיקה");
      if(command.enabled && rule.cycles>=rule.maxCycles) throw new Error("המסלול הגיע למגבלת המחזורים");
      rule.enabled=command.enabled===true;rule.status=rule.enabled?"ממתין לבדיקה":"מושבת";
      if(rule.enabled) {
        rule.nextRunAt=rule.startImmediately?Date.now():Math.max(Date.now(),rule.startAt??0,rule.nextRunAt??0);
        if(rule.nextRunAt>Date.now()) rule.status="ממתין למועד המתוכנן";
      }
      event(state,rule,rule.enabled?"enabled":"paused",rule.status);
    } else throw new Error("פקודת אוטומציה אינה נתמכת");
    await write(state);
    return visible(state,accountKey);
  }
  // One-time upgrade of existing active policies, requested by the user:
  // reuse an existing target in the same world, verify it per account, then
  // enable continuous export. Later explicit user settings always win.
  async function enableContinuousExports(state) {
    const realm=key=>String(key).split('|').slice(1).join('|');
    for(const rule of state.rules.filter(r=>r.policyMode&&r.enabled&&!r.deleted&&!r.inFlight&&!r.continuousExportV1)) {
      const target=rule.externalTarget??state.rules.find(r=>r.policyMode&&r.externalTarget&&realm(r.accountKey)===realm(rule.accountKey))?.externalTarget;
      if(!target)continue;
      if(rule.accountKey.split('|')[0]===target.playerName){rule.continuousExportV1=true;continue;}
      try {
        const tab=await findTab(rule.accountKey);if(!tab?.id||await identity(tab)!==rule.accountKey)continue;
        const verified=await chrome.tabs.sendMessage(tab.id,{type:'IKARIAM_AGENT_VERIFY_EXTERNAL_TARGET',target});
        if(!verified?.ok||!verified.target||verified.target.playerName!==target.playerName)continue;
        // Only the verified target is kept; the account's switches stay as the user set them.
        rule.externalTarget=verified.target;rule.continuousExportV1=true;rule.nextRunAt=Date.now();
        event(state,rule,'verified','יעד ההעברה לראשי אומת: '+target.playerName+' · '+target.cityName);
      }catch { /* Keep the saved policy intact until its account and target can be verified. */ }
    }
  }
  // A switch flipped during a scan: applied as soon as the run ends (see configure-policy).
  async function applyPending(state) {
    for(const rule of state.rules.filter(rule=>rule.policyMode&&!rule.inFlight&&rule.pendingPolicy)) {
      const config=rule.pendingPolicy;rule.pendingPolicy=null;
      const stop=(await chrome.storage.local.get('transport-stop-'+rule.id))['transport-stop-'+rule.id];
      if(stop?.pending) await chrome.storage.local.set({['transport-stop-'+rule.id]:null});
      const pause=(await chrome.storage.local.get('transport-pause-'+rule.id))['transport-pause-'+rule.id];
      if(pause?.pending) await chrome.storage.local.set({['transport-pause-'+rule.id]:null});
      // Only a target already verified on this policy is used here; a new one is set through the normal path.
      Object.assign(rule,{balanceEnabled:config.balanceEnabled,exportEnabled:config.exportEnabled&&!!rule.externalTarget,enabled:MAIN_EDITION()||config.balanceEnabled||config.exportEnabled,nextRunAt:Date.now(),
        status:config.balanceEnabled||config.exportEnabled?'ממתין לסריקה':MAIN_EDITION()?SCAN_ONLY:'אוטומציות החשבון מושבתות'});
      event(state,rule,rule.enabled?'enabled':'paused','השינוי במתגים הוחל: איזון '+(rule.balanceEnabled?'פעיל':'כבוי')+' · העברה לראשי '+(rule.exportEnabled?'פעילה':'כבויה'));
    }
  }
  async function applyStops(state) {
    for(const rule of state.rules) if(!rule.inFlight&&(await chrome.storage.local.get('transport-stop-'+rule.id))['transport-stop-'+rule.id]&&rule.enabled) {
      rule.enabled=false;rule.stopRequested=true;rule.status='נעצר אחרי סיום הפעולה הנוכחית; משימות אחרות יכולות להמשיך';event(state,rule,'paused',rule.status);
    }
  }
  // Accounts whose run is active in this worker. The long wait for a shipment result happens
  // outside the shared lock, so one slow account never delays another or a "use free ships
  // now" click; state changes are applied under the lock on freshly read state.
  const live=new Set();
  async function select(preferredIds) {
    const state=await read();
    await enableContinuousExports(state);
    // A service-worker restart during a POST must never cause automatic replay.
    const running=new Set(live);
    // An account supply stopped by the old count limit runs again once.
    for(const rule of state.rules.filter(rule=>rule.policyMode&&!rule.deleted&&!rule.enabled&&!rule.inFlight&&!rule.countFix&&/המחזור הגיע למגבלת 60/.test(rule.status??''))) {
      rule.countFix=1;rule.enabled=true;rule.checks=0;rule.nextRunAt=Date.now();rule.status='הופעלה מחדש: אספקת החשבון לא נעצרת יותר לפי מספר בדיקות';event(state,rule,'enabled',rule.status);await write(state);
    }
    for(const rule of state.rules.filter(rule=>rule.policyMode && !rule.deleted && !live.has(rule.id))) {
      const stopped=!!(await chrome.storage.local.get('transport-stop-'+rule.id))['transport-stop-'+rule.id];
      // A policy stopped only by an error (not by the user) resumes; its ledger prevents replay.
      if(!rule.inFlight && !rule.enabled && !stopped && /^נעצר: |^הריצה הקודמת/.test(rule.status??"")) {rule.enabled=true;rule.nextRunAt=Date.now();event(state,rule,"enabled","האוטומציה חודשה אחרי שגיאה זמנית");continue;}
      if(!rule.inFlight) continue;
      const wasEnabled=rule.enabled||/תוצאת משלוח|תוצאת המשלוח|נדרשת בדיקה|לא התקבלה תוצאת|^נעצר: /.test(rule.status??"");
      const settled=await settlePolicy(state,rule);
      if(settled==="running") {running.add(rule.id);continue;}
      if(settled==="cleared" && wasEnabled) {rule.enabled=!stopped;rule.nextRunAt=Date.now();}
    }
    for(const rule of state.rules.filter(rule=>rule.inFlight && rule.enabled && !running.has(rule.id))) {
      const saved=(await chrome.storage.local.get("transport-result-"+rule.inFlight))["transport-result-"+rule.inFlight];
      if(saved?.status==="complete" && saved.ok) {finish(state,rule,saved);continue;}
      rule.enabled=false;rule.status="נדרשת בדיקה — תוצאת משלוח לא ידועה";event(state,rule,"uncertain",rule.status);
    }
    await applyPending(state);await applyStops(state);
    await cleanupResults(state);
    // A balancing scan waiting more than ten minutes goes before war shipments (user decision,
    // 2026-10-20: wine balancing must run during a war, not wait behind a stream of loads).
    const overdue=rule=>!MAIN_EDITION()&&rule.policyMode&&Date.now()-(rule.nextRunAt??0)>600000;
    // One due rule per account; every account works in its own tab, in parallel.
    // Firefox: a hidden account keeps its routes but sends nothing (user decision, 2026-10-25).
    const hidden=new Set(MAIN_EDITION()?[]:((await chrome.storage.local.get('hidden-accounts-v1'))['hidden-accounts-v1']??['Orakel8|42|il','Orelkaful8|42|il']));
    const due=state.rules.filter(item=>item.enabled && !hidden.has(item.accountKey) && !item.inFlight && !live.has(item.id) && item.nextRunAt<=Date.now() && ![...live].some(id=>state.rules.find(r=>r.id===id)?.accountKey===item.accountKey))
      // War mode (user decision, 2026-10-16): its shipments go before everything, the balancing too.
      .sort((a,b)=>Number(overdue(b))-Number(overdue(a)) || Number(!!b.war)-Number(!!a.war) || Number(!!b.policyMode)-Number(!!a.policyMode) || Number(preferredIds.includes(b.id))-Number(preferredIds.includes(a.id)) || a.nextRunAt-b.nextRunAt);
    const game=(await chrome.storage.local.get('game-automations-v1'))['game-automations-v1'];
    const selected=[];for(const rule of due) {
      // The tab's read queue already serializes requests; only an operation actually running
      // defers shipping, never one that is merely due (that starved shipping indefinitely),
      // and never a run the user asked for now or one already deferred for ten minutes.
      // The main edition never defers its balancing (user report, 2026-10-16: with 11 building queues
      // something was always running, so the ships waited up to ten minutes each time).
      // War shipments are never deferred (user decision, 2026-10-18: no pauses between loads); the
      // tab's own queue already keeps them from running at the same moment as another request.
      // Supply to the main account is never deferred either (user report, 2026-10-22: attack and barbarian
      // checks ran every few minutes in each account, so the claims' shipments kept waiting).
      const supply=!MAIN_EDITION()&&rule.oneOff&&!!rule.externalTarget&&!rule.policyMode;
      const other=!MAIN_EDITION()&&!rule.war&&!supply&&!preferredIds.includes(rule.id)&&Date.now()-(rule.deferredSince??Date.now())<600000&&(game?.rules??[]).some(task=>task.accountKey===rule.accountKey&&!task.deleted&&!task.uncertain&&task.inFlight);
      if(other)rule.deferredSince??=Date.now();else rule.deferredSince=null;
      if(other){rule.nextRunAt=Date.now()+60000;rule.status='ממתין לסיום משימה אחרת בחשבון; לא תישלח בקשה במקביל';continue;}
      if(!selected.some(item=>item.accountKey===rule.accountKey))selected.push(rule);
    }
    for(const rule of selected) live.add(rule.id);
    await write(state);
    return selected.map(rule=>rule.id);
  }
  async function tick(preferredIds=[]) {
    const ids=await serial(()=>select(preferredIds));
    await Promise.all(ids.map(id=>run(id).finally(()=>live.delete(id))));
    // A war shipment that is due again (the next load, or the next city) does not wait for the alarm.
    if(ids.length&&(await read()).rules.some(rule=>rule.war&&rule.enabled&&!rule.inFlight&&!live.has(rule.id)&&rule.nextRunAt<=Date.now())) await tick();
  }
  async function run(id) {
    // Phase 1 (locked): verify the tab and mark the operation in flight.
    const prepared=await serial(async()=>{
      const state=await read(),rule=state.rules.find(item=>item.id===id);
      if(!rule?.enabled || rule.inFlight || rule.deleted) return null;
      try {
        if(rule.policyMode) {
          if(Date.now()-(rule.windowStartedAt??0)>=86400000) {rule.windowStartedAt=Date.now();rule.windowShipments=0;}
          // Continuous policy never pauses merely because a daily counter was reached.
          // Per-scan budget, verified inventory and durable receipts bound actual work.
          rule.shipmentBudget=40;
        }
        const tab=await findTab(rule.accountKey);
        let owner=null;try {owner=tab?.id?await identity(tab):null;} catch { /* Loading or not injected yet. */ }
        if(owner!==rule.accountKey) {
          // A closed or loading tab only postpones this account; nothing was sent.
          const waiting="ממתין ללשונית פתוחה של החשבון; לא נשלח משלוח";
          if(rule.status!==waiting) event(state,rule,"waiting",waiting);
          rule.status=waiting;rule.nextRunAt=Date.now()+120000;await write(state);return null;
        }
        // Wine-only mode (user decision, 2026-10-16): the account's policy only balances wine, and
        // only between 00:00 and 07:00 Israel time; the user's own routes still run.
        if(rule.policyMode&&(await chrome.storage.local.get('wine-only-v1'))['wine-only-v1']?.accounts?.[rule.accountKey]) {
          const hour=Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jerusalem',hour:'2-digit',hourCycle:'h23'}).format(new Date()));
          if(hour>=7) {
            const midnight=new Date(new Date().toLocaleString('en-US',{timeZone:'Asia/Jerusalem'}));const wait=(24-midnight.getHours())*3600000-midnight.getMinutes()*60000;
            const status='מצב יין בלבד: איזון יין רק בין 00:00 ל־07:00; בשעות היום הסוכן לא שולח משלוחים בחשבון';
            if(rule.status!==status) event(state,rule,'waiting',status);
            rule.status=status;rule.nextRunAt=Date.now()+Math.max(60000,Math.min(wait,3600000));await write(state);return null;
          }
          rule.wineOnly=true;
        } else rule.wineOnly=false;
        // While war mode is on, the account's balancing moves wine only; the rest goes to the war.
        rule.warActive=!!rule.policyMode&&!!(await chrome.storage.local.get('war-mode-v1'))['war-mode-v1']?.active;
        rule.checks=(rule.checks??0)+1;
        // The account's supply never stops by a count (user report, 2026-10-30: runs that failed while the game tab
        // was in the lobby stopped it overnight); its receipts and the movements read each scan prevent replay.
        if(rule.checks>60&&!rule.war&&!rule.policyMode) throw new Error("המחזור הגיע למגבלת 60 בדיקות ללא השלמה");
        rule.inFlight=crypto.randomUUID();rule.status="בודק ומכין משלוח";
        await write(state);
        return {tab,rule:JSON.parse(JSON.stringify(rule))};
      } catch(error) {fail(state,rule,error);await write(state);return null;}
    });
    if(!prepared) return;
    // Phase 2 (unlocked): the tab scans and ships; this may take minutes.
    let response,failure=null;
    try {
      try {response=await chrome.tabs.sendMessage(prepared.tab.id,{type:"IKARIAM_AGENT_AUTOMATION_TRANSPORT",rule:prepared.rule});}
      catch(error) {
        // Closing an acknowledgement channel is not permission to resend.
        const stored=(await chrome.storage.local.get("transport-result-"+prepared.rule.inFlight))["transport-result-"+prepared.rule.inFlight];
        if(!stored) throw error;
        response={ok:true,accepted:true,operationId:prepared.rule.inFlight};
      }
      if(response?.accepted && response.operationId===prepared.rule.inFlight) response=await awaitOperation(prepared.rule.inFlight,prepared.tab.id);
    } catch(error) {failure=error;}
    // Phase 3 (locked): apply the outcome to the current state.
    const report=await serial(async()=>{
      const state=await read(),rule=state.rules.find(item=>item.id===id);
      if(!rule || rule.inFlight!==prepared.rule.inFlight) return null;
      try {if(failure) throw failure;finish(state,rule,response);}
      catch(error) {fail(state,rule,error,response);}
      await applyPending(state);await applyStops(state);await write(state);
      return rule.policyMode&&rule.enabled&&rule.report?rule.report:null;
    });
    if(report) {try {await onPolicyReport(prepared.rule.accountKey,report);}catch{ /* Read/notification failure must not replay shipments. */ }}
  }
  function fail(state,rule,error,response) {
    if(error.safeToRetry) rule.inFlight=null;
    const disconnected=/message channel|Receiving end|asynchronous response|context invalidated/i.test(error.message);
    if(disconnected && !rule.inFlight) {
      rule.status="ממתין לחידוש החיבור אחרי רענון המשחק";
      rule.nextRunAt=Date.now()+120000;
      event(state,rule,"waiting",rule.status);
      return;
    }
    // A policy run that ended with an error (a slow game response, a changed page) keeps the
    // policy on: its receipt ledger and the movements read on the next scan prevent replay.
    if(rule.policyMode && response?.status==="complete") {
      // A run the tab never started is sent again within half a minute.
      const notStarted=/לא התחילה אותה/.test(error.message);
      rule.inFlight=null;rule.nextRunAt=Date.now()+(notStarted?30000:180000);
      rule.status=notStarted?error.message:"שגיאה זמנית: "+error.message+" — ניסיון נוסף בעוד 3 דקות";
      event(state,rule,"failed",rule.status);
      return;
    }
    rule.enabled=false;rule.status="נעצר: "+(disconnected?
      (rule.inFlight?"התקשורת עם לשונית המשחק נותקה. תוצאת המשלוח אינה ידועה; בדוק תנועות לפני חידוש":"התקשורת עם לשונית המשחק נותקה לפני תחילת המשלוח"):error.message);
    event(state,rule,rule.inFlight?"uncertain":"failed",rule.status);
  }
  // Read-only commands need not wait for a shipment receipt in this worker.
  // Target verification still uses the content script's shared game-read queue.
  return {command:command=>["list","verify-target","overview","stop-after-current","fleet"].includes(command.operation)?handle(command):serial(()=>handle(command)),tick:(preferredIds=[])=>tick(preferredIds),
    immediateIds:(command,data)=>command.operation==='configure-policy'&&command.startImmediately&&data.policy?.enabled?[data.policy.id]:command.enabled && ["toggle","toggle-group"].includes(command.operation)?
      data.rules.filter(rule=>rule.enabled && rule.startImmediately && (command.operation==="toggle"?rule.id===command.id:rule.groupId===command.id)).map(rule=>rule.id):[],
    start:()=>chrome.alarms.create(ALARM,{periodInMinutes:1}),alarmName:ALARM};
}

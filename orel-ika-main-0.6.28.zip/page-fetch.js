// Sends game requests exactly as the page itself would. In Firefox, the global
// fetch of a content script belongs to the extension; content.fetch belongs to
// the page, so requests keep the tab's container cookies, origin and relative
// URL resolution. Chrome content scripts already behave this way.
(() => {
  const timeoutError=()=>new DOMException('הבקשה חרגה מזמן ההמתנה','TimeoutError');
  let cancelInPage=true;
  function once(url,options) {
    const page=globalThis.content;
    if(typeof globalThis.cloneInto!=='function' || typeof page?.fetch!=='function') return fetch(url,options);
    // An AbortSignal cannot cross into the page compartment, so the page's own AbortController
    // cancels the request when the caller's signal fires. A request left running after its timeout
    // kept one of the browser's few connections to the game server; once they were all taken, every
    // later request of the tab waited behind them and timed out until Firefox was restarted (user
    // report, 2026-10-27: the agent froze about an hour after each restart). The race stays as the
    // fallback where the page controller cannot be used.
    const {signal,...rest}=options;
    let controller=null,request=null;
    // The page's own constructor (waived), so the controller and its signal belong to the page. Should
    // the page refuse the signal, the request goes as before, without it, and the tab stops trying.
    if(signal&&cancelInPage) try {
      controller=new (page.wrappedJSObject??page).AbortController();
      request=page.fetch(url,globalThis.cloneInto({...rest,signal:controller.signal},page,{wrapReflectors:true})).catch(error=>{
        if(!/signal/i.test(String(error?.message??''))) throw error;
        cancelInPage=false;controller=null;return page.fetch(url,globalThis.cloneInto(rest,page));
      });
    } catch {cancelInPage=false;controller=null;request=null;}
    request??=page.fetch(url,globalThis.cloneInto(rest,page));
    if(!signal) return request;
    return Promise.race([request,new Promise((_,reject)=>{
      // The timeout settles the race first; the cancel then frees the connection.
      const stop=()=>{reject(timeoutError());try {controller?.abort();} catch { /* Already settled. */ }};
      if(signal.aborted) stop();
      else signal.addEventListener('abort',stop,{once:true});
    })]);
  }
  // A slow game server or VPN must not fail a whole account scan. Read-only requests
  // (GET without an action) get 30 s per attempt and up to two retries; anything that
  // may change the game is sent once, exactly as the caller asked.
  // Load diagnostics (user decision, 2026-10-14): per account and minute — requests, failures,
  // timeouts, retries, response times and the tab's queue — kept for three hours, plus the last 30
  // errors, in diag-v1-<account>. Read in Settings ("אבחון עומס") and by the developer. No game data.
  const diag={buckets:[],errors:[],dirty:false};
  const bucket=()=>{const t=Math.floor(Date.now()/60000)*60000;let b=diag.buckets.at(-1);if(!b||b.t!==t){b={t,req:0,fail:0,timeout:0,retry:0,ms:0,max:0,slow:0,actions:0};diag.buckets.push(b);diag.buckets=diag.buckets.slice(-180);}return b;};
  const viewOf=url=>url.searchParams.get('action')?'action:'+url.searchParams.get('action')+(url.searchParams.get('function')?'/'+url.searchParams.get('function'):''):'view:'+(url.searchParams.get('view')??'page');
  function record(url,started,error,retried) {
    const b=bucket(),ms=Date.now()-started;b.req++;b.ms+=ms;b.max=Math.max(b.max,ms);if(ms>5000)b.slow++;if(retried)b.retry++;if(url.searchParams.has('action'))b.actions++;
    if(error) {
      const timeout=/TimeoutError|timed out|חרגה מזמן/i.test((error?.name??'')+' '+(error?.message??''));
      if(timeout)b.timeout++;else b.fail++;
      diag.errors=[{at:Date.now(),kind:timeout?'timeout':(error?.name??'error'),message:String(error?.message??error).slice(0,120),what:viewOf(url),ms},...diag.errors].slice(0,30);
    }
    diag.dirty=true;
  }
  setInterval(()=>{
    if(!diag.dirty) return;diag.dirty=false;
    let account=null;try {account=globalThis.IkariamDiagAccount?.();} catch { /* Not identified yet. */ }
    if(!account) return;
    const queue=(()=>{try {return globalThis.IkariamDiagQueue?.()??null;} catch {return null;}})();
    try {void chrome.storage.local.set({['diag-v1-'+account]:{at:Date.now(),account,buckets:diag.buckets,errors:diag.errors,queue,requests:{running,waiting:turns.length}}});} catch { /* Diagnostics only. */ }
  },60000);
  const measured=fn=>async(path,options={})=>{
    const url=new URL(path,location.href),started=Date.now();
    try {const response=await fn(path,options);record(url,started,response?.ok===false?new Error('HTTP '+response.status):null,false);return response;}
    catch(error) {record(url,started,error,false);throw error;}
  };
  // Firefox (user decision, 2026-10-27): the game server answers one account's requests one after
  // another (its session is locked per request), so many parallel requests only queue there and take
  // the browser's few connections. At most two of this tab's game requests run at once; the others
  // wait their turn here, so every automation still runs, in turn. A request that never settles gives
  // its turn back after two minutes. Three timeouts in a row pause the tab's requests for a minute,
  // letting the server and the connections clear instead of piling up more.
  // At most one request start every five seconds per account (user decision, 2026-10-27): the game stopped
  // answering the whole VPN address after a burst of about 30 requests a minute from each of the seven accounts.
  const LIMIT=2,HOLD=120000,PAUSE=60000,GAP=5000;
  let running=0,timeouts=0,pausedUntil=0,nextStart=0;const turns=[];
  const turn=()=>new Promise(resolve=>{
    const take=()=>{running++;let given=false;const timer=setTimeout(()=>giveBack(),HOLD);
      function giveBack() {if(given) return;given=true;clearTimeout(timer);running--;turns.shift()?.();}
      resolve(giveBack);};
    if(running<LIMIT) take(); else turns.push(take);
  });
  const gated=async fn=>{
    if(typeof globalThis.cloneInto!=='function') return fn();
    if(Date.now()<pausedUntil) await new Promise(resolve=>setTimeout(resolve,pausedUntil-Date.now()));
    const giveBack=await turn();
    const at=Math.max(Date.now(),nextStart);nextStart=at+GAP;
    if(at>Date.now()) await new Promise(resolve=>setTimeout(resolve,at-Date.now()));
    try {const result=await fn();timeouts=0;return result;}
    catch(error) {
      if(/TimeoutError/.test(error?.name??'')&&++timeouts>=3) {timeouts=0;pausedUntil=Date.now()+PAUSE;bucket().paused=(bucket().paused??0)+1;diag.dirty=true;}
      throw error;
    } finally {giveBack();}
  };
  const pageFetch=async(path,options={})=>{
    const url=new URL(path,location.href);
    const readOnly=String(options.method??'GET').toUpperCase()==='GET' && !url.searchParams.has('action') && url.origin===location.origin;
    // The tab queue's running job can be stopped between two requests (by the user, or to make way
    // for a raid): its next request fails instead of being sent. A job that already sent a change
    // reports the result as unknown, so nothing is sent twice.
    // A read made outside the queue (the raids panel's crew check) belongs to no job.
    const job=options.outsideQueue?null:globalThis.IkariamCurrentJob;
    if(job?.stop) {const error=new Error(job.stop);error.mutationSubmitted=job.posted?undefined:false;throw error;}
    if(job&&!readOnly) job.posted=true;
    if(!readOnly || typeof AbortSignal?.timeout!=='function') return gated(()=>once(url.href,options));
    for(let attempt=0;;attempt++) {
      // The 30 seconds start when the request's turn comes, not while it waits for it.
      try {return await gated(()=>once(url.href,{...options,signal:AbortSignal.timeout(30000)}));}
      catch(error) {
        const transient=/TimeoutError|AbortError|NetworkError|TypeError/.test(error?.name??'') || /timed out|fetch/i.test(error?.message??'');
        if(!transient || attempt>=2) throw error;
        bucket().retry++;diag.dirty=true;
        await new Promise(resolve=>setTimeout(resolve,2000*(attempt+1)));
      }
    }
  };
  globalThis.IkariamPageFetch=measured(pageFetch);
})();

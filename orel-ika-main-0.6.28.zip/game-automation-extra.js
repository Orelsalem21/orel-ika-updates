// Additional Ikabot adapters (autoPirate, modifyProduction, activateShrine,
// stationArmy, searchForIslandSpaces, reorganizeCityBuildings, donate,
// vacationMode). Each step reuses the context from game-automation-actions.js:
// one verified mutation per tick, fresh preflight, ownership and token checks.
(() => {
const KINDS=['pirates','workers','shrine','station','islands','reorganize','donate','market','consolidate'];
const READ_ONLY=['islands'];
const mainEdition=()=>{try {return /\bmain\b/.test(chrome.runtime.getManifest?.()?.version_name??'');} catch {return false;}};
// The captured raid summary uses ש for hours before minutes and for seconds
// after minutes (57ד 30ש; 1ש 55ד). A lone ש is ambiguous: do not guess.
function raidDuration(value) {
 const text=String(value??'').replace(/\s+/g,' ').trim();
 if(!text) return null;
 if(!/[ידש]/.test(text)) return globalThis.IkariamReadInsights?.parseDuration(text)??null;
 const tokens=[...text.matchAll(/(\d+)\s*([ידש])/g)];
 if(text.replace(/(\d+)\s*([ידש])/g,'').trim()) return null;
 const minute=tokens.findIndex(token=>token[2]==='ד');
 let total=0,last=-1;
 for(let i=0;i<tokens.length;i++) {
   const [,raw,unit]=tokens[i];
   if(unit==='ש'&&minute<0) return null;
   const rank=unit==='י'?0:unit==='ד'?2:i<minute?1:3;
   if(rank<=last) return null;
   const amount=Number(raw);if(rank>=2&&amount>=60) return null;
   total+=amount*[86400000,3600000,60000,1000][rank];last=rank;
 }
 return Number.isSafeInteger(total)&&total>0?total:null;
}
// config.py piracyMissionToBuildingLevel / piracyMissionWaitingTime.
const PIRACY_LEVEL={1:1,2:3,3:5,4:7,5:9,6:11,7:13,8:15,9:17};
const PIRACY_SECONDS={1:150,2:450,3:900,4:1800,5:3600,6:7200,7:14400,8:28800,9:57600};
// Capture points per mission (official Ikariam forum, Piracy Guide).
const PIRACY_POINTS={1:115,2:276,3:442,4:707,5:1131,6:1810,7:2896,8:4634,9:7414};
// "Smart" pirates (user decision, 2026-10-14): the most capture points per hour, counting the time a
// mission waits for the captcha answer. q = how often a launch asks for a captcha and D = how long
// the answer takes, both measured on this account (until measured: every other launch, 30 minutes).
function bestPirateMission(level,stats={}) {
  const q=((stats.captchas??0)+1)/((stats.launches??0)+2);
  const delays=(stats.delays??[]).filter(Number.isFinite),wait=delays.length?delays.reduce((a,b)=>a+b,0)/delays.length:1800;
  const allowed=Object.keys(PIRACY_LEVEL).map(Number).filter(mission=>PIRACY_LEVEL[mission]<=level);
  return allowed.sort((a,b)=>PIRACY_POINTS[b]/(PIRACY_SECONDS[b]+q*wait)-PIRACY_POINTS[a]/(PIRACY_SECONDS[a]+q*wait))[0]??null;
}
// Opera at night (user decision, 2026-10-22: larger gaps until the morning): from 23:00 to 07:00 Israel
// time the longest allowed mission that still ends by 07:00, so few captchas wait for the night.
function nightPirateMission(level,now=Date.now()) {
  const parts=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jerusalem',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date(now)).map(part=>[part.type,part.value]));
  const minutes=Number(parts.hour)*60+Number(parts.minute);
  if(minutes>=7*60&&minutes<23*60) return null;
  const left=((7*60-minutes+1440)%1440)*60;
  const allowed=Object.keys(PIRACY_LEVEL).map(Number).filter(mission=>PIRACY_LEVEL[mission]<=level);
  return allowed.filter(mission=>PIRACY_SECONDS[mission]<=left).sort((a,b)=>PIRACY_SECONDS[b]-PIRACY_SECONDS[a])[0]??allowed.sort((a,b)=>PIRACY_SECONDS[a]-PIRACY_SECONDS[b])[0]??null;
}
const GODS={1:'Pan (עץ)',2:'Dionysus (יין)',3:'Tyche (שיש)',4:'Plutus (זהב)',5:'Theia (קריסטל)',6:'Hephaestus (גופרית)'};
const SHRINE_PERIOD=70*3600000;
const N=value=>value==null||value===''?null:Number.isFinite(Number(value))?Number(value):null;
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
// reorganizeCityBuildings._compute_moves: swaps that make target match template.
function reorganizeMoves(template,target) {
  const normalize=building=>['palace','palaceColony'].includes(building)?'government':building;
  const group=city=>{const result={};for(const slot of city.position) if(slot.building!=='empty') (result[normalize(slot.building)]??=[]).push(slot.position);for(const key in result) result[key].sort((a,b)=>a-b);return result;};
  const wanted=group(template),current=group(target),assignment=new Map();
  for(const [type,positions] of Object.entries(wanted)) {
    const available=current[type]??[];
    positions.forEach((desired,index)=>{if(index<available.length && available[index]!==desired) assignment.set(desired,available[index]);});
  }
  const tracker=new Map([...assignment.values()].map(value=>[value,value])),reverse=new Map([...tracker].map(([key,value])=>[value,key])),moves=[];
  for(const [desired,original] of assignment) {
    const now=tracker.get(original);if(now===desired) continue;
    moves.push([now,desired]);
    const displaced=reverse.get(desired);
    tracker.set(original,desired);reverse.set(desired,original);reverse.delete(now);
    if(displaced!==undefined) {tracker.set(displaced,now);reverse.set(now,displaced);}
  }
  return moves;
}
function netGold(header) {
  const parts=['income','godGoldResult','badTaxAccountant','upkeep','scientistsUpkeep'].map(key=>N(header?.[key]));
  return parts.every(value=>value!==null)?parts.reduce((a,b)=>a+b,0):null;
}
function sliderValue(slider) {
  for(const key of ['value','current_value','default_value']) if(N(slider?.[key])!==null) return N(slider[key]);
  return null;
}
function captchaImage(text,template) {
  let src=null;try {src=template(text).js_captchaImage?.src;} catch { /* Fallback below parses the raw response. */ }
  const match=String(typeof src==='string'?src:text).replace(/\\\//g,'/').match(/data:image\/png;base64,[A-Za-z0-9+/=]+/);
  return match?.[0]??null;
}
function createExtras(bridge,h) {
 const {commands,template,html,doc,armyCounts}=h;
 async function ownCity(c,id) {
   const text=await c.request({view:'city',cityId:id});
   const match=text.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/);
   if(!match) throw new Error('עיר היעד אינה ניתנת לקריאה');
   const city=JSON.parse(match[1]);
   if(String(city.id)!==String(id) || bridge.decodeUnicodeEscape(city.ownerName)!==c.initial.ownerName) throw new Error('ניתן לבחור רק ערים בחשבון שלך');
   city.position=bridge.transformPositions(city.position);return city;
 }
 // Raid round (main edition, user request 2026-10-16): up to 10 verified target cities, raided one
 // after the other — the next leaves only when the previous one is back — then the fortress returns
 // to its capture missions. Started and stopped from the raids panel (pirate-raids-v1). The raid is
 // the game's own form: its link is found on the target's island page and the form it opens is
 // sent as the game built it, only when it names the raid and the verified target city. Anything
 // unrecognised stops the round and keeps the page for checking; nothing is guessed.
 const RAIDS='pirate-raids-v1';
 async function archiveCompletedRaid(key,state,captchaAt) {
   if(!mainEdition()||!state||state.running||state.stoppedByUser||!state.finishedAt||!state.targets?.length||state.index<state.targets.length||state.targets.some(target=>!['done','skipped'].includes(target.status)))return;
   const total=state.targets.length,completed=state.targets.filter(target=>target.status==='done'&&target.confirmed!==false).length,skipped=state.targets.filter(target=>target.status==='skipped').length,unverified=state.targets.filter(target=>target.status==='done'&&target.confirmed===false).length;
   const message=completed===total?`הסבב ${state.auto?'העצמאי ':''}בוצע בהצלחה בכל ${total} היעדים`:`הסבב הסתיים: ${completed} הושלמו, ${skipped} דולגו${unverified?`, ${unverified} ללא אימות תנועה`:""}; פירוט נשמר בלוג`;
   const lastKey='main-raid-last-v1',last=(await chrome.storage.local.get(lastKey))[lastKey]??{};
   const all=(await chrome.storage.local.get(RAIDS))[RAIDS]??{},live=all[key];
   if(live&&!live.running&&!live.stoppedByUser&&live.startedAt===state.startedAt)await chrome.storage.local.set({[lastKey]:{...last,[key]:{...state,debug:undefined,captchaAt:Number.isFinite(captchaAt)&&state.startedAt>=captchaAt?captchaAt:null,message,summary:{total,completed,skipped,unverified}}},[RAIDS]:{...all,[key]:null}});
 }
 // The game's own raid screen for a city from a fortress city (see reach), shared by the raids and by the live
 // target check of the raids table: its island, the raid link and the form the game shows only when it can raid.
 function raidScreens(c,record) {
   const findLinks=(island,cityId)=>{
     const links=[];
     for(const node of doc(island).querySelectorAll('[href], [onclick]')) {
       const values=[node.getAttribute('href')??'',...[...(node.getAttribute('onclick')??'').matchAll(/["']([^"']*\?[^"']+)["']/g)].map(m=>m[1])];
       for(const value of values) {
         if(!value.startsWith('?')&&!value.startsWith('/index.php?')&&!value.startsWith('index.php?')) continue;
         const query=new URLSearchParams(value.slice(value.indexOf('?')+1));
         if(query.get('destinationCityId')!==String(cityId)||!/raid|piracy/i.test(query.get('view')??'')||query.has('action')||query.has('function')) continue;
         query.delete('actionRequest');links.push(Object.fromEntries(query));
       }
     }
     return [...new Map(links.map(p=>[JSON.stringify(Object.entries(p).sort()),p])).values()];
   };
   const unescape=text=>String(text).replace(/\\"/g,'"').replace(/\\\//g,'/').replace(/\\n/g,'\n').replace(/&amp;/g,'&');
   const islandPage=async(origin,islandId,cityId)=>{
     // The origin scan (and a target check) leave another city selected: the raid's city is selected first.
     await c.request({view:'city',cityId:origin});
     const island=unescape(await c.request({view:'island',islandId}));
     // The island page is only a frame: the game fills a city's action buttons (the raid among them)
     // from its details panel, opened by a click on the city (user report 2026-10-18, page evidence).
     let details='';
     if(cityId) try {details=unescape(await c.request({view:'cityDetails',destinationCityId:cityId,backgroundView:'island',currentIslandId:islandId,templateView:'cityDetails',ajax:1}));} catch { /* The island page alone is checked. */ }
     return details?details+'\n<!-- island page -->\n'+island:island;
   };
   const formsOf=(page,cityId,islandId)=>{
    const document=doc(page);
    const forms=[...document.querySelectorAll('form')].map(form=>{
     const fields={};
     // HTML forms may carry action/function in their action URL rather than inputs.
     // Opera accepts only the local game endpoint, and refuses conflicting values.
     if(mainEdition()) {
       const action=form.getAttribute('action')??'';
       if(action&&action!=='index.php'&&action!=='/index.php') {
         const query=action.match(/^(?:\/?index\.php)?\?(.+)$/)?.[1];
         if(!query) return null;
         for(const [name,value] of new URLSearchParams(query.replace(/&amp;/g,'&'))) {
           if(name in fields&&fields[name]!==value) return null;
           fields[name]=value;
         }
       }
     }
     for(const input of form.querySelectorAll('input[name], select[name], textarea[name]')) {
       const name=input.getAttribute('name'),type=(input.getAttribute('type')??'').toLowerCase();
       if(input.hasAttribute('disabled')||['submit','button','image','reset','file'].includes(type)||['checkbox','radio'].includes(type)&&!input.hasAttribute('checked')) continue;
       if(mainEdition()&&name!=='actionRequest'&&name in fields&&fields[name]!==input.getAttribute('value')) return null;
       fields[name]=input.tagName.toLowerCase()==='select'?(input.querySelector('option[selected]')??input.querySelector('option'))?.getAttribute('value')??'':input.getAttribute('value')??input.textContent??'';
     }
     delete fields.actionRequest;return fields;
   }).filter(fields=>fields&&(mainEdition()?fields.action==='PiracyScreen'&&fields.function==='raid':fields.action&&/raid|piracy/i.test(String(fields.action)+' '+String(fields.function??'')))&&String(fields.destinationCityId??'')===String(cityId));
    if(forms.length||!mainEdition()) return forms;
    // Actual game response supplied 2026-10-18: the enabled submit control is
    // <a id="actionLink" class="plunderbutton plunder_ok" href="?action=...">.
    // Its four action fields come from the page; the AJAX context was captured
    // separately in the user's successful manual request. No token is retained.
    return [...document.querySelectorAll('a#actionLink.plunderbutton.plunder_ok[href]')].map(link=>{
      if(link.hasAttribute('disabled')||link.getAttribute('aria-disabled')==='true'||link.classList.contains('disabled')) return null;
      const href=link.getAttribute('href');if(!href?.startsWith('?')) return null;
      const params=new URLSearchParams(href.slice(1)),allowed=['action','function','destinationCityId','destinationIslandId','actionRequest'];
      if([...params.keys()].some(name=>!allowed.includes(name))||allowed.some(name=>params.getAll(name).length>1)) return null;
      if(params.get('action')!=='PiracyScreen'||params.get('function')!=='raid'||params.get('destinationCityId')!==String(cityId)||params.get('destinationIslandId')!==String(islandId)) return null;
      params.delete('actionRequest');
      return {...Object.fromEntries(params),backgroundView:'island',currentIslandId:String(islandId),templateView:'piracyRaid',ajax:'1'};
    }).filter(Boolean);
   };
   // Whether the raid can leave from this origin to this city: the game's own raid screen shows its
   // form only when it can. A raid button in the page is followed; without one (the island page is a
   // frame filled by the game's scripts) the screen is opened as the game itself opens it —
   // view=piracyRaid with the island and the city (user capture of the game's requests, 2026-10-18).
   const reach=async(origin,islandId,cityId)=>{
     const island=await islandPage(origin,islandId,cityId),links=findLinks(island,cityId);
     if(links.length>1) return {island,links,forms:[]};
     // The game's own request, captured 2026-10-18: view=piracyRaid&isMission=1&destinationCityId=…
     // &islandId=…&backgroundView=island&currentIslandId=…&templateView=cityDetails&ajax=1.
     const params=links[0]??{view:'piracyRaid',isMission:'1',destinationCityId:String(cityId),islandId:String(islandId),templateView:'cityDetails'};
     // A raid screen that cannot be opened is a raid that cannot leave from here (a read, never a send).
     let page='',raw='';try {raw=await c.request({...params,backgroundView:'island',currentIslandId:islandId,templateView:params.templateView??params.view,ajax:1},false,{postRead:mainEdition()});page=unescape(raw);} catch(error) {if(error.mutationSubmitted) throw error;}
     const forms=page?formsOf(page,cityId,islandId):[];
     const formStructure=mainEdition()&&page?[...doc(page).querySelectorAll('form')].slice(0,10).map(form=>({
       fields:[...form.querySelectorAll('[name]')].map(input=>input.getAttribute('name')).filter(name=>!/token|captcha|actionRequest|cookie|password/i.test(name??'')).slice(0,40),
       actionKeys:[...new URLSearchParams((form.getAttribute('action')??'').split('?')[1]??'').keys()].filter(name=>!/token|captcha|actionRequest|cookie|password/i.test(name)).slice(0,40)
     })):[];
     await record('raid-screen',{originCityId:origin,targetCityId:cityId,targetIslandId:islandId,pageReturned:!!page,formCount:forms.length,formStructure});
     return {island,page:page||null,raw:raw||null,links:[params],forms};
   };
   return {findLinks,reach};
 }
 // "בדוק עכשיו במשחק" in the raids table (user request, 2026-10-29: know before a round starts): every city of the
 // player is checked in the game, then the game's raid screen is opened from the nearest fortress cities — the same
 // reads a raid makes, never a send — and what the game answered is returned per city.
 async function raidProbe(c,playerName,cities) {
   const origins=await raidOrigins(c),{reach}=raidScreens(c,async()=>{});
   const name=id=>origins.names?.[id]??id,ap=new Map((origins.points??[]).map(item=>[String(item.cityId),item.ap]));
   const fortresses=(origins.points??[]).map(item=>String(item.cityId));
   const results=[];
   for(const city of cities.slice(0,6)) {
     const entry={name:city.name,x:city.x,y:city.y,found:false,tries:[]};results.push(entry);
     try {const verified=await bridge.verifyExternalTarget({x:city.x,y:city.y,playerName,islandName:'',cityName:city.name},true);entry.found=true;entry.cityId=String(verified.cityId);entry.islandId=String(verified.islandId);}
     catch(error) {entry.error=error.message;continue;}
     const near=fortresses.map(id=>({id,distance:origins.coords?.[id]?Math.hypot(origins.coords[id].x-city.x,origins.coords[id].y-city.y):1e6})).sort((a,b)=>a.distance-b.distance).slice(0,3);
     for(const origin of near) {
       const tried=await reach(origin.id,entry.islandId,entry.cityId);
       // What the game's raid screen itself says when it offers no raid (user report, 2026-10-29: a city 1.4 away
       // with free action points was refused and the reason was not shown).
       let screen=null;
       if(tried.forms.length!==1&&tried.raw) try {
         const page=doc(tried.raw),button=page.querySelector('.plunderbutton, #actionLink');
         const text=String(page.body?.textContent||page.documentElement?.textContent||'').replace(/\s+/g,' ').trim();
         screen=[button?'כפתור הפשיטה: '+(button.getAttribute('title')||button.textContent||'').trim()+(button.classList.contains('plunder_ok')?'':' (כבוי)'):null,text.slice(0,400)].filter(Boolean).join(' · ')||null;
       } catch { /* The reason stays unknown. */ }
       entry.tries.push({origin:name(origin.id),distance:origin.distance<1e6?Math.round(origin.distance*10)/10:null,ap:ap.get(origin.id)??null,
        ok:tried.links.length<=1&&tried.forms.length===1,why:tried.links.length>1?'כמה אפשרויות פשיטה שונות בדף':tried.forms.length!==1?(tried.page?'מסך הפשיטה לא הציע פשיטה':'מסך הפשיטה לא נפתח'):null,screen});
       if(entry.tries.at(-1).ok) break;
     }
     entry.ok=entry.tries.some(item=>item.ok);
   }
   return {at:Date.now(),playerName,fortresses:(origins.points??[]).map(item=>({city:name(item.cityId),ap:item.ap})),cities:results};
 }
 async function raidStep(c) {
   const key=c.rule.accountKey,state=((await chrome.storage.local.get(RAIDS))[RAIDS]??{})[key];
   if(mainEdition()&&!state?.running)await archiveCompletedRaid(key,state,c.progress.captcha?.at);
   // Opera diagnostics are metadata only. Logging failures must never change game execution.
   const record=async(stage,details={})=>{
     if(!mainEdition()||!state?.running) return;
     try {
       const logKey='raid-log-v1-'+key,events=(await chrome.storage.local.get(logKey))[logKey]??[];
       const queue=globalThis.IkariamDiagQueue?.();
       await chrome.storage.local.set({[logKey]:[...events.filter(event=>Date.now()-event.at<86400000),{at:Date.now(),roundStartedAt:state.startedAt??null,operationId:c.rule.inFlight??null,index:state.index,stage,...details,...(queue?{queue:{running:queue.running, runningForSec:queue.runningForSec,waiting:queue.waiting}}:{})}].slice(-400)});
     } catch { /* Diagnostic storage is best effort; never retry a game action for a log. */ }
   };
   if(mainEdition()&&state?.running) {
     const original=c,request=c.request;
     c=Object.create(original);
     c.request=async(params,...args)=>{
       const fields=Object.fromEntries(['view','action','function','cityId','islandId','destinationCityId','destinationIslandId','templateView'].filter(name=>params[name]!==undefined).map(name=>[name,String(params[name])]));
       const started=Date.now();await record('request-start',{fields,mutation:args[0]===true});
       try {
         const result=await request.call(original,params,...args);
         await record('request-end',{fields,ms:Date.now()-started,mutation:args[0]===true,captcha:/js_captchaImage|createCaptcha/.test(result)});
         return result;
       } catch(error) {await record('request-error',{fields,ms:Date.now()-started,mutation:args[0]===true,outcomeUnknown:error.mutationSubmitted===true});throw error;}
     };
     await record('step-start',{targetCityId:state.targets?.[state.index]?.cityId??null});
   }
   if(state?.running&&state.ruleId&&state.ruleId!==c.rule.id) {
     // A round whose automation was deleted is taken over here instead of waiting for it forever.
     const owner=((await chrome.storage.local.get('game-automations-v1'))['game-automations-v1']?.rules??[]).find(rule=>rule.id===state.ruleId&&!rule.deleted);
     if(owner) return {...c.wait('סבב פשיטות פעיל במבצר אחר בחשבון; הלכידות ממתינות לסיומו'),delayMs:120000};
     state.ruleId=c.rule.id;
   }
   // A capture captcha waiting for its answer does not hold a round: the crew is home and idle.
   if(!state?.running) return null;
   const save=async()=>{const all=(await chrome.storage.local.get(RAIDS))[RAIDS]??{};const live=all[key];
     // The user's "stop" pressed meanwhile wins.
     if(live&&!live.running&&state.running) {state.running=false;state.message=live.message??'הסבב נעצר';state.stoppedByUser=live.stoppedByUser;}
     await chrome.storage.local.set({[RAIDS]:{...all,[key]:{...state,updatedAt:Date.now()}}});};
   const shipState=c.home.replace(/\\"/g,'"').match(/"showPirateFortressShip"\s*:\s*([01])/);
   if(!shipState) {state.message='לא ניתן לקרוא את מצב הצוות מהמשחק; ממתין לבדיקה חוזרת';await save();return {...c.wait(state.message),delayMs:60000};}
   const total=state.targets.length,shipOut=shipState[1]==='0';
   await record('crew-state',{shipOut});
   const updateTimes=(target,source)=>{
     let matched=false;
     try {
       const movements=bridge.advisorMovements(h.commands(source));
       const yes=value=>value===true||value===1||value==='1'||value==='true';
       for(const movement of movements) {
         const returning=yes(movement.event?.isFleetReturning),destination=returning?movement.origin:movement.target;
         if(yes(movement.isHostile)||!yes(movement.isOwnArmyOrFleet)) continue;
         const mission=bridge.decodeUnicodeEscape(String(movement.event?.missionText??''));
         if(!/piracy|pirate|raid|פשיט|פיראט/i.test(mission)) continue;
         const origin=returning?movement.target:movement.origin;
         const cityId=place=>String(place?.cityId??place?.id),own=String(target.originCityId??c.rule.cityId);
         if(mainEdition()) {
           // Captured returning piracy movement keeps the original origin/target;
           // isFleetReturning marks direction without swapping the endpoints.
           const direct=cityId(movement.origin)===own&&cityId(movement.target)===String(target.cityId);
           const reversed=returning&&cityId(movement.target)===own&&cityId(movement.origin)===String(target.cityId);
           if(!direct&&!reversed) continue;
         } else if(cityId(destination)!==String(target.cityId)||cityId(origin)!==own) continue;
         matched=true;target.confirmed=true;
         const raw=Number(movement.eventTime),at=raw>1e12?raw:raw*1000;
         if(!Number.isFinite(at)||at<=0) continue;
         if(returning) target.returnAt=at;else target.arrivalAt=at;
       }
     } catch { /* A missing movement time must never replay an already sent raid. */ }
     return matched;
   };
   const keepEvidence=(page,target)=>{
     if(page) {
       // Keep target/action evidence even when it occurs far beyond the page header.
       const source=String(page).replace(/<input\b[^>]*\bname\s*=\s*["']actionRequest["'][^>]*>/gi,'<!-- actionRequest omitted -->')
         .replace(/actionRequest(?:\\?["'])?\s*(?:=|:)\s*(?:\\?["'])?[^\s&<>"'\\]+/gi,'actionRequest=…');
       const sections=[],ranges=[];
       let size=0;
       const add=(at,before=700,after=1800)=>{
         const start=Math.max(0,at-before),end=Math.min(source.length,at+after);
         if(ranges.some(([a,b])=>start>=a&&end<=b)||size>=24000) return;
         const text=source.slice(start,end).slice(0,24000-size);size+=text.length;ranges.push([start,end]);
         sections.push(`--- page offset ${start} ---\n${text}`);
       };
       for(const value of [target?.cityName,target?.cityId]) {
         if(!value) continue;
         let at=source.indexOf(String(value)),count=0;
         while(at>=0&&count++<4) {add(at);at=source.indexOf(String(value),at+String(value).length);}
       }
       for(const match of source.matchAll(/piracy|pirate|raid|פשיטה|פיראט|destinationCityId|<form\b/gi)) add(match.index,300,1200);
       if(!sections.length) add(0,0,4000);
       state.debug={at:Date.now(),snippet:`Target: ${target?.playerName??''} ${target?.cityName??''} | cityId: ${target?.cityId??''} | islandId: ${target?.islandId??''}\nPage length: ${String(page).length}\n${sections.join('\n\n')}`};
     }
   };
   const stop=async(message,page,target)=>{
     state.running=false;state.message=message;if(target){target.status='error';target.message=message;}
     keepEvidence(page,target);
     await save();return {...c.wait(message+' · הסבב נעצר'),delayMs:60000};
   };
   // A target that cannot be raided (no data, out of reach, an unrecognised screen) is skipped and the
   // round goes on with the next one; only a raid asking for a captcha stops the round.
   const skip=async(message,page,target)=>{
     keepEvidence(page,target);
     target.status='skipped';target.message=message;state.index++;
     state.message=message+' · ממשיך ליעד הבא';
     await save();return {...c.wait(state.message),delayMs:5000};
   };
   const current=state.targets[state.index];
   if(current?.status==='sent') {
     const advisor=await c.request({...c.base,view:'militaryAdvisor',oldView:'city',activeTab:'militaryMovements'});
     // Still out while the crew is away, the raid's own movement is listed, or it left moments ago.
     // A raid whose movement was never recognised ends once the crew is home — never an endless wait.
     const moving=updateTimes(current,advisor);
     await record('movement-check',{matched:moving,targetCityId:current.cityId,arrivalAt:current.arrivalAt??null,returnAt:current.returnAt??null});
     if(shipOut||moving||Date.now()-current.sentAt<120000) {
       state.message=current.confirmed===false?'בקשת הפשיטה נשלחה; ממתין לאימות תנועה ליעד '+current.cityName:`פשיטה ${state.index+1}/${total} על ${current.cityName} בדרך; הבאה תצא כשהכוח יחזור`;
       await save();return {...c.wait(state.message),delayMs:current.confirmed===false?60000:120000};
     }
     current.status='done';current.doneAt=Date.now();state.index++;
     if(current.confirmed===false) current.message='הצוות חזר; תנועת הפשיטה לא זוהתה במשחק';
     await remember(key,current);
   }
   if(state.index>=total) {
     if(mainEdition()&&shipOut){state.message='כל היעדים טופלו; ממתין לאימות חזרת הצוות לפני סיום הסבב';await save();return {...c.wait(state.message),delayMs:60000};}
     if(mainEdition())await record('round-complete',{total,completed:state.targets.filter(target=>target.status==='done').length,skipped:state.targets.filter(target=>target.status==='skipped').length});
     state.running=false;state.finishedAt=Date.now();state.message='הסבב הושלם · חוזר למשימות לכידה';await save();
     if(mainEdition())await archiveCompletedRaid(key,state,c.progress.captcha?.at);
     return null;
   }
   if(shipOut) {state.message='ממתינה לסיום המשימה הנוכחית במבצר לפני הפשיטה';await save();return {...c.wait(state.message),delayMs:120000};}
   const target=state.targets[state.index],label=target.playerName??target.cityName??'';
   // Action points (user decision, 2026-10-18): a raid takes one action point of the city it leaves
   // from, and every city of the account has a fortress, so it leaves from a fortress city with free
   // points. With none free anywhere the round waits for the next return of a movement from those
   // cities, and the captures go on meanwhile (the crew is shared, one mission at a time).
   if(state.apWaitUntil&&Date.now()<state.apWaitUntil) return {deferred:true,until:state.apWaitUntil};
   const origins=await raidOrigins(c);
   await record('origin-scan',{points:origins.points??[],unknown:!!origins.unknown,waitUntil:origins.until??null});
   if(origins.none) {
     await c.cityRead();state.apWaitUntil=origins.until;
     state.message=origins.unknown?'נקודות הפעולה לא פוענחו; הפשיטה ממתינה לקריאה חוזרת, ללא ניחוש':`אין נקודת פעולה פנויה באף עיר עם מבצר; הפשיטה על ${label} תצא בערך ב־${new Date(origins.until).toLocaleTimeString('he-IL',{timeZone:'Asia/Jerusalem'})} · בינתיים ממשיכות הלכידות`;
     await save();return {deferred:true,until:origins.until};
   }
   state.apWaitUntil=undefined;
   const {reach}=raidScreens(c,record);
   let chosen=null,island='';
   if(target.playerName&&!target.cityId) {
     // A player (raids panel, user decision 2026-10-18): the nearest of his cities to a fortress city
     // with a free action point, checked in the game; one out of reach gives way to the next pair.
     const picked=await pickPlayerCity(c,key,target,origins,reach);
     island=picked.island;chosen=picked.chosen;
     if(picked.pending) {state.message='בדיקת טווח הפשיטה על '+label+' ממשיכה מהצמד הבא';await c.cityRead();await save();return {...c.wait(state.message),delayMs:5000};}
     if(!chosen) {await c.cityRead();return skip(picked.reason,island,target);}
   } else {
     if(!/^\d+$/.test(String(target.cityId??''))||!/^\d+$/.test(String(target.islandId??''))) return skip('היעד '+label+' לא אומת',null,target);
     let several=false;
     for(const id of origins.list) {
       const tried=await reach(id,target.islandId,target.cityId);island=tried.page??tried.island;
       if(tried.links.length>1) {several=true;continue;}
       if(tried.forms.length===1) {chosen={origin:id,page:tried.page,forms:tried.forms};break;}
     }
     if(!chosen) {await c.cityRead();return skip(several?'נמצאו כמה אפשרויות פשיטה שונות על '+label:'מסך הפשיטה של המשחק לא הציג טופס פשיטה ל'+label+(origins.list.length>1?' מאף עיר עם נקודת פעולה פנויה':''),island,target);}
   }
   const origin=chosen.origin,page=chosen.page,forms=chosen.forms;
   const summary=mainEdition()?doc(page):null;
   const journeyMs=summary?raidDuration(summary.querySelector('#journeyTime')?.textContent):null;
   const roundTripMs=summary?raidDuration(summary.querySelector('#returnTime')?.textContent):null;
   target.originCityId=origin;target.originName=origins.names?.[origin]??null;
   const fields=forms[0];
   await record('raid-pre-submit',{originCityId:origin,targetCityId:target.cityId,targetIslandId:target.islandId,fieldNames:Object.keys(fields).filter(name=>!/token|captcha|actionRequest|cookie|password/i.test(name))});
   // Persist intent before submission so a lost response cannot trigger a second raid.
   if(c.rule.inFlight) {
     const receiptKey='game-result-'+c.rule.inFlight,receipt=(await chrome.storage.local.get(receiptKey))[receiptKey]??{};
     await chrome.storage.local.set({[receiptKey]:{...receipt,status:'pending',phase:'running',raidTracking:1,raidSubmission:{cityId:String(target.cityId),at:Date.now()}}});
   }
   const submittedAt=Date.now();
   const response=await c.request(fields,true,{allowRejected:true});
   await record('raid-response',{captcha:/js_captchaImage|createCaptcha/.test(response)});
   if(/js_captchaImage|createCaptcha/.test(response)) return stop('המשחק דרש קפצ׳ה לפשיטה על '+target.cityName+'; צא לפשיטה הזו ידנית',null,target);
   await c.cityRead();
   c.ensure(/"showPirateFortressShip"\s*:\s*0/.test((response+' '+c.home).replace(/\\"/g,'"')));
   target.status='sent';target.sentAt=Date.now();target.confirmed=false;target.message='נשלחה; ממתין לאימות תנועת הפשיטה';
   if(mainEdition()) {
     if(journeyMs!==null) target.expectedArrivalAt=submittedAt+journeyMs;
     if(roundTripMs!==null&&journeyMs!==null&&roundTripMs>=journeyMs) target.expectedReturnAt=submittedAt+roundTripMs;
     await record('raid-expected-times',{expectedArrivalAt:target.expectedArrivalAt??null,expectedReturnAt:target.expectedReturnAt??null});
   }
   await record('raid-sent',{originCityId:origin,targetCityId:target.cityId});
   state.message=`בקשת פשיטה ${state.index+1}/${total} נשלחה אל ${target.cityName}; ממתין לאימות תנועה`;await save();
   try {
     if(updateTimes(target,await c.request({...c.base,view:'militaryAdvisor',oldView:'city',activeTab:'militaryMovements'}))) {
       await record('movement-confirmed',{targetCityId:target.cityId,arrivalAt:target.arrivalAt??null,returnAt:target.returnAt??null});
       target.message='יצאה — אומתה תנועת פשיטה ליעד';state.message=`פשיטה ${state.index+1}/${total} יצאה אל ${target.cityName}`;
     }
     await save();
   } catch { /* Submission is already saved; verify it later without sending again. */ }
   return {...c.changed(state.message),delayMs:120000};
 }
 // Raid targets (main edition, user decisions 2026-10-18): players kept by name in
 // pirate-raid-players-v1, their cities read from ikatracker.com by the background page; an older
 // list of verified cities (pirate-raid-targets-v1) still works. Each keeps the times of its last raid.
 const RAID_TARGETS='pirate-raid-targets-v1',RAID_PLAYERS='pirate-raid-players-v1',CAPTCHA_IDLE=30*60000,PLAYER_DATA_AGE=24*3600000,PAIR_TRIES=6;
 async function remember(key,target) {
   const last={originName:target.originName??null,cityName:target.cityName??null,sentAt:target.sentAt??null,arrivalAt:target.arrivalAt??null,returnAt:target.returnAt??null,doneAt:target.doneAt??Date.now(),confirmed:target.confirmed!==false,...(mainEdition()?{expectedArrivalAt:target.expectedArrivalAt??null,expectedReturnAt:target.expectedReturnAt??null}:{})};
   const store=target.playerName?RAID_PLAYERS:RAID_TARGETS,all=(await chrome.storage.local.get(store))[store]??{},list=all[key]??[];
   const saved=list.find(item=>target.playerName?item.playerName===target.playerName:String(item.cityId)===String(target.cityId));if(!saved) return;
   saved.lastRaid=last;await chrome.storage.local.set({[store]:{...all,[key]:list}});
 }
 // The player's cities; asked from ikatracker through the background page only when none are kept,
 // at most once a day (the tracker allows five searches a day). A changed city fails the game check.
 async function playerData(key,name) {
   const read=async()=>((((await chrome.storage.local.get(RAID_PLAYERS))[RAID_PLAYERS]??{})[key])??[]).find(item=>item.playerName===name);
   let player=await read();
   if(player&&!player.cities?.length&&Date.now()-(player.failedAt??0)>PLAYER_DATA_AGE&&globalThis.chrome?.runtime?.sendMessage) {
     try {await Promise.race([chrome.runtime.sendMessage({type:'IKARIAM_AGENT_RAID_PLAYERS',command:{operation:'refresh',accountKey:key,names:[name]}}),sleep(30000)]);} catch { /* The data kept so far is used. */ }
     player=await read();
   }
   return player;
 }
 // Ids found in the game for a player's city are kept with it, so it is checked once.
 async function keepCityIds(key,name,city) {
   const all=(await chrome.storage.local.get(RAID_PLAYERS))[RAID_PLAYERS]??{},player=(all[key]??[]).find(item=>item.playerName===name);
   const saved=player?.cities?.find(item=>item.name===city.name&&item.x===city.x&&item.y===city.y);
   if(saved) {saved.cityId=city.cityId;saved.islandId=city.islandId;await chrome.storage.local.set({[RAID_PLAYERS]:all});}
 }
 // The nearest pair of a fortress city with a free action point and a city of the player (island
 // distance on the world map), checked in the game: a city that fails the check or is out of the
 // fortress's reach gives way to the next pair, at most PAIR_TRIES island pages per raid.
 async function pickPlayerCity(c,key,target,origins,reach) {
   const player=await playerData(key,target.playerName);
   if(!player?.cities?.length) return {reason:'אין נתוני ערים לשחקן '+target.playerName+(player?.error?' ('+player.error+')':' — יש לרענן את הנתונים בחלונית')};
   // The departure city the user chose for this player (raids panel, user decision 2026-10-27) is the only one
   // tried while it has a free action point; without one there, the nearest free city as before.
   const preferred=player.originCityId&&origins.list.includes(String(player.originCityId))?String(player.originCityId):null;
   const fromList=preferred?[preferred]:origins.list;
   const order=new Map(origins.list.map((id,index)=>[id,index]));
   const pairs=[];
   for(const origin of fromList) for(const city of player.cities) {
     const at=origins.coords?.[origin];
     pairs.push({origin,city,distance:at?Math.hypot(at.x-city.x,at.y-city.y):1e6});
   }
   pairs.sort((a,b)=>a.distance-b.distance||order.get(a.origin)-order.get(b.origin));
   const failed=new Set(),trace=[],name=id=>origins.names?.[id]??id;let island='',tries=0,lastError='';
   if(player.originCityId&&!preferred) trace.push('לעיר שנבחרה ליציאה ('+name(String(player.originCityId))+') אין נקודת פעולה פנויה; הפשיטה יוצאת מהעיר הקרובה הפנויה');
   const resume=mainEdition(),checked=new Set(resume?target.checkedPairs??[]:[]);
   const where=pair=>name(pair.origin)+' ← '+pair.city.name+' ['+pair.city.x+':'+pair.city.y+']'+(pair.distance<1e6?' מרחק '+pair.distance.toFixed(1):'');
   for(const pair of pairs) {
     const city=pair.city,cityKey=city.name+'|'+city.x+':'+city.y;
     if(resume) {
       const pairKey=pair.origin+'|'+cityKey;
       if(checked.has(pairKey)) continue;
       if(tries>=PAIR_TRIES) {target.checkedPairs=[...checked];target.trace=[...(target.trace??[]),...trace];return {pending:true,island};}
       checked.add(pairKey);tries++;
     }
     if(failed.has(cityKey)) continue;
     if(!/^\d+$/.test(String(city.cityId??''))||!/^\d+$/.test(String(city.islandId??''))) {
       try {
         const verified=await bridge.verifyExternalTarget({x:city.x,y:city.y,playerName:target.playerName,islandName:'',cityName:city.name},true);
         city.cityId=String(verified.cityId);city.islandId=String(verified.islandId);await keepCityIds(key,target.playerName,city);
       } catch(error) {failed.add(cityKey);lastError=city.name+': '+error.message;trace.push(city.name+': בדיקת העיר במשחק נכשלה ('+error.message+')');continue;}
     }
     if(!resume&&++tries>PAIR_TRIES) {trace.push('הופסק אחרי '+PAIR_TRIES+' בדיקות');break;}
     const tried=await reach(pair.origin,city.islandId,city.cityId);island=tried.page??tried.island;
     if(tried.links.length>1) {trace.push(where(pair)+': כמה אפשרויות פשיטה שונות בדף');continue;}
     if(tried.forms.length!==1) {trace.push(where(pair)+': מסך הפשיטה של המשחק לא הציג טופס (מחוץ לטווח או לא זמין)');continue;}
     Object.assign(target,{cityId:city.cityId,islandId:city.islandId,cityName:city.name,x:city.x,y:city.y});
     if(resume) delete target.checkedPairs;
     return {island,chosen:{origin:pair.origin,page:tried.page,forms:tried.forms}};
   }
   // What was tried, so a skip can be checked: free action points per fortress city and every pair.
   const free=(origins.points??[]).map(item=>name(item.cityId)+' '+(item.ap??'?')).join(', ');
   target.trace=[...(resume?target.trace??[]:[]),...(free?['נקודות פעולה פנויות: '+free]:[]),...trace];
   return {island,reason:'אף עיר של '+target.playerName+' לא נמצאה בטווח של מבצר עם נקודת פעולה פנויה'+(lastError&&!trace.length?' ('+lastError+')':'')};
 }
 // A capture captcha left unanswered for 30 minutes (user decision, 2026-10-18): the idle crew raids
 // the saved players one after the other, round after round, until the code is entered; a round
 // under way then finishes and the code goes with the next capture. A round the user stopped, one
 // stopped by an error (a raid asking for its own captcha) or one that raided no one is not
 // restarted for this image — nothing loops without raiding.
// Opera: raids only, ordered by capture points (user decision, 2026-10-28; main-raid-smart-v1, on unless switched
// off). The raid list is raided round after round without end: a round that ends starts the next at once by the
// latest ranking; a new daily ranking (Firefox reads it at 18:01) starts a new round once the raid under way is
// back. Order, as raid-players.js raidOrder: players Firefox does not read first, in the list's order; then the
// Firefox accounts read in this cycle, most capture points first; then those not read; a player added during a
// round last until read. Targets still waiting follow fresh capture points unless the user reordered them.
const SMART='main-raid-smart-v1',RANKING='main-capture-ranking-v1';
function raidGroup(target,ranking) {
  const point=ranking?.points?.[target.playerName],cycle=ranking?.cycle?.at??0;
  return point&&point.at>=cycle?1:target.added?3:point?2:0;
}
function raidOrder(list,ranking) {
  const value=item=>ranking?.points?.[item.playerName]?.value??0;
  return list.map((item,index)=>({item,index,group:raidGroup(item,ranking)})).sort((a,b)=>a.group-b.group||(a.group===1?value(b.item)-value(a.item):0)||a.index-b.index).map(entry=>entry.item);
}
async function smartRaids(c) {
  if(!mainEdition()||((await chrome.storage.local.get(SMART))[SMART]??{}).enabled===false) return false;
  const key=c.rule.accountKey,all=(await chrome.storage.local.get(RAIDS))[RAIDS]??{},state=all[key];
  const ranking=(await chrome.storage.local.get(RANKING))[RANKING]??null,cycle=ranking?.cycle?.complete?ranking.cycle.at:0;
  const players=((((await chrome.storage.local.get(RAID_PLAYERS))[RAID_PLAYERS]??{})[key])??[]).slice(0,20);
  if(!players.length) return true;
  const start=async message=>{
    const targets=raidOrder(players.map(player=>({playerName:player.playerName})),ranking);
    await chrome.storage.local.set({[RAIDS]:{...all,[key]:{index:0,targets,running:true,auto:true,smart:true,startedAt:Date.now(),ruleId:c.rule.id,message}}});
  };
  if(!state?.running) {
    // A round the user stopped stays stopped until the user starts one or the next daily ranking arrives.
    if(state?.stoppedByUser&&!(cycle>(state.updatedAt??state.startedAt??0))) return true;
    await start('סבב פשיטות לפי נקודות לכידה');return true;
  }
  // Only between raids: the raid under way always comes back first.
  if(state.targets?.[state.index]?.status==='sent') return true;
  if(cycle>(state.startedAt??0)) {await start('דירוג יומי חדש (18:01) — סבב חדש לפי נקודות הלכידה');return true;}
  if(state.manualOrder) return true;
  const done=state.targets.slice(0,state.index),pending=raidOrder(state.targets.slice(state.index),ranking);
  if(pending.some((target,place)=>target!==state.targets[state.index+place])) await chrome.storage.local.set({[RAIDS]:{...all,[key]:{...state,targets:[...done,...pending]}}});
  return true;
}
 async function captchaRound(c) {
   const p=c.progress,key=c.rule.accountKey;
   if(!p.captcha||c.rule.captchaAnswer?.value&&c.rule.captchaAnswer.at>=p.captcha.at||Date.now()-p.captcha.at<CAPTCHA_IDLE) return;
   const all=(await chrome.storage.local.get(RAIDS))[RAIDS]??{},previous=all[key];
   if(previous?.running) return;
   if(mainEdition()&&previous?.finishedAt)await archiveCompletedRaid(key,previous,p.captcha.at);
   if(mainEdition()) {
     const last=((await chrome.storage.local.get('main-raid-last-v1'))['main-raid-last-v1']??{})[key];
     // One completed round per unanswered image. A new image or an explicit new round still works.
     if(last?.finishedAt&&last.captchaAt===p.captcha.at)return;
   }
   if(previous?.auto&&(previous.startedAt??0)>=p.captcha.at&&(previous.stoppedByUser||previous.targets?.some(target=>target.status==='error')||!previous.targets?.some(target=>target.status==='done'))) return;
   const players=((((await chrome.storage.local.get(RAID_PLAYERS))[RAID_PLAYERS]??{})[key])??[]).slice(0,20).map(player=>({playerName:player.playerName}));
   const targets=players.length?players:(((await chrome.storage.local.get(RAID_TARGETS))[RAID_TARGETS]??{})[key]??[])
     .filter(target=>/^\d+$/.test(String(target.cityId??''))&&/^\d+$/.test(String(target.islandId??''))).slice(0,20).map(({lastRaid:_,...target})=>({...target}));
   if(!targets.length) return;
   await chrome.storage.local.set({[RAIDS]:{...all,[key]:{index:0,targets,running:true,auto:true,startedAt:Date.now(),ruleId:c.rule.id,
     message:'קפצ׳ה ממתינה 30 דקות בלי תשובה — סבב פשיטות עצמאי על השחקנים השמורים'}}});
 }
 // Free action points of a city, as the game reports them (header maxActionPoints, the free count
 // despite its name, or the global menu); null when the page does not show them.
 function actionPoints(text) {
   const source=String(text).replace(/\\"/g,'"');
   const value=source.match(/"maxActionPoints"\s*:\s*"?(\d+)/)?.[1]??source.match(/js_GlobalMenu_maxActionPoints"[^>]*>\s*(\d+)/)?.[1];
   return value==null?null:Number(value);
 }
 // The account's fortress cities with free action points, most first (the automation's own city
 // first on a tie); or, with none free, when the next movement of those cities comes back.
 async function raidOrigins(c) {
   const own=String(c.rule.cityId);
   let ids=[own];const coords={};
   try {
     const related=c.home.match(/relatedCityData:\s*JSON\.parse\('(.+?),\\"additionalInfo/);
     if(related) {
       const data=JSON.parse((related[1]+'}').replace(/\\/g,'').replace(/city_/g,''));ids=[...new Set([own,...Object.keys(data).filter(id=>data[id].relationship==='ownCity')])];
       for(const id of ids) {const match=String(data[id]?.coords??'').match(/(\d+)\D+(\d+)/);if(match) coords[id]={x:Number(match[1]),y:Number(match[2])};}
     }
   } catch { /* Only the automation's own city is known. */ }
   const points=[],names={};
   for(const id of ids) {
     const text=await c.request({view:'city',cityId:id});
     let fortress=id===own,name=null;
     try {const match=text.match(/"updateBackgroundData",\s?([\s\S]*?)\],\["updateTemplateData"/);if(match) {const city=JSON.parse(match[1]);name=bridge.decodeUnicodeEscape(city.name??'');fortress=(city.position??[]).some(item=>item?.building==='pirateFortress');}} catch { /* Unreadable city: skipped below. */ }
     names[id]=name;if(fortress) points.push({cityId:id,ap:actionPoints(text)});
   }
   if(!points.some(item=>item.ap!==null)) return mainEdition()?{none:true,names,coords,points,unknown:true,until:Date.now()+120000}:{list:[own],names,coords,points,unknown:true};
   const free=points.filter(item=>item.ap>0).sort((a,b)=>b.ap-a.ap||Number(b.cityId===own)-Number(a.cityId===own));
   if(free.length) return {list:free.map(item=>item.cityId),names,coords,points};
   let until=null;
   try {
     const fortresses=new Set(points.map(item=>item.cityId)),yes=value=>value===true||value===1||value==='1'||value==='true';
     for(const movement of bridge.advisorMovements(h.commands(await c.request({...c.base,view:'militaryAdvisor',oldView:'city',activeTab:'militaryMovements'})))) {
       if(!yes(movement.isOwnArmyOrFleet)||yes(movement.isHostile)) continue;
       const home=yes(movement.event?.isFleetReturning)?movement.target:movement.origin;
       if(!fortresses.has(String(home?.cityId??home?.id))) continue;
       const raw=Number(movement.eventTime),at=raw>1e12?raw:raw*1000;
       if(Number.isFinite(at)&&at>Date.now()&&(until===null||at<until)) until=at;
     }
   } catch { /* No movement times: check again in ten minutes. */ }
   return {none:true,names,coords,points,until:Math.max(Date.now()+120000,(until??Date.now()+600000)+30000)};
 }
 // A learned mission length is used only up to twice the game's own (see the learning below).
 const plausible=(seconds,mission)=>seconds>0&&seconds<=(PIRACY_SECONDS[mission]??0)*2;
 async function pirates(c) {
   const {rule,progress:p}=c,fortress=c.building('pirateFortress');
   const smart=await smartRaids(c);
   if(!smart) await captchaRound(c);
   // A code entered during a round is kept for the capture that follows the round. A round waiting
   // for an action point lets the captures go on meanwhile.
   const raided=await raidStep(c);if(raided&&!raided.deferred) {delete p.missionEndsAt;return {...raided,keepCaptchaAnswer:true};}
   // Opera raids only: no capture mission is ever sent; the next round starts on the next check.
   if(smart) {
     if(raided?.deferred) return {...c.wait('הפשיטה הבאה ממתינה לנקודת פעולה פנויה · אין משימות לכידה באופרה'),delayMs:Math.max(30000,raided.until-Date.now())};
     return {...c.wait('מצב פשיטות בלבד — משימות לכידה כבויות באופרה'),delayMs:5000};
   }
   // Captures switched off (before the round, or by the user during it): the round is over, the
   // captures stay off.
   if(p.raidOnly||rule.enabled===false) {
     if(raided?.deferred) return {...c.wait('סבב הפשיטות ממתין לנקודת פעולה פנויה; הלכידות כבויות לבקשתך'),delayMs:Math.max(60000,raided.until-Date.now())};
     p.raidOnly=false;return c.result('complete','סבב הפשיטות הסתיים; משימות הלכידה כבויות לבקשתך');
   }
   p.stats??={launches:0,captchas:0,delays:[]};
   // A captcha already shown keeps the mission it was asked for.
   const mission=rule.pirateStrategy==='auto'?(p.captcha?.mission??(mainEdition()?nightPirateMission(Number(fortress.level)||0):null)??bestPirateMission(Number(fortress.level)||0,p.stats)??rule.pirateMission):rule.pirateMission,level=PIRACY_LEVEL[mission];
   if(!Number.isFinite(fortress.level)||fortress.level<level) throw new Error('רמת מבצר הפיראטים נמוכה מהנדרש למשימה שנבחרה');
   const fortressView=extra=>c.request({...c.base,view:'pirateFortress',position:fortress.position,templateView:'pirateFortress',...extra});
   async function confirmCapture(response) {
     if(!/"showPirateFortressShip"\s*:\s*0/.test(response.replace(/\\"/g,'"'))){await c.cityRead();c.ensure(/"showPirateFortressShip"\s*:\s*0/.test(c.home));}
     p.missionStartedAt=Date.now();p.missionEndsAt=p.missionStartedAt+(p.missionMission===mission&&plausible(p.missionSeconds,mission)?p.missionSeconds:PIRACY_SECONDS[mission])*1000;p.activeMission=mission;p.stats.launches=(p.stats.launches??0)+1;p.captureConversionPending=rule.convertPoints===true;
   }
   const params={...c.base,action:'PiracyScreen',function:'capture',buildingLevel:level,view:'pirateFortress',position:fortress.position,activeTab:'tabBootyQuest',templateView:'pirateFortress'};
   if(p.captcha && rule.captchaAnswer?.value && rule.captchaAnswer.at>=p.captcha.at) {
     const response=await c.request({...params,captchaNeeded:1,captcha:rule.captchaAnswer.value},true,{allowRejected:true});
     if(response.includes('"showPirateFortressShip":1') || /js_captchaImage/.test(response)) {
       p.captcha={image:captchaImage(response,template)??p.captcha.image,at:Date.now(),wrong:true,mission};
       // Telegram: the new image is sent with "שחזור הקוד … נכשל" as its caption.
       return c.result('alert','הקפצ׳ה שהוזנה לא התקבלה; יש להזין את הקוד החדש בחלון האוטומציה',{alerts:[]});
     }
     p.stats.delays=[...(p.stats.delays??[]),Math.max(0,(rule.captchaAnswer.at-p.captcha.at)/1000)].slice(-20);
     await confirmCapture(response);p.captcha=null;
     return {...c.changed('משימת פיראטים יצאה לאחר פתרון הקפצ׳ה'),cycle:true,delayMs:PIRACY_SECONDS[mission]*1000+15000,alerts:['✅ שחזור הקוד בחשבון "'+String(rule.accountKey).split('|')[0]+'" עבר בהצלחה, משימת פיראטים בחשבון "'+String(rule.accountKey).split('|')[0]+'" יצאה בהצלחה']};
   }
   if(/"showPirateFortressShip":0/.test(c.home)) {
     const source=await fortressView({activeTab:'tabCrew'}),remaining=N(source.match(/ongoingMissionTimeRemaining\\?"?:\s*(\d+)/)?.[1]);
     if(remaining!==null&&remaining>=0)p.missionEndsAt=Date.now()+remaining*1000;
     // The mission's real length as the game counts it (user report, 2026-10-28: mission 1 took about five
     // minutes, not Ikabot's two and a half), learned so the next capture leaves right when the crew is back.
     // Only a plausible length is learned (user report, 2026-10-29: 313 to 667 seconds were learned for mission 1,
     // which takes 2:49, and each capture then left minutes late, since a later check never sees the crew out).
     if(remaining!==null&&remaining>=0&&p.missionStartedAt&&Date.now()-p.missionStartedAt<3600000) {const seconds=Math.round((p.missionEndsAt-p.missionStartedAt)/1000);if(plausible(seconds,p.activeMission)) {p.missionSeconds=seconds;p.missionMission=p.activeMission;}}
     if(rule.convertPoints && !source.includes('conversionProgressBar')) {
       const points=N(source.match(/\\?"capturePoints\\?":\\?"(\d+)/)?.[1]);
       const amount=points===null?null:Math.floor((rule.convertAmount>0?Math.min(rule.convertAmount,points):points)/10);
       if(amount>0) {
         await c.request({...c.base,action:'PiracyScreen',function:'convert',view:'pirateFortress',islandId:c.city.islandId,activeTab:'tabCrew',crewPoints:amount,position:fortress.position,templateView:'pirateFortress'},true);
         c.ensure((await fortressView({activeTab:'tabCrew'})).includes('conversionProgressBar'));p.captureConversionPending=false;
         return {...c.changed('הומרו '+amount*10+' נקודות לכידה לכוח צוות'),delayMs:Math.max(120000,(remaining??600)*1000)};
       }
     }
     p.captureConversionPending=false;
     return {...c.wait('משימת פיראטים פעילה; ממתינה לסיומה'),delayMs:Math.max(120000,((remaining??600)+15)*1000)};
   }
   // The same captcha waits for the user's answer however late it comes (user decision,
   // 2026-10-14): no new captcha is requested meanwhile, so a late reply still fits its image. A new
   // image is sent only when the game itself rejects the code. Reminder every 30 minutes.
   if(p.captcha) {
     const remind=!p.captcha.remindedAt || Date.now()-p.captcha.remindedAt>=30*60000;if(remind) p.captcha.remindedAt=Date.now();
     return c.result(remind?'alert':'waiting','ממתינה לפתרון הקפצ׳ה שמוצג בחלון האוטומציה',{alerts:remind?['משימת פיראטים בחשבון "'+String(rule.accountKey).split('|')[0]+'" ממתינה לפתרון קפצ׳ה']:[]});
   }
   const response=await c.request(params,true,{allowRejected:true});
   if(response.includes('function=createCaptcha') || response.includes('js_captchaImage')) {
     const image=captchaImage(response,template);
     if(!image) throw new Error('המשחק דרש קפצ׳ה אך התמונה לא פוענחה');
     p.captcha={image,at:Date.now(),remindedAt:Date.now(),mission};p.stats.captchas=(p.stats.captchas??0)+1;
     return c.result('alert','המשחק דורש קפצ׳ה; יש להזין את הקוד שבתמונה בחלון האוטומציה',{alerts:[]});
   }
   await confirmCapture(response);
   return {...c.changed('משימת פיראטים יצאה · '+Math.round(PIRACY_SECONDS[mission]/60)+' דקות'),cycle:true,delayMs:PIRACY_SECONDS[mission]*1000+15000};
 }
 async function workers(c) {
   const {rule,progress:p}=c,islandId=String(c.city.islandId??'');
   if(!/^\d+$/.test(islandId)) throw new Error('לא זוהה אי העיר');
   const plan=[];
   if(rule.woodPercent!=null) plan.push({key:'resource',label:'עובדי עץ',percent:rule.woodPercent});
   if(rule.luxuryPercent!=null) plan.push({key:'tradegood',label:'עובדי משאב יוקרה',percent:rule.luxuryPercent});
   if(rule.scientistPercent!=null && c.city.position.some(item=>item.building==='academy')) plan.push({key:'academy',label:'מדענים',percent:rule.scientistPercent});
   if(rule.priestPercent!=null && c.city.position.some(item=>item.building==='temple')) plan.push({key:'temple',label:'כמרים',percent:rule.priestPercent});
   if(!plan.length) throw new Error('אין מבנים או משאבים מתאימים בעיר להגדרת העובדים');
   for(const item of plan) {
     const island=['resource','tradegood'].includes(item.key);
     const source=island?await c.request({view:item.key,type:item.key,islandId,cityId:c.rule.cityId,backgroundView:'island',currentIslandId:islandId,ajax:1}):await c.view(item.key);
     const slider=template(source)[{resource:'js_ResourceSlider',tradegood:'js_ResourceSlider',academy:'js_AcademySlider',temple:'js_TempleSlider'}[item.key]]?.slider;
     const max=N(slider?.max_value),over=N(slider?.overcharge)??0;
     if(max===null) throw new Error('נתוני '+item.label+' אינם זמינים');
     const target=item.percent===100&&island&&rule.overcharge?max+over:Math.floor(max*item.percent/100),current=sliderValue(slider);
     if(current===target || p.applied?.[item.key]===target&&current===null) continue;
     if(c.rule.protectGold && (current===null || target>current)) {
       const header=await c.rawHeader(),net=netGold(header),gold=N(header.gold);
       if(net===null||gold===null) return c.wait('נתוני הזהב אינם זמינים; העובדים לא שונו כדי לא לפגוע בזהב');
       if(net<0||gold<=0) return c.result('alert','מאזן הזהב שלילי — לא מוסיפים עובדים או מדענים',{alerts:['הגדרת עובדים נעצרה: מאזן הזהב לשעה שלילי ('+Math.round(net)+')']});
     }
     const position=island?null:c.building(item.key).position;
     const body=item.key==='academy'?{...c.base,action:'IslandScreen',function:'workerPlan',screen:'academy',position,s:target,templateView:'academy'}
       :item.key==='temple'?{...c.base,action:'CityScreen',function:'assignPriests',position,priests:target,templateView:'temple'}
       :{islandId,cityId:c.rule.cityId,type:item.key,screen:item.key,action:'IslandScreen',function:'workerPlan',[item.key==='resource'?'rw':'tw']:target,templateView:item.key,ajax:1};
     await c.request(body,true);
     p.applied={...(p.applied??{}),[item.key]:target};
     const alerts=[];
     if(c.rule.protectGold) {
       try {const net=netGold(await c.rawHeader());if(net!==null&&net<0) alerts.push('אזהרת זהב: לאחר הגדרת '+item.label+' המאזן לשעה הוא '+Math.round(net));} catch { /* The change itself was accepted. */ }
     }
     return {...c.result(alerts.length?'alert':'changed',item.label+' הוגדרו ל־'+target+' ('+item.percent+'%)',{alerts}),cycle:true};
   }
   return c.wait('הגדרות העובדים תואמות את היעד');
 }
 async function shrine(c) {
   const {rule,progress:p}=c,shrineBuilding=c.building('shrineOfOlympus');
   const read=async()=>N(template(await c.request({...c.base,view:'shrineOfOlympus',position:shrineBuilding.position,activeTab:'tabOverview',templateView:'shrineOfOlympus'})).currentFavor);
   if(p.round?.completedAt) {
     if(Date.now()-p.round.completedAt<SHRINE_PERIOD) return {...c.wait('האלים הופעלו; ההפעלה הבאה אחרי 70 שעות'),delayMs:p.round.completedAt+SHRINE_PERIOD-Date.now()};
     p.round=null;
   }
   p.round??={done:[]};
   const pending=rule.gods.filter(god=>!p.round.done.includes(god)),favour=await read();
   if(favour===null) throw new Error('מלאי החסד אינו זמין');
   if(!p.round.done.length && favour<pending.length*100) return {...c.wait('ממתינה ל־'+pending.length*100+' נקודות חסד (יש '+favour+')'),delayMs:3*3600000};
   const god=pending[0];
   await c.request({...c.base,action:'DonateFavorToGod',godId:god,position:shrineBuilding.position,templateView:'shrineOfOlympus',currentTab:'tabOverview'},true);
   const after=await read();c.ensure(after!==null&&after<favour);
   p.round.done.push(god);
   const complete=p.round.done.length===rule.gods.length;
   if(complete) p.round.completedAt=Date.now();
   return {...c.changed('הופעל '+GODS[god]+' · חסד שנותר: '+after),cycle:complete};
 }
 async function station(c) {
   const {rule}=c,type=rule.deployType==='fleet'?'fleet':'army';
   const destination=await ownCity(c,rule.destinationCityId);await c.cityRead();
   if(!/^\d+$/.test(String(destination.islandId??''))) throw new Error('אי היעד אינו זמין');
   const source=html(await c.request({view:'deployment',deploymentType:type,destinationCityId:rule.destinationCityId,backgroundView:'city',currentCityId:rule.cityId,ajax:1}));
   const units=[...source.matchAll(new RegExp('name="cargo_'+type+'_(\\d+)_upkeep"\\s+value="([^"]+)"','g'))].map(match=>({id:match[1],upkeep:match[2]}));
   const amounts=[...source.matchAll(/<div class="amount">(.*?)<\/div>/g)].map(match=>globalThis.IkariamReadInsights.numeric(match[1]));
   const weights=[...source.matchAll(/<div class="weight">(.*?)<\/div>/g)].map(match=>N(match[1]));
   if(!units.length) return c.result('complete','אין יחידות זמינות להצבה בעיר המוצא');
   if(amounts.length<units.length || amounts.some(value=>value===null)) throw new Error('כמויות היחידות לא פוענחו');
   const wanted=Object.fromEntries((rule.entries??[]).map(entry=>[entry.key,entry.target]));
   const payload={action:'transportOperations',function:type==='army'?'deployArmy':'deployFleet',islandId:destination.islandId,destinationCityId:rule.destinationCityId,deploymentType:type,backgroundView:'city',currentCityId:rule.cityId,templateView:'deployment',ajax:1};
   let total=0,weight=0;
   units.forEach((unit,index)=>{
     const quantity=rule.entries?.length?Math.min(wanted[unit.id]??0,amounts[index]):amounts[index];
     payload['cargo_'+type+'_'+unit.id+'_upkeep']=unit.upkeep;payload['cargo_'+type+'_'+unit.id]=quantity;total+=quantity;
     if(type==='army'&&weights[index]>0) weight+=quantity*weights[index];
   });
   if(!total) return c.result('complete','אין יחידות שנבחרו להצבה בעיר המוצא');
   if(type==='army'&&String(destination.islandId)!==String(c.city.islandId)) {
     const capacity=N(commands(await c.request({view:'merchantNavy'})).find(item=>item[1]?.singleTransporterCapacity!==undefined)?.[1]?.singleTransporterCapacity);
     const ships=N((await c.rawHeader()).freeTransporters);
     if(capacity===null||ships===null) throw new Error('קיבולת הספינות אינה זמינה');
     if(Math.ceil(weight/capacity)>ships) return c.wait('אין מספיק ספינות מסחר להעברת כל היחידות');
   }
   const before=bridge.advisorMovements(commands(await c.request({...c.base,view:'militaryAdvisor',oldView:'city',oldBackgroundView:'city'})));
   await c.request(payload,true);
   const after=bridge.advisorMovements(commands(await c.request({...c.base,view:'militaryAdvisor',oldView:'city',oldBackgroundView:'city'})));
   c.ensure(after.some(movement=>!before.some(old=>String(old.event?.id)===String(movement.event?.id))));
   return {...c.changed('נשלחו '+total+' יחידות '+(type==='army'?'צבא':'צי')+' אל '+bridge.decodeUnicodeEscape(destination.name)),cycle:true};
 }
 async function islands(c) {
   const {rule,progress:p}=c;let targets=rule.islandCoords??[];
   if(!targets.length) {
     const match=c.home.match(/relatedCityData:\s*JSON\.parse\('(.+?),\\"additionalInfo/);
     if(!match) throw new Error('רשימת הערים אינה זמינה לזיהוי האיים');
     const related=JSON.parse((match[1]+'}').replace(/\\/g,'').replace(/city_/g,''));
     targets=[...new Set(Object.values(related).filter(item=>item.relationship==='ownCity').map(item=>String(item.coords).match(/(\d+):(\d+)/)?.slice(1,3).join(':')).filter(Boolean))];
   }
   p.islands??={};const alerts=[];
   for(const coords of targets.slice(0,20)) {
     const [x,y]=coords.split(':');
     const island=commands(await c.request({view:'island',xcoord:x,ycoord:y})).find(item=>item[0]==='updateBackgroundData')?.[1];
     if(!island||!Array.isArray(island.cities)) throw new Error('נתוני האי '+coords+' אינם זמינים');
     const now=island.cities.filter(city=>city.type!=='buildplace'&&city.type!=='empty'&&city.id!=null).map(city=>({id:String(city.id),name:bridge.decodeUnicodeEscape(city.name??''),owner:bridge.decodeUnicodeEscape(city.ownerName??city.Name??''),fight:city.infos?.armyAction==='fight'}));
     const before=p.islands[coords],label='['+coords+']';
     if(before) {
       for(const old of before) if(!now.some(city=>city.id===old.id)) alerts.push('העיר '+old.name+' של '+old.owner+' נעלמה מהאי '+label+' — נפתח מקום פנוי');
       for(const city of now) {
         const old=before.find(item=>item.id===city.id);
         if(!old) alerts.push(city.owner+' ייסד עיר חדשה '+city.name+' באי '+label);
         else if(rule.watchFights&&city.fight!==old.fight) alerts.push((city.fight?'התחיל קרב':'הסתיים קרב')+' בעיר '+city.name+' של '+city.owner+' באי '+label);
       }
     }
     p.islands[coords]=now;
   }
   return c.result(alerts.length?'alert':'waiting',alerts.join('\n')||'נסרקו '+Math.min(targets.length,20)+' איים; לא זוהו שינויים',{alerts});
 }
 async function reorganize(c) {
   const template=await ownCity(c,c.rule.templateCityId);await c.cityRead();
   const moves=reorganizeMoves(template,c.city);
   if(!moves.length) return c.result('complete','סידור המבנים כבר תואם לעיר התבנית');
   await c.request({view:'saveCityBuildingsPositions',cityId:c.rule.cityId,backgroundView:'city',currentCityId:c.rule.cityId,ajax:1});
   await sleep(2000+1000*Math.min(moves.length,10));
   const payload={action:'SaveBuildingPositions',backgroundView:'city',currentCityId:c.rule.cityId,templateView:'saveCityBuildingsPositions',ajax:1,cityId:c.rule.cityId};
   moves.forEach(([from,to],index)=>{payload['moves['+index+'][from]']=from;payload['moves['+index+'][to]']=to;});
   await c.request(payload,true);
   await c.cityRead();c.ensure(reorganizeMoves(template,c.city).length<moves.length);
   return {...c.changed('בוצעו '+moves.length+' החלפות מיקום לפי עיר התבנית'),cycle:true};
 }
 async function donate(c) {
   const {rule}=c,islandId=String(c.city.islandId??'');
   if(!/^\d+$/.test(islandId)) throw new Error('לא זוהה אי העיר');
   const island=commands(await c.request({view:'island',islandId})).find(item=>item[0]==='updateBackgroundData')?.[1];
   const good=N(island?.tradegood);if(String(island?.id)!==islandId||good===null) throw new Error('סוג משאב היוקרה באי אינו זמין');
   const read=async type=>{
     const response=commands(await c.request({view:type,type:type==='resource'?'resource':good,islandId,backgroundView:'island',currentIslandId:islandId,ajax:1}));
     const data=response.find(item=>item[1]?.backgroundData)?.[1]?.backgroundData;
     const view=response.find(item=>item[0]==='changeView')?.[1]?.[1]??'';
     const wood=[...String(view).matchAll(/<li class="wood">(.*?)<\/li>/g)].map(match=>globalThis.IkariamReadInsights.numeric(match[1]));
     return {upgrading:N(data?.[type+'EndUpgradeTime'])>0,needed:wood[0]??null,donated:wood[1]??null};
   };
   const resource=await read('resource'),tradegood=rule.donateTarget==='resource'?null:await read('tradegood');
   const choice=rule.donateTarget==='tradegood'?'tradegood':rule.donateTarget==='resource'?'resource':!resource.upgrading?'resource':'tradegood';
   const info=choice==='resource'?resource:tradegood;
   if(info.upgrading) return c.wait('המכרה נמצא בשדרוג; ממתינה לסיום לפני תרומה');
   if(info.donated===null) throw new Error('נתוני התרומה באי אינם זמינים');
   const amount=Math.min(rule.donateAmount,Math.max(0,c.stock.wood-c.reserve));
   if(amount<=0) return c.wait('אין עץ פנוי לתרומה מעל המלאי השמור');
   await c.cityRead();
   await c.request({islandId,type:choice,action:'IslandScreen',function:'donate',donation:amount,backgroundView:'island',templateView:'resource',ajax:1},true);
   const after=await read(choice);c.ensure(after.donated!==null&&after.donated>info.donated);
   return {...c.changed('נתרמו '+amount+' עץ ל'+(choice==='resource'?'מנסרה':'מכרה משאב היוקרה')+' באי'),cycle:true};
 }
 // Ikabot buyResources / sellResources (marketplace, branch office). One trade per check:
 // buy — the cheapest offer at or below the price cap, until the city holds the target amount,
 // never spending gold below the gold reserve; sell — the best buy-offer at or above the price
 // floor, never below the amount kept in the city. Goods travel on the account's merchant ships.
 const MARKET_RESOURCES=['wood','wine','marble','crystal','sulfur'];
 const marketSearch=resource=>resource==='wood'?'resource':String(MARKET_RESOURCES.indexOf(resource));
 function marketOffers(source) {
   const text=html(source),offers=[];
   for(const [,row] of text.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/g)) {
     const place=row.match(/<td class="short_text80">(.*?)<br\s*\/?>\s*\((.*?)\)/),amount=row.match(/<div class="tooltip"[^>]*>(\d[^<]*)<\/div>/),price=row.match(/<td style="white-space:nowrap;">(\d+)/);
     const link=row.match(/view=takeOffer&(?:amp;)?destinationCityId=(\d+)&(?:amp;)?oldView=branchOffice&(?:amp;)?activeTab=bargain&(?:amp;)?cityId=(\d+)&(?:amp;)?position=(\d+)&(?:amp;)?type=(\d+)&(?:amp;)?resource=(\w+)/);
     if(!place||!amount||!price||!link) continue;
     const units=Number(String(amount[1]).replace(/\D/g,''));
     if(!Number.isSafeInteger(units)||units<=0) continue;
     offers.push({city:place[1].replace(/<[^>]*>/g,'').trim(),player:place[2].replace(/<[^>]*>/g,'').trim(),amount:units,price:Number(price[1]),destinationCityId:link[1],cityId:link[2],position:link[3],type:link[4],resource:link[5]});
   }
   return offers;
 }
 async function market(c) {
   const {rule,progress:p}=c,resource=rule.marketResource,office=c.building('branchOffice');
   if(!MARKET_RESOURCES.includes(resource)) throw new Error('משאב המסחר אינו תקין');
   const buying=rule.marketMode==='buy',name={wood:'עץ',wine:'יין',marble:'שיש',crystal:'קריסטל',sulfur:'גופרית'}[resource];
   const stock=c.stock[resource],header=await c.rawHeader(),gold=N(header.gold),ships=N(header.freeTransporters);
   const capacity=N(commands(await c.request({view:'merchantNavy'})).find(item=>item[1]?.singleTransporterCapacity!==undefined)?.[1]?.singleTransporterCapacity);
   if(gold===null||ships===null||capacity===null||capacity<=0) throw new Error('הזהב, הספינות או קיבולת הספינה אינם זמינים');
   const want=buying?rule.marketTarget-stock:stock-rule.marketTarget;
   if(want<=0) return {...c.wait(buying?'במלאי כבר '+stock.toLocaleString('he-IL')+' '+name+' — היעד הושג':'אין '+name+' מעל הכמות השמורה למכירה'),idle:true};
   if(ships<=0) return c.wait('ממתינה לספינת מסחר פנויה');
   const range=Math.max(0,...[...html(await c.request({...c.base,view:'branchOffice',position:office.position})).matchAll(/<option[^>]*>(\d+)<\/option>/g)].map(match=>Number(match[1])));
   const offers=marketOffers(await c.request({...c.base,view:'branchOffice',position:office.position,activeTab:'bargain',type:buying?444:333,searchResource:marketSearch(resource),range,templateView:'branchOffice',currentTab:'bargain'}));
   const fit=offers.filter(offer=>buying?offer.price<=rule.marketPrice:offer.price>=rule.marketPrice).sort((a,b)=>buying?a.price-b.price:b.price-a.price);
   p.market={at:Date.now(),offers:offers.length,best:fit[0]?{price:fit[0].price,amount:fit[0].amount,player:fit[0].player}:null};
   if(!fit.length) return {...c.wait('אין בשוק הצעה '+(buying?'במחיר עד ':'במחיר של לפחות ')+rule.marketPrice+' זהב ל־'+name+' (נבדקו '+offers.length+' הצעות)'),delayMs:30*60000};
   const offer=fit[0];
   let amount=Math.min(want,offer.amount,ships*capacity);
   if(buying) {
     const free=globalThis.IkariamReadInsights.parseResourceCapacities(c.home)?.[resource];
     if(Number.isFinite(free)) amount=Math.min(amount,Math.max(0,free-stock));
     amount=Math.min(amount,Math.floor((gold-rule.goldReserve)/offer.price));
     if(amount<=0) return c.wait('אין מקום במחסן או זהב מעל השמור לקנייה');
   }
   if(amount<=0) return c.wait('אין כמות לסחור בה');
   const transporters=Math.ceil(amount/capacity);
   const take=String(await c.request({view:'takeOffer',destinationCityId:offer.destinationCityId,oldView:'branchOffice',activeTab:'bargain',cityId:offer.cityId,position:offer.position,type:offer.type,resource:offer.resource,backgroundView:'city',currentCityId:offer.cityId,templateView:'branchOffice',ajax:1}));
   const fields={};
   for(const [,key,value] of take.matchAll(/["']?(resourcePrice|tradegood\dPrice)["']?\s*[:=]\s*["']?(\d+)/g)) fields[key]=Number(value);
   const cargo=resource==='wood'?'cargo_resource':'cargo_tradegood'+MARKET_RESOURCES.indexOf(resource);
   const payload={action:'transportOperations',function:buying?'buyGoodsAtAnotherBranchOffice':'sellGoodsAtAnotherBranchOffice',cityId:offer.cityId,destinationCityId:offer.destinationCityId,oldView:'branchOffice',position:office.position,
     avatar2Name:offer.player,city2Name:offer.city,type:buying?Number(offer.type):'333',activeTab:'bargain',transportDisplayPrice:0,premiumTransporter:0,normalTransportersMax:ships,capacity:5,max_capacity:5,jetPropulsion:0,transporters,
     backgroundView:'city',currentCityId:offer.cityId,templateView:'takeOffer',currentTab:'bargain',cargo_resource:0,...Object.fromEntries([1,2,3,4].map(index=>['cargo_tradegood'+index,0])),...fields,[cargo]:amount};
   if(!buying) payload[resource==='wood'?'resourcePrice':'tradegood'+MARKET_RESOURCES.indexOf(resource)+'Price']=offer.price;
   await c.request(payload,true);
   // The trade went out when ships left (and, for a purchase, the gold was paid).
   const after=await c.rawHeader();
   c.ensure(N(after.freeTransporters)<ships||buying&&N(after.gold)<gold);
   p.trades=[{at:Date.now(),mode:rule.marketMode,amount,price:offer.price,player:offer.player},...(p.trades??[])].slice(0,20);
   return {...c.changed((buying?'נקנו ':'נמכרו ')+amount.toLocaleString('he-IL')+' '+name+' ב־'+offer.price+' זהב ליחידה '+(buying?'מ':'ל')+offer.player+' · '+(amount*offer.price).toLocaleString('he-IL')+' זהב'),cycle:true};
 }
 // Ikabot consolidateResources: one resource from every other city of the account into this
 // city, one shipment per check through the shared shipping adapter, keeping the amount the user
 // chose in each source city and counting cargo already on its way.
 async function consolidate(c) {
   const {rule}=c,resource=rule.marketResource;
   if(!MARKET_RESOURCES.includes(resource)) throw new Error('המשאב לאיחוד אינו תקין');
   const movements=bridge.advisorMovements(commands(await c.request({...c.base,view:'militaryAdvisor',oldView:'city',oldBackgroundView:'city'})))
     .map(m=>({...m,origin:m.origin?{...m.origin,name:bridge.decodeUnicodeEscape(m.origin.name),avatarName:bridge.decodeUnicodeEscape(m.origin.avatarName)}:m.origin,target:m.target?{...m.target,name:bridge.decodeUnicodeEscape(m.target.name),avatarName:bridge.decodeUnicodeEscape(m.target.avatarName)}:m.target}));
   const snapshot=await bridge.collectAccountSnapshot(false);
   if(snapshot.ownerName!==c.initial.ownerName) throw new Error('החשבון השתנה במהלך האיחוד');
   const reservations=globalThis.IkariamAccountPolicy.cargoReservations(snapshot.cities,movements,c.initial.ownerName);
   const here=snapshot.cities.find(city=>String(city.id)===String(rule.cityId));
   const free=here?.resourceCapacities?.[resource]!=null?here.resourceCapacities[resource]-(here.resources?.[resource]??0)-(reservations.incoming[rule.cityId]?.[resource]??0):null;
   if(free!==null&&free<=0) return {...c.wait('המחסן בעיר היעד מלא'),idle:true};
   const surplus=city=>(city.resources?.[resource]??0)-(reservations.outgoing[city.id]?.[resource]??0)-rule.marketTarget;
   const donor=snapshot.cities.filter(city=>String(city.id)!==String(rule.cityId)&&surplus(city)>=500).sort((a,b)=>surplus(b)-surplus(a))[0];
   if(!donor) return {...c.result('complete','האיחוד הושלם: אין עוד עודפים מעל הכמות השמורה בערים האחרות'),idle:true};
   c.markExternalSubmitted();
   const amount=Math.floor(Math.min(surplus(donor),free??Infinity));
   const result=await bridge.executeAutomationTransport({originCityId:donor.id,destinationCityId:rule.cityId,resource,sendMode:'reserve',quantity:rule.marketTarget,remaining:amount,intervalMinutes:2,maxCycles:1,accountKey:rule.accountKey,gameAutomationId:rule.id,gameOperationId:rule.inFlight});
   return c.result(result.status==='sent'?'changed':'waiting',result.message,{cycle:false});
 }
 async function step(c) {
   return {pirates,workers,shrine,station,islands,reorganize,donate,market,consolidate}[c.rule.kind](c);
 }
 async function catalog(c) {
   if(c.rule.kind==='station') {
     const type=c.rule.deployType==='fleet'?'fleet':'army';
     const military=await c.request({...c.base,view:'cityMilitary',activeTab:type==='army'?'tabUnits':'tabShips',currentTab:'multiTab1'});
     let counts={};try {counts=armyCounts(military);} catch {counts={};}
     return Object.entries(counts).filter(([,count])=>count>0).map(([id,count])=>({key:id,label:id,level:count,next:count}));
   }
   if(c.rule.kind==='pirates') c.building('pirateFortress');
   if(c.rule.kind==='shrine') c.building('shrineOfOlympus');
   return [];
 }
 // vacationMode.activateVacationMode: explicit user command only, never a rule.
 async function vacation(accountKey) {
   const page=await bridge.resolveCurrentPage();
   if(!page.found || [page.ownerName,page.mundo,page.servidor].join('|')!==accountKey || !/^\d+$/.test(page.cityId??'')) throw new Error('החשבון המחובר אינו תואם');
   const home=await (await (globalThis.IkariamPageFetch??fetch)('/index.php?'+new URLSearchParams({view:'city',cityId:page.cityId}),{credentials:'same-origin',redirect:'error',signal:AbortSignal.timeout(15000)})).text();
   const token=home.match(/actionRequest"?:\s*"([^"]+)"/)?.[1];if(!token) throw new Error('לא נמצא טוקן פעולה');
   await sleep(550);
   const response=await (globalThis.IkariamPageFetch??fetch)('/index.php?'+new URLSearchParams({action:'Options',function:'activateVacationMode',actionRequest:token,backgroundView:'city',currentCityId:page.cityId,templateView:'options_umod_confirm'}),{method:'POST',body:'',headers:{'Content-Type':'application/x-www-form-urlencoded'},credentials:'same-origin',signal:AbortSignal.timeout(15000)}).catch(()=>null);
   return {sent:true,status:response?.status??null,message:'בקשת מצב חופשה נשלחה למשחק. בדוק במשחק שהמצב הופעל.'};
 }
 return {step,catalog,vacation,raidProbe};
}
globalThis.IkariamGameAutomationExtras={bestPirateMission,KINDS,READ_ONLY,PIRACY_LEVEL,PIRACY_SECONDS,GODS,reorganizeMoves,netGold,createExtras};
})();

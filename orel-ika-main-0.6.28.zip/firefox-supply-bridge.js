// Firefox reader of the local supply bridge (docs/OPERA_FIREFOX_SUPPLY_BRIDGE.md, contract v1,
// 2026-10-21). Opera publishes the main account's shortages per city; Firefox reads them with its
// consumerKey, validates every field (and the revision hash), and acknowledges the exact revision
// with every demand id so Opera can show a current read. Observation only: nothing here reserves,
// plans or sends a shipment — the bridge itself refuses claims and shipments.
export const BRIDGE_URL = 'http://127.0.0.1:18746', BRIDGE_ORIGINS = ['http://127.0.0.1/*'];
export const FF_BRIDGE_CONFIG = 'firefox-supply-bridge-v1', FF_BRIDGE_STATUS = 'firefox-supply-bridge-status-v1';
const RESOURCES = ['wood', 'marble', 'wine', 'crystal', 'sulfur'], PURPOSES = ['construction', 'wine'], LIFETIMES = [600000, 1800000, 3600000]; // Observe: ten minutes; allocation scans: an hour (user report, 2026-10-23: an Opera round now takes over 30 minutes).
const fail = message => { throw new Error(message); };
const hex = async text => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)))].map(byte => byte.toString(16).padStart(2, '0')).join('');

// The bridge's answer to GET /v1/demands: {schema, mode, dispatchEnabled, observation|null}.
// Returns the observation (or null when the bridge has no valid one); anything off is refused.
// Optional supply timing per demand (Codex, be661a4): kept for the planner, checked for shape only;
// its absence is "unknown", never a reason to drop or re-plan a claim. Dates are ms UTC or null.
const DATE = value => value === null || Number.isSafeInteger(value) && value > 0;
function timingOf(value, total) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) fail('נתוני התזמון של חוסר אינם תקינים');
  if (!DATE(value.neededAt) || !['critical-wine', 'construction', 'wine-balance'].includes(value.priority) || !['wine-depletion', 'game-queue', 'queue-estimate', 'unknown'].includes(value.basis) || value.travelEstimate !== null) fail('נתוני התזמון של חוסר אינם תקינים');
  const external = Object.hasOwn(value, 'externalNeededAt');
  if (external && !DATE(value.externalNeededAt)) fail('מועד הצורך החיצוני אינו תקין');
  if (!Array.isArray(value.steps) || value.steps.length > 80) fail('שלבי התזמון אינם תקינים');
  let sum = 0;
  const steps = value.steps.map(step => {
    if (!step || typeof step.building !== 'string' || !Number.isSafeInteger(step.level) || !Number.isSafeInteger(step.amount) || step.amount <= 0 || step.amount % 500 || !DATE(step.neededAt) || typeof step.estimated !== 'boolean') fail('שלב תזמון לא תקין');
    if (external && !(Number.isSafeInteger(step.externalAmount) && step.externalAmount >= 0 && step.externalAmount <= step.amount)) fail('כמות חיצונית בשלב אינה תקינה');
    sum += step.amount;
    return { building: step.building, level: step.level, amount: step.amount, ...(external ? { externalAmount: step.externalAmount } : {}), neededAt: step.neededAt, estimated: step.estimated, source: step.source, costSource: step.costSource };
  });
  if (sum > total || !Number.isSafeInteger(value.unmappedAmount) || value.unmappedAmount !== total - sum) fail('כמויות התזמון אינן תואמות את החוסר');
  return { neededAt: value.neededAt, ...(external ? { externalNeededAt: value.externalNeededAt, internalPlannedAmount: value.internalPlannedAmount } : {}), priority: value.priority, basis: value.basis, steps, unmappedAmount: value.unmappedAmount };
}
// Schema 2 (the allocation pilot, proposed in docs/SUPPLY_ALLOCATION_PROTOCOL_DRAFT.md) adds per city
// {name, playerName, islandId, x, y} and a claimable amount per demand; its revision is taken as the
// SHA-256 of the observation exactly as served without the revision field (to confirm with Codex).
export async function parseDemands(body, now = Date.now()) {
  const v2 = body?.schema === 2;
  if (v2 ? !['observe', 'pilot', 'dispatch'].includes(body.mode) : body?.schema !== 1 || body.mode !== 'observe' || body.dispatchEnabled !== false) fail('תשובת השירות אינה במבנה מוכר (schema 1 observe / schema 2)');
  const value = body.observation;
  if (value === null) return null;
  if (!value || value.schema !== body.schema || value.mode !== body.mode) fail('תצפית לא תקינה');
  if (typeof value.accountKey !== 'string' || !/^.{1,100}\|\d{1,5}\|[a-z]{2,5}$/.test(value.accountKey)) fail('מזהה החשבון הראשי אינו תקין');
  if (!Number.isSafeInteger(value.scannedAt) || value.scannedAt > now + 30000) fail('זמן הסריקה אינו תקין');
  if (!LIFETIMES.includes(value.expiresAt - value.scannedAt)) fail('תוקף התצפית אינו תואם את זמן הסריקה');
  if (value.expiresAt <= now) fail('התצפית פגה');
  if (typeof value.revision !== 'string' || !/^[a-f0-9]{64}$/.test(value.revision)) fail('גרסת התצפית אינה תקינה');
  if (!Array.isArray(value.demands) || value.demands.length > 500) fail('רשימת החוסרים אינה תקינה');
  const ids = new Set(), pairs = new Set();
  const demands = value.demands.map(item => {
    if (!item || typeof item.id !== 'string' || !/^[a-f0-9]{32}$/.test(item.id) || ids.has(item.id)) fail('מזהה חוסר חסר או כפול');
    if (typeof item.cityId !== 'string' || !/^\d{1,12}$/.test(item.cityId) || !RESOURCES.includes(item.resource) || !PURPOSES.includes(item.purpose)) fail('פריט חוסר לא תקין');
    if (!Number.isSafeInteger(item.amount) || item.amount <= 0 || item.amount > 100000000 || item.amount % 500) fail('כמות חוסר לא תקינה');
    const pair = item.cityId + ':' + item.resource;
    if (pairs.has(pair)) fail('חוסר כפול לאותה עיר ומשאב');
    ids.add(item.id);pairs.add(pair);
    if (v2 && !(Number.isSafeInteger(item.claimable) && item.claimable >= 0 && item.claimable <= item.amount)) fail('כמות פנויה להקצאה אינה תקינה');
    return { id: item.id, cityId: item.cityId, resource: item.resource, amount: item.amount, purpose: item.purpose,
      ...(v2 ? { claimable: item.claimable, ...(Number.isSafeInteger(item.externalEligible) ? { externalEligible: item.externalEligible } : {}), ...(Number.isSafeInteger(item.capacityAvailable) ? { capacityAvailable: item.capacityAvailable } : {}), ...(Number.isSafeInteger(item.firstSeenAt) && item.firstSeenAt > 0 ? { firstSeenAt: item.firstSeenAt } : {}), ...(item.timing != null ? { timing: timingOf(item.timing, item.amount) } : {}) } : {}) };
  });
  if (v2) {
    const { revision, ...served } = value;
    if (await hex(JSON.stringify(served)) !== revision) fail('גרסת התצפית אינה תואמת את תוכנה');
    const cities = {};
    for (const [cityId, city] of Object.entries(value.cities ?? {})) {
      if (!/^\d{1,12}$/.test(cityId) || !city || typeof city !== 'object') fail('פרטי עיר יעד לא תקינים');
      const text = field => typeof city[field] === 'string' && city[field].length <= 100 ? city[field] : null, int = field => Number.isSafeInteger(city[field]) ? city[field] : null;
      cities[cityId] = { name: text('name'), playerName: text('playerName'), islandName: text('islandName'), islandId: city.islandId == null ? null : String(city.islandId), x: int('x'), y: int('y') };
    }
    return { schema: 2, mode: value.mode, accountKey: value.accountKey, scannedAt: value.scannedAt, expiresAt: value.expiresAt, demands, cities, revision };
  }
  const normal = { schema: 1, mode: 'observe', accountKey: value.accountKey, scannedAt: value.scannedAt, expiresAt: value.expiresAt, demands };
  if (await hex(JSON.stringify(normal)) !== value.revision) fail('גרסת התצפית אינה תואמת את תוכנה');
  return { ...normal, revision: value.revision };
}
// The shortages of every city of the main account, for the panel.
export function byCity(observation) {
  const cities = {};
  for (const item of observation?.demands ?? []) (cities[item.cityId] ??= { cityId: item.cityId, items: [] }).items.push(item);
  return Object.values(cities);
}

export function createFirefoxSupplyBridge(api, { fetcher = (...args) => fetch(...args), now = () => Date.now() } = {}) {
  if (/\bmain\b/.test(api.runtime?.getManifest?.()?.version_name ?? '')) return null;
  let busy = false;
  const request = (path, key, init = {}) => fetcher(BRIDGE_URL + path, { ...init, headers: { Authorization: 'Bearer ' + key, ...(init.headers ?? {}) }, cache: 'no-store', signal: AbortSignal.timeout(5000) });
  async function tick() {
    if (busy) return;busy = true;
    const status = { at: now(), ok: false };
    try {
      const config = (await api.storage.local.get(FF_BRIDGE_CONFIG))[FF_BRIDGE_CONFIG];
      if (!config?.enabled) return;
      if (!/^[a-f0-9]{64}$/.test(config.key ?? '')) throw new Error('המפתח אינו תקין — יש להדביק את consumerKey');
      if (!await api.permissions.contains({ origins: BRIDGE_ORIGINS })) throw new Error('נדרשת הרשאה לחיבור המקומי (127.0.0.1)');
      let response;
      try { response = await request('/v1/demands', config.key); } catch { throw new Error('שירות התיאום המקומי אינו פועל — יש להריץ את start.ps1'); }
      if (response.status === 401) throw new Error('השירות דחה את המפתח (401) — יש לבדוק את consumerKey');
      if (!response.ok) throw new Error('השירות החזיר שגיאה (' + response.status + ')');
      const observation = await parseDemands(await response.json(), now());
      Object.assign(status, { connected: true, observation, readAt: now() });
      if (!observation) { Object.assign(status, { ok: true, message: 'מחובר · אין תצפית תקפה מאופרה כרגע (אינה אישור למסירה או לביטול)' });return; }
      // Every id exactly once, also an empty list: Opera shows the read as current only after this.
      const ack = await request('/v1/consumer-ack', config.key, { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ revision: observation.revision, scannedAt: observation.scannedAt, demandIds: observation.demands.map(item => item.id) }) });
      if (!ack.ok) throw new Error(ack.status === 409 ? 'התצפית התחלפה בזמן הקריאה — תיקרא שוב בבדיקה הבאה' : 'אישור הקליטה נדחה (' + ack.status + ')');
      Object.assign(status, { ok: true, ackAt: now(), ackRevision: observation.revision, message: 'מחובר · נקראו ואושרו ' + observation.demands.length + ' חוסרים · קריאה בלבד, אין שליחה' });
    } catch (error) {
      status.message = /[א-ת]/.test(error.message ?? '') ? error.message : 'הקריאה מהשירות נכשלה';
    } finally {
      const config = (await api.storage.local.get(FF_BRIDGE_CONFIG))[FF_BRIDGE_CONFIG];
      if (config?.enabled) {
        // A failed read keeps the last observation only as history, marked as not current.
        const previous = (await api.storage.local.get(FF_BRIDGE_STATUS))[FF_BRIDGE_STATUS];
        await api.storage.local.set({ [FF_BRIDGE_STATUS]: status.ok ? status : { ...status, observation: null, last: previous?.observation ?? previous?.last ?? null } });
      }
      busy = false;
    }
  }
  return { tick };
}
// Every 30 seconds while switched on, and at once when the switch or the key changes.
export function startFirefoxSupplyBridge(api) {
  const bridge = createFirefoxSupplyBridge(api);
  if (!bridge) return null;
  api.alarms.create('firefox-supply-bridge', { periodInMinutes: 0.5 });
  api.alarms.onAlarm.addListener(alarm => { if (alarm.name === 'firefox-supply-bridge') void bridge.tick().catch(() => {}); });
  api.storage.onChanged?.addListener((changes, area) => { if (area === 'local' && changes[FF_BRIDGE_CONFIG]) void bridge.tick().catch(() => {}); });
  return bridge;
}

// Overnight watchdog (every five minutes). A game tab that no longer shows a signed-in game
// page — an error page after maintenance or a short network drop — is reloaded like F5, up to
// three times; after that a Telegram message says which account needs a new login.
// No internet (user decision, 2026-10-28: the connection or the VPN drops now and then): while the game server
// cannot be reached nothing is reloaded and no attempt is counted; the check runs every minute until it is back,
// and then the tabs are reloaded at once. A tab still not answering is reloaded again every fifteen minutes —
// never given up for good.
import { reloadGameTab } from "./tab-refresh.js";

const KEY='tab-watchdog-v1',GAME=/^https:\/\/s\d+-\w+\.ikariam\.gameforge\.com\//,LOBBY=/^https:\/\/lobby\.ikariam\.gameforge\.com\/[a-z]{2}_[A-Z]{2}\/hub/;
// The game's lobby, as the page itself writes its "last played" button (any language the lobby shows).
const LAST_PLAYED=['שיחקת לאחרונה','Last played','Zuletzt gespielt'];
// Runs in the lobby page: the "last played" button — a link is returned so the tab itself opens it (a click
// from the extension is no user gesture, and a new window could be blocked); a plain button is clicked.
function lastPlayed(texts) {
  const node=[...document.querySelectorAll('a, button, [role="button"]')].find(item=>texts.some(text=>(item.textContent??'').includes(text)));
  if(!node) return {found:false,href:null};
  const href=node.tagName==='A'&&/^https:\/\//.test(node.href??'')?node.href:null;
  if(!href) node.click();
  return {found:true,href};
}
// Whether the game server answers at all (any HTTP answer counts; only a network failure means offline).
const reachable=async url=>{try {await fetch(new URL(url).origin+'/',{method:'HEAD',cache:'no-store',redirect:'manual',signal:AbortSignal.timeout(8000)});return true;} catch {return false;}};
export function createTabWatchdog(chrome,{identify,notify,now=()=>Date.now(),every=300000,online=reachable,inPage=(tabId,func,args)=>chrome.scripting.executeScript({target:{tabId},func,args}).then(results=>results?.[0]?.result??null)}) {
  let running=false;
  const read=async()=>({tabs:{},lastRunAt:0,log:[],...((await chrome.storage.local.get(KEY))[KEY]??{})});
  const note=(state,message)=>{state.log=[{time:now(),message},...(state.log??[])].slice(0,200);};
  const send=async(accountKey,text)=>{try {await notify(accountKey??'all',text);} catch { /* No channel configured. */ }};
  const name=(entry,tab)=>entry?.accountKey?.split('|')[0]??tab?.title??'חשבון';
  async function tick() {
    if(running) return;
    running=true;
    try {
      const state=await read();
      if(now()-state.lastRunAt<(state.offlineSince?60000:every)) return;
      state.lastRunAt=now();
      const all=await chrome.tabs.query({}),tabs=all.filter(tab=>GAME.test(tab.url??''));
      // A game tab that fell to the lobby (the session ended: user decision, 2026-10-30): after five minutes there,
      // with the server reachable, its "last played" button is pressed; tried again every ten minutes, and
      // Telegram is told when the button is missing (a login is needed). A lobby tab that never was a game tab
      // is left alone.
      for(const tab of all.filter(tab=>LOBBY.test(tab.url??''))) {
        const entry=state.tabs[tab.id];
        if(!entry?.accountKey) continue;
        entry.lobbySince??=now();
        if(now()-entry.lobbySince<5*60000||now()-(entry.lobbyTriedAt??0)<10*60000) continue;
        if(!(await online(tab.url))) continue;
        entry.lobbyTriedAt=now();
        let answer=null;try {answer=await inPage(tab.id,lastPlayed,[LAST_PLAYED]);} catch { /* The page is still loading. */ }
        if(answer?.href) {try {await chrome.tabs.update(tab.id,{url:answer.href});} catch { /* Tab closed meanwhile. */ }}
        if(answer?.found) note(state,name(entry,tab)+' נפל ללובי — נלחץ "שיחקת לאחרונה"');
        else if(!entry.lobbyAlerted) {entry.lobbyAlerted=true;note(state,name(entry,tab)+' בלובי בלי "שיחקת לאחרונה" — נשלחה הודעה');await send(entry.accountKey,'⚠️ '+name(entry,tab)+' נפל ללובי ולא נמצא "שיחקת לאחרונה" — צריך להתחבר מחדש.');}
      }
      let checked=null;
      for(const tab of tabs) {
        const entry=state.tabs[tab.id]??={fails:0};
        const accountKey=await identify(tab).catch(()=>null);
        if(accountKey) {
          if(entry.alerted||entry.fails) note(state,accountKey.split('|')[0]+' חזר לעבוד'+(entry.fails?' אחרי '+entry.fails+' רענונים':''));
          if(entry.alerted) await send(accountKey,'✅ '+accountKey.split('|')[0]+' מחובר שוב.');
          // A tab whose read queue is held by one job for over ten minutes is stuck: reload it
          // (at most every half hour). Runs cut off this way are released and read again.
          let health=null;try {health=await Promise.race([chrome.tabs.sendMessage(tab.id,{type:'IKARIAM_AGENT_QUEUE_HEALTH'}),new Promise(resolve=>setTimeout(()=>resolve(null),5000))]);} catch { /* Older page. */ }
          const stuckSince=health?.runningSince??null,lastStuck=entry.stuckReloadAt??0;
          if(stuckSince&&now()-stuckSince>10*60000&&now()-lastStuck>30*60000) {
            note(state,accountKey.split('|')[0]+' נתקע ('+(health.label??'קריאה')+' יותר מ־10 דקות) — הלשונית נטענה מחדש');
            state.tabs[tab.id]={fails:0,accountKey,stuckReloadAt:now()};
            try {await reloadGameTab(chrome,tab);} catch { /* Tab closed meanwhile. */ }
            continue;
          }
          state.tabs[tab.id]={fails:0,accountKey,stuckReloadAt:lastStuck||undefined};
          continue;
        }
        checked??=await online(tab.url);
        if(!checked) {if(!state.offlineSince) {state.offlineSince=now();note(state,'אין חיבור לשרת המשחק — הלשוניות יירעננו כשהחיבור יחזור');}continue;}
        // Back online: every tab still on an error page is reloaded at once, its count started afresh.
        if(state.offlineSince&&!entry.backAt) {entry.fails=0;entry.alerted=false;entry.backAt=now();}
        entry.fails++;
        if(entry.fails<=3||(entry.fails-3)%3===0) {note(state,name(entry,tab)+' לא ענה — רענון '+entry.fails+'/3');try {await reloadGameTab(chrome,tab);} catch { /* Tab closed meanwhile. */ }}
        else if(!entry.alerted) {
          entry.alerted=true;note(state,name(entry,tab)+' מנותק — נשלחה הודעה לטלגרם');
          await send(entry.accountKey,'⚠️ '+name(entry,tab)+' מנותק — הלשונית לא חזרה אחרי 3 רענונים. צריך להתחבר מחדש דרך הלובי.');
        }
      }
      if(checked!==false&&state.offlineSince) {note(state,'החיבור חזר');delete state.offlineSince;for(const entry of Object.values(state.tabs)) delete entry.backAt;}
      // A tab in the lobby keeps its entry (see above); a game tab drops the lobby marks.
      for(const tab of tabs) if(state.tabs[tab.id]) {delete state.tabs[tab.id].lobbySince;delete state.tabs[tab.id].lobbyTriedAt;delete state.tabs[tab.id].lobbyAlerted;}
      for(const id of Object.keys(state.tabs)) if(!tabs.some(tab=>String(tab.id)===id)&&!all.some(tab=>String(tab.id)===id&&LOBBY.test(tab.url??''))) delete state.tabs[id];
      await chrome.storage.local.set({[KEY]:state});
    } finally {running=false;}
  }
  return {tick};
}

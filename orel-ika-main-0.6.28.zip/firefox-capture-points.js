// Capture points for Opera's raids (user decision, 2026-10-28): daily at 18:01 every Firefox account's capture
// points ("נקודות לכידה" in its pirate fortress) are read and handed to the local coordination service — the
// account's name and the number only. An account Opera asks for meanwhile (added to its raid list during a
// round) is read at once. An account whose tab is closed or busy is simply left out; Opera puts it last.
import { BRIDGE_URL, BRIDGE_ORIGINS, FF_BRIDGE_CONFIG } from './firefox-supply-bridge.js';

export const CAPTURE_STATE = 'firefox-capture-points-v1';
// The latest 18:01 at or before the moment (local time).
export function dailyCycle(now) {
  const moment = new Date(now);moment.setHours(18, 1, 0, 0);
  if (moment.getTime() > now) moment.setDate(moment.getDate() - 1);
  return moment.getTime();
}
export function createFirefoxCapturePoints(api, { findTab, fetcher = (...args) => fetch(...args), now = () => Date.now() } = {}) {
  if (/\bmain\b/.test(api.runtime?.getManifest?.()?.version_name ?? '')) return null;
  let busy = false;
  const call = async (key, path, body) => {
    const response = await fetcher(BRIDGE_URL + path, { method: body ? 'PUT' : 'GET', headers: { Authorization: 'Bearer ' + key, ...(body ? { 'Content-Type': 'application/json' } : {}) }, ...(body ? { body: JSON.stringify(body) } : {}), cache: 'no-store', signal: AbortSignal.timeout(5000) });
    if (!response.ok) throw new Error('שירות התיאום החזיר ' + response.status);
    return response.json();
  };
  const accounts = async () => Object.keys(await api.storage.local.get(null)).filter(key => key.startsWith('account-snapshot-')).map(key => key.slice('account-snapshot-'.length));
  async function readOne(accountKey) {
    const tab = await findTab(accountKey);
    if (!tab?.id) throw new Error('לשונית החשבון סגורה');
    const response = await api.tabs.sendMessage(tab.id, { type: 'IKARIAM_AGENT_CAPTURE_POINTS' });
    if (!response?.ok || !Number.isSafeInteger(response.result?.points)) throw new Error(response?.reason ?? 'קריאת נקודות הלכידה נכשלה');
    return response.result.points;
  }
  async function tick() {
    if (busy) return;busy = true;
    const status = (await api.storage.local.get(CAPTURE_STATE))[CAPTURE_STATE] ?? {};
    try {
      const config = (await api.storage.local.get(FF_BRIDGE_CONFIG))[FF_BRIDGE_CONFIG];
      if (!config?.enabled || !/^[a-f0-9]{64}$/.test(config.key ?? '') || !await api.permissions.contains({ origins: BRIDGE_ORIGINS })) return;
      const keys = await accounts(), byName = new Map(keys.map(key => [key.split('|')[0], key]));
      const cycle = dailyCycle(now());
      if ((status.cycleAt ?? 0) < cycle) {
        const points = {}, failed = {};
        for (const accountKey of keys) { try { points[accountKey.split('|')[0]] = await readOne(accountKey); } catch (error) { failed[accountKey.split('|')[0]] = error.message; } }
        await call(config.key, '/v1/capture-points', { schema: 1, cycleAt: cycle, complete: true, points });
        Object.assign(status, { cycleAt: cycle, readAt: now(), points, failed });
      }
      const requested = ((await call(config.key, '/v1/capture-requests')).names ?? []).filter(name => byName.has(name));
      const points = {};
      for (const name of requested) { try { points[name] = await readOne(byName.get(name)); } catch (error) { (status.failed ??= {})[name] = error.message; } }
      if (Object.keys(points).length) { await call(config.key, '/v1/capture-points', { schema: 1, points });status.points = { ...(status.points ?? {}), ...points }; }
      status.message = null;
    } catch (error) { status.message = /[א-ת]/.test(error.message ?? '') ? error.message : 'הקריאה מהשירות נכשלה'; }
    finally { status.at = now();await api.storage.local.set({ [CAPTURE_STATE]: status });busy = false; }
  }
  return { tick };
}

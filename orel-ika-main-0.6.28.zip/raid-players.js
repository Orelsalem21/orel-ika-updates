// Raid players (main edition, user decision 2026-10-18): the raids panel keeps player names only; the
// cities of each player are read from ikatracker.com, a public tracker of the game's world map, and
// kept per account in pirate-raid-players-v1. The raid picks the city (see raidStep). A city already
// checked in the game keeps its ids while its name and coordinates stay the same.
const KEY = 'pirate-raid-players-v1', MAX = 20, SITE = 'https://ikatracker.com';
// The fixed list's cities, taken on 2026-10-18 from the agent's own reads (user decision): ikatracker
// allows five searches a day without a plan, so the tracker is asked only for players added later or
// on "refresh". Before each raid the city is checked in the game anyway (renamed cities fail there).
const c = (name, x, y) => ({ name, islandName: '', x, y });
export const BUILT_IN = {
  Orakel1: [c('YK1', 52, 36), c('KK1', 51, 35), c('SK1', 52, 35), c('SSK1', 49, 38), c('GK1', 51, 36), c('SSSK1', 49, 38)],
  Orakel2: [c('YK2', 52, 36), c('KK2', 51, 35), c('SK2', 48, 41), c('GK2', 51, 42), c('SSK2', 48, 41), c('KKK2', 51, 35)],
  Orakel3: [c('SK3', 49, 38), c('YK3', 52, 36), c('KK3', 51, 35), c('GK3', 51, 36), c('SSK3', 48, 41), c('KKK3', 56, 34), c('פוליס', 48, 41)],
  Orakel4: [c('YK4-1', 52, 36), c('YK4-2', 52, 36), c('GK4-1', 55, 37), c('GK4-2', 55, 37), c('GK4-3', 55, 37), c('KK-4', 56, 34), c('SK-4', 49, 38)],
  Orakel5: [c('Polis1', 55, 37), c('Polis2 יין', 55, 37), c('Polis3', 55, 37), c('Polis4 קריסטל', 56, 34), c('Polis5', 55, 37), c('Polis6 שיש', 57, 37), c('Polis7 שיש', 57, 37), c('Polis8 שיש', 57, 37), c('Polis9', 55, 37), c('Polis10', 55, 37)],
  Orakel6: [c('YK6', 55, 35), c('SK6', 57, 37), c('GK6', 55, 37), c('KK6', 58, 34)],
  Orakel7: [c('חסות Orel G', 55, 37), c('חסות Orel Y', 52, 36), c('חסות Orel S', 48, 41)],
  Orakel8: [c('חסות Orel 3', 55, 37), c('חסות Orel 4', 55, 37), c('חסות Orel G', 51, 42)],
};
const builtIn = playerName => BUILT_IN[playerName] ? { playerName, cities: BUILT_IN[playerName].map(city => ({ ...city })), source: 'built-in' } : { playerName };
const decode = text => String(text).replace(/&#0?39;|&apos;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');

// The player's cities from the tracker's search page: its copy block lists "N. city — island [x:y] — …"
// under a first line naming the player. Anything else (no such player, several matches) is refused.
export function parsePlayerPage(html, playerName) {
  const block = String(html).match(/<textarea id="playerCopyData"[^>]*>([\s\S]*?)<\/textarea>/)?.[1];
  if (!block) throw new Error('השחקן ' + playerName + ' לא נמצא ב־ikatracker בשרת הזה');
  const lines = decode(block).split(/\r?\n/).map(line => line.trim());
  const name = lines[0].split(' · ')[0].replace(/\s+\[[^\]]*\]$/, '').trim();
  if (name !== playerName) throw new Error('ikatracker החזיר שחקן אחר (' + name + ') במקום ' + playerName);
  const cities = [];
  for (const line of lines) {
    const match = line.match(/^\d+\.\s+(.+?)\s+—\s+(.+?)\s+\[(\d+):(\d+)\]/);
    if (match) cities.push({ name: match[1].trim(), islandName: match[2].trim(), x: Number(match[3]), y: Number(match[4]) });
  }
  if (!cities.length) throw new Error('לא נמצאו ערים לשחקן ' + playerName + ' ב־ikatracker');
  return cities;
}
// Raid order by capture points (user decision, 2026-10-28). ranking: {points: {name: {value, at}}, cycle: {at}}
// as Firefox reported them. First the players Firefox does not read (no capture points), in the list's order;
// then the Firefox accounts read in this cycle, most capture points first; then the Firefox accounts not read in
// it. A player added during a round goes last until Firefox has read it (target.added).
export function raidGroup(target, ranking) {
  const point = ranking?.points?.[target.playerName], cycle = ranking?.cycle?.at ?? 0;
  if (point && point.at >= cycle) return 1;
  if (target.added) return 3;
  return point ? 2 : 0;
}
export function raidOrder(players, ranking) {
  const value = item => ranking?.points?.[item.playerName]?.value ?? 0;
  return players.map((item, index) => ({ item, index, group: raidGroup(item, ranking) }))
    .sort((a, b) => a.group - b.group || (a.group === 1 ? value(b.item) - value(a.item) : 0) || a.index - b.index).map(entry => entry.item);
}
export const serverOf = accountKey => { const [, world, server] = String(accountKey).split('|'); return /^\d+$/.test(world ?? '') && /^[a-z]{2,3}$/.test(server ?? '') ? 's' + world + '-' + server : null; };

export function createRaidPlayers(chrome, { fetch: get = fetch, now = () => Date.now(), sleep = ms => new Promise(resolve => setTimeout(resolve, ms)) } = {}) {
  const read = async () => (await chrome.storage.local.get(KEY))[KEY] ?? {};
  // Reads the given players (default: all of the account's) one after the other and keeps the result.
  async function refresh(accountKey, names) {
    const server = serverOf(accountKey);
    if (!server) throw new Error('השרת של החשבון לא זוהה');
    const wanted = new Set((names ?? []).map(String));
    const list = (await read())[accountKey] ?? [];
    let first = true, limited = false;
    for (const player of list) {
      if (wanted.size && !wanted.has(player.playerName)) continue;
      if (limited) { player.error = 'ממתין למחר: מגבלת החיפושים היומית של ikatracker';player.failedAt = now();continue; }
      if (!first) await sleep(1000);first = false;
      try {
        const response = await get(SITE + '/atlas/search?' + new URLSearchParams({ type: 'player', server, community: '', q: player.playerName }), { signal: AbortSignal.timeout(20000) });
        if (!response.ok) throw new Error('ikatracker לא הגיב (' + response.status + ')');
        const html = await response.text();
        // Five searches a day without a plan: the rest waits for tomorrow, the cities kept so far stay.
        if (/search limit|searches per day|מגבלת החיפושים/i.test(html)) { limited = true; throw new Error('הגעת למגבלת החיפושים היומית של ikatracker (5 ביום); הערים שנשמרו נשארות — אפשר לרענן מחר'); }
        const cities = parsePlayerPage(html, player.playerName);
        // Ids already checked in the game stay with the same city.
        const known = new Map((player.cities ?? []).filter(city => city.cityId).map(city => [city.name + '|' + city.x + ':' + city.y, city]));
        player.cities = cities.map(city => ({ ...city, ...(known.has(city.name + '|' + city.x + ':' + city.y) ? { cityId: known.get(city.name + '|' + city.x + ':' + city.y).cityId, islandId: known.get(city.name + '|' + city.x + ':' + city.y).islandId } : {}) }));
        player.fetchedAt = now();player.error = null;player.source = 'ikatracker';
      } catch (error) { player.error = error.message;player.failedAt = now(); }
    }
    // Saved over the latest list: a player added or removed meanwhile is kept as the user left it.
    const latest = await read(), current = latest[accountKey] ?? [];
    for (const player of list) { const live = current.find(item => item.playerName === player.playerName); if (live) Object.assign(live, { cities: player.cities, fetchedAt: player.fetchedAt, error: player.error, failedAt: player.failedAt, source: player.source }); }
    await chrome.storage.local.set({ [KEY]: { ...latest, [accountKey]: current } });
    return current;
  }
  // A player added while a round runs joins it (user decision, 2026-10-28): last for now, and Firefox is asked
  // for its capture points at once — once they arrive the round puts the player in place.
  async function joinRound(accountKey, playerName) {
    const rounds = (await chrome.storage.local.get('pirate-raids-v1'))['pirate-raids-v1'] ?? {}, round = rounds[accountKey];
    if (!round?.running || !round.smart || round.targets?.some(target => target.playerName === playerName)) return;
    await chrome.storage.local.set({ 'pirate-raids-v1': { ...rounds, [accountKey]: { ...round, targets: [...round.targets, { playerName, added: true }] } } });
    const asked = (await chrome.storage.local.get('main-capture-requests-v1'))['main-capture-requests-v1'] ?? [];
    if (!asked.includes(playerName)) await chrome.storage.local.set({ 'main-capture-requests-v1': [...asked, playerName].slice(-50) });
  }
  async function handle(command) {
    const all = await read(), list = all[command.accountKey] ?? [];
    if (command.operation === 'list') return list;
    if (command.operation === 'seed') {
      if (all[command.accountKey]) return list;
      const seeded = (command.names ?? []).slice(0, MAX).map(playerName => builtIn(String(playerName)));
      await chrome.storage.local.set({ [KEY]: { ...all, [command.accountKey]: seeded } });
      const missing = seeded.filter(item => !item.cities).map(item => item.playerName);
      return missing.length ? refresh(command.accountKey, missing) : (await read())[command.accountKey];
    }
    if (command.operation === 'add') {
      const playerName = String(command.playerName ?? '').trim();
      if (!playerName) throw new Error('יש להקליד שם שחקן');
      if (list.length >= MAX) throw new Error('אפשר לשמור עד ' + MAX + ' שחקנים');
      if (list.some(item => item.playerName === playerName)) throw new Error('השחקן כבר ברשימה');
      await chrome.storage.local.set({ [KEY]: { ...all, [command.accountKey]: [...list, { playerName }] } });
      if (BUILT_IN[playerName]) { await chrome.storage.local.set({ [KEY]: { ...all, [command.accountKey]: [...list, builtIn(playerName)] } });await joinRound(command.accountKey, playerName);return (await read())[command.accountKey]; }
      const players = await refresh(command.accountKey, [playerName]), added = players.find(item => item.playerName === playerName);
      if (added?.error) {
        const next = (await read())[command.accountKey].filter(item => item.playerName !== playerName);
        await chrome.storage.local.set({ [KEY]: { ...(await read()), [command.accountKey]: next } });
        throw new Error(added.error);
      }
      await joinRound(command.accountKey, playerName);
      return players;
    }
    // Added by hand (user decision, 2026-10-27: ikatracker refreshes once a day, so a player who joined today
    // is not there yet): the cities as the user typed them; an existing player gets the typed cities.
    if (command.operation === 'add-manual') {
      const playerName = String(command.playerName ?? '').trim();
      if (!playerName) throw new Error('יש להקליד שם שחקן');
      // A city verified in the game first ("אמת במשחק") arrives with its game ids, which are kept.
      const ids = city => /^\d+$/.test(String(city?.cityId ?? '')) && /^\d+$/.test(String(city?.islandId ?? '')) ? { cityId: String(city.cityId), islandId: String(city.islandId), checkedAt: now(), checkError: null } : {};
      const cities = (command.cities ?? []).map(city => ({ name: String(city?.name ?? '').trim(), islandName: String(city?.islandName ?? '').trim(), x: Number(city?.x), y: Number(city?.y), ...ids(city) }))
        .filter(city => city.name && Number.isInteger(city.x) && Number.isInteger(city.y) && city.x > 0 && city.y > 0 && city.x <= 100 && city.y <= 100);
      if (!cities.length) throw new Error('יש להקליד לפחות עיר אחת, שורה לכל עיר: שם העיר [x:y]');
      const entry = { playerName, cities, fetchedAt: now(), error: null, source: 'manual' };
      const known = list.find(item => item.playerName === playerName);
      if (!known && list.length >= MAX) throw new Error('אפשר לשמור עד ' + MAX + ' שחקנים');
      // append (the verify form): a city added to a known player joins his cities instead of replacing them.
      const merged = known && command.append ? [...(known.cities ?? []).filter(old => !cities.some(city => city.name === old.name && city.x === old.x && city.y === old.y)), ...cities] : cities;
      const next = known ? list.map(item => item.playerName === playerName ? { ...item, ...entry, cities: merged, source: command.append && item.source !== 'manual' ? item.source : 'manual' } : item) : [...list, entry];
      await chrome.storage.local.set({ [KEY]: { ...all, [command.accountKey]: next } });
      if (!known) await joinRound(command.accountKey, playerName);
      return (await read())[command.accountKey];
    }
    // A target still waiting in the running round, one step up or down (user decision, 2026-10-28: the order
    // can be edited during a round); from then on the round keeps the user's order.
    if (command.operation === 'round-move') {
      const rounds = (await chrome.storage.local.get('pirate-raids-v1'))['pirate-raids-v1'] ?? {}, round = rounds[command.accountKey];
      if (!round?.running) throw new Error('אין סבב פעיל');
      const first = round.index + (round.targets[round.index]?.status === 'sent' ? 1 : 0);
      const index = round.targets.findIndex((target, place) => place >= first && target.playerName === command.playerName), to = index + (Number(command.direction) < 0 ? -1 : 1);
      if (index < 0 || to < first || to >= round.targets.length) return round;
      const targets = [...round.targets];[targets[index], targets[to]] = [targets[to], targets[index]];
      const next = { ...round, targets, manualOrder: true };
      await chrome.storage.local.set({ 'pirate-raids-v1': { ...rounds, [command.accountKey]: next } });
      return next;
    }
    // The raids table's edit mode (user decision, 2026-10-29). "הסר מהסבב הנוכחי": a target leaves the running
    // round (never the one out right now); the player stays in the list for the next rounds.
    if (command.operation === 'round-remove') {
      const rounds = (await chrome.storage.local.get('pirate-raids-v1'))['pirate-raids-v1'] ?? {}, round = rounds[command.accountKey];
      if (!round?.running) throw new Error('אין סבב פעיל');
      const index = round.targets.findIndex(target => target.playerName === command.playerName);
      if (index < 0) return round;
      if (index === round.index && round.targets[index]?.status === 'sent') throw new Error('הפשיטה על ' + command.playerName + ' בדרך עכשיו; אפשר להסיר אותו אחרי שהצוות יחזור');
      const next = { ...round, targets: round.targets.filter((_, place) => place !== index), index: index < round.index ? round.index - 1 : round.index, manualOrder: true };
      await chrome.storage.local.set({ 'pirate-raids-v1': { ...rounds, [command.accountKey]: next } });
      return next;
    }
    // "בדוק יעד מחדש": the player's cities as the user corrected them (name, x, y; a changed city is checked in the
    // game again, an unchanged one keeps its ids), and the target goes next in the running round with nothing
    // left of its skip (user report, 2026-10-29: Forks211 was skipped every time).
    if (command.operation === 'round-retry') {
      const player = list.find(item => item.playerName === command.playerName);
      if (!player) throw new Error('השחקן ' + command.playerName + ' לא ברשימה');
      if (Array.isArray(command.cities)) {
        const cities = command.cities.map(city => ({ name: String(city?.name ?? '').trim(), islandName: String(city?.islandName ?? '').trim(), x: Number(city?.x), y: Number(city?.y) }))
          .filter(city => city.name && Number.isInteger(city.x) && Number.isInteger(city.y) && city.x > 0 && city.y > 0 && city.x <= 100 && city.y <= 100);
        if (!cities.length) throw new Error('יש להשאיר לפחות עיר אחת עם שם ו־X:Y בין 1 ל־100');
        const known = new Map((player.cities ?? []).map(city => [city.name + '|' + city.x + ':' + city.y, city]));
        const kept = cities.map(city => { const old = known.get(city.name + '|' + city.x + ':' + city.y);return old?.cityId && !old.checkError ? { ...city, cityId: old.cityId, islandId: old.islandId, checkedAt: old.checkedAt } : city; });
        await chrome.storage.local.set({ [KEY]: { ...all, [command.accountKey]: list.map(item => item.playerName === command.playerName ? { ...item, cities: kept, error: null, source: 'manual', fetchedAt: now() } : item) } });
      }
      const rounds = (await chrome.storage.local.get('pirate-raids-v1'))['pirate-raids-v1'] ?? {}, round = rounds[command.accountKey];
      if (!round?.running) return { player: (await read())[command.accountKey].find(item => item.playerName === command.playerName), round: round ?? null };
      const first = round.index + (round.targets[round.index]?.status === 'sent' ? 1 : 0), index = round.targets.findIndex(target => target.playerName === command.playerName);
      if (index >= 0 && index === round.index && round.targets[index]?.status === 'sent') throw new Error('הפשיטה על ' + command.playerName + ' בדרך עכשיו');
      const fresh = { playerName: command.playerName, ...(index >= 0 && round.targets[index].added ? { added: true } : {}) };
      const rest = round.targets.filter((_, place) => place !== index), at = index >= 0 && index < first ? first - 1 : first;
      const next = { ...round, targets: [...rest.slice(0, at), fresh, ...rest.slice(at)], index: index >= 0 && index < round.index ? round.index - 1 : round.index, manualOrder: true };
      await chrome.storage.local.set({ 'pirate-raids-v1': { ...rounds, [command.accountKey]: next } });
      return { player: (await read())[command.accountKey].find(item => item.playerName === command.playerName), round: next };
    }
    // A city checked in the game from the panel ("אמת במשחק", user decision 2026-10-27): its game ids, or why
    // the check failed; the raid then needs no check of its own for it.
    if (command.operation === 'city-check') {
      const ok = /^\d+$/.test(String(command.cityId ?? '')) && /^\d+$/.test(String(command.islandId ?? ''));
      const next = list.map(item => item.playerName !== command.playerName ? item : { ...item, cities: (item.cities ?? []).map(city => city.name !== command.name || city.x !== Number(command.x) || city.y !== Number(command.y) ? city
        : { ...city, ...(ok ? { cityId: String(command.cityId), islandId: String(command.islandId) } : {}), checkedAt: now(), checkError: ok ? null : String(command.error ?? 'העיר לא אומתה במשחק') }) });
      await chrome.storage.local.set({ [KEY]: { ...all, [command.accountKey]: next } });
      return (await read())[command.accountKey];
    }
    // The order of the list is the order of a raid round (user decision, 2026-10-27): one step up or down.
    if (command.operation === 'move') {
      const index = list.findIndex(item => item.playerName === command.playerName), to = index + (Number(command.direction) < 0 ? -1 : 1);
      if (index < 0 || to < 0 || to >= list.length) return list;
      const next = [...list];[next[index], next[to]] = [next[to], next[index]];
      await chrome.storage.local.set({ [KEY]: { ...all, [command.accountKey]: next } });
      return (await read())[command.accountKey];
    }
    // The departure city chosen for the player (user decision, 2026-10-27); none: the nearest free one.
    if (command.operation === 'origin') {
      const originCityId = /^\d+$/.test(String(command.originCityId ?? '')) ? String(command.originCityId) : null;
      await chrome.storage.local.set({ [KEY]: { ...all, [command.accountKey]: list.map(item => item.playerName === command.playerName ? { ...item, originCityId } : item) } });
      return (await read())[command.accountKey];
    }
    if (command.operation === 'remove') {
      // "הסרה" in the raids table (user decision, 2026-10-29): the player leaves the list and a running round too
      // (never the raid out right now).
      const rounds = (await chrome.storage.local.get('pirate-raids-v1'))['pirate-raids-v1'] ?? {}, round = rounds[command.accountKey];
      const index = round?.running ? round.targets.findIndex(target => target.playerName === command.playerName) : -1;
      if (index >= 0 && index === round.index && round.targets[index]?.status === 'sent') throw new Error('הפשיטה על ' + command.playerName + ' בדרך עכשיו; אפשר להסיר אותו אחרי שהצוות יחזור');
      if (index >= 0) await chrome.storage.local.set({ 'pirate-raids-v1': { ...rounds, [command.accountKey]: { ...round, targets: round.targets.filter((_, place) => place !== index), index: index < round.index ? round.index - 1 : round.index, manualOrder: true } } });
      await chrome.storage.local.set({ [KEY]: { ...all, [command.accountKey]: list.filter(item => item.playerName !== command.playerName) } });
      return (await read())[command.accountKey];
    }
    if (command.operation === 'restore') {
      const keep = new Map(list.map(item => [item.playerName, item]));
      await chrome.storage.local.set({ [KEY]: { ...all, [command.accountKey]: (command.names ?? []).slice(0, MAX).map(playerName => keep.get(playerName)?.cities ? keep.get(playerName) : builtIn(playerName)) } });
      const missing = (command.names ?? []).filter(name => !keep.get(name)?.cities && !BUILT_IN[name]);
      return missing.length ? refresh(command.accountKey, missing) : (await read())[command.accountKey];
    }
    if (command.operation === 'refresh') return refresh(command.accountKey, command.names);
    throw new Error('פעולה לא נתמכת');
  }
  return { handle, refresh, key: KEY };
}

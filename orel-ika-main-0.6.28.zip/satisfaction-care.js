// Satisfaction care (Firefox edition, user decision 2026-10-20): one automation for every city of
// every account, with three tasks only.
// 1. Wine always: a city holding less than 24 hours of its tavern's consumption (the game's own
//    rate, read with the account) gets wine from the account's city with the most to spare, up to
//    48 hours; a city whose rate was not read falls back to the 2,000 floor of the satisfaction guard.
// 2. Governor's residences: every colony's residence at the number of colonies (cities − 1, the
//    level that ends corruption), built where it is missing; the builder brings the materials and
//    adds workers. No approval is asked.
// 3. An account where both are done sends its marble, 20,000 kept in every city, to the main
//    account's marble city (the target the user set).
export const CARE_KEY = 'satisfaction-care-v1', CARE_STATUS = 'satisfaction-care-status-v1';
// Accounts whose residences are left as they are (user decision, 2026-10-22: Orakel5 is happy in
// every city and level 9 costs hundreds of thousands per city). Wine and taverns are still cared for.
// The marble of handled accounts no longer goes to the main account's marble city by default (user
// report, 2026-10-22: it had over a million there): steady supply sends each main city what it lacks.
export const CARE_DEFAULTS = { enabled: true, sendMarble: false, keepMarble: 20000, minMarble: 5000, skipGovernors: ['Orakel5'],
  target: { playerName: 'Orel Hagadol', cityName: 'שיש 6', islandName: 'Toreos', x: 52, y: 35 } };
const HOURS = 24, FILL = 48, FLOOR = 2000, MIN = 500;
const has = (city, building) => (city?.buildings ?? []).some(item => item?.building === building);
const found = (city, building) => (city?.buildings ?? []).find(item => item?.building === building);
const wineOf = city => Math.max(0, Math.floor(Number(city?.resources?.wine) || 0));
const rate = city => Number.isFinite(city?.wineConsumptionPerHour) && city.wineConsumptionPerHour > 0 ? city.wineConsumptionPerHour : null;

export function carePlan(cities, options = {}) {
  const list = Array.isArray(cities) ? cities : [], keep = options.keepMarble ?? CARE_DEFAULTS.keepMarble, least = options.minMarble ?? CARE_DEFAULTS.minMarble;
  const capital = list.find(city => city?.isCapital === true) ?? list.find(city => has(city, 'palace'));
  const needed = Math.max(0, list.length - 1);
  const governors = [];
  for (const city of options.skipGovernors === true ? [] : list) {
    if (!capital || city === capital || needed < 1) continue;
    const building = found(city, 'palaceColony'), level = Number(building?.level) || 0;
    if (level >= needed) continue;
    const position = Number.isInteger(Number(building?.position)) ? Number(building.position) : null;
    governors.push({ cityId: String(city.id), name: city.name ?? String(city.id), level, needed,
      entry: building && position !== null ? { key: position + ':palaceColony', position, target: needed, label: 'מגורי מושל' } : { key: 'new:palaceColony', position: 0, target: 1, label: 'מגורי מושל' } });
  }
  // Wine: who is short, and who can give without falling under its own 48 hours.
  const spare = city => wineOf(city) - Math.max(5000, rate(city) ? Math.ceil(rate(city) * FILL) : 0);
  const wine = [];
  for (const city of list) {
    const use = rate(city), floor = use ? Math.ceil(use * HOURS) : FLOOR;
    if (wineOf(city) >= floor) continue;
    const want = (use ? Math.ceil(use * FILL) : FLOOR * 2) - wineOf(city);
    const room = Number.isFinite(city?.storageCapacity) ? Math.max(0, city.storageCapacity - wineOf(city)) : want;
    const donor = list.filter(other => other !== city).sort((a, b) => spare(b) - spare(a))[0];
    const quantity = donor ? Math.min(want, room, spare(donor)) : 0;
    wine.push({ cityId: String(city.id), name: city.name ?? String(city.id), wine: wineOf(city), floor, from: donor && quantity >= MIN ? String(donor.id) : null, quantity: quantity >= MIN ? Math.floor(quantity) : 0 });
  }
  const handled = !!capital && list.length > 0 && !governors.length && !wine.length;
  const marble = handled ? list.map(city => ({ cityId: String(city.id), quantity: Math.floor((Number(city?.resources?.marble) || 0) - keep) })).filter(item => item.quantity >= Math.max(MIN, least)) : [];
  return { needed, capital: capital ? String(capital.id) : null, governors, wine, handled, marble };
}

// Read-only Opera metadata. No timers, listeners, reservations or game requests.
const time=value=>Number.isSafeInteger(value)&&value>0?value:null;
export function demandTiming(demand,report){
  const input=report.mainCoordinationInputs,city=report.cities.find(c=>String(c.id)===demand.cityId);
  const queue=input.queueTiming?.[demand.cityId];
  const stock=(city?.resources?.[demand.resource]??0)+(input.incoming?.[demand.cityId]?.[demand.resource]??0);
  const externalEligible=Number.isSafeInteger(demand.externalEligible)?demand.externalEligible:demand.amount;
  let planned=demand.amount-externalEligible;
  const steps=[];let clock=time(queue?.neededAt),cumulative=0,assigned=0,estimated=false;
  for(const item of queue?.items??[]){
    const cost=item.costs?.[demand.resource];
    if(Number.isSafeInteger(cost)&&cost>=0)cumulative+=cost;
    const gap=Math.min(demand.amount,Math.ceil(Math.max(0,cumulative-stock)/500)*500),amount=gap-assigned;
    if(amount>0){const covered=Math.min(planned,amount);planned-=covered;steps.push({building:item.building,level:item.level,amount,externalAmount:amount-covered,neededAt:clock,estimated,source:item.list?'game-list':'extension-target',costSource:item.costSource==='live-game-quote'?'live-game-quote':'table-estimate'});assigned=gap;}
    const seconds=item.seconds;
    clock=clock!==null&&Number.isFinite(seconds)&&seconds>=0&&Number.isSafeInteger(clock+Math.ceil(seconds*1000))?clock+Math.ceil(seconds*1000):null;
    estimated=true; // Future completion depends on resources, start time and later queue execution.
  }
  const critical=demand.resource==='wine'&&report.wine?.criticalCityIds?.includes(demand.cityId);
  const drain=(city?.wineConsumptionPerHour??NaN)-(city?.productionPerHour?.wine??NaN);
  const depletion=critical&&Number.isFinite(drain)&&drain>0&&Number.isSafeInteger(city?.resources?.wine)?time(report.scannedAt+Math.floor(city.resources.wine/drain*3600000)):null;
  const allKnown=steps.length>0&&steps.every(s=>s.neededAt!==null),buildingAt=allKnown?Math.min(...steps.map(s=>s.neededAt)):null;
  const neededAt=critical?depletion===null?buildingAt:buildingAt===null?depletion:Math.min(depletion,buildingAt):buildingAt;
  const externalSteps=steps.filter(s=>s.externalAmount>0),externalAt=externalSteps.length&&externalSteps.every(s=>s.neededAt!==null)?Math.min(...externalSteps.map(s=>s.neededAt)):null;
  return {neededAt,externalNeededAt:critical?neededAt:externalAt,internalPlannedAmount:demand.amount-externalEligible,priority:critical?'critical-wine':steps.length||demand.purpose==='construction'?'construction':'wine-balance',basis:critical&&neededAt===depletion?'wine-depletion':buildingAt!==null?steps.some(s=>s.estimated)?'queue-estimate':'game-queue':'unknown',steps,unmappedAmount:demand.amount-assigned,travelEstimate:null};
}
// Consumers must recompute dispatch time with THEIR origin/queue and a fresh game quote.
export function compareDemandTiming(a,b){
  const rank=d=>({ 'critical-wine':0,construction:1,'wine-balance':2 }[d.timing?.priority]??1);
  const due=d=>d.timing&&Object.hasOwn(d.timing,'externalNeededAt')?d.timing.externalNeededAt:d.timing?.neededAt;
  return rank(a)-rank(b)||(due(a)??Infinity)-(due(b)??Infinity)||a.cityId.localeCompare(b.cityId)||a.resource.localeCompare(b.resource);
}

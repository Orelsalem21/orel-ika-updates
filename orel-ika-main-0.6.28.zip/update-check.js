// Update check for the Opera main edition (user decision, 2026-10-16, option B): an unpacked
// extension cannot update itself, so every 6 hours the agent reads opera.json in the public
// repository github.com/Orelsalem21/orel-ika-updates and, when it names a newer version, keeps
// it in update-available-v1; the panel shows it with the download link. Nothing is installed.
const KEY='update-available-v1',EVERY_MS=6*3600000;
export const OPERA_UPDATE_URL='https://raw.githubusercontent.com/Orelsalem21/orel-ika-updates/main/opera.json';
// 0.5.18 < 0.5.19 < 0.6.0.
export function newer(candidate,current) {
  const a=String(candidate??'').split('.').map(Number),b=String(current??'').split('.').map(Number);
  if(!a.length||a.some(n=>!Number.isInteger(n))) return false;
  for(let i=0;i<Math.max(a.length,b.length);i++) {const x=a[i]??0,y=b[i]??0;if(x!==y) return x>y;}
  return false;
}
export function createUpdateCheck(chrome,{fetch=globalThis.fetch,now=()=>Date.now()}={}) {
  async function tick(force=false) {
    const state=(await chrome.storage.local.get(KEY))[KEY]??{};
    if(!force&&state.checkedAt&&now()-state.checkedAt<EVERY_MS) return state;
    const current=chrome.runtime.getManifest().version;
    const next={checkedAt:now(),current,version:null,link:null,error:null};
    try {
      const response=await fetch(OPERA_UPDATE_URL+'?t='+now(),{cache:'no-store'});
      if(!response.ok) throw new Error('HTTP '+response.status);
      const data=await response.json();
      // Only links into the update repository itself are shown.
      if(newer(data.version,current)&&/^https:\/\/github\.com\/Orelsalem21\/orel-ika-updates\//.test(String(data.link??''))) {next.version=String(data.version);next.link=String(data.link);}
    } catch(error) {next.error=String(error?.message??error);}
    await chrome.storage.local.set({[KEY]:next});
    return next;
  }
  return {tick,key:KEY};
}
